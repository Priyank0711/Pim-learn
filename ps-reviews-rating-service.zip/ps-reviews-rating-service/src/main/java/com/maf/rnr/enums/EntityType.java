package com.maf.rnr.enums;

import lombok.Getter;

@Getter
public enum EntityType {
    SELLER,
    PRODUCT
}
