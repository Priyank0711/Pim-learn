package com.maf.rnr.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
@Getter
public enum FeedbackType {
    UP("up"),
    DOWN("down"),
    RESET("reset"),
    BAD("bad");

    final String val;
}
