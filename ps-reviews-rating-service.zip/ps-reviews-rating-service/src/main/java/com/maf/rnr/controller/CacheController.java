package com.maf.rnr.controller;

import com.maf.rnr.enums.Country;
import com.maf.rnr.service.CacheService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

@RestController
@Slf4j
@RequestMapping("/{country}/cache")
public class CacheController {

    private final CacheService cacheService;

    public CacheController(CacheService cacheService) {
        this.cacheService = cacheService;
    }

    @GetMapping("/clear")
    public void clearCache(@RequestParam(required = false) List<String> cacheNames, @PathVariable("country") Country country) {
        if(Objects.isNull(cacheNames)){
            cacheNames = new ArrayList<>();
        }
        cacheService.refreshAllCache(cacheNames);
    }
}
