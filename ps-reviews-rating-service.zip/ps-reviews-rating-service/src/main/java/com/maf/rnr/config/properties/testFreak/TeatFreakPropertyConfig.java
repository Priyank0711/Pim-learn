package com.maf.rnr.config.properties.testFreak;


import com.maf.rnr.enums.EntityType;
import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
@ConfigurationProperties(prefix = "test-freak")
@Getter
@Setter
public class TeatFreakPropertyConfig {

    private List<TestFreakProperties> properties;
    private TestFreakBaseUrls baseUrls;


    public TestFreakProperties get(EntityType type) {
        return properties.stream()
                .filter(template -> type.equals(template.getType()))
                .findFirst()
                .orElseThrow();
    }
}
