package com.maf.rnr.job.impl;

import com.maf.rnr.dto.RatingData;
import com.maf.rnr.dto.testFreak.TFRatingDTO;
import com.maf.rnr.dto.testFreak.TFRatingResponse;
import com.maf.rnr.enums.Country;
import com.maf.rnr.enums.EntityType;
import com.maf.rnr.job.RatingFetcher;
import com.maf.rnr.service.RatingService;
import com.maf.rnr.service.TestFreakService;
import com.maf.rnr.utils.CommonUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.util.List;
import java.util.Objects;

@Slf4j
@Service
public class RatingFetcherImpl implements RatingFetcher {

    private final TestFreakService testFreakService;
    private final RatingService ratingService;
    private final KafkaTemplate<String, RatingData> ratingKafkaProducer;

    @Value("kafka.rating.topic")
    private String ratingTopicName;

    public RatingFetcherImpl(TestFreakService testFreakService, RatingService ratingService, KafkaTemplate<String, RatingData> ratingKafkaProducer) {
        this.testFreakService = testFreakService;
        this.ratingService = ratingService;
        this.ratingKafkaProducer = ratingKafkaProducer;
    }

    @Override
    public void fetch(Country country, EntityType entityType) {
        TFRatingResponse response = new TFRatingResponse();
        do {
            String after = null;
            //set after to null if response link is null or link next is null and if next is present then set it to next
            if(Objects.nonNull(response.getLinks()) && Objects.nonNull(response.getLinks().getNext())) {
                after = CommonUtils.getQueryParams(response.getLinks().getNext()).get("after");
            }
            log.info("{}-{} Started fetching Ratings", country, entityType);
            response = testFreakService.fetchRatings(after, country, entityType);
            sendToDownStream(response.getData(), entityType, country);
        } while (Objects.nonNull(response.getLinks()) && Objects.nonNull(response.getLinks().getNext()));
    }

    private void sendToDownStream(List<TFRatingDTO> data, EntityType entityType, Country country) {
        //send data to downstream
        if(CollectionUtils.isEmpty(data)){
            log.info("No data for sending to kafka");
        } else {
            log.info("Sending {} ratings to kafka", data.size());
            data.parallelStream().forEach(rating -> {
                RatingData ratingData = ratingService.getRatingData(rating, entityType, rating.getId(), country);
//                ratingKafkaProducer.send(ratingTopicName, ratingData);
            });
        }
    }

}
