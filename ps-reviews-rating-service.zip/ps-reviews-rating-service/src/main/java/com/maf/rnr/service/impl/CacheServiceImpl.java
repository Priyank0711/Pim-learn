package com.maf.rnr.service.impl;


import com.maf.rnr.dto.RatingData;
import com.maf.rnr.enums.Country;
import com.maf.rnr.enums.EntityType;
import com.maf.rnr.service.CacheService;
import com.maf.rnr.utils.Constants;
import lombok.extern.slf4j.Slf4j;
import org.springframework.cache.Cache;
import org.springframework.cache.CacheManager;
import org.springframework.cache.annotation.CachePut;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.util.Collection;
import java.util.Optional;

@Service
@Slf4j
public class CacheServiceImpl implements CacheService {

    private final CacheManager cacheManager;

    public CacheServiceImpl(CacheManager cacheManager) {
        this.cacheManager = cacheManager;
    }

    @Override
    public void refreshAllCache(Collection<String> cacheNames) {
        if(CollectionUtils.isEmpty(cacheNames)) {
            cacheNames = cacheManager.getCacheNames();
        }
        for (String cacheKey : cacheNames) {
            log.info("Cache Evicted for - {}", cacheKey);
            Cache c = cacheManager.getCache(cacheKey);
            if(c!=null){
                c.clear();
            }
        }
    }

    @Override
    public Optional<RatingData> getEntityRating(String entityId, EntityType entityType, Country country) {
        Cache cache = cacheManager.getCache(Constants.RATING_CACHE);
        if (cache != null) {
            String key = entityType + "_" + entityId + "_" + country;
            return Optional.ofNullable(cache.get(key, RatingData.class));
        }
        return Optional.empty();
    }

    @CachePut(value = Constants.RATING_CACHE, key = "#entityType + '_' + #id + '_' + #country")
    @Override
    public RatingData saveRatingToCache(RatingData data, EntityType entityType, String id, Country country) {
        return data;
    }
}
