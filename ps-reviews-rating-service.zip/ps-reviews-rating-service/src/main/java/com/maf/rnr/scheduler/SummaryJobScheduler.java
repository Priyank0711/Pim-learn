package com.maf.rnr.scheduler;

import com.maf.rnr.enums.EntityType;
import com.maf.rnr.job.RatingFetcher;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;

@Slf4j
public class SummaryJobScheduler {

    @Autowired
    private RatingFetcher fetcher;

    @Scheduled(cron="${summary.job.product.cron}")
    public void scheduleSummaryJob_Product_UAE() {
        log.info("product summary_scheduleJob_uae started.");
        fetcher.fetch(com.maf.rnr.enums.Country.UAE, EntityType.PRODUCT);
        log.info("product summary_scheduleJob_uae finished.");
    }

    @Scheduled(cron="${summary.job.seller.cron}")
    public void scheduleSummaryJob_Seller_UAE() {
        log.info("seller summary_scheduleJob_uae started.");
        fetcher.fetch(com.maf.rnr.enums.Country.UAE, EntityType.SELLER);
        log.info("seller summary_scheduleJob_uae finished.");
    }
}