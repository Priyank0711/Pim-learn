package com.maf.rnr.config.properties.testFreak;

import com.maf.rnr.enums.EntityType;
import lombok.Data;

@Data
public class TestFreakProperties {

    private EntityType type;
    private String clientId;
    private Integer summaryPageSize;
}
