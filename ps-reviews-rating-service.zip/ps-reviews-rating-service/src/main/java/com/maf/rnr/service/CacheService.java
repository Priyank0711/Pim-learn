package com.maf.rnr.service;

import com.maf.rnr.dto.RatingData;
import com.maf.rnr.enums.Country;
import com.maf.rnr.enums.EntityType;

import java.util.Collection;
import java.util.Optional;

public interface CacheService {

    void refreshAllCache(Collection<String> cacheNames);

    Optional<RatingData> getEntityRating(String entityId, EntityType entityType, Country country);

    RatingData saveRatingToCache(RatingData data, EntityType entityType, String id, Country country);
}
