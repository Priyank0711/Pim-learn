package com.maf.rnr.job;

import com.maf.rnr.enums.Country;
import com.maf.rnr.enums.EntityType;

public interface RatingFetcher {
     void fetch(Country country, EntityType entityType);
}
