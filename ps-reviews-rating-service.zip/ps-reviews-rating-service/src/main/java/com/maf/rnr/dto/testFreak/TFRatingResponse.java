package com.maf.rnr.dto.testFreak;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.maf.rnr.dto.NextPageLink;
import lombok.Data;

import java.io.Serial;
import java.io.Serializable;
import java.util.List;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class TFRatingResponse implements Serializable {
    @Serial
    private static final long serialVersionUID = -3403755079303073713L;
    private List<TFRatingDTO> data;
    private NextPageLink links;

}
