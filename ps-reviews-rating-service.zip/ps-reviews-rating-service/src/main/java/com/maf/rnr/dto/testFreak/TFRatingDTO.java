package com.maf.rnr.dto.testFreak;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import lombok.Data;

import java.util.List;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
public class TFRatingDTO {

    private Double score;
    private Double yourAvgScore;

    private Integer proReviewCount;
    private Integer userReviewCount;
    private Integer yourReviewCount;

    private List<Integer> proScoreDistAll;
    private List<Integer> userScoreDistAll;
    private List<Integer> yourScoreDist;

    private List<String> productPros;
    private List<String> productCons;

    private String id;
    private String familyId;
    private String title;

    private String proReviewUrl;
    private String userReviewUrl;
    private String yourReviewUrl;
}
