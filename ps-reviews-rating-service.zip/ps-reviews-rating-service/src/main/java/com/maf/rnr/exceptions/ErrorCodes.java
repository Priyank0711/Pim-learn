package com.maf.rnr.exceptions;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum ErrorCodes {

    INTERNAL_SERVER_ERROR(500001, "Something went wrong, Please try after sometime."),
    BAD_REVIEW_FILTER_REQUEST(400001, "Bad Filter - %s");

    final Integer code;
    final String message;

}
