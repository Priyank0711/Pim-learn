package com.maf.rnr.enums;

import lombok.Getter;

@Getter
public enum ReviewType {
    pro,
    user,
    customer
}
