package com.maf.rnr.controller;


import com.maf.rnr.dto.*;
import com.maf.rnr.enums.Country;
import com.maf.rnr.enums.ReviewFilter;
import com.maf.rnr.exceptions.ApiErrors;
import com.maf.rnr.exceptions.ApiException;
import com.maf.rnr.exceptions.ErrorCodes;
import com.maf.rnr.service.RatingService;
import com.maf.rnr.service.ReviewService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/{country}")
@Slf4j
@AllArgsConstructor
@Validated
@Tag(name = "Review Rating Controller", description = "APIs for reviews and ratings and feedback")
public class ReviewRatingController {

    private final ReviewService reviewService;
    private final RatingService ratingService;


    @PostMapping("/ratings")
    @Operation(summary = "Get ratings/summary for seller or product", description = "Get ratings/summary for seller or product")
    public ResponseEntity<List<RatingData>> getRatings(
            @Valid @RequestBody List<RatingRequest> requests,
            @PathVariable("country") Country country) {

        return ResponseEntity.ok(ratingService.getRatings(country, requests));

    }

    @PostMapping("/reviews")
    @Operation(summary = "Get reviews list for seller or product", description = "Get reviews list for seller or product")
    public ResponseEntity<List<EntityReview>> getReviews(
            @Valid @RequestBody ReviewRequest request,
            @PathVariable("country") Country country) {

        validateFilters(request.getFilters());
        List<EntityReview> reviews = reviewService.getReviewDetails(country, request);
        return ResponseEntity.ok().body(reviews);

    }

    @PostMapping("/feedback")
    @Operation(summary = "Submit feedback for reviews", description = "Submit feedback for reviews")
    public ResponseEntity<Object> submitFeedback(
            @Valid @RequestBody ReviewFeedbackRequest request,
            @PathVariable("country") Country country) {

        reviewService.submitFeedback(country, request);
        return ResponseEntity.ok().body("Feedback submitted successfully");

    }

    private void validateFilters(Map<ReviewFilter, Object> filters) {
        filters.forEach((filter, value) -> {
            switch (filter) {
                case SCORE -> {
                    if (!(value instanceof Integer score) || score < 1 || score > 5) {
                        throw new ApiException(new ApiErrors(
                                ErrorCodes.BAD_REVIEW_FILTER_REQUEST, "Score must be an integer between 1 and 5."));
                    }
                }
                case GALLERY -> {
                    if (!(value instanceof Boolean)) {
                        throw new ApiException(new ApiErrors(
                                ErrorCodes.BAD_REVIEW_FILTER_REQUEST, "Gallery must be a boolean value (true or false)."));
                    } else {
                        filters.put(ReviewFilter.GALLERY, (Boolean) value? 1: 0);
                    }
                }
            }
        });
    }
}
