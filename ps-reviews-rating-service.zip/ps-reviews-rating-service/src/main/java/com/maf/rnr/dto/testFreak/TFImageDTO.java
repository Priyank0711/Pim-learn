package com.maf.rnr.dto.testFreak;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import lombok.Data;

import java.io.Serial;
import java.io.Serializable;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
public class TFImageDTO implements Serializable {

    @Serial
    private static final long serialVersionUID = 4755077563939265097L;
    private String icon;
    private Integer iconWidth;
    private Integer iconHeight;

    private String medium;
    private Integer mediumWidth;
    private Integer mediumHeight;

    private String large;
    private Integer largeWidth;
    private Integer largeHeight;

}
