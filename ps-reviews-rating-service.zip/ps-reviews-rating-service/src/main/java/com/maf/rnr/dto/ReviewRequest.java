package com.maf.rnr.dto;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.maf.rnr.enums.EntityType;
import com.maf.rnr.enums.ReviewFilter;
import com.maf.rnr.enums.ReviewSort;
import com.maf.rnr.enums.ReviewType;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

import java.io.Serial;
import java.io.Serializable;
import java.util.EnumSet;
import java.util.List;
import java.util.Map;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class ReviewRequest implements Serializable {

    @Serial
    private static final long serialVersionUID = 8825026461121957911L;
    @NotEmpty(message = "ids is required")
    @NotNull(message = "ids is required")
    private List<String> ids;
    @NotNull(message = "entityType is required")
    private EntityType entityType;
    private EnumSet<ReviewType> reviewTypes;
    private Integer limit;
    private Integer offset;
    private ReviewSort sortBy;

    @Schema(description = "Filters applicable to the reviews",
            example = "{\"SCORE\": 5, \"GALLERY\": true}")
    private Map<ReviewFilter, Object> filters;
}
