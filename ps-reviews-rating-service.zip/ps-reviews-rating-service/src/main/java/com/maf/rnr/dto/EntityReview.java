package com.maf.rnr.dto;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.maf.rnr.enums.ReviewType;
import lombok.Data;

import java.io.Serial;
import java.io.Serializable;
import java.util.Map;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class EntityReview implements Serializable {

    @Serial
    private static final long serialVersionUID = 6801612748113673632L;
    private String id;
    private Map<ReviewType, ReviewTypeDetail> data;

}
