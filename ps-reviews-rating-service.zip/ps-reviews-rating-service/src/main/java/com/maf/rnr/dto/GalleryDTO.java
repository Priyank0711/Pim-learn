package com.maf.rnr.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.maf.rnr.enums.GalleryType;
import lombok.Data;

import java.io.Serial;
import java.io.Serializable;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class GalleryDTO implements Serializable {

    @Serial
    private static final long serialVersionUID = 492123682100512041L;
    private String icon;
    private Integer iconWidth;
    private Integer iconHeight;

    private String medium;
    private Integer mediumWidth;
    private Integer mediumHeight;

    private String large;
    private Integer largeWidth;
    private Integer largeHeight;

    private GalleryType type;

}
