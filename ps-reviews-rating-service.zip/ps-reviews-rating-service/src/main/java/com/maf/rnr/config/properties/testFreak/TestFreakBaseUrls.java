package com.maf.rnr.config.properties.testFreak;

import lombok.Data;

@Data
public class TestFreakBaseUrls {
    private String summaryUrl;
    private String displayUrl;
    private String externalReviewUrl;
    private String customerReviewUrl;
    private String externalFeedbackUrl;
    private String customerFeedbackUrl;

}
