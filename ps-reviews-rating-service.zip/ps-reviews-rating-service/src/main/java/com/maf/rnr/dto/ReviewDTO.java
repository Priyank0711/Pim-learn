package com.maf.rnr.dto;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.maf.rnr.enums.ReviewType;
import lombok.Data;

import java.io.Serial;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class ReviewDTO implements Serializable {
    @Serial
    private static final long serialVersionUID = -8726784389261790944L;
    private ReviewType type;
    private String source;
    private String domain;
    private String title;

    private String clientId;
    private String productId;
    private String product;
    private String author;

    private Double score;
    private Double scoreMax;
    private String extract;
    private String pros;
    private String cons;

    private String date;
    private String country;
    private String lang;
    private Boolean verifiedBuyer;

    private Integer votesUp;
    private Integer votesDown;

    private String logo;
    private Integer logoWidth;
    private Integer logoHeight;

    private String icon;
    private Integer iconWidth;
    private Integer iconHeight;

    private String reviewId;

    private List<GalleryDTO> gallery = new ArrayList<>();
}
