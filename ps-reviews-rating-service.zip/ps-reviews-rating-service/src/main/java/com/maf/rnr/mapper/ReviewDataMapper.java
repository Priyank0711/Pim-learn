package com.maf.rnr.mapper;

import com.maf.rnr.dto.ReviewDTO;
import com.maf.rnr.dto.testFreak.TFReviewDTO;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;
import org.mapstruct.factory.Mappers;
import org.springframework.util.StringUtils;

import java.net.URI;
import java.util.List;

@Mapper()
public interface ReviewDataMapper {

    ReviewDataMapper INSTANCE = Mappers.getMapper(ReviewDataMapper.class);

    @Mapping(target = "gallery", ignore = true)
    @Mapping(target = "reviewId", source = "feedbackUrl", qualifiedByName = "getReviewId")
    ReviewDTO convertToReviewData(TFReviewDTO dto);

    List<ReviewDTO> convertToReviewData(List<TFReviewDTO> dto);

    @Named(value = "getReviewId")
    default String getReviewId(String feedbackUrl){
        if (StringUtils.hasText(feedbackUrl)) {
            try {
                URI uri = new URI(feedbackUrl);
                String path = uri.getPath();
                String[] segments = path.split("/");
                return segments.length > 2 ? segments[segments.length - 2] : null;
            } catch (Exception e) {
                return null;
            }
        }
        return null;
    }

}
