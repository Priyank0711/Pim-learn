package com.maf.rnr.exceptions;

import com.google.gson.Gson;
import jakarta.validation.ConstraintViolation;
import jakarta.validation.ConstraintViolationException;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.support.DefaultMessageSourceResolvable;
import org.springframework.http.*;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@ControllerAdvice
@Slf4j
public class RNRExceptionHandler extends ResponseEntityExceptionHandler {

    @Getter
    @Setter
    @NoArgsConstructor
    class ErrorBody {
        private List<String> messages;
    }

    private static final Gson gson = new Gson();

    @ExceptionHandler(value = {ApiException.class})
    protected ResponseEntity<ErrorBody> handleApiException(ApiException e, WebRequest request) {
        ErrorBody errorBody = new ErrorBody();
        List<String> messages = new ArrayList<>();
        messages.add(e.getApiErrors().message);
        errorBody.setMessages(messages);
        return ResponseEntity.status(e.getApiErrors().code/1000).body(errorBody);
    }

    @ExceptionHandler({ ConstraintViolationException.class})
    public ResponseEntity<Object> handleConstraintViolation(
            ConstraintViolationException ex, WebRequest request) {
        HttpHeaders headers= new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        ErrorBody errorBody = new ErrorBody();
        List<String> messages = new ArrayList<>();
        for (ConstraintViolation<?> violation : ex.getConstraintViolations()) {
            messages.add(violation.getPropertyPath() + ": " + violation.getMessage());
        }
        errorBody.setMessages(messages);
        return handleExceptionInternal(ex,gson.toJson(errorBody),headers,HttpStatus.BAD_REQUEST,request);
    }

    @ExceptionHandler({ MethodArgumentTypeMismatchException.class})
    public ResponseEntity<Object> handleConstraintViolation(
            MethodArgumentTypeMismatchException ex, WebRequest request) {
        HttpHeaders headers= new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        ErrorBody errorBody = new ErrorBody();
        List<String> messages = new ArrayList<>();
        if(ex.getRootCause() != null){
            messages.add(ex.getRootCause().getMessage());
        } else {
            messages.add(ex.getMessage());
        }
        errorBody.setMessages(messages);
        return handleExceptionInternal(ex,gson.toJson(errorBody),headers,HttpStatus.BAD_REQUEST,request);
    }

    @Override
    public ResponseEntity<Object> handleMissingServletRequestParameter(
            MissingServletRequestParameterException ex, HttpHeaders h, HttpStatusCode status, WebRequest request) {
        HttpHeaders headers= new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        ErrorBody errorBody = new ErrorBody();
        List<String> messages = new ArrayList<>();
        messages.add(ex.getMessage());
        errorBody.setMessages(messages);
        return handleExceptionInternal(ex,gson.toJson(errorBody),headers,HttpStatus.BAD_REQUEST,request);
    }

    @Override
    public ResponseEntity<Object> handleMethodArgumentNotValid(MethodArgumentNotValidException ex, HttpHeaders headers, HttpStatusCode status, WebRequest request) {

        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.setContentType(MediaType.APPLICATION_JSON);
        ErrorBody errorBody = new ErrorBody();
        List<String> errors = ex.getBindingResult()
                .getFieldErrors()
                .stream()
                .map(DefaultMessageSourceResolvable::getDefaultMessage)
                .collect(Collectors.toList());
        errorBody.setMessages(errors);

        return handleExceptionInternal(ex,gson.toJson(errorBody),httpHeaders,HttpStatus.BAD_REQUEST,request);
    }

    @Override
    protected ResponseEntity<Object> handleHttpMessageNotReadable(HttpMessageNotReadableException ex, HttpHeaders headers, HttpStatusCode status, WebRequest request) {
        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.setContentType(MediaType.APPLICATION_JSON);
        ErrorBody errorBody = new ErrorBody();
        List<String> errors = List.of(ex.getLocalizedMessage());
        errorBody.setMessages(errors);
        return handleExceptionInternal(ex,gson.toJson(errorBody),httpHeaders,HttpStatus.BAD_REQUEST,request);
    }
}