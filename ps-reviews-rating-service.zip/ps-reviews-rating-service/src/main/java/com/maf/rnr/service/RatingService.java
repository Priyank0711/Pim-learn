package com.maf.rnr.service;

import com.maf.rnr.dto.RatingData;
import com.maf.rnr.dto.RatingRequest;
import com.maf.rnr.dto.testFreak.TFRatingDTO;
import com.maf.rnr.enums.Country;
import com.maf.rnr.enums.EntityType;

import java.util.List;

public interface RatingService {

    List<RatingData> getRatings(Country country, List<RatingRequest> requests);

    RatingData getRatingData(TFRatingDTO rating, EntityType entityType, String id, Country country);
}
