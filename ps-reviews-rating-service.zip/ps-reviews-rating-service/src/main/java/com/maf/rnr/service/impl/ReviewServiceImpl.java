package com.maf.rnr.service.impl;

import com.maf.rnr.dto.*;
import com.maf.rnr.dto.testFreak.TFRatingDTO;
import com.maf.rnr.dto.testFreak.TFReviewDTO;
import com.maf.rnr.dto.testFreak.TFReviewResponse;
import com.maf.rnr.enums.Country;
import com.maf.rnr.enums.EntityType;
import com.maf.rnr.enums.ReviewSort;
import com.maf.rnr.enums.ReviewType;
import com.maf.rnr.exceptions.ApiErrors;
import com.maf.rnr.exceptions.ApiException;
import com.maf.rnr.exceptions.ErrorCodes;
import com.maf.rnr.mapper.GalleryMapper;
import com.maf.rnr.mapper.ReviewDataMapper;
import com.maf.rnr.service.CacheService;
import com.maf.rnr.service.ReviewService;
import com.maf.rnr.service.TestFreakService;
import com.maf.rnr.utils.CommonUtils;
import com.maf.rnr.utils.Constants;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.util.*;

@Slf4j
@Service
public class ReviewServiceImpl implements ReviewService {

    private final TestFreakService testFreakService;

    public ReviewServiceImpl(TestFreakService testFreakService, CacheService cacheService) {
        this.testFreakService = testFreakService;
    }

    @Override
    public List<EntityReview> getReviewDetails(Country country, ReviewRequest request) {
        try {
            List<EntityReview> entityReviews = new ArrayList<>();
            Map<String, Object> sortAndFilter = getSortAndFilterMap(request);
            EnumSet<ReviewType> reviewTypes = Optional.ofNullable(request.getReviewTypes())
                    .filter(list -> !list.isEmpty())
                    .orElse(EnumSet.allOf(ReviewType.class));


            request.getIds().forEach(entityId -> {
                TFRatingDTO ratingDisplayDTO = testFreakService.fetchRatingDisplay(entityId, country, request.getEntityType());
                Map<ReviewType, String> urlKeyMap = getUrlKeyMap(ratingDisplayDTO);
                entityReviews.add(
                        getEntityDetailReviews(country, entityId, request.getEntityType(), reviewTypes, sortAndFilter, urlKeyMap)
                );
            });

            return entityReviews;
        } catch (ApiException e) {
            throw e;
        } catch (Exception e) {
            log.error("Error while fetching reviews", e);
            throw new ApiException(new ApiErrors(ErrorCodes.INTERNAL_SERVER_ERROR));
        }
    }

    @Override
    public void submitFeedback(Country country, ReviewFeedbackRequest request) {
        testFreakService.submitFeedback(country, request);
    }

    private EntityReview getEntityDetailReviews(Country country, String entityId, EntityType entityType,
                                                EnumSet<ReviewType> reviewTypes, Map<String, Object> sortAndFilter,
                                                Map<ReviewType, String> urlKeyMap) {
        EntityReview entityReview = new EntityReview();
        entityReview.setId(entityId);
        Map<ReviewType, ReviewTypeDetail> data = new HashMap<>();

        reviewTypes.parallelStream().forEach(type -> {
            TFReviewResponse response = testFreakService.fetchReviews(urlKeyMap.get(type), country, entityType, type, sortAndFilter);
            ReviewTypeDetail reviewTypeDetail = new ReviewTypeDetail();
            reviewTypeDetail.setReviews(Optional.ofNullable(response.getReviews()).map(this::mapToReviewDTO)
                    .orElse(Collections.emptyList()));
            String offsetStr = CommonUtils.getQueryParams(response.getNextPageUrl()).get("offset");
            Integer offset = offsetStr != null ? Integer.valueOf(offsetStr) : null;
            reviewTypeDetail.setOffset(offset);
            data.put(type, reviewTypeDetail);
        });

        entityReview.setData(data);
        return entityReview;
    }


    private Map<ReviewType, String> getUrlKeyMap(TFRatingDTO ratingDisplayDTO) {
        return Map.of(
                ReviewType.user, CommonUtils.getQueryParams(ratingDisplayDTO.getUserReviewUrl()).getOrDefault("pid", ""),
                ReviewType.pro, CommonUtils.getQueryParams(ratingDisplayDTO.getProReviewUrl()).getOrDefault("pid", ""),
                ReviewType.customer, CommonUtils.getQueryParams(ratingDisplayDTO.getYourReviewUrl()).getOrDefault("mapping_ids%5B%5D", "")
        );
    }

    private List<ReviewDTO> mapToReviewDTO(List<TFReviewDTO> tfReviewDTOS) {
        List<ReviewDTO> dtos = new ArrayList<>();
        tfReviewDTOS.forEach(tfReviewDTO -> {
            ReviewDTO dto = ReviewDataMapper.INSTANCE.convertToReviewData(tfReviewDTO);
            List<GalleryDTO> images = GalleryMapper.INSTANCE.convertToGallery(tfReviewDTO.getImages());
            if(!CollectionUtils.isEmpty(images)){
                dto.getGallery().addAll(images);
            }
            dtos.add(dto);
        });
        return dtos;
    }

    private static Map<String, Object> getSortAndFilterMap(ReviewRequest request) {
        Map<String, Object> sortAndFilter = new HashMap<>();
        sortAndFilter.put("limit", Objects.isNull(request.getLimit()) ? Constants.DEFAULT_DETAIL_REVIEW_LIMIT : request.getLimit());
        sortAndFilter.put("offset", Objects.isNull(request.getOffset()) ? 0 : request.getOffset());
        sortAndFilter.put("sort", Objects.isNull(request.getSortBy()) ? ReviewSort.RELEVANCE.getKey() : request.getSortBy().getKey());

        request.getFilters().forEach((k, v) -> sortAndFilter.put(k.getKey(), v));
        return sortAndFilter;
    }
}
