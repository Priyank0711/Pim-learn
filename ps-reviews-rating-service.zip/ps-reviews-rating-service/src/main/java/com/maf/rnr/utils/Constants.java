package com.maf.rnr.utils;

public class Constants {

    public static final Integer DEFAULT_DETAIL_REVIEW_LIMIT = 10;


    public static final String RATING_DISPLAY_CACHE = "ratingDisplayCache";

    public static final String REVIEW_DETAIL_CACHE = "reviewDetailCache";
    public static final String RATING_CACHE = "ratingCache";
}
