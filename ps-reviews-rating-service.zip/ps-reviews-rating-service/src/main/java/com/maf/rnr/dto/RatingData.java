package com.maf.rnr.dto;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.maf.rnr.enums.Country;
import com.maf.rnr.enums.EntityType;
import lombok.Data;

import java.io.Serial;
import java.io.Serializable;
import java.util.List;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class RatingData implements Serializable {

    @Serial
    private static final long serialVersionUID = 4568343426331950764L;
    private Double score;
    private Double yourAvgScore;

    private Integer proReviewCount;
    private Integer userReviewCount;
    private Integer yourReviewCount;

    private List<Integer> proScoreDistAll;
    private List<Integer> userScoreDistAll;
    private List<Integer> yourScoreDist;

    private List<String> productPros;
    private List<String> productCons;

    private String id;
    private String familyId;
    private String title;
    private EntityType entityType;
    private Country country;
}
