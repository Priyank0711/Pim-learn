package com.maf.rnr.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
@Getter
public enum ReviewSort {
    SCORE("score"),
    SCORE_ASC("score:asc"),
    DATE_ASC("date:asc"),
    DATE("date"),
    RELEVANCE("relevance");

    final String key;
}
