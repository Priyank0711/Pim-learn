package com.maf.rnr.service;

import com.maf.rnr.dto.EntityReview;
import com.maf.rnr.dto.ReviewFeedbackRequest;
import com.maf.rnr.dto.ReviewRequest;
import com.maf.rnr.enums.Country;
import jakarta.validation.Valid;

import java.util.List;

public interface ReviewService {

    List<EntityReview> getReviewDetails(Country country, ReviewRequest request);

    void submitFeedback(Country country, @Valid ReviewFeedbackRequest request);
}
