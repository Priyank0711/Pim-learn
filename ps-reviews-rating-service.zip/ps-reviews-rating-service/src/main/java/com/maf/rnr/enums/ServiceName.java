package com.maf.rnr.enums;

import lombok.Getter;

@Getter
public enum ServiceName {
    TEST_FREAK
}
