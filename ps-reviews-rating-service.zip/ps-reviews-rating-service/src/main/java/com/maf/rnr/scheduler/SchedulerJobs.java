package com.maf.rnr.scheduler;

import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class SchedulerJobs {
    @Bean
    @ConditionalOnProperty(value = "summary.job.enabled", matchIfMissing = true, havingValue = "true")
    public SummaryJobScheduler summaryJobScheduler() { return new SummaryJobScheduler(); }
}
