package com.maf.rnr.service;

import com.maf.rnr.dto.ReviewFeedbackRequest;
import com.maf.rnr.dto.testFreak.TFRatingDTO;
import com.maf.rnr.dto.testFreak.TFRatingResponse;
import com.maf.rnr.dto.testFreak.TFReviewResponse;
import com.maf.rnr.enums.Country;
import com.maf.rnr.enums.EntityType;
import com.maf.rnr.enums.ReviewType;

import java.util.Map;

public interface TestFreakService {

    TFRatingResponse fetchRatings(String after, Country country, EntityType entityType);

    TFRatingDTO fetchRatingDisplay(String key, Country country, EntityType entityType);

    TFReviewResponse fetchReviews(String key, Country country, EntityType entityType, ReviewType type,
                                  Map<String, Object> sortAndFilter);

    void submitFeedback(Country country, ReviewFeedbackRequest request);
}
