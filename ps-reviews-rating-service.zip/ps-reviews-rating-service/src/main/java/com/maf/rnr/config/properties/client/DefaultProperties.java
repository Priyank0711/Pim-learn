package com.maf.rnr.config.properties.client;

import lombok.Data;

@Data
public class DefaultProperties {
    private Long connectionTimeout;
    private Long readTimeout;
    private Integer noOfRetries;
    private Long retryDelay;
}
