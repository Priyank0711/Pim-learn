package com.maf.rnr.dto;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.maf.rnr.enums.EntityType;
import com.maf.rnr.enums.FeedbackType;
import com.maf.rnr.enums.ReviewType;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

import java.io.Serial;
import java.io.Serializable;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class ReviewFeedbackRequest implements Serializable {


    @Serial
    private static final long serialVersionUID = -8888427683277456423L;

    @NotNull(message = "feedbackType is required")
    private FeedbackType feedbackType;
    private String comment;

    @NotNull(message = "voterId is required")
    private String voterId;

    @NotNull(message = "entityType is required")
    private EntityType entityType;
    @NotNull(message = "reviewType is required")
    private ReviewType reviewType;

    @NotNull(message = "reviewId is required")
    private String reviewId;
}
