package com.maf.rnr.service.impl;

import com.maf.rnr.config.properties.testFreak.TeatFreakPropertyConfig;
import com.maf.rnr.config.properties.testFreak.TestFreakProperties;
import com.maf.rnr.dto.ReviewFeedbackRequest;
import com.maf.rnr.dto.testFreak.TFRatingDTO;
import com.maf.rnr.dto.testFreak.TFRatingResponse;
import com.maf.rnr.dto.testFreak.TFReviewResponse;
import com.maf.rnr.enums.Country;
import com.maf.rnr.enums.EntityType;
import com.maf.rnr.enums.ReviewType;
import com.maf.rnr.exceptions.ApiErrors;
import com.maf.rnr.exceptions.ApiException;
import com.maf.rnr.exceptions.ErrorCodes;
import com.maf.rnr.service.TestFreakService;
import com.maf.rnr.utils.CommonUtils;
import com.maf.rnr.utils.Constants;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

import java.util.Map;
import java.util.Optional;

@Slf4j
@Service
public class TestFreakServiceImpl implements TestFreakService {

    private final WebClient testFreakWebClient;
    private final TeatFreakPropertyConfig testFreakPropertyConfig;

    public TestFreakServiceImpl(@Qualifier("testFreakWebClient") WebClient testFreakWebClient,
                                TeatFreakPropertyConfig testFreakPropertyConfig) {
        this.testFreakWebClient = testFreakWebClient;
        this.testFreakPropertyConfig = testFreakPropertyConfig;
    }

    @Override
    public TFRatingResponse fetchRatings(String after, Country country, EntityType entityType) {
        try {
            TestFreakProperties properties = testFreakPropertyConfig.get(entityType);
            String clientId = CommonUtils.formatIfApplicable(properties.getClientId(), country.getIso(), "en");
            return testFreakWebClient
                    .get()
                    .uri(testFreakPropertyConfig.getBaseUrls().getSummaryUrl(),
                            uriBuilder -> uriBuilder
                                    .queryParamIfPresent("after", Optional.ofNullable(after))
                                    .queryParam("limit", properties.getSummaryPageSize())
                                    .queryParam("client_id", clientId)
                                    .build())
                    .retrieve()
                    .bodyToMono(new ParameterizedTypeReference<TFRatingResponse>() {
                    })
                    .block();
        } catch (Exception e) {
            log.error("Error while fetching product summaries", e);
            return new TFRatingResponse();
        }
    }

    @Cacheable(value = Constants.RATING_DISPLAY_CACHE, key = "#entityType + '_' + #key + '_' + #country")
    @Override
    public TFRatingDTO fetchRatingDisplay(String key, Country country, EntityType entityType) {
        try {
            TestFreakProperties properties = testFreakPropertyConfig.get(entityType);
            String clientId = CommonUtils.formatIfApplicable(properties.getClientId(), country.getIso(), "en");
            String url = CommonUtils.formatIfApplicable(testFreakPropertyConfig.getBaseUrls().getDisplayUrl(), clientId);
            return testFreakWebClient
                    .get()
                    .uri(url,
                            uriBuilder -> uriBuilder
                                    .queryParamIfPresent("key", Optional.ofNullable(key))
                                    .build())
                    .retrieve()
                    .bodyToMono(new ParameterizedTypeReference<TFRatingDTO>() {
                    })
                    .block();
        } catch (Exception e) {
            log.error("Error while calling TF display api", e);
            throw new ApiException(new ApiErrors(ErrorCodes.INTERNAL_SERVER_ERROR));
        }
    }

    @Cacheable(value = Constants.REVIEW_DETAIL_CACHE, key = "#entityType + '_' + #id + '_' + #country + '_' + #type + '_' + #sortAndFilter")
    @Override
    public TFReviewResponse fetchReviews(String id, Country country, EntityType entityType, ReviewType type,
                                         Map<String, Object> sortAndFilter) {
        if (!StringUtils.hasText(id)) return new TFReviewResponse();
        try {
            TestFreakProperties properties = testFreakPropertyConfig.get(entityType);
            String clientId = CommonUtils.formatIfApplicable(properties.getClientId(), country.getIso(), "en");
            String url = getReviewUrl(type, clientId);
            String key = ReviewType.customer.equals(type)? "mapping_ids[]" : "pid";
            return testFreakWebClient
                    .get()
                    .uri(url,
                            uriBuilder -> {
                                uriBuilder.queryParam(key, id)
                                        .queryParam("type", type)
                                        .queryParam("client_id", clientId);

                                // Iterate and add all queryParams from map dynamically
                                sortAndFilter.forEach((k, v) ->
                                        uriBuilder.queryParamIfPresent(k, Optional.ofNullable(v))
                                );
                                return uriBuilder.build();
                            })
                    .retrieve()
                    .bodyToMono(new ParameterizedTypeReference<TFReviewResponse>() {
                    })
                    .block();
        } catch (Exception e) {
            log.error("Error while calling TF {}_review api", type, e);
            throw new ApiException(new ApiErrors(ErrorCodes.INTERNAL_SERVER_ERROR));
        }
    }

    @Override
    public void submitFeedback(Country country, ReviewFeedbackRequest request) {
        String key = request.getReviewId();
        if (!StringUtils.hasText(key)) return;
        try {
            TestFreakProperties properties = testFreakPropertyConfig.get(request.getEntityType());
            String clientId = CommonUtils.formatIfApplicable(properties.getClientId(), country.getIso(), "en");

            String url = getFeedbackUrl(request.getReviewType(), key, clientId);

            BodyInserters.FormInserter<String> body = BodyInserters.fromFormData("type", request.getFeedbackType().getVal());
            if(StringUtils.hasText(request.getVoterId()))
                body.with("voter_id", request.getVoterId());
            if(StringUtils.hasText(request.getComment()))
                body.with("comment", request.getComment());

            testFreakWebClient
                .post()
                .uri(url)
                .body(body)
                .exchangeToMono(clientResponse -> {
                    if (clientResponse.statusCode().is2xxSuccessful()) {
                        return Mono.empty(); // API returns no body, so return empty Mono
                    } else {
                        return clientResponse.createException().flatMap(Mono::error);
                    }
                })
                .block();

        } catch (Exception e) {
            log.error("Error while submitting review feedback", e);
            throw new ApiException(new ApiErrors(ErrorCodes.INTERNAL_SERVER_ERROR));
        }
    }

    private String getReviewUrl(ReviewType type, String clientId) {
        if(ReviewType.customer.equals(type))
            return testFreakPropertyConfig.getBaseUrls().getCustomerReviewUrl();
        return CommonUtils.formatIfApplicable(testFreakPropertyConfig.getBaseUrls().getExternalReviewUrl(), clientId);
    }

    private String getFeedbackUrl(ReviewType type, String key, String clientId) {
        if(ReviewType.customer.equals(type))
            return CommonUtils.formatIfApplicable(testFreakPropertyConfig.getBaseUrls().getCustomerFeedbackUrl(), key);
        return CommonUtils.formatIfApplicable(testFreakPropertyConfig.getBaseUrls().getExternalFeedbackUrl(), clientId, key);
    }
}