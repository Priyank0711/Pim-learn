package com.maf.rnr.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
@Getter
public enum ReviewFilter {
    SCORE("score_dist"),
    GALLERY("only_with_images");

    final String key;
}
