package com.maf.rnr.dto;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.maf.rnr.enums.EntityType;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

import java.io.Serial;
import java.io.Serializable;
import java.util.List;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class RatingRequest implements Serializable {

    @Serial
    private static final long serialVersionUID = 1170651250772332381L;
    @NotEmpty(message = "ids is required")
    @NotNull(message = "ids is required")
    private List<String> ids;
    @NotNull(message = "entityType is required")
    private EntityType entityType;
}
