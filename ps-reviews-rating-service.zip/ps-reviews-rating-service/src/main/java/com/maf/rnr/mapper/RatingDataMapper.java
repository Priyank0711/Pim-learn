package com.maf.rnr.mapper;

import com.maf.rnr.dto.RatingData;
import com.maf.rnr.dto.testFreak.TFRatingDTO;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;


@Mapper()
public interface RatingDataMapper {

    RatingDataMapper INSTANCE = Mappers.getMapper(RatingDataMapper.class);

    @Mapping(target = "entityType", ignore = true)
    @Mapping(target = "country", ignore = true)
    RatingData convertToSummaryData(TFRatingDTO dto);

}
