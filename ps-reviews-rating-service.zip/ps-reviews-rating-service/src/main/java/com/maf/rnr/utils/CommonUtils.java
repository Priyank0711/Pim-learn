package com.maf.rnr.utils;

import lombok.experimental.UtilityClass;
import lombok.extern.slf4j.Slf4j;
import org.springframework.util.StringUtils;

import java.net.MalformedURLException;
import java.net.URI;
import java.net.URL;
import java.text.MessageFormat;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

@Slf4j
@UtilityClass
public class CommonUtils {

    public static String formatIfApplicable(String input, Object... args) {
        if (input.contains("{")) {
            return MessageFormat.format(input, args);
        }
        return input;
    }

    public static Map<String, String> getQueryParams(String urlString) {
        Map<String, String> params = new HashMap<>();
        if(!StringUtils.hasText(urlString)) return params;
        try {
            URL url = URI.create(urlString).toURL();
            String query = url.getQuery();
            if (query != null) {
                Arrays.stream(query.split("&"))
                        .map(param -> param.split("="))
                        .filter(pair -> pair.length == 2)
                        .forEach(pair -> params.put(pair[0], pair[1]));
            }
        } catch (MalformedURLException e) {
            log.error("Malformed URL: {}", urlString, e);
        }
        return params;
    }

}
