package com.maf.rnr.dto.testFreak;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import com.maf.rnr.enums.ReviewType;
import lombok.Data;

import java.io.Serial;
import java.io.Serializable;
import java.util.List;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
public class TFReviewDTO implements Serializable {

    @Serial
    private static final long serialVersionUID = 3334380532822995700L;
    private ReviewType type;
    private String source;
    private String domain;
    private String title;

    private String clientId;
    private String productId;
    private String product;
    private String author;

    private Double score;
    private Double scoreMax;
    private String extract;
    private String pros;
    private String cons;

    private String date;
    private String country;
    private String lang;
    private Boolean verifiedBuyer;

    private Integer votesUp;
    private Integer votesDown;

    private String logo;
    private Integer logoWidth;
    private Integer logoHeight;

    private String icon;
    private Integer iconWidth;
    private Integer iconHeight;

    private String feedbackUrl;
    private String link;

    private List<TFImageDTO> images;
}
