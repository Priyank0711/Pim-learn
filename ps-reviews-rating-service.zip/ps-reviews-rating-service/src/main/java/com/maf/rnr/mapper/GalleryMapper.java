package com.maf.rnr.mapper;

import com.maf.rnr.dto.GalleryDTO;
import com.maf.rnr.dto.testFreak.TFImageDTO;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import java.util.List;


@Mapper()
public interface GalleryMapper {

    GalleryMapper INSTANCE = Mappers.getMapper(GalleryMapper.class);

    @Mapping(target = "type", expression = "java(com.maf.rnr.enums.GalleryType.IMAGE)")
    GalleryDTO convertToGallery(TFImageDTO dto);

    List<GalleryDTO> convertToGallery(List<TFImageDTO> dto);

}
