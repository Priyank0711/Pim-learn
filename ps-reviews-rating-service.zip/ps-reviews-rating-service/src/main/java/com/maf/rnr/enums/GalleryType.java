package com.maf.rnr.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
@Getter
public enum GalleryType {
    IMAGE,

}
