package com.maf.rnr.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

@AllArgsConstructor
@Getter
public enum Country {
    LBN("LBN",""),
    KEN("KEN",""),
    PAK("PAK", ""),
    JOR("JOR", ""),

    BHR("BHR", ""),
    KWT("KWT", ""),
    EGY("EGY", "eg"),

    SAU("SAU", "sa"),
    OMN("OMN", ""),
    QAT("QAT", ""),

    UAE("UAE", "ae");

    final String code;
    final String iso;

    private static final Map<String, Country> COUNTRY_MAP = new HashMap<>();

    static {
        for (Country e: values()) {
            COUNTRY_MAP.put(e.name(), e);
        }
    }

    public static Optional<Country> getCountryCode(String country) {
        return Optional.of(COUNTRY_MAP.get(country));
    }
}
