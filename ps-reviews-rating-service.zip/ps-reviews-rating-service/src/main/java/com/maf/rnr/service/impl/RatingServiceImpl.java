package com.maf.rnr.service.impl;

import com.maf.rnr.dto.RatingData;
import com.maf.rnr.dto.RatingRequest;
import com.maf.rnr.dto.testFreak.TFRatingDTO;
import com.maf.rnr.enums.Country;
import com.maf.rnr.enums.EntityType;
import com.maf.rnr.exceptions.ApiErrors;
import com.maf.rnr.exceptions.ApiException;
import com.maf.rnr.exceptions.ErrorCodes;
import com.maf.rnr.mapper.RatingDataMapper;
import com.maf.rnr.service.CacheService;
import com.maf.rnr.service.RatingService;
import com.maf.rnr.service.TestFreakService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

@Slf4j
@Service
public class RatingServiceImpl implements RatingService {

    private final CacheService cacheService;
    private final TestFreakService testFreakService;


    public RatingServiceImpl(CacheService cacheService, TestFreakService testFreakService) {
        this.cacheService = cacheService;
        this.testFreakService = testFreakService;
    }

    @Override
    public List<RatingData> getRatings(Country country, List<RatingRequest> requests) {
        try {
            List<RatingData> summaryList = new ArrayList<>();
            requests.parallelStream().forEach(request -> request.getIds().forEach(id -> {
                // if present in cache add to summaryList or else try to fetch from TestFreak
                cacheService.getEntityRating(id, request.getEntityType(), country)
                        .ifPresentOrElse(
                                summaryList::add,
                                () -> {
                                    // Fetch from TestFreak and add to summaryList
                                    TFRatingDTO tfRatingDTO = testFreakService.fetchRatingDisplay(id, country, request.getEntityType());
                                    summaryList.add(getRatingData(tfRatingDTO, request.getEntityType(), id, country));
                                }
                        );
            }));
            return summaryList;
        } catch (Exception e){
            log.error("Error while fetching ratings", e);
            throw new ApiException(new ApiErrors(ErrorCodes.INTERNAL_SERVER_ERROR));
        }
    }

    @Override
    public RatingData getRatingData(TFRatingDTO rating, EntityType entityType, String id, Country country) {
        RatingData ratingData = RatingDataMapper.INSTANCE.convertToSummaryData(rating);
        if(!Objects.isNull(ratingData)) {
            ratingData.setId(id);
            ratingData.setEntityType(entityType);
            ratingData.setCountry(country);
        }
        return cacheService.saveRatingToCache(ratingData, entityType, id, country);
    }

}
