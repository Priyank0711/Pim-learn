## ps-reviews-rating-service

For saving and fetching the product and seller reviews