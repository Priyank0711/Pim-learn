package com.maf.aiorchestrator.facade.impl;

import com.maf.aiorchestrator.dto.ImportWrapperDTO;
import com.maf.aiorchestrator.dto.ProductAIDTO;
import com.maf.aiorchestrator.dto.PromptsAndRequiredAttributes;
import com.maf.aiorchestrator.entities.CategoryFormat;
import com.maf.aiorchestrator.entities.EnrichOption;
import com.maf.aiorchestrator.entities.ImportsData;
import com.maf.aiorchestrator.enums.EnrichOptionsEnum;
import com.maf.aiorchestrator.enums.ImportStatus;
import com.maf.aiorchestrator.facade.ImportFacade;
import com.maf.aiorchestrator.reader.ProductReader;
import com.maf.aiorchestrator.repository.CategoryFormatRepository;
import com.maf.aiorchestrator.repository.EnrichOptionsRepository;
import com.maf.aiorchestrator.service.ImportsDataService;
import com.maf.aiorchestrator.service.ProductService;
import com.maf.aiorchestrator.utils.Constants;
import com.maf.aiorchestrator.utils.ProductReaderFactory;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import reactor.core.publisher.Flux;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Slf4j
@Service
@AllArgsConstructor
public class ImportFacadeImpl implements ImportFacade {

    private final EnrichOptionsRepository enrichOptionsRepository;
    private final ProductReaderFactory productReaderFactory;
    private final ProductService productService;
    private final ImportsDataService importsDataService;
    private final CategoryFormatRepository categoryFormatRepository;

    @Override
    public void processImport(ImportWrapperDTO importWrapperDTO) {
        ImportsData importsData = importWrapperDTO.getImportsData();
        Optional<ProductReader> productReader = productReaderFactory.findStrategy(importsData.getType());
        PromptsAndRequiredAttributes promptsAndRequiredAttributes  = getPromptsAndRequiredAttributes(importsData);
        Flux<ProductAIDTO> readerFlux = Flux.empty();
        if(productReader.isPresent()) {
            readerFlux = productReader.get().getProducts(importWrapperDTO, promptsAndRequiredAttributes.getRequiredAttributes());
        }
        Flux<Void> productFlux = readerFlux.buffer(Constants.AI_BATCH_SIZE)
                    // send products in batch for enrichment
                    .flatMap(batch -> productService.enrichProductsAndSaveToELK(promptsAndRequiredAttributes.getPrompts(), batch, importsData.getImportId()))
                    .doOnError(e -> {
                        log.error("Error while reading products for importId {}", importsData.getImportId(), e);
                        importsDataService.updateImportStatusInDb(ImportStatus.FAILED, importsData.getImportId());
                    })
                    // Update the status in the DB after all batches are processed
                    .doOnComplete(() -> importsDataService.updateImportStatusInDb(ImportStatus.ENRICHED, importsData.getImportId()));
        productFlux.subscribe();
    }

    @Override
    public PromptsAndRequiredAttributes getPromptsAndRequiredAttributes(ImportsData importsData) {
        List<EnrichOptionsEnum> enrichOptionsSelected = importsData.getEnrichOptionsSelected();
        List<String> prompts = new ArrayList<>();
        List<String> requiredAttributes = new ArrayList<>();
        List<EnrichOption> enrichOptions = enrichOptionsRepository.findByNameInOrUiEnabledFalse(enrichOptionsSelected.stream().map(Enum::name).toList());
        String categoryCode = importsData.getCategoryCode();
        if(!StringUtils.hasText(categoryCode)){
            categoryCode = Constants.DEFAULT_CATEGORY_CODE;
            enrichOptions.removeIf(enrichOption -> enrichOption.getName().equals(EnrichOptionsEnum.ENRICH_ATTRIBUTE));
        }
        CategoryFormat categoryFormat = categoryFormatRepository.findByCode(categoryCode);
        for (EnrichOption option : enrichOptions) {
            getCategoryFormat(option, prompts, categoryFormat);
            requiredAttributes.addAll(option.getRequiredAttributes());
        }
        PromptsAndRequiredAttributes promptsAndRequiredAttributes = new PromptsAndRequiredAttributes();
        promptsAndRequiredAttributes.setPrompts(prompts);
        promptsAndRequiredAttributes.setRequiredAttributes(requiredAttributes);
        return promptsAndRequiredAttributes;
    }

    private void getCategoryFormat(EnrichOption option, List<String> prompts, CategoryFormat categoryFormat){
        List<String> prompt = option.getPrompt();
        if(option.isEnhancePrompt() && categoryFormat != null){
            String generationObj = Optional.ofNullable(categoryFormat.getEnrichmentFields().get(String.valueOf(option.getName())))
                    .orElse("");
            String enhancePrompt = prompt.getFirst().replace(Constants.PROMPT_FORMAT, generationObj);
            prompts.add(enhancePrompt);
        } else {
            prompts.addAll(prompt);
        }
    }
}
