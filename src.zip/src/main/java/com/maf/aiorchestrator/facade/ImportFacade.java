package com.maf.aiorchestrator.facade;

import com.maf.aiorchestrator.dto.ImportWrapperDTO;
import com.maf.aiorchestrator.dto.PromptsAndRequiredAttributes;
import com.maf.aiorchestrator.entities.ImportsData;

import java.io.IOException;

public interface ImportFacade {

    void processImport(ImportWrapperDTO importWrapperDTO) throws IOException;

    PromptsAndRequiredAttributes getPromptsAndRequiredAttributes(ImportsData fileDetails);

}
