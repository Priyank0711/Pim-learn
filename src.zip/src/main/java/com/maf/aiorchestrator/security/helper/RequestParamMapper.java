package com.maf.aiorchestrator.security.helper;


import com.maf.aiorchestrator.dto.JwtTokenParams;
import com.maf.aiorchestrator.enums.Country;
import com.maf.aiorchestrator.enums.UserRole;
import com.maf.aiorchestrator.utils.Constants;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

@Component
@Slf4j
public class RequestParamMapper {
    @Autowired
    private JwtTokenDetail jwtTokenDetail;

    public JwtTokenParams getTokenParams(JwtTokenParams params) {
        Map<String, Object> requestClaims = jwtTokenDetail.getClaims();
        params.setEmail((String) requestClaims.get(Constants.JWT_CLAIM_EMAIL_KEY));
        Set<UserRole> roles = getRoles(requestClaims);
        if (!CollectionUtils.isEmpty(roles)) {
            params.setRoles(roles);
            params.setCountry(getCountry(roles));
        }
        return params;
    }


    private Set<Country> getCountry(Set<UserRole> roles) {
        return roles.stream().map(UserRole::getCountry).map(Country::valueOf).collect(Collectors.toSet());
    }

    private Set<UserRole> getRoles(Map<String, Object> requestClaims) {
        Set<UserRole> currentUserRoles = new HashSet<>();
        List<String> roles = (List<String>) requestClaims.get(Constants.JWT_CLAIM_ROLES_KEY);
        if (roles != null && !roles.isEmpty()) {
            currentUserRoles = roles.stream().map(UserRole::fromString).filter(r -> !r.equals(UserRole.DEFAULT)).collect(Collectors.toSet());
        }
        return currentUserRoles;
    }

}
