package com.maf.aiorchestrator.security;

import com.maf.aiorchestrator.security.config.JWTIssuer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.oauth2.core.DelegatingOAuth2TokenValidator;
import org.springframework.security.oauth2.core.OAuth2TokenValidator;
import org.springframework.security.oauth2.jwt.*;
import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationConverter;
import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationProvider;
import org.springframework.security.oauth2.server.resource.authentication.JwtIssuerAuthenticationManagerResolver;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.header.writers.StaticHeadersWriter;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

@Configuration
@EnableWebSecurity
public class SpringSecurityConfig {

    @Autowired
    private Set<JWTIssuer> jwtIssuers;

    @Value("${spring.security.allow.frame.for.ancestor}")
    private String ancestor;

    private final String[] whiteListPatterns = {"/v3/api-docs/**",
                                                "/configuration/**",
                                                "/swagger*/**",
                                                "/webjars/**",
                                                "/health",
                                                "/refreshCache"};

    final Map<String, AuthenticationManager> authenticationManagers = new HashMap<>();

    final JwtIssuerAuthenticationManagerResolver authenticationManagerResolver = new JwtIssuerAuthenticationManagerResolver(authenticationManagers::get);

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        // Register each JWT issuer's authentication manager
        jwtIssuers.forEach(jwtIssuer -> addManager(jwtIssuer, authenticationManagers));

        http.authorizeHttpRequests(auth -> auth.requestMatchers(whiteListPatterns).permitAll().anyRequest().authenticated()).cors(c -> c.configurationSource(corsConfigurationSource())).oauth2ResourceServer(oauth2ResourceServer -> {
            oauth2ResourceServer.authenticationManagerResolver(this.authenticationManagerResolver);
        });
        // Disable CSRF for APIs, as it's common for stateless APIs
        http.csrf(AbstractHttpConfigurer::disable);

        // Disable X-Frame-Options to allow embedding
        http.headers(headers -> {
            // Add custom Content-Security-Policy headers
            headers.addHeaderWriter(new StaticHeadersWriter("X-Content-Security-Policy", "frame-ancestors " + ancestor));
            headers.addHeaderWriter(new StaticHeadersWriter("Content-Security-Policy", "frame-ancestors " + ancestor));
        });
        return http.build();  // Return the configured SecurityFilterChain
    }

    private void addManager(JWTIssuer jwtIssuer, Map<String, AuthenticationManager> authenticationManagers) {
        JwtDecoder jwtDecoder = jwtDecoder(jwtIssuer);
        JwtAuthenticationProvider authenticationProvider = new JwtAuthenticationProvider(jwtDecoder);
        authenticationProvider.setJwtAuthenticationConverter(jwtAuthenticationConverter(jwtIssuer));
        authenticationManagers.put(jwtIssuer.getIssuerUri(), authenticationProvider::authenticate);
    }

    CorsConfigurationSource corsConfigurationSource() {
        CorsConfiguration configuration = new CorsConfiguration();
        configuration.setAllowedMethods(Arrays.asList(HttpMethod.GET.name(), HttpMethod.PUT.name(), HttpMethod.POST.name(), HttpMethod.DELETE.name()));

        UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
        source.registerCorsConfiguration("/**", configuration.applyPermitDefaultValues());
        return source;
    }

    JwtDecoder jwtDecoder(final JWTIssuer issuer) {
        OAuth2TokenValidator<Jwt> withAudience = new AudienceValidator(issuer.getAudience());
        OAuth2TokenValidator<Jwt> withIssuer = JwtValidators.createDefaultWithIssuer(issuer.getIssuerUri());
        OAuth2TokenValidator<Jwt> validator = new DelegatingOAuth2TokenValidator<>(withAudience, withIssuer);

        NimbusJwtDecoder jwtDecoder = (NimbusJwtDecoder) JwtDecoders.fromOidcIssuerLocation(issuer.getIssuerUri());
        jwtDecoder.setJwtValidator(validator);
        return jwtDecoder;
    }

    JwtAuthenticationConverter jwtAuthenticationConverter(final JWTIssuer issuer) {
        CustomJwtGrantedAuthoritiesConverter converter = new CustomJwtGrantedAuthoritiesConverter();
        converter.setAuthoritiesClaimName("permissions");
        converter.setAuthorityPrefix("");
        converter.setRoleClaimName(issuer.getRoleClaimName());

        JwtAuthenticationConverter jwtConverter = new JwtAuthenticationConverter();
        jwtConverter.setJwtGrantedAuthoritiesConverter(converter);

        return jwtConverter;
    }

}
