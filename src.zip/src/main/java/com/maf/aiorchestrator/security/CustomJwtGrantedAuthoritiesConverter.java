package com.maf.aiorchestrator.security;

import com.maf.aiorchestrator.enums.UserRole;
import org.apache.commons.lang3.BooleanUtils;
import org.springframework.core.convert.converter.Converter;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.util.Assert;
import org.springframework.util.StringUtils;

import java.util.*;


public final class CustomJwtGrantedAuthoritiesConverter implements Converter<Jwt, Collection<GrantedAuthority>> {

    private static final Collection<String> WELL_KNOWN_AUTHORITIES_CLAIM_NAMES = Arrays.asList("scope", "scp");
    private String authorityPrefix = "SCOPE_";
    private String authoritiesClaimName;
    private String roleClaimName;

    public Collection<GrantedAuthority> convert(Jwt jwt) {
        Collection<GrantedAuthority> grantedAuthorities = new ArrayList<>();
        Collection<String> authorities = this.getAuthorities(jwt);
        authorities.addAll(getRole(jwt).stream().map(e -> UserRole.fromString(e).name()).toList());

        for (String authority : authorities) {
            grantedAuthorities.add(new SimpleGrantedAuthority(this.authorityPrefix + authority));
        }

        return grantedAuthorities;
    }

    public void setAuthorityPrefix(String authorityPrefix) {
        Assert.notNull(authorityPrefix, "authorityPrefix cannot be null");
        this.authorityPrefix = authorityPrefix;
    }

    public void setAuthoritiesClaimName(String authoritiesClaimName) {
        Assert.hasText(authoritiesClaimName, "authoritiesClaimName cannot be empty");
        this.authoritiesClaimName = authoritiesClaimName;
    }

    private String getAuthoritiesClaimName(Jwt jwt) {
        if (this.authoritiesClaimName != null) {
            return this.authoritiesClaimName;
        } else {
            Iterator<String> var2 = WELL_KNOWN_AUTHORITIES_CLAIM_NAMES.iterator();

            String claimName;
            do {
                if (!var2.hasNext()) {
                    return null;
                }

                claimName = var2.next();
            } while (BooleanUtils.isNotTrue(jwt.hasClaim(claimName)));

            return claimName;
        }
    }

    private Collection<String> getAuthorities(Jwt jwt) {
        String claimName = this.getAuthoritiesClaimName(jwt);
        if (claimName == null) {
            return new ArrayList<>();
        } else {
            Object authorities = jwt.getClaim(claimName);
            if (authorities instanceof String) {
                return StringUtils.hasText((String) authorities) ? Arrays.asList(((String) authorities).split(" ")) : new ArrayList<>();
            } else {
                return (authorities instanceof Collection ? (Collection<String>) authorities : new ArrayList<>());
            }
        }
    }

    private Collection<String> getRole(Jwt jwt) {
        String claimName = this.roleClaimName;
        if (claimName == null) {
            return Collections.emptyList();
        } else {
            Object authorities = jwt.getClaim(claimName);
            if (authorities instanceof String) {
                return StringUtils.hasText((String) authorities) ? Arrays.asList(((String) authorities).split(" ")) : Collections.emptyList();
            } else {
                return (authorities instanceof Collection ? (Collection<String>) authorities : Collections.emptyList());
            }
        }
    }

    public String getRoleClaimName() {
        return roleClaimName;
    }

    public void setRoleClaimName(String roleClaimName) {
        this.roleClaimName = roleClaimName;
    }
}
