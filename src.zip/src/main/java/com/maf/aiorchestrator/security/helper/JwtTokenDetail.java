package com.maf.aiorchestrator.security.helper;

import com.maf.aiorchestrator.exception.InvalidToken;
import com.maf.aiorchestrator.exception.JwtClaimNotFound;
import com.maf.aiorchestrator.security.config.MafAzureJWTIssuer;
import com.maf.aiorchestrator.utils.Constants;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.security.oauth2.jwt.Jwt;

import java.util.*;

@Component
public class JwtTokenDetail {

    @Autowired
    private MafAzureJWTIssuer mafAzureJWTIssuer;

    public Map<String, Object> getClaims() {
        Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        if (principal instanceof Jwt) {
            Jwt jwt = (Jwt) principal;
            return jwtClaimToRequestClaimMap(jwt);
        }
        throw new InvalidToken("Principal is not instance of JWT");

    }

    private Map<String, Object> jwtClaimToRequestClaimMap(Jwt jwt) {
        Map<String, Object> requestClaimMap = new HashMap<>();
        Map<String, Object> tokenClaims = jwt.getClaims();

        validateClaim(tokenClaims, Constants.JWT_CLAIM_ISSUER_KEY);
        if (mafAzureJWTIssuer.getIssuerUri().equals(tokenClaims.get(Constants.JWT_CLAIM_ISSUER_KEY))) {
            addRolesAndEmailInRequestClaimMap(requestClaimMap, tokenClaims);
        }
        return requestClaimMap;
    }


    private void addRolesAndEmailInRequestClaimMap(Map<String, Object> requestClaimMap, Map<String, Object> jwtClaimsMap) {
        //Roles
        validateClaim(jwtClaimsMap, mafAzureJWTIssuer.getRoleClaimName());
        final List<String> roles = new ArrayList<>();
        if (jwtClaimsMap.get(mafAzureJWTIssuer.getRoleClaimName()) instanceof String) {
            roles.add((String) jwtClaimsMap.get(mafAzureJWTIssuer.getRoleClaimName()));
        } else if (jwtClaimsMap.get(mafAzureJWTIssuer.getRoleClaimName()) instanceof String[]) {
            roles.addAll(Arrays.asList((String[]) jwtClaimsMap.get(mafAzureJWTIssuer.getRoleClaimName())));
        } else {
            roles.addAll((List<String>) jwtClaimsMap.get(mafAzureJWTIssuer.getRoleClaimName()));
        }
        requestClaimMap.put(Constants.JWT_CLAIM_ROLES_KEY, roles);

        //Email
        validateClaim(jwtClaimsMap, Constants.JWT_CLAIM_MAF_EMAIL_KEY);
        requestClaimMap.put(Constants.JWT_CLAIM_EMAIL_KEY, jwtClaimsMap.get(Constants.JWT_CLAIM_MAF_EMAIL_KEY));

    }

    private void validateClaim(Map<String, Object> jwtClaimsMap, String claimKey) {
        if (!jwtClaimsMap.containsKey(claimKey)) {
            throw new JwtClaimNotFound(" claim " + claimKey + "  not found in JWT token ");
        }
    }

}
