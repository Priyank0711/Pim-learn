package com.maf.aiorchestrator.security.config;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;


@Data
public class JWTIssuer {
    @NotBlank
    private String audience;
    @NotBlank
    private String domain;
    private String identityAPI;
    @NotBlank
    private String issuerUri;
    @NotBlank
    private String roleClaimName;
}
