package com.maf.aiorchestrator.security;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.stereotype.Component;

@Component
public class AuthorityHelper {

    public boolean hasAuthorityContaining(Authentication authentication, String role, String country) {
        return authentication.getAuthorities().stream()
                .map(GrantedAuthority::getAuthority)
                .anyMatch(i -> i.contains(role) && i.contains(country));
    }
}
