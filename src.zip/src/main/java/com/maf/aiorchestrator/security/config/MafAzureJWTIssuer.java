package com.maf.aiorchestrator.security.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.validation.annotation.Validated;

@Validated
@ConfigurationProperties("mafsso")
@Configuration
public class MafAzureJWTIssuer extends JWTIssuer {

}
