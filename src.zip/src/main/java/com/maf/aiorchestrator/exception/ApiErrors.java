package com.maf.aiorchestrator.exception;

import lombok.Getter;

import java.io.Serial;
import java.io.Serializable;

@Getter
public class ApiErrors implements Serializable {
    @Serial
    private static final long serialVersionUID = 4104899980453016055L;
    Integer code;
    String message;

    public ApiErrors(ErrorCodes errorCodes) {
        this.code = errorCodes.getCode();
        this.message = errorCodes.getMessage();
    }
}
