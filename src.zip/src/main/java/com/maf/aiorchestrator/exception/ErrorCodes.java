package com.maf.aiorchestrator.exception;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum ErrorCodes {

    INTERNAL_SERVER_ERROR(500001, "Something went wrong, Please try after sometime."),
    INTERNAL_SERVER_ERROR_SCAN(500002, "Something went wrong while scanning, Please try after sometime."),
    PRODUCT_NOT_FOUND(404001, "Product not found"),
    BAD_REQUEST(400001, "Bad Request - %s"),
    SCAN_BAD_REQUEST(400002, "Bad Request for scanning online index - %s");

    final Integer code;
    final String message;

}
