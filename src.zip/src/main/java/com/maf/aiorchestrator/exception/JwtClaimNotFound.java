package com.maf.aiorchestrator.exception;

public class JwtClaimNotFound extends RuntimeException{
	
	private static final long serialVersionUID = 8670402956251749123L;

	public JwtClaimNotFound(String message) {
        super(message);
    }
}
