package com.maf.aiorchestrator.exception;

public class MafElasticSearchException extends RuntimeException {

    public MafElasticSearchException(String message) {
        super(message);
    }

}
