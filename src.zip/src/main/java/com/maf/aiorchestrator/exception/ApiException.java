package com.maf.aiorchestrator.exception;

import lombok.Getter;
import lombok.Setter;

import java.io.Serial;
import java.io.Serializable;

@Getter
@Setter
public class ApiException extends RuntimeException implements Serializable {

    @Serial
    private static final long serialVersionUID = -1568038561698864895L;

    private final ApiErrors apiErrors;

    public ApiException(ApiErrors apiErrors) {
        super(apiErrors.message);
        this.apiErrors = apiErrors;
    }

    public ApiException(ApiErrors apiErrors, String mssg) {
        super(String.format(apiErrors.message, mssg));
        this.apiErrors = apiErrors;
        this.apiErrors.message = String.format(apiErrors.message, mssg);
    }

}
