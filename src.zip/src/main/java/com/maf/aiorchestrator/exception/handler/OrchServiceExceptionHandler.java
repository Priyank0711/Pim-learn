package com.maf.aiorchestrator.exception.handler;

import com.maf.aiorchestrator.exception.ApiException;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import java.util.ArrayList;
import java.util.List;

@ControllerAdvice
public class OrchServiceExceptionHandler extends ResponseEntityExceptionHandler {

    @Getter
    @Setter
    @NoArgsConstructor
    class ErrorBody {
        private List<String> messages;
    }

    @ExceptionHandler(value = {ApiException.class})
    protected ResponseEntity<ErrorBody> handleApiException(ApiException e) {
        ErrorBody errorBody = new ErrorBody();
        List<String> messages = new ArrayList<>();
        messages.add(e.getApiErrors().getMessage());
        errorBody.setMessages(messages);
        return ResponseEntity.status(e.getApiErrors().getCode()/1000).body(errorBody);
    }

}
