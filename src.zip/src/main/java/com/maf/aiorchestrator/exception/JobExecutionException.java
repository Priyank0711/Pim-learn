package com.maf.aiorchestrator.exception;

import java.io.Serial;
import java.io.Serializable;

public class JobExecutionException extends RuntimeException implements Serializable {


    @Serial
    private static final long serialVersionUID = 4263848326140909053L;

    public JobExecutionException(String message) {
        super(message);
    }

    public JobExecutionException(String message, Throwable t) {
        super(message, t);
    }
}
