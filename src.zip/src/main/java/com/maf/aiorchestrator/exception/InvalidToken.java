package com.maf.aiorchestrator.exception;

public class InvalidToken extends RuntimeException {
	
	private static final long serialVersionUID = 1752739346789519297L;

	public InvalidToken(String message) {
        super(message);
    }
}
