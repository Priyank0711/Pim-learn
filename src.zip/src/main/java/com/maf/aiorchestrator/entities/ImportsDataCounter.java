package com.maf.aiorchestrator.entities;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.mongodb.core.mapping.Document;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
@Document(collection = "importsDataCounter")
public class ImportsDataCounter {

    @Id
    private String id;
    private String shopId;
    private Long counter;

    @LastModifiedDate
    private long _ts;
}
