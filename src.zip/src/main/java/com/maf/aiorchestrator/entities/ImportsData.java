package com.maf.aiorchestrator.entities;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.maf.aiorchestrator.dto.file.FileData;
import com.maf.aiorchestrator.enums.Country;
import com.maf.aiorchestrator.enums.EnrichOptionsEnum;
import com.maf.aiorchestrator.enums.ImportStatus;
import com.maf.aiorchestrator.enums.ImportType;
import lombok.Data;
import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.Instant;
import java.util.List;

@Data
@Document(collection = "imports")
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class ImportsData {

    @Id
    private String id;
    private String importId;
    private FileData fileData;
    private Country country;
    private ImportStatus status;
    private ImportType type;
    private List<EnrichOptionsEnum> enrichOptionsSelected;
    private String aiModel;
    private String categoryCode;
    private String categoryName;
    private String shopId;

    @LastModifiedDate
    private Instant lastModifiedTime;

}
