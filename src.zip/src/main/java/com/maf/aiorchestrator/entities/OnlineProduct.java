package com.maf.aiorchestrator.entities;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.maf.aiorchestrator.config.InstantDeserializer;
import com.maf.aiorchestrator.data.*;
import lombok.Data;
import org.springframework.data.annotation.Id;
import org.springframework.data.elasticsearch.annotations.DateFormat;
import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;

import java.time.Instant;
import java.util.Date;
import java.util.List;
import java.util.Set;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class OnlineProduct {

    @Id
    private String id;
    private String code;
    private String storeId;
    private String name;
    private String url;
    private String description;
    private Double width;
    private Double height;
    private Double depth;
    private Double weight;
    private String department;
    private String section;
    private String family;
    private String subFamily;
    private String status;
    @JsonDeserialize(using = InstantDeserializer.class)
    @Field(name = "statusStartDate", type = FieldType.Date, format = DateFormat.date_optional_time)
    private Instant statusStartDate;
    @JsonDeserialize(using = InstantDeserializer.class)
    @Field(name = "statusEndDate", type = FieldType.Date, format = DateFormat.date_optional_time)
    private Instant statusEndDate;
    private String itemStatus;
    private String marketingText;
    private String marketingText_ar;
    private Integer unitItem;
    private List<String> barCodes;
    private boolean isSubstituted;
    private String name_ar;
    private String onlineName_ar;
    private String description_ar;
    private String bulkMessage_ar;
    @JsonProperty("isBuyNowProduct")
    private boolean isBuyNowProduct;
    private boolean warranty;
    private List<CategoryData> categoriesHierarchy;
    private String maxOrderQuantity;
    private String minOrderQuantity;
    private String onlineName;
    private String tipsAndVideos;
    private String productColor;
    private String color;
    private String ean;
    private String numberOfPoints;
    private boolean cashbackStickerVisible;
    private Double cashbackPoints;
    private Date loyaltyPointStartDate;
    private Date loyaltyPointEndDate;
    private String metaTitle;
    private String metaDescription;
    private String metaKeywords;
    private String brandCode;
    private String brandName;
    private String brandName_ar;
    private String minimumWeightToOrder;
    private String maxToOrder;
    private String type;
    private Double freeDeliveryThreshold;
    private String bulkMessage;
    private String productTypeDM51;
    private boolean nonReplenishable;
    private Set<ProductAssortmentData> assortments;
    private String freeInstallation;
    private boolean genuineStock;
    private boolean freeDelivery;
    private boolean onDemand;
    private String preorder;
    private String preorderDescription;
    private String deliveryCode;
    private Integer nbrOfMonth;
    private String deliveryTime;
    private String preorderDate;
    private String countryOrigin;
    private String brandMarketingMessage;
    private String weightIncrement;
    private String averageWeightByKg;
    private String ingredients;
    private String safetyWarnings;
    private String storageCondition;
    private String preparationAndUsage;
    private String allergyAdvice;
    private String productSize;
    private String ingredients_ar;
    private String brandMarketingMessage_ar;
    private String storageCondition_ar;
    private String allergyAdvice_ar;
    private String preparationAndUsage_ar;
    private String productSize_ar;
    private String countryOrigin_ar;
    private String ProductFoodType;
    private String foodProductType;
    private String measure;
    private String gicaItemMeasure;
    private String nature;
    private Boolean soldByWeight;
    private Double weightVariation;
    private Double averageWeightByPiece;
    private Integer yearOfWarranty;
    private String warrantyType;
    private List<ImageData> images;
    private List<ImageData> gallery;
    private List<CategoryData> categories;
    private String express;
    private List<ClassificationData> classifications;
    private String gicaVatCod;
    private String gicaVatPer;
    private String numberOfUnit;
    private String mainImageUrl;
    private String image2Url;
    private String image3Url;
    private String image4Url;
    private String image5Url;
    private Double grossWeight;
    private String productCategoriesHearchi;
    private Boolean marketplaceProduct;
    private List<String> listofUnpublishedPOS;
    private String supplier;
    private String supplierDescription;
    private List<ProductSupplierData> supplierData;
    private List<CategoryData> navigationCategoriesHierarchy;
    private String marketplaceOwner;
    private String marketplaceShopOwnerId;
    private String marketplaceProductType;
    private List<CategoryData> marketplaceCategoriesHierarchy;
    @JsonDeserialize(using = InstantDeserializer.class)
    @Field(name = "creationTime", type = FieldType.Date, format = DateFormat.date_optional_time)
    private Instant creationTime;
    @JsonDeserialize(using = InstantDeserializer.class)
    @Field(name = "modifiedTime", type = FieldType.Date, format = DateFormat.date_optional_time)
    private Instant modifiedTime;
    private CategoryData productVariantData;
    private String classCategory;
    private String l1NavCategory;
    private String l2NavCategory;
    private String l3NavCategory;
    private String l4NavCategory;

}
