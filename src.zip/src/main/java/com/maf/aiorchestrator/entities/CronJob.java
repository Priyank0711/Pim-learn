package com.maf.aiorchestrator.entities;

import com.maf.aiorchestrator.enums.JobStatus;
import lombok.Data;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.Instant;

@Data
@Document(collection = "cronJobs")
public class CronJob {
    @Id
    private String id;
    private JobStatus status;
    private Instant lastUpdated;
    private Instant startDate;
    private Instant endDate;

}
