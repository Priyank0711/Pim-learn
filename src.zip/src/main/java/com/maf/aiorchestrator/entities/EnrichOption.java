package com.maf.aiorchestrator.entities;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.maf.aiorchestrator.enums.EnrichOptionsEnum;
import lombok.Data;
import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.Instant;
import java.util.List;

@Data
@Document(collection = "enrichOptions")
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class EnrichOption {

    @Id
    private String id;
    private EnrichOptionsEnum name;
    private List<String> requiredAttributes;
    private List<String> prompt;
    private boolean uiEnabled;
    private boolean enhancePrompt;

    @LastModifiedDate
    private Instant lastModifiedTime;

}

