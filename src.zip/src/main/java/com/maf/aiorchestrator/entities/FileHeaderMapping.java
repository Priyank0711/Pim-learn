package com.maf.aiorchestrator.entities;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.maf.aiorchestrator.dto.file.StandardHeaderDetail;
import com.maf.aiorchestrator.enums.FileType;
import lombok.Data;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.Map;

@Data
@Document(collection = "headerMappings")
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class FileHeaderMapping {

    @Id
    private String id;
    private FileType fileType;
    private Map<String, StandardHeaderDetail> attributeMap;

}
