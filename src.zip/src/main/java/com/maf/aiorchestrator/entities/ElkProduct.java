package com.maf.aiorchestrator.entities;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.maf.aiorchestrator.config.InstantDeserializer;
import com.maf.aiorchestrator.dto.EnrichedData;
import com.maf.aiorchestrator.enums.Country;
import lombok.Data;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.elasticsearch.annotations.DateFormat;
import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;

import java.time.Instant;
import java.util.Map;
import java.util.UUID;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class ElkProduct {

    public ElkProduct(){
        this.id = UUID.randomUUID().toString();
    }

    @Id
    private String id;
    private String importId;
    private String productId;
    private String productName;
    private Map<String, Map<String, String>> metaAttributes;
    private Map<String, Map<String, String>> classAttributes;
    private EnrichedData enrichedData;
    private String status;
    private String categoryCode;
    private String categoryName;
    private String category; //(code-name)
    @JsonDeserialize(using = InstantDeserializer.class)
    @Field(name = "createdTime", type = FieldType.Date, format = DateFormat.strict_date_optional_time)
    @CreatedDate
    private Instant createdTime;
    @LastModifiedDate
    @JsonDeserialize(using = InstantDeserializer.class)
    @Field(name = "lastModifiedTime", type = FieldType.Date, format = DateFormat.strict_date_optional_time)
    private Instant lastModifiedTime;
    private Country country;

}
