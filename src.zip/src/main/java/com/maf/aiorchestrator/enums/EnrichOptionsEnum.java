package com.maf.aiorchestrator.enums;

public enum EnrichOptionsEnum {
    ENRICH_ATTRIBUTE,
    AR_TRANSLATION,
    SENSITIVE_SPELL_CHECK,
    TITLE_GENERATION,
    HIGHLIGHT_GENERATION,
    DESCRIPTION_GENERATION
}