package com.maf.aiorchestrator.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.Arrays;
import java.util.List;

@Getter
@AllArgsConstructor
public enum UserRole {
    ROLE_PIM_UAE("pim-user-uae-role", "UAE"),
    ROLE_PIM_QAT("pim-user-qat-role", "QAT"),
    ROLE_PIM_OMN("pim-user-omn-role", "OMN"),
    ROLE_PIM_KSA("pim-user-ksa-role", "SAU"),
    ROLE_PIM_EGY("pim-user-egy-role","EGY"),
    ROLE_PIM_KWT("pim-user-kwt-role", "KWT"),
    ROLE_PIM_BHR("pim-user-bhr-role", "BHR"),
    ROLE_PIM_JOR("pim-user-jor-role","JOR"),
    ROLE_PIM_PAK("pim-user-pak-role", "PAK"),
    ROLE_PIM_KEN("pim-user-ken-role", "KEN"),
    ROLE_PIM_LBN("pim-user-lbn-role", "LBN"),
    ROLE_PIM_SAU("pim-user-sau-role", "SAU"),

    DEFAULT("", "");

    String role;
    String country;
    public static UserRole fromString(String role) {
        for (UserRole b : UserRole.values()) {
            if (b.role.equalsIgnoreCase(role)) {
                return b;
            }
        }
        return DEFAULT;
    }

    public static List<String> getAllRoles(){
        return Arrays.stream(UserRole.values()).map(UserRole::name).toList();
    }
}