package com.maf.aiorchestrator.enums;

public enum ImportType {
    FILE,
    SCANNING
}
