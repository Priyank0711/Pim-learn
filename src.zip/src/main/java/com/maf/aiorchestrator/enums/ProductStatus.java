package com.maf.aiorchestrator.enums;

import lombok.Getter;

@Getter
public enum ProductStatus {
    PENDING,
    APPROVED,
    REJECTED,
    VALIDATION_FAILED
}
