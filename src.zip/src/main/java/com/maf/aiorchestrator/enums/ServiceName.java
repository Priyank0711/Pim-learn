package com.maf.aiorchestrator.enums;

import lombok.Getter;

@Getter
public enum ServiceName {
    AI_ENGINE,
    PIM
}
