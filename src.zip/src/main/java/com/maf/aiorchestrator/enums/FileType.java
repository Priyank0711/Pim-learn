package com.maf.aiorchestrator.enums;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

public enum FileType {
    MDM,
    PIM_PRODUCT,
    MARKETPLACE;


    private static final Map<String, FileType> BY_FILETYPE = new HashMap<>();

    static {
        for (FileType e: values()) {
            BY_FILETYPE.put(e.name(), e);
        }
    }

    public static Optional<FileType> getFileType(String fileName) {
        return Optional.of(BY_FILETYPE.get(fileName));
    }
}
