package com.maf.aiorchestrator.enums;

public enum JobStatus {
    RUNNING,
    ERROR,
    FINISHED
}
