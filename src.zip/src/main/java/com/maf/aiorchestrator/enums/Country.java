package com.maf.aiorchestrator.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.*;

@AllArgsConstructor
@Getter
public enum Country {
    LBN("LBN"),
    KEN("KEN"),
    PAK("PAK"),
    JOR("JOR"),

    BHR("BHR"),
    KWT("KWT"),
    EGY("EGY"),

    SAU("SAU"),
    OMN("OMN"),
    QAT("QAT"),

    UAE("UAE");

    final String code;

    private static final Map<String, Country> COUNTRY_MAP = new HashMap<>();

    static {
        for (Country e: values()) {
            COUNTRY_MAP.put(e.name(), e);
        }
    }

    public static Optional<Country> getCountryCode(String country) {
        return Optional.of(COUNTRY_MAP.get(country));
    }
}
