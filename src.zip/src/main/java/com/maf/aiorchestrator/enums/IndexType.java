package com.maf.aiorchestrator.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
@Getter
public enum IndexType {
    STAGED_PRODUCTS("SP"),
    ONLINE_PRODUCTS("OP");

    private final String code;
}
