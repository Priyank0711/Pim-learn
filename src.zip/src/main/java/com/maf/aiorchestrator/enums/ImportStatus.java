package com.maf.aiorchestrator.enums;

import lombok.Getter;

@Getter
public enum ImportStatus {
    UPLOADED,
    PROCESSING,
    FAILED,
    ENRICHED,
    DOWNLOADED,
    PENDING,
    APPROVED,
    REJECTED
}
