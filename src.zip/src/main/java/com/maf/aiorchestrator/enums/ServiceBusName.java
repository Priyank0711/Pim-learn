package com.maf.aiorchestrator.enums;

import lombok.Getter;

@Getter
public enum ServiceBusName {
    CATALOG_IMPORT,
    PRODUCT_VALIDATION
}
