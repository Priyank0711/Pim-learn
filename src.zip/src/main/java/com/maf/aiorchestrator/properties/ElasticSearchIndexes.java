package com.maf.aiorchestrator.properties;

import lombok.Data;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

import java.util.Map;

@Data
@Configuration
public class ElasticSearchIndexes {

    @Value("#{${elastic.indexes.product.staged}}")
    private Map<String, String> stagedProductIndex;
    @Value("#{${elastic.indexes.product.online}}")
    private Map<String, String> onlineProductIndex;

}
