package com.maf.aiorchestrator.mapper;

import com.maf.aiorchestrator.elastic.dto.OnlineProductListingDTO;
import com.maf.aiorchestrator.elastic.dto.ProductResultDTO;
import com.maf.aiorchestrator.entities.ElkProduct;
import com.maf.aiorchestrator.entities.OnlineProduct;
import com.maf.aiorchestrator.exception.MafElasticSearchException;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper(componentModel = "spring")
public interface ProductResultMapper {

    ProductResultMapper INSTANCE = Mappers.getMapper(ProductResultMapper.class);

    default <T, U> T map(U source, Class<T> targetClass) {
        if (targetClass.equals(ProductResultDTO.class)) {
            return targetClass.cast(mapToProductResultDto((ElkProduct) source));
        }
        if (targetClass.equals(OnlineProductListingDTO.class)) {
            return targetClass.cast(mapToOnlineProductListingDto((OnlineProduct) source));
        }
        if (targetClass.equals(OnlineProduct.class)) {
            return targetClass.cast(mapToOnlineProduct((OnlineProduct) source));
        }
        throw new MafElasticSearchException("No mapper found for search result " + targetClass.getName());
    }

    ProductResultDTO mapToProductResultDto(ElkProduct source);

    OnlineProductListingDTO mapToOnlineProductListingDto(OnlineProduct source);

    default OnlineProduct mapToOnlineProduct(OnlineProduct source){
        return source;
    }
}
