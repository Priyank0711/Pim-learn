package com.maf.aiorchestrator.mapper;

import com.maf.aiorchestrator.dto.EnrichedData;
import com.maf.aiorchestrator.dto.ProductAIDTO;
import com.maf.aiorchestrator.entities.ElkProduct;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import java.util.Arrays;
import java.util.Objects;

@Mapper(componentModel = "spring")
public interface ProductAIDTOMapper {

    ProductAIDTOMapper INSTANCE = Mappers.getMapper(ProductAIDTOMapper.class);

    @Mapping(target = "category", expression = "java(concatStrings(\"-\", requestDTO.getCategoryCode(), requestDTO.getCategoryName()))")
    ElkProduct convertToElkProduct(ProductAIDTO requestDTO);

    EnrichedData covertToEnrichedData(ProductAIDTO responseDTO);

    default String concatStrings(String delimiter, String ... fields) {
        if(Arrays.stream(fields).anyMatch(Objects::isNull)) {
            return null;
        }
        return String.join(delimiter, fields);
    }

    @Mapping(target = "classAttributes", ignore = true)
    @Mapping(target = "metaAttributes", ignore = true)
    ProductAIDTO copyWithoutAttributes(ProductAIDTO productAIDTO);

}
