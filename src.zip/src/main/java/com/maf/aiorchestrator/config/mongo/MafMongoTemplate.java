package com.maf.aiorchestrator.config.mongo;

import com.mongodb.client.MongoClient;
import org.springframework.data.mongodb.core.FindAndModifyOptions;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;

public class MafMongoTemplate extends MongoTemplate {

    public MafMongoTemplate(MongoClient mongoClient, String databaseName) {
        super(mongoClient, databaseName);
    }

    public <T> T getCounter(Query query, Class<T> entityClass) {
        Update update = new Update();
        update.inc("counter", 1);

        FindAndModifyOptions options = new FindAndModifyOptions();
        options.upsert(true);
        options.returnNew(true);

        return findAndModify(query, update, options, entityClass);
    }

}
