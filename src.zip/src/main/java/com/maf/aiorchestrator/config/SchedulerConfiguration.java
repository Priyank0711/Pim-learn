package com.maf.aiorchestrator.config;

import net.javacrumbs.shedlock.core.LockProvider;
import net.javacrumbs.shedlock.provider.mongo.MongoLockProvider;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoDatabase;
import net.javacrumbs.shedlock.spring.annotation.EnableSchedulerLock;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableScheduling;

@Configuration
@EnableScheduling
@EnableSchedulerLock(defaultLockAtMostFor = "PT30M")
public class SchedulerConfiguration {

    @Value("${mongodb.database}")
    private String dbName;

    @Bean
    public LockProvider lockProvider(MongoClient mongoClient) {
        MongoDatabase mongoDatabase = mongoClient.getDatabase(dbName);
        return new MongoLockProvider(mongoDatabase);
    }
}
