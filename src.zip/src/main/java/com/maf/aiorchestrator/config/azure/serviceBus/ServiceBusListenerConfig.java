package com.maf.aiorchestrator.config.azure.serviceBus;

import com.azure.messaging.servicebus.ServiceBusClientBuilder;
import com.azure.messaging.servicebus.ServiceBusProcessorClient;
import com.azure.messaging.servicebus.ServiceBusReceivedMessageContext;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.maf.aiorchestrator.dto.jms.NotificationMessage;
import com.maf.aiorchestrator.enums.ServiceBusName;
import com.maf.aiorchestrator.listener.AIOrchImportListener;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import net.minidev.json.JSONValue;
import org.apache.commons.lang3.StringUtils;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration(proxyBeanMethods=false)
@Slf4j
@Getter
@RequiredArgsConstructor
public class ServiceBusListenerConfig {

    private final ObjectMapper objectMapper;
    private final ServiceBusPropertyConfig propertyConfig;
    private final AIOrchImportListener importListener;

    @Bean
    public void catalogSBListener() {
        ServiceBusProperties properties = propertyConfig.get(ServiceBusName.CATALOG_IMPORT);
        ServiceBusProcessorClient processorClient = new ServiceBusClientBuilder()
                .connectionString(properties.getConnectionString())
                .processor()
                .disableAutoComplete()
                .topicName(properties.getTopicName())
                .subscriptionName(properties.getSubscriptionName())
                .processMessage(m -> process(m, ServiceBusName.CATALOG_IMPORT))
                .processError(errorContext -> log.error("Error occurred while receiving message", errorContext.getException())).buildProcessorClient();
        processorClient.start();
    }

    private void process(ServiceBusReceivedMessageContext messageContext, ServiceBusName serviceBusName) {
        if (messageContext.getMessage() == null) {
            log.error("Skip null message from {} - {}", serviceBusName, messageContext);
            messageContext.complete();
            return;
        }
        String jsonMessage = messageContext.getMessage().getBody().toString();
        if (StringUtils.isBlank(jsonMessage) || !JSONValue.isValidJsonStrict(jsonMessage)) {
            log.error("Invalid message from {} - {}", serviceBusName, messageContext);
            messageContext.complete();
            return;
        }
        try {
            log.info("Received Message from {} - {}", serviceBusName, jsonMessage);
            NotificationMessage message = objectMapper.readValue(jsonMessage, NotificationMessage.class);
            //Invoke message processing logic which implemented by subclass
            importListener.processMessage(message);
            messageContext.complete();
        } catch (Exception ex) {
            log.error("Error occurred while processing message from {} - {}", serviceBusName, jsonMessage, ex);
            messageContext.abandon();
        }
    }
}
