package com.maf.aiorchestrator.config;

import com.maf.aiorchestrator.config.client.ServiceConfiguration;
import com.maf.aiorchestrator.config.client.ServiceProperties;
import com.maf.aiorchestrator.enums.ServiceName;
import io.netty.channel.ChannelOption;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpHeaders;
import org.springframework.http.client.reactive.ReactorClientHttpConnector;
import org.springframework.web.reactive.function.client.ExchangeFilterFunction;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;
import reactor.netty.http.client.HttpClient;
import reactor.netty.resources.ConnectionProvider;

import java.time.Duration;
import java.util.Map;
import java.util.function.Consumer;

@Slf4j
@Configuration
@AllArgsConstructor(onConstructor_ = {@Autowired})
public class WebClientConfig {

    private ServiceConfiguration serviceConfiguration;

    @Bean(name = "pimServiceWebClient")
    public WebClient pimServiceWebClient() {
        ServiceProperties properties = serviceConfiguration.get(ServiceName.PIM);
        return WebClient.builder()
                .baseUrl(properties.getBaseUrl())
                .filter(logRequest())
                .filter(logResponse())
                .defaultHeaders(setHeaders(properties.getHeaders()))
                .clientConnector(setHttpConnectionProperties(properties))
                .build();
    }

    @Bean(name = "aiEngineWebClient")
    public WebClient aiEngineWebClient() {
        ServiceProperties properties = serviceConfiguration.get(ServiceName.AI_ENGINE);
        return WebClient.builder()
                .baseUrl(properties.getBaseUrl())
                .filter(logRequest())
                .filter(logResponse())
                .defaultHeaders(setHeaders(properties.getHeaders()))
                .clientConnector(setHttpConnectionProperties(properties))
                .build();
    }

    private ReactorClientHttpConnector setHttpConnectionProperties(ServiceProperties properties){
        ConnectionProvider provider = ConnectionProvider.builder(properties.getConnectionPoolName())
                .maxConnections(properties.getMaxConnection()).build();
        HttpClient client = HttpClient.create(provider).option(ChannelOption.CONNECT_TIMEOUT_MILLIS, properties.getConnectionTimeout().intValue())
                .option(ChannelOption.SO_KEEPALIVE, true)
                .responseTimeout(Duration.ofMillis(properties.getReadTimeout()));

        return new ReactorClientHttpConnector(client);
    }

    public static ExchangeFilterFunction logRequest() {
        return ExchangeFilterFunction.ofRequestProcessor(clientRequest -> {
            log.info("Request: {} {} {}", clientRequest.method(), clientRequest.url(),clientRequest.body());
            clientRequest.headers().forEach((name, values) ->
                    values.forEach(value -> log.debug("{}={}", name, value)));
            return Mono.just(clientRequest);
        });
    }

    public static ExchangeFilterFunction logResponse() {
        return ExchangeFilterFunction.ofResponseProcessor(clientResponse -> {
            log.info("Response status: {}", clientResponse.statusCode());
            clientResponse.headers().asHttpHeaders().forEach((name, values) ->
                    values.forEach(value -> log.debug("{}={}", name, value)));
            return Mono.just(clientResponse);
        });
    }

    public static Consumer<HttpHeaders> setHeaders(Map<String,String> headerMap) {
        Consumer<HttpHeaders> headersConsumer =  null;
        if (headerMap != null && headerMap.size() > 0) {
            headersConsumer = headers ->
                    headerMap.forEach(headers::add);
        }
        return headersConsumer;
    }
}
