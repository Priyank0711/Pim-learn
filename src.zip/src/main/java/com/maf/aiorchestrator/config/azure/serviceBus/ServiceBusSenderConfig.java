package com.maf.aiorchestrator.config.azure.serviceBus;

import com.azure.messaging.servicebus.ServiceBusClientBuilder;
import com.azure.messaging.servicebus.ServiceBusSenderClient;
import com.maf.aiorchestrator.enums.ServiceBusName;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration(proxyBeanMethods=false)
@Slf4j
@Getter
@RequiredArgsConstructor
public class ServiceBusSenderConfig {
    private final ServiceBusPropertyConfig propertyConfig;

    @Bean
    public ServiceBusSenderClient serviceBusSenderClient() {
        ServiceBusProperties properties = propertyConfig.get(ServiceBusName.PRODUCT_VALIDATION);
        return new ServiceBusClientBuilder()
                .connectionString(properties.getConnectionString())
                .sender()
                .topicName(properties.getTopicName())
                .buildClient();
    }

}
