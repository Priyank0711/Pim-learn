package com.maf.aiorchestrator.config.azure.storage.config;

import com.azure.storage.blob.BlobContainerClient;
import com.azure.storage.blob.BlobServiceClient;
import com.azure.storage.blob.BlobServiceClientBuilder;
import com.maf.aiorchestrator.properties.StorageProperties;
import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Data
@Configuration
public class CatalogAzureConfig {

    @Bean
    @ConfigurationProperties("azure.storage")
    public StorageProperties storageProperties() {
        return new StorageProperties();
    }

    @Bean
    public BlobServiceClient blobServiceClient(){
        return new BlobServiceClientBuilder()
                .connectionString(storageProperties().getConnectionString())
                .buildClient();
    }

    @Bean
    public BlobContainerClient blobContainerClient(){
       return blobServiceClient().getBlobContainerClient(storageProperties().getContainerName());
    }


}
