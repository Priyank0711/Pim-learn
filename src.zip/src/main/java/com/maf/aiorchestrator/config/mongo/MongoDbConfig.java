package com.maf.aiorchestrator.config.mongo;

import com.mongodb.ConnectionString;
import com.mongodb.MongoClientSettings;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.mongodb.config.EnableMongoAuditing;
import org.springframework.data.mongodb.config.EnableReactiveMongoAuditing;
import org.springframework.data.mongodb.repository.config.EnableMongoRepositories;
import org.springframework.scheduling.annotation.EnableScheduling;

import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;

@Configuration
@EnableScheduling
@EnableMongoRepositories(basePackages = {"com.maf.aiorchestrator.repository"})
@EnableMongoAuditing
@EnableReactiveMongoAuditing
@Slf4j
public class MongoDbConfig {

    @Value("${mongodb.database}")
    private String dbName;

    @Value("${mongodb.uri}")
    private String uri;

    @Value("${mongodb.username}")
    private String mongodbUsername;

    @Value("${mongodb.password}")
    private String mongodbPassword;

    protected String getDatabaseName() {
        return dbName;
    }

    @Bean
    public MafMongoTemplate mongoTemplate(){
        return new MafMongoTemplate(mongoClient(), getDatabaseName());
    }

    private String getUrlEncodedString(String plainText){
        return URLEncoder.encode(plainText, StandardCharsets.UTF_8);
    }


    @Bean
    public MongoClient mongoClient(){
        String mongodbConnectionString = "mongodb+srv://" + getUrlEncodedString(mongodbUsername) + ":" + getUrlEncodedString(mongodbPassword) + "@" + uri;
        final ConnectionString connectionString = new ConnectionString(mongodbConnectionString);
        final MongoClientSettings mongoClientSettings = MongoClientSettings.builder()
                .applyConnectionString(connectionString)
                .build();
        return MongoClients.create(mongoClientSettings);
    }

    @Bean
    public MafReactiveMongoTemplate reactiveMongoTemplate(){
        return new MafReactiveMongoTemplate(reactiveMongoClient(), getDatabaseName());
    }

    @Bean
    public com.mongodb.reactivestreams.client.MongoClient reactiveMongoClient(){
        String mongodbConnectionString = "mongodb+srv://" + getUrlEncodedString(mongodbUsername) + ":" + getUrlEncodedString(mongodbPassword) + "@" + uri;
        final ConnectionString connectionString = new ConnectionString(mongodbConnectionString);
        final MongoClientSettings mongoClientSettings = MongoClientSettings.builder()
                .applyConnectionString(connectionString)
                .build();
        return com.mongodb.reactivestreams.client.MongoClients.create(mongoClientSettings);
    }

}
