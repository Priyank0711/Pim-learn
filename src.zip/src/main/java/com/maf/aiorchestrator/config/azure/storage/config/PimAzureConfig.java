package com.maf.aiorchestrator.config.azure.storage.config;

import com.azure.storage.blob.BlobContainerClient;
import com.azure.storage.blob.BlobServiceClient;
import com.azure.storage.blob.BlobServiceClientBuilder;
import com.maf.aiorchestrator.properties.StorageProperties;
import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Data
@Configuration
public class PimAzureConfig {

    @Bean
    @ConfigurationProperties("pim.azure.storage")
    public StorageProperties pimStorageProperties() {
        return new StorageProperties();
    }

    @Bean
    public BlobServiceClient pimBlobServiceClient(){
        return new BlobServiceClientBuilder()
                .connectionString(pimStorageProperties().getConnectionString())
                .buildClient();
    }

    @Bean
    public BlobContainerClient pimBlobContainerClient(){
       return pimBlobServiceClient().getBlobContainerClient(pimStorageProperties().getContainerName());
    }


}
