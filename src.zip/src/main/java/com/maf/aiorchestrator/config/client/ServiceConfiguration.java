package com.maf.aiorchestrator.config.client;


import com.maf.aiorchestrator.enums.ServiceName;
import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;
import org.springframework.util.ObjectUtils;
import reactor.netty.resources.ConnectionProvider;

import java.util.List;

@Component
@ConfigurationProperties(prefix = "config.integration.httpclient")
@Getter
@Setter
public class ServiceConfiguration {

    private List<ServiceProperties> services;
    private DefaultProperties defaultProperties;

    public ServiceProperties get(ServiceName serviceName) {
        return services.stream()
                .filter(template -> serviceName.equals(template.getName()))
                .findFirst()
                .map(this::setDefaults)
                .orElseThrow();
    }

    private ServiceProperties setDefaults(ServiceProperties template) {
        if (ObjectUtils.isEmpty(template.getConnectionTimeout())) {
            template.setConnectionTimeout(defaultProperties.getConnectionTimeout());
        }
        if (ObjectUtils.isEmpty(template.getReadTimeout())) {
            template.setReadTimeout(defaultProperties.getReadTimeout());
        }
        if (ObjectUtils.isEmpty(template.getRetryDelay())) {
            template.setRetryDelay(defaultProperties.getRetryDelay());
        }
        if (ObjectUtils.isEmpty(template.getNoOfRetries())) {
            template.setNoOfRetries(defaultProperties.getNoOfRetries());
        }
        if (ObjectUtils.isEmpty(template.getMaxConnection())) {
            template.setMaxConnection(ConnectionProvider.DEFAULT_POOL_MAX_CONNECTIONS);
        }
        if (ObjectUtils.isEmpty(template.getConnectionPoolName())) {
            template.setConnectionPoolName(template.getName()+"_POOL");
        }
        return template;
    }
}
