package com.maf.aiorchestrator.config.azure.serviceBus;


import com.maf.aiorchestrator.enums.ServiceBusName;
import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
@ConfigurationProperties(prefix = "service-bus")
@Getter
@Setter
public class ServiceBusPropertyConfig {

    private List<ServiceBusProperties> properties;
    public ServiceBusProperties get(ServiceBusName serviceBusName) {
        return properties.stream()
                .filter(template -> serviceBusName.equals(template.getName()))
                .findFirst()
                .orElseThrow();
    }
}
