package com.maf.aiorchestrator.config;

import com.maf.aiorchestrator.properties.ESConnectionProperties;
import lombok.AllArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.elasticsearch.client.ClientConfiguration;
import org.springframework.data.elasticsearch.client.elc.ReactiveElasticsearchConfiguration;
import org.springframework.data.elasticsearch.config.EnableElasticsearchAuditing;

@EnableElasticsearchAuditing
@Configuration
@AllArgsConstructor(onConstructor_={@Autowired})
public class ReactiveElasticsearchConfig extends ReactiveElasticsearchConfiguration {

    private ESConnectionProperties esConnectionProperties;

    @Override
    public ClientConfiguration clientConfiguration() {
        return ClientConfiguration.builder()
                .connectedTo(esConnectionProperties.getHostname() + ":" + esConnectionProperties.getPort())
                .usingSsl()
                .withBasicAuth(esConnectionProperties.getUsername(), esConnectionProperties.getPassword())
                .withSocketTimeout(esConnectionProperties.getSockettimeout())
                .withConnectTimeout(esConnectionProperties.getSockettimeout())
                .build();
    }


}