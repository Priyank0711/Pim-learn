package com.maf.aiorchestrator.config.azure.serviceBus;

import com.maf.aiorchestrator.enums.ServiceBusName;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class ServiceBusProperties {
    private ServiceBusName name;
    private String connectionString;
    private String subscriptionName;
    private String topicName;
}
