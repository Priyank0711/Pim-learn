package com.maf.aiorchestrator.config.client;

import com.maf.aiorchestrator.enums.ServiceName;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

@Getter
@Setter
@ToString
public class ServiceProperties {
    private ServiceName name;
    private String connectionPoolName;
    private Integer maxConnection;
    private String baseUrl;
    private Long connectionTimeout;
    private Long readTimeout;
    private Integer noOfRetries;
    private Long retryDelay;
    private Map<String,String> headers;

    public Map<String,String> getHeaders(){
        return Optional.ofNullable(this.headers).orElseGet(HashMap::new)
                .entrySet()
                .stream()
                .collect(Collectors.toMap(Map.Entry::getKey,Map.Entry::getValue));
    }
}
