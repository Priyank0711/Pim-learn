package com.maf.aiorchestrator.config.mongo;

import com.mongodb.reactivestreams.client.MongoClient;
import org.springframework.data.mongodb.core.ReactiveMongoTemplate;

public class MafReactiveMongoTemplate extends ReactiveMongoTemplate {
    public MafReactiveMongoTemplate(MongoClient mongoClient, String databaseName) {
        super(mongoClient, databaseName);
    }
}
