package com.maf.aiorchestrator.factory;

import com.maf.aiorchestrator.properties.ElasticSearchIndexes;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Component;

@Component
@AllArgsConstructor
public class IndexFactory {
	private final ElasticSearchIndexes indexes;
	
	public String getStagedProductIndexName(String countryCode){
        return indexes.getStagedProductIndex().get(countryCode);
	}

	public String getOnlineProductIndexName(String countryCode){
		return indexes.getOnlineProductIndex().get(countryCode);
	}

}
