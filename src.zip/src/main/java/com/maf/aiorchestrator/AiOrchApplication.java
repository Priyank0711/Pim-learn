package com.maf.aiorchestrator;

import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.servers.Server;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;

@SpringBootApplication
@EnableAsync
@EnableCaching
@EnableMethodSecurity(securedEnabled = true)
@OpenAPIDefinition(servers = {@Server(url = "${server.servlet.context-path}", description = "Base Server URL")})
public class AiOrchApplication {
	public static void main(String[] args) {
		SpringApplication.run(AiOrchApplication.class, args);
	}
}
