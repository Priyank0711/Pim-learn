package com.maf.aiorchestrator.scheduler;

import com.maf.aiorchestrator.enums.Country;
import com.maf.aiorchestrator.service.FileExportService;
import com.maf.aiorchestrator.service.JobService;
import com.maf.aiorchestrator.utils.Constants;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import net.javacrumbs.shedlock.spring.annotation.SchedulerLock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

@Slf4j
@Component
@AllArgsConstructor(onConstructor_ = {@Autowired})
public class FileExportScheduler {

    private final JobService jobService;
    private final FileExportService service;

    @Scheduled(cron="${scheduler.job.file.export.cron.expression}")
    @SchedulerLock(name = "file_export_scheduleJob_uae", lockAtLeastFor="${scheduler.job.file.export.lockAtLeastFor.duration}",lockAtMostFor = "${scheduler.job.file.export.lockAtMostFor.duration}")
    public void scheduleExportJob() {
        log.info("file_export_scheduleJob_uae started.");
        jobService.executeJob(Constants.FILE_EXPORT_JOB_CODE, job -> service.execute(job.getLastUpdated(), Country.UAE));
        log.info("file_export_scheduleJob_uae finished.");
    }

    @Scheduled(cron="${scheduler.job.file.export.cron.expression}")
    @SchedulerLock(name = "file_export_scheduleJob_sau", lockAtLeastFor="${scheduler.job.file.export.lockAtLeastFor.duration}",lockAtMostFor = "${scheduler.job.file.export.lockAtMostFor.duration}")
    public void scheduleSauExportJob() {
        log.info("file_export_scheduleJob_sau started.");
        jobService.executeJob(Constants.FILE_EXPORT_JOB_CODE_SAU, job -> service.execute(job.getLastUpdated(), Country.SAU));
        log.info("file_export_scheduleJob_sau finished.");
    }
}
