package com.maf.aiorchestrator.repository;

import com.maf.aiorchestrator.entities.CronJob;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface CronJobRepository extends MongoRepository<CronJob, String> {
}
