package com.maf.aiorchestrator.repository;

import com.maf.aiorchestrator.entities.EnrichOption;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.List;

public interface EnrichOptionsRepository extends MongoRepository<EnrichOption, String> {

    List<EnrichOption> findByNameInOrUiEnabledFalse(List<String> name);
}
