package com.maf.aiorchestrator.repository;

import com.maf.aiorchestrator.entities.ImportsData;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.List;


public interface ImportsDataRepository extends MongoRepository<ImportsData, String> {

    List<ImportsData> findByImportIdIn(List<String> importIdList);

    ImportsData findByImportId(String importId);

}
