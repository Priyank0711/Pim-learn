package com.maf.aiorchestrator.repository;

import com.maf.aiorchestrator.entities.CategoryFormat;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface CategoryFormatRepository extends MongoRepository<CategoryFormat, String> {

    CategoryFormat findByCode(String code);

    boolean existsByCodeAndIsIncluded(String code, boolean isIncluded);

}
