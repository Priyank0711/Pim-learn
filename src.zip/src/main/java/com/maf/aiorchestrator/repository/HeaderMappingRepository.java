package com.maf.aiorchestrator.repository;

import com.maf.aiorchestrator.entities.FileHeaderMapping;
import com.maf.aiorchestrator.enums.FileType;
import com.maf.aiorchestrator.utils.Constants;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.Optional;

public interface HeaderMappingRepository extends MongoRepository<FileHeaderMapping, String> {

@Cacheable(key = "#fileType", value = Constants.HEADER_MAPPING_CACHE)
    Optional<FileHeaderMapping> findByFileType(FileType fileType);
}
