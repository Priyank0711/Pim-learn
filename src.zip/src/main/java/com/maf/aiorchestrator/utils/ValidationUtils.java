package com.maf.aiorchestrator.utils;

import com.maf.aiorchestrator.dto.ProductAIDTO;
import com.maf.aiorchestrator.dto.file.ColumnValue;
import lombok.experimental.UtilityClass;
import org.apache.commons.lang3.StringUtils;

import java.util.List;

@UtilityClass
public class ValidationUtils {

    public static boolean validateRowData(List<String> requiredAttributes, List<ColumnValue> columns) {
        // Check if all required attributes are present as the header in columns list and column value should not be empty and column lang should be en
        return requiredAttributes.stream().allMatch(requiredAttribute -> columns.stream()
                .anyMatch(column ->
                        "en".equalsIgnoreCase(column.getHeader().getLang())
                        && requiredAttribute.equalsIgnoreCase(column.getHeader().getKey().trim())
                        && !column.getValue().isBlank()));
    }

    public static boolean validateScanProduct(List<String> requiredAttributes, ProductAIDTO product) {
        // Check if all required attributes are present in the product meta attributes and the value is not empty
        return requiredAttributes.stream().allMatch(requiredAttribute -> product.getMetaAttributes().containsKey(requiredAttribute)
                && StringUtils.isNotBlank(product.getMetaAttributes().get(requiredAttribute).get("en")));
    }
}
