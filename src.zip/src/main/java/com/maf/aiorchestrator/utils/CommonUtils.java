package com.maf.aiorchestrator.utils;

import com.maf.aiorchestrator.dto.file.CsvMetadata;
import lombok.experimental.UtilityClass;
import org.springframework.util.CollectionUtils;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@UtilityClass
public class CommonUtils {

    public static Map<String, Map<String, String>> filterEnglishOnlyMap(Map<String, Map<String, String>> attributes){
        if(CollectionUtils.isEmpty(attributes)){
            return null;
        }
        return attributes.entrySet().stream()
                .collect(Collectors.toMap(
                        Map.Entry::getKey, // Keep the original key
                        entry -> {
                            Map<String, String> newInnerMap = new HashMap<>();
                            String enValue = entry.getValue().getOrDefault("en",""); // Fetch the "en" value directly
                            newInnerMap.put("en", enValue); // Add to new inner map if it exists
                            return newInnerMap; // Return the new inner map
                        }
                ));
    }


    public static CsvMetadata parseCSVMetadata(String metadataString) {
        CsvMetadata metadata = new CsvMetadata();
        metadata.setMetaDataString(metadataString);
        String[] pairs = metadataString.split(",");
        for (String pair : pairs) {
            String[] keyValue = pair.split(":");
            switch (keyValue[0].trim().toUpperCase()) {
                case Constants.TEMPLATE_TYPE -> metadata.setTemplateType(keyValue[1].trim());
                case Constants.CATEGORY_CODE -> metadata.setCategoryCode(keyValue[1].trim());
                case Constants.ROLES -> metadata.setRoles(List.of(keyValue[1].replace("[", "").
                        replace("]", "").split("~")));
                case Constants.EMAIL_ID -> metadata.setEmailId(keyValue[1].trim());
            }
        }
        return metadata;
    }

}
