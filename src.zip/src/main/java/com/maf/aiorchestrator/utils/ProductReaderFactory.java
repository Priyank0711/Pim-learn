package com.maf.aiorchestrator.utils;

import com.maf.aiorchestrator.enums.ImportType;
import com.maf.aiorchestrator.reader.ProductReader;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.EnumMap;
import java.util.Optional;
import java.util.Set;


@Component
@Slf4j
public class ProductReaderFactory {

    private EnumMap<ImportType, ProductReader> strategies;

    @Autowired
    public ProductReaderFactory(Set<ProductReader> strategySet) {
        createStrategy(strategySet);
    }

    private void createStrategy(Set<ProductReader> strategySet) {
        strategies = new EnumMap<>(ImportType.class);
        strategySet.forEach(strategy -> strategies.put(strategy.getImportType(), strategy));
    }

    public Optional<ProductReader> findStrategy(ImportType importType) {
        if (!strategies.containsKey(importType)) {
            log.info("No Strategy exists for import type "+importType);
            return Optional.empty();
        }
        return Optional.of(strategies.get(importType));
    }
}
