package com.maf.aiorchestrator.utils;

import lombok.experimental.UtilityClass;
import org.apache.commons.csv.*;
import org.apache.commons.io.FileUtils;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.maf.aiorchestrator.utils.Constants.CSV_DELIMITER;

@UtilityClass
public class CsvUtils {

    public static File writeContentInNewCsv(List<String[]> data, String prefixFileName, String suffixFileName) throws IOException {
        // Create a temporary file for the CSV content
        String path = "data/export/" + prefixFileName+suffixFileName;
        File csvContent = new File(path);
        csvContent.getParentFile().mkdirs();
        CSVFormat csvFormat = CSVFormat.Builder.create()
                .setDelimiter(CSV_DELIMITER)
                .setRecordSeparator(System.lineSeparator())
                .setQuoteMode(QuoteMode.ALL)
                .build();
        // Create a FileWriter to write to the file
        try (FileWriter outputFile = new FileWriter(csvContent);
             CSVPrinter csvPrinter = new CSVPrinter(outputFile, csvFormat)) {

            // Write each row of data to the CSV file
            for (String[] row : data) {
                csvPrinter.printRecord((Object[]) row);
            }
        }
        // Return the created file
        return csvContent;
    }

    public static List<Map<String, String>> parseCsvRows(CSVFormat csvFormat, BufferedReader reader) throws IOException {
        List<Map<String, String>> resultList = new ArrayList<>();
        // Parse and process records
        try (CSVParser csvParser = new CSVParser(reader, csvFormat)) {
            for (CSVRecord csvRecord : csvParser) {
                if (csvRecord.isConsistent() && !csvRecord.stream().allMatch(String::isBlank)) {
                    Map<String, String> rowMap = new HashMap<>();
                    for (String header : csvParser.getHeaderNames()) {
                        rowMap.put(header, csvRecord.get(header));
                    }
                    resultList.add(rowMap);
                }
            }
        }
        return resultList;
    }

    public static void cleanUpTempFiles(List<File> files) {
        for (File file : files) {
            FileUtils.deleteQuietly(file);
        }
    }
}
