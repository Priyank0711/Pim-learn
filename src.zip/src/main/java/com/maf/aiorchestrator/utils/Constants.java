package com.maf.aiorchestrator.utils;

public class Constants {

    public static final String LOCALIZED_ATTR_REGEX = "\\s*([\\S\\s]*[^\\s])\\s*\\[\\s*(\\S+)\\s*]\\s*\\[\\s*(\\S+)\\s*]|\\s*([\\S\\s]*[^\\s])\\s*\\[\\s*(\\S+)\\s*]";
    public static final int AI_BATCH_SIZE = 2;
    public static final int FILE_BATCH_SIZE = 6;
    public static final int SCAN_BATCH_SIZE = 10;
    public static final String TEMPLATE_TYPE = "TEMPLATETYPE";
    public static final String CATEGORY_CODE = "CATEGORY_CODE";
    public static final String ROLES = "ROLES";
    public static final String EMAIL_ID = "EMAILID";
    public static final String FILE_EXPORT_JOB_CODE = "file-export-products-uae";

    public static final String FILE_EXPORT_JOB_CODE_SAU = "file-export-products-sau";
    public static final String PIM_FILE_FORMAT = "-CLASSIFICATION-AI_ENRICHED.csv";
    public static final String PRODUCT_FILE_NAME = "carrefour-";
    public static final char CSV_DELIMITER = '|';
    public static final String PROMPT_FORMAT = "{PROMPT_PATTERN}";
    public static final String PRODUCT_REVIEWED = "Selected products got reviewed";
    public static final String PRODUCT_NOT_REVIEWED = "%d products are not reviewed, please review them";
    public static final String IMPORT_REVIEWED = "Import is %s";
    public static final String AI = "ai-";

    public static final String JWT_CLAIM_ROLES_KEY =  "/roles";
    public static final String JWT_CLAIM_EMAIL_KEY =  "/email";
    public static final String JWT_CLAIM_ISSUER_KEY = "iss";
    public static final String JWT_CLAIM_MAF_EMAIL_KEY = "email";
    public static final String JWT_CLAIM_COUNTRY_KEY =  "/country";


    public static final String IMPORT_ID_OR_PRODUCT_ID_REQUIRED = "Import Id or Product Id is required";
    public static final String SCAN_IDENTIFIER = "ai_scan";
    public static final String PIM_ATTRIBUTES_CACHE = "pimAttributeCache";
    public static final String HEADER_MAPPING_CACHE = "headerMappingCache";

    public static final String TEMPLATE_TYPE_HEADER ="\"templateType:PIM_PRODUCT\"";
    public static final String DEFAULT_CATEGORY_CODE = "food_category";

}
