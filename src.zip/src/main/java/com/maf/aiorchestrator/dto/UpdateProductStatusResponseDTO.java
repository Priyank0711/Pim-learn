package com.maf.aiorchestrator.dto;

import com.maf.aiorchestrator.elastic.utils.MafFacetTerm;
import lombok.Data;

import java.util.List;

@Data
public class UpdateProductStatusResponseDTO {

    List<MafFacetTerm> statusCountList;
    String message;

}
