package com.maf.aiorchestrator.dto.file;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serial;
import java.io.Serializable;

@Data
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class HeaderData implements Serializable {

	@Serial
	private static final long serialVersionUID = -412562393908542274L;
	private String key;
	private String lang;//language
	private boolean isClassificationAttribute ;
}
