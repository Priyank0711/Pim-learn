package com.maf.aiorchestrator.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.maf.aiorchestrator.elastic.request.OnlineProductsScanRequest;
import com.maf.aiorchestrator.entities.ImportsData;
import lombok.Data;

import java.io.File;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class ImportWrapperDTO {

    private File file;
    private ImportsData importsData;
    private OnlineProductsScanRequest scanRequest;
}
