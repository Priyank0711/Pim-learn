package com.maf.aiorchestrator.dto;

import com.maf.aiorchestrator.enums.Country;
import com.maf.aiorchestrator.enums.UserRole;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Set;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class JwtTokenParams {

	private Set<UserRole> roles;
	private String email;
	private Set<Country> country;

}
