package com.maf.aiorchestrator.dto;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.maf.aiorchestrator.enums.Country;
import com.maf.aiorchestrator.enums.ProductStatus;
import lombok.Data;

import java.util.Map;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class ProductAIDTO {
    private String productId;
    private String productName;
    private Map<String, Map<String, String>> classAttributes;
    private Map<String, Map<String, String>> metaAttributes;
    private Country country;
    private String categoryCode;
    private String categoryName;
    @JsonIgnore
    private transient ProductStatus status = ProductStatus.PENDING;
}
