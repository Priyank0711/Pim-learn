package com.maf.aiorchestrator.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

import java.io.Serial;
import java.io.Serializable;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@Data
public class EnrichedData implements Serializable {
    @Serial
    private static final long serialVersionUID = 6546585373895202346L;
    private Map<String, Map<String, String>> classAttributes;
    private Map<String, Map<String, String>> metaAttributes;
}
