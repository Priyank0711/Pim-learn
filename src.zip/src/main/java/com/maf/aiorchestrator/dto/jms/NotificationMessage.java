package com.maf.aiorchestrator.dto.jms;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serial;
import java.io.Serializable;

@Data
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class NotificationMessage implements Serializable{
	@Serial
	private static final long serialVersionUID = 2043010485182794206L;
	private String importId;
	private String shopId;
	private String country;
	private FileDetails file;
	private String templateType;
	private FileDetails transformedFile;
	private AIEnrichRequest enrichRequest;
	private String categoryCode;
	private String status;

}
