package com.maf.aiorchestrator.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

import java.util.Map;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class ProductElkUpdateDTO {
    private String id;
    private Map<String, Map<String, String>> enrichedMetaAttributes;
    private Map<String, Map<String, String>> enrichedClassAttributes;
}
