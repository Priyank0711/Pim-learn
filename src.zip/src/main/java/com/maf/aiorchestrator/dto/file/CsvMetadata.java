package com.maf.aiorchestrator.dto.file;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

import java.util.List;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class CsvMetadata {
    private String metaDataString;
    private String templateType;
    private String categoryCode;
    private List<String> roles;
    private String emailId;
}
