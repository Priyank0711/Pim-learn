package com.maf.aiorchestrator.dto;

import com.maf.aiorchestrator.enums.ProductStatus;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

import java.util.List;

@Data
public class UpdateStatusRequestDTO {

    String importId;
    List<String> elasticIdList;
    @NotNull
    ProductStatus status;

}
