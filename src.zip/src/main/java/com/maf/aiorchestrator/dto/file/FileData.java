package com.maf.aiorchestrator.dto.file;

import com.maf.aiorchestrator.enums.FileType;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serial;
import java.io.Serializable;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class FileData implements Serializable {

	@Serial
	private static final long serialVersionUID = 4654614404312264785L;
	private String name;
	private String location;
	private FileType fileType;
	private CsvMetadata csvMetadata;

}
