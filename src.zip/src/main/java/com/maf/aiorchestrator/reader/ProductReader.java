package com.maf.aiorchestrator.reader;

import com.maf.aiorchestrator.dto.ImportWrapperDTO;
import com.maf.aiorchestrator.dto.ProductAIDTO;
import com.maf.aiorchestrator.enums.ImportType;
import reactor.core.publisher.Flux;

import java.util.List;

public interface ProductReader {

    ImportType getImportType();
    Flux<ProductAIDTO> getProducts(ImportWrapperDTO importsWrapperDTO, List<String> requiredAttributes);
}
