package com.maf.aiorchestrator.reader;

import com.maf.aiorchestrator.dto.ImportWrapperDTO;
import com.maf.aiorchestrator.dto.ProductAIDTO;
import com.maf.aiorchestrator.dto.file.ColumnValue;
import com.maf.aiorchestrator.dto.file.HeaderData;
import com.maf.aiorchestrator.dto.pim.AttributeResponse;
import com.maf.aiorchestrator.entities.ImportsData;
import com.maf.aiorchestrator.enums.ImportType;
import com.maf.aiorchestrator.enums.ProductStatus;
import com.maf.aiorchestrator.service.HeaderMappingService;
import com.maf.aiorchestrator.service.ImportsDataService;
import com.maf.aiorchestrator.service.PimService;
import com.maf.aiorchestrator.utils.Constants;
import com.maf.aiorchestrator.utils.CsvUtils;
import com.maf.aiorchestrator.utils.ValidationUtils;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.csv.CSVFormat;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.maf.aiorchestrator.utils.CommonUtils.parseCSVMetadata;

@Slf4j
@Service
@AllArgsConstructor
public class FileProductReader implements ProductReader {

    private final HeaderMappingService headerMappingService;
    private final ImportsDataService importsDataService;
    private final PimService pimService;

    @Override
    public ImportType getImportType() {
        return ImportType.FILE;
    }

    @Override
    public Flux<ProductAIDTO> getProducts(ImportWrapperDTO importsWrapperDTO, List<String> requiredAttributes) {
        ImportsData importsData = importsWrapperDTO.getImportsData();
        try {
            File file = importsWrapperDTO.getFile();
            List<Map<String, String>> rows = parseCsv(file, importsData);

            String categoryCode = importsData.getFileData().getCsvMetadata().getCategoryCode();
            AttributeResponse attributeResponse = pimService.getClassificationAttributes(importsData.getCountry(), categoryCode);
            importsData.setCategoryName(attributeResponse.getCategoryName());
            importsDataService.save(importsData);

            List<String> headers = rows.getFirst().keySet().stream().toList(); //taking out labels
            Map<String, HeaderData> headerMap =
                    headerMappingService.createLocalizedAttributeMap(headers, importsData.getFileData().getFileType());
            headerMappingService.populateAndReflectPimClassAttributeHeader(headerMap, attributeResponse);

            return processRowsInBatches(rows, headerMap, requiredAttributes, importsData);
        } catch (Exception e) {
            log.error("Error Processing input file with import id {}", importsData.getImportId());
            return Flux.error(e);
        }
    }

    private Flux<ProductAIDTO> processRowsInBatches(List<Map<String, String>> rows,
                                                    Map<String, HeaderData> headerMap,
                                                    List<String> requiredAttributes, ImportsData importsData) {
        return Flux.defer(() -> {
            // Directly use rows as the iterable
            return Flux.fromIterable(rows)
                    .buffer(Constants.FILE_BATCH_SIZE) // Buffer rows into batches
                    .parallel() // Process in parallel
                    .flatMap(batch -> Flux.fromIterable(batch) // Iterate over each batch
                            .map(row -> convertToProductAIDTO(row, headerMap, requiredAttributes, importsData)));
        });
    }

    protected ProductAIDTO convertToProductAIDTO(Map<String, String> row,
                                                 Map<String, HeaderData> headerMap,
                                                 List<String> requiredAttributes, ImportsData importsData) {

        List<ColumnValue> columns = convertToColumnValues(row, headerMap);
        ProductAIDTO product = new ProductAIDTO();


        Map<String, Map<String, String>> classAttributes = new HashMap<>(); // <pimkey<lang,value>>
        Map<String, Map<String, String>> metaAttributes = new HashMap<>();
        // Iterate through each key-value pair in the row
        for (ColumnValue column : columns) {
            if (column.getHeader().isClassificationAttribute()) {
                // Classification attributes
                classAttributes
                        .computeIfAbsent(column.getHeader().getKey(), k -> new HashMap<>())
                        .put(column.getHeader().getLang(), column.getValue());
            } else {
                // Meta attributes
                metaAttributes
                        .computeIfAbsent(column.getHeader().getKey(), k -> new HashMap<>())
                        .put(column.getHeader().getLang(), column.getValue());
            }
        }

        // Set basic product attributes
        product.setProductId(metaAttributes.get("ean") != null ? metaAttributes.get("ean").get("en") : null);
        product.setProductName(metaAttributes.get("onlineName") != null ? metaAttributes.get("onlineName").get("en") : null);
        product.setCountry(importsData.getCountry());
        product.setCategoryCode(importsData.getCategoryCode());
        product.setCategoryName(importsData.getCategoryName());
        // Set the attributes to the product DTO
        product.setClassAttributes(classAttributes);
        product.setMetaAttributes(metaAttributes);
        //if header is a requiredAttribute and its value is empty then it's invalid product
        if (!ValidationUtils.validateRowData(requiredAttributes, columns)) {
            product.setStatus(ProductStatus.VALIDATION_FAILED);
        }
        return product; // Return the populated ProductAIDTO
    }

    private List<ColumnValue> convertToColumnValues(Map<String, String> row, Map<String, HeaderData> headerMap) {
        List<ColumnValue> columns = new ArrayList<>();
        for (Map.Entry<String, String> entry : row.entrySet()) {
            ColumnValue columnValue = new ColumnValue();
            if(headerMap.containsKey(entry.getKey())) {
                HeaderData headerData = headerMap.get(entry.getKey());
                columnValue.setHeader(headerData); // Get the attribute name
                columnValue.setValue(row.get(entry.getKey()));// Get the value for the current key
                columns.add(columnValue);
            }
        }
        return columns;
    }


    private List<Map<String, String>> parseCsv(File file, ImportsData importsData) throws IOException {
        // Initialize the result list to store processed records
        List<Map<String, String>> resultList = new ArrayList<>();

        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            // add the CSV metadata (1st line)
            importsData.getFileData().setCsvMetadata(parseCSVMetadata(reader.readLine()));
            // Skip the second line as it's not required
            reader.readLine(); // Skip the 2nd line

            // Automatically use the third line as the header by letting CSVParser handle it
            CSVFormat format = CSVFormat.Builder.create()
                    .setDelimiter('|')
                    .setSkipHeaderRecord(false)
                    .setHeader()
                    .build();

            resultList.addAll(CsvUtils.parseCsvRows(format, reader));
        }

        return resultList;
    }
}
