package com.maf.aiorchestrator.reader;

import com.maf.aiorchestrator.dto.ImportWrapperDTO;
import com.maf.aiorchestrator.dto.ProductAIDTO;
import com.maf.aiorchestrator.dto.pim.AttributeResponse;
import com.maf.aiorchestrator.elastic.request.OnlineProductsScanRequest;
import com.maf.aiorchestrator.elastic.response.MafSearchResultData;
import com.maf.aiorchestrator.elastic.service.ElasticSearchService;
import com.maf.aiorchestrator.elastic.utils.MafPageable;
import com.maf.aiorchestrator.entities.ImportsData;
import com.maf.aiorchestrator.entities.OnlineProduct;
import com.maf.aiorchestrator.enums.ImportType;
import com.maf.aiorchestrator.enums.ProductStatus;
import com.maf.aiorchestrator.service.HeaderMappingService;
import com.maf.aiorchestrator.service.PimService;
import com.maf.aiorchestrator.utils.Constants;
import com.maf.aiorchestrator.utils.ValidationUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;
import reactor.core.publisher.Flux;

import java.util.*;

@Slf4j
@Service
public class ScanningProductReader implements ProductReader {

    private final HeaderMappingService headerMappingService;
    private final ElasticSearchService elasticSearchService;
    private final PimService pimService;

    @Value("${scan.default.page.size:1000}")
    private int defaultPageSize;

    public ScanningProductReader(HeaderMappingService headerMappingService, ElasticSearchService elasticSearchService,
                                 PimService pimService) {
        this.headerMappingService = headerMappingService;
        this.elasticSearchService = elasticSearchService;
        this.pimService = pimService;
    }

    @Override
    public ImportType getImportType() {
        return ImportType.SCANNING;
    }

    @Override
    public Flux<ProductAIDTO> getProducts(ImportWrapperDTO importsWrapperDTO, List<String> requiredAttributes) {
        ImportsData importsData = importsWrapperDTO.getImportsData();
        try {
            OnlineProductsScanRequest scanRequest = importsWrapperDTO.getScanRequest();
            MafPageable pageData = new MafPageable();
            pageData.setCount(defaultPageSize);
            scanRequest.setPageData(pageData);
            MafSearchResultData<OnlineProduct> productPage;
            List<Flux<ProductAIDTO>> productFluxes = new ArrayList<>();
            do {
                log.info("{}-{} Started Scan Products for Page {} and size {}", importsData.getCountry(),
                        importsData.getCategoryName() , scanRequest.getPageData().getPage(), scanRequest.getPageData().getCount());
                productPage = elasticSearchService.getOnlineProductScanPage(scanRequest, importsData.getCountry().getCode());
                productFluxes.add(processScan(importsWrapperDTO, requiredAttributes, productPage));
                scanRequest.getPageData().setPage(productPage.getPageData().getPage() + 1);
            } while (productPage.getPageData().getTotalPages() >= scanRequest.getPageData().getPage());
            return Flux.merge(productFluxes);
        } catch (Exception e) {
            log.error("Error Processing scan with import id {}", importsData.getImportId());
            return Flux.error(e);
        }
    }

    private Flux<ProductAIDTO> processScan(ImportWrapperDTO importsWrapperDTO, List<String> requiredAttributes,
                                           MafSearchResultData<OnlineProduct> productPage) {
        ImportsData importsData = importsWrapperDTO.getImportsData();
        AttributeResponse attributeResponse = pimService.getClassificationAttributes(importsData.getCountry(),
                StringUtils.hasText(importsData.getCategoryCode())?importsData.getCategoryCode():Constants.DEFAULT_CATEGORY_CODE);

        Set<String> metaKeys =  headerMappingService.getNonLocalizedPimAttributeKeys(
                attributeResponse.getAttributeGroups().stream().limit(2).toList());
        Set<String> classKeys = headerMappingService.getNonLocalizedPimAttributeKeys(
                attributeResponse.getAttributeGroups().stream().skip(2).toList());

        return processRowsInBatches(productPage, metaKeys, classKeys, requiredAttributes, importsData);
    }

    private Flux<ProductAIDTO> processRowsInBatches(MafSearchResultData<OnlineProduct> productPage,
                                                    Set<String> metaKeys, Set<String> classKeys,
                                                    List<String> requiredAttributes, ImportsData importsData) {
        return Flux.defer(() -> {
            // Directly use rows as the iterable
            return Flux.fromIterable(productPage.getData())
                    .buffer(Constants.SCAN_BATCH_SIZE) // Buffer rows into batches
                    .parallel() // Process in parallel
                    .flatMap(batch -> Flux.fromIterable(batch) // Iterate over each batch
                            .map(product ->
                                    convertToProductAIDTO(product, metaKeys, classKeys, requiredAttributes, importsData)));
        });
    }

    protected ProductAIDTO convertToProductAIDTO(OnlineProduct onlineProduct,
                                                 Set<String> metaKeys, Set<String> classKeys,
                                                 List<String> requiredAttributes, ImportsData importsData) {

        //List<ColumnValue> columns = convertToColumnValues(onlineProduct, headerMap);
        ProductAIDTO product = new ProductAIDTO();
        Map<String, Map<String, String>> classAttributes = new HashMap<>(); // <pimkey<lang,value>>
        Map<String, Map<String, String>> metaAttributes = new HashMap<>();
        // Iterate through each key-value pair in the onlineProduct
        if(StringUtils.hasText(importsData.getCategoryCode())) {
            populateClassAttributes(classAttributes, onlineProduct, classKeys);
        }
        populateMetaAttributes(metaAttributes, onlineProduct, metaKeys);

        // Set basic product attributes
        product.setProductId(metaAttributes.get("ean") != null ? metaAttributes.get("ean").get("en") : null);
        product.setProductName(metaAttributes.get("onlineName") != null ? metaAttributes.get("onlineName").get("en") : null);
        product.setCountry(importsData.getCountry());
        product.setCategoryCode(importsData.getCategoryCode());
        product.setCategoryName(importsData.getCategoryName());
        // Set the attributes to the product DTO
        product.setClassAttributes(classAttributes);
        product.setMetaAttributes(metaAttributes);
        //if header is a requiredAttribute and its value is empty then it's invalid product
        if (!ValidationUtils.validateScanProduct(requiredAttributes, product)) {
            product.setStatus(ProductStatus.VALIDATION_FAILED);
        }
        return product; // Return the populated ProductAIDTO
    }

    private void populateMetaAttributes(Map<String, Map<String, String>> metaAttributes, OnlineProduct onlineProduct,
                                        Set<String> metaKeys) {
        metaKeys.forEach(k -> {
            Map<String, String> localizedValue = new HashMap<>();
            try {
                String enValue = (String) onlineProduct.getClass().getDeclaredMethod("get"+
                        StringUtils.capitalize(k)).invoke(onlineProduct);
                localizedValue.put("en", enValue);
                String arValue = (String) onlineProduct.getClass().getDeclaredMethod("get" +
                        StringUtils.capitalize(k) + "_ar").invoke(onlineProduct);
                localizedValue.put("ar", arValue);
            } catch (Exception e) {
                log.debug("en/ar value for key {} not found", k);
            }
            if(!localizedValue.isEmpty())
                metaAttributes.put(k, localizedValue);
        });
    }

    private void populateClassAttributes(Map<String, Map<String, String>> classAttributes, OnlineProduct onlineProduct,
                                         Set<String> classKeys) {
        if(!CollectionUtils.isEmpty(onlineProduct.getClassifications())) {
            onlineProduct.getClassifications().stream().flatMap(c -> c.getFeatures().stream())
                    .filter(f -> !CollectionUtils.isEmpty(f.getFeatureValues()))
                    .forEach(f -> {
                        Map<String, String> localizedValue = new HashMap<>();
                        f.getFeatureValues().forEach(v -> {
                            localizedValue.put("en", v.getValue());
                            localizedValue.put("ar", v.getValue_ar());
                        });
                        classAttributes.put(f.getId(), localizedValue);
                    });
        }
        classKeys.forEach(k -> classAttributes.putIfAbsent(k, Map.of("en","")));
    }
}
