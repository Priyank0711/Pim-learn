package com.maf.aiorchestrator.elastic.request;

import com.maf.aiorchestrator.enums.IndexType;
import lombok.Getter;
import lombok.Setter;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Setter
@Getter
public class ListingProductsSearchRequest extends ProductsSearchRequest {

    private static final String IMPORT_ID = "importId";
    private static final String STATUS = "status";
    private static final String CATEGORY = "category"; //code-name
    private Map<String,String> keyColumnMapping;

    public Map<String,String> createKeyColumnMapping() {
        Map<String,String> map = new HashMap<>();
        map.put(IMPORT_ID,"importId.keyword");
        map.put(STATUS,"status.keyword");
        map.put(CATEGORY,"category.keyword");
        return map;
    }

    public void setProperties() {
        Map<String, String> keyColumnMap = createKeyColumnMapping();
        setKeyColumnMapping(keyColumnMap);
    }

    @Override
    public IndexType getIndexType() {
        return IndexType.STAGED_PRODUCTS;
    }

    @Override
    public List<String> getSourceExcludes() {
        return List.of("classAttributes", "metaAttributes", "enrichedData");
    }
}
