package com.maf.aiorchestrator.elastic.utils;

import co.elastic.clients.elasticsearch._types.SortOrder;
import co.elastic.clients.elasticsearch._types.mapping.FieldType;
import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.Map;

@AllArgsConstructor
@Getter
public enum ProductsSort {

    CREATED_ASC("CREATED_ASC", "Created (oldest first)",
            SortOrder.Asc, Map.of("SP","createdTime", "OP",""), FieldType.Date),
    CREATED_DESC("CREATED_DESC", "Created (newest first)",
            SortOrder.Desc, Map.of("SP","createdTime", "OP",""), FieldType.Date),
    MODIFIED_ASC("MODIFIED_ASC", "Updated (oldest first)",
            SortOrder.Asc, Map.of("SP","lastModifiedTime", "OP",""), FieldType.Date),
    MODIFIED_DESC("MODIFIED_DESC", "Updated (newest first)",
            SortOrder.Desc, Map.of("SP","lastModifiedTime", "OP",""), FieldType.Date);

    private final String code;
    private final String value;
    private final SortOrder sortOrder;
    private final Map<String, String> fieldName;
    private final FieldType dataType;
}
