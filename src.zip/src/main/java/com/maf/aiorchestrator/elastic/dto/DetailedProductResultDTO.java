package com.maf.aiorchestrator.elastic.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

import java.util.Map;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class DetailedProductResultDTO {

    private String id;
    private String importId;
    private String productId;
    private String productName;
    private String status;
    private Map<String, Map<String, Map<String,String>>> metaAttributesComparison;
    private Map<String, Map<String, Map<String,String>>> classAttributesComparison;

}
