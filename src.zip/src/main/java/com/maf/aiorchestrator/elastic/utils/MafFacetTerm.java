package com.maf.aiorchestrator.elastic.utils;

import lombok.Data;

@Data
public class MafFacetTerm {

    String key;
    Long count;

}
