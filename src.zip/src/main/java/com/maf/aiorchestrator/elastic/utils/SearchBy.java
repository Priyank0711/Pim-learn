package com.maf.aiorchestrator.elastic.utils;

import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.List;
import java.util.Map;

@Getter
@AllArgsConstructor
public enum SearchBy {

    BY_PRODUCT_NAME("BY_PRODUCT_NAME", "By Product Name",
            Map.of("SP", List.of("productName"), "OP", List.of("name","name_ar","onlineName","onlineName_ar"))),
    BY_PRODUCT_EAN("BY_PRODUCT_EAN", "By Product EAN",
            Map.of("SP", List.of("productId"), "OP", List.of("ean"))),
    BY_PRODUCT_CODE("BY_PRODUCT_CODE", "By Product Code",
            Map.of("OP", List.of("code")));

    private final String code;
    private final String value;
    private final Map<String,List<String>> fieldNames;
}