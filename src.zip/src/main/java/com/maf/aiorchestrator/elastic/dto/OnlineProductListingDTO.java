package com.maf.aiorchestrator.elastic.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

import java.time.Instant;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class OnlineProductListingDTO {

    private String id;
    private String code;
    private String ean;
    private String name;
    private String onlineName;
    private String status;
    private String classCategory;
    private String brandName;
    private String categoryCode;
    private String productCategoriesHearchi;
    private String mainImageUrl;
    private boolean marketplaceProduct;
    private Instant creationTime;
    private Instant modifiedTime;
}
