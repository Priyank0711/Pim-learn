package com.maf.aiorchestrator.elastic.request;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.maf.aiorchestrator.elastic.utils.MafFacet;
import com.maf.aiorchestrator.elastic.utils.MafPageable;
import com.maf.aiorchestrator.elastic.utils.MafSort;
import com.maf.aiorchestrator.elastic.utils.SearchBy;
import com.maf.aiorchestrator.enums.IndexType;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
import java.util.Map;

@Data
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public abstract class ProductsSearchRequest {

    private List<MafFacet> facets;
    private MafPageable pageData;
    private MafSort sort = new MafSort();
    private String searchTerm;
    private SearchBy searchBy;

    public abstract Map<String,String> getKeyColumnMapping();
    public abstract IndexType getIndexType();
    public List<String> getSourceIncludes(){
        return List.of();
    }
    public List<String> getSourceExcludes(){
        return List.of();
    }

}
