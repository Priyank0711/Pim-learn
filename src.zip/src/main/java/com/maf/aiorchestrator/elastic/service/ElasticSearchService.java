package com.maf.aiorchestrator.elastic.service;

import co.elastic.clients.elasticsearch.core.SearchResponse;
import com.maf.aiorchestrator.elastic.dto.OnlineProductListingDTO;
import com.maf.aiorchestrator.elastic.dto.ProductResultDTO;
import com.maf.aiorchestrator.elastic.request.ProductsSearchRequest;
import com.maf.aiorchestrator.elastic.response.MafSearchResultData;
import com.maf.aiorchestrator.entities.OnlineProduct;

public interface ElasticSearchService {
    MafSearchResultData<ProductResultDTO> getStagedProductSearchResult(ProductsSearchRequest searchRequest, String country);

    MafSearchResultData<OnlineProductListingDTO> getOnlineProductListingResult(ProductsSearchRequest searchRequest, String country);

    MafSearchResultData<OnlineProduct> getOnlineProductScanPage(ProductsSearchRequest searchRequest, String country);

    <T> SearchResponse<T> getProductSearchResponse(String indexName, ProductsSearchRequest productsSearchRequest, String country, Class<T> entityClass, boolean aggregationRequired);

    <T, U> MafSearchResultData<T> transformResponse(SearchResponse<U> searchResponse, ProductsSearchRequest searchRequest, Class<T> responseClass);
}
