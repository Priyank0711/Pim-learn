package com.maf.aiorchestrator.elastic.request;

import com.maf.aiorchestrator.enums.IndexType;
import lombok.Getter;
import lombok.Setter;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Setter
@Getter
public class OnlineProductsListingRequest extends ProductsSearchRequest {

    private static final String STATUS = "status";
    private static final String CATEGORY = "category"; //code-name
    private static final String BRAND = "brand";
    private static final String MKP_PRODUCT = "marketplaceProduct";
    private static final String L1_NAV_CATEGORY = "l1NavCategory";
    private static final String L2_NAV_CATEGORY = "l2NavCategory";
    private static final String L3_NAV_CATEGORY = "l3NavCategory";
    private static final String L4_NAV_CATEGORY = "l4NavCategory";

    private Map<String,String> keyColumnMapping;

    public Map<String,String> createKeyColumnMapping() {
        Map<String,String> map = new HashMap<>();
        map.put(MKP_PRODUCT,"marketplaceProduct");
        map.put(STATUS,"status.keyword");
        map.put(CATEGORY,"classCategory.keyword");
        map.put(BRAND,"brandName.keyword");
        map.put(L1_NAV_CATEGORY,"l1NavCategory.keyword");
        map.put(L2_NAV_CATEGORY,"l2NavCategory.keyword");
        map.put(L3_NAV_CATEGORY,"l3NavCategory.keyword");
        map.put(L4_NAV_CATEGORY,"l4NavCategory.keyword");

        return map;
    }

    public void setProperties() {
        Map<String, String> keyColumnMapping = createKeyColumnMapping();
        setKeyColumnMapping(keyColumnMapping);
    }

    @Override
    public IndexType getIndexType() {
        return IndexType.ONLINE_PRODUCTS;
    }

    @Override
    public List<String> getSourceIncludes() {
        return List.of("id", "code", "ean", "name", "onlineName", "status", "brandName", "classCategory",
                "productCategoriesHearchi", "mainImageUrl", "marketplaceProduct", "modifiedTime", "creationTime");
    }
}
