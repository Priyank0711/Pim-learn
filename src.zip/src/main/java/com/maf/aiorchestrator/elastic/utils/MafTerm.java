package com.maf.aiorchestrator.elastic.utils;

import lombok.Data;

@Data
public class MafTerm {

    String key;
    String label;

}
