package com.maf.aiorchestrator.elastic.utils;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
public class MafFacet {

    List<MafFacetTerm> list;
    String selectedValue;
    String key;
    List<String> selectedValueList;

}
