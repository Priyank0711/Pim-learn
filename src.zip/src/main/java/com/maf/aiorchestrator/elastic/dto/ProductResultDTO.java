package com.maf.aiorchestrator.elastic.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

import java.time.Instant;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ProductResultDTO {

    private String id;
    private String importId;
    private String productId;
    private String productName;
    private String status;
    private String category;
    private String categoryCode;
    private Instant lastModifiedTime;
    private Instant creationTime;
}
