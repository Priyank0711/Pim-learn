package com.maf.aiorchestrator.elastic.utils;

import lombok.Data;

import java.util.ArrayList;
import java.util.List;

@Data
public class MafSearchBy {

    List<MafTerm> list = new ArrayList<>();
    SearchBy selected;
}