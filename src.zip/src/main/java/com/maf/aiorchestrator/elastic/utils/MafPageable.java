package com.maf.aiorchestrator.elastic.utils;

import lombok.Data;

@Data
public class MafPageable {

    int count;
    long totalCount;
    int page;
    int totalPages;

    public MafPageable() {
        this.count = 10;
        this.page = 1;
    }

}
