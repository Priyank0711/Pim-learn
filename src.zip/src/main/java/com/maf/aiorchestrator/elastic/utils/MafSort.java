package com.maf.aiorchestrator.elastic.utils;

import lombok.Data;

import java.util.ArrayList;
import java.util.List;

@Data
public class MafSort {

    List<MafTerm> list;
    ProductsSort selectedValue;

    public MafSort() {
        list = new ArrayList<>();
        selectedValue = ProductsSort.MODIFIED_DESC;
    }
}
