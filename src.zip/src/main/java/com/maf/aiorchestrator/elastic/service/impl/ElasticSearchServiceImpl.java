package com.maf.aiorchestrator.elastic.service.impl;

import co.elastic.clients.elasticsearch.ElasticsearchClient;
import co.elastic.clients.elasticsearch._types.ElasticsearchException;
import co.elastic.clients.elasticsearch._types.FieldValue;
import co.elastic.clients.elasticsearch._types.aggregations.*;
import co.elastic.clients.elasticsearch._types.query_dsl.BoolQuery;
import co.elastic.clients.elasticsearch._types.query_dsl.Query;
import co.elastic.clients.elasticsearch._types.query_dsl.QueryBuilders;
import co.elastic.clients.elasticsearch.core.SearchRequest;
import co.elastic.clients.elasticsearch.core.SearchResponse;
import co.elastic.clients.elasticsearch.core.search.Hit;
import co.elastic.clients.elasticsearch.core.search.HitsMetadata;
import co.elastic.clients.elasticsearch.core.search.SourceConfig;
import co.elastic.clients.elasticsearch.core.search.TotalHits;
import co.elastic.clients.util.ObjectBuilder;
import com.maf.aiorchestrator.elastic.dto.OnlineProductListingDTO;
import com.maf.aiorchestrator.elastic.dto.ProductResultDTO;
import com.maf.aiorchestrator.elastic.request.ProductsSearchRequest;
import com.maf.aiorchestrator.elastic.response.MafSearchResultData;
import com.maf.aiorchestrator.elastic.service.ElasticSearchService;
import com.maf.aiorchestrator.elastic.utils.*;
import com.maf.aiorchestrator.entities.ElkProduct;
import com.maf.aiorchestrator.entities.OnlineProduct;
import com.maf.aiorchestrator.enums.IndexType;
import com.maf.aiorchestrator.exception.MafElasticSearchException;
import com.maf.aiorchestrator.factory.IndexFactory;
import com.maf.aiorchestrator.mapper.ProductResultMapper;
import com.nimbusds.oauth2.sdk.util.StringUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.util.*;

@Slf4j
@Service
public class ElasticSearchServiceImpl implements ElasticSearchService {

    @Value("${catalog.facet.default.size:5000}")
    private int defaultFacetSize;

    private final ElasticsearchClient client;
    private final IndexFactory indexFactory;

    public ElasticSearchServiceImpl(ElasticsearchClient client, IndexFactory indexFactory) {
        this.client = client;
        this.indexFactory = indexFactory;
    }

    @Override
    public MafSearchResultData<ProductResultDTO> getStagedProductSearchResult(ProductsSearchRequest searchRequest, String country) {
        String indexName = indexFactory.getStagedProductIndexName(country);
        SearchResponse<ElkProduct> response = getProductSearchResponse(indexName, searchRequest, country, ElkProduct.class, true);
        return transformResponse(response, searchRequest, ProductResultDTO.class);
    }

    @Override
    public MafSearchResultData<OnlineProductListingDTO> getOnlineProductListingResult(ProductsSearchRequest searchRequest, String country) {
        String indexName = indexFactory.getOnlineProductIndexName(country);
        SearchResponse<OnlineProduct> response = getProductSearchResponse(indexName, searchRequest, country, OnlineProduct.class, true);
        return transformResponse(response, searchRequest, OnlineProductListingDTO.class);
    }

    @Override
    public MafSearchResultData<OnlineProduct> getOnlineProductScanPage(ProductsSearchRequest searchRequest, String country) {
        String indexName = indexFactory.getOnlineProductIndexName(country);
        SearchResponse<OnlineProduct> response = getProductSearchResponse(indexName, searchRequest, country, OnlineProduct.class, false);
        return transformResponse(response, searchRequest, OnlineProduct.class);
    }

    @Override
    public <T> SearchResponse<T> getProductSearchResponse(String indexName, ProductsSearchRequest productsSearchRequest, String country, Class<T> entityClass, boolean aggregationRequired) {
        try {
            BoolQuery.Builder boolQueryBuilder = QueryBuilders.bool();
            List<Query> queries = new ArrayList<>();

            if (StringUtils.isNotBlank(productsSearchRequest.getSearchTerm()) && productsSearchRequest.getSearchBy() != null) {
                productsSearchRequest.getSearchBy().getFieldNames().get(productsSearchRequest.getIndexType().getCode())
                        .stream().filter(Objects::nonNull).forEach(field ->
                        boolQueryBuilder.should(
                                Query.of(q -> q.match(m -> m.field(field).query(productsSearchRequest.getSearchTerm())))
                        )
                );
                boolQueryBuilder.minimumShouldMatch("1");
            }

            MafPageable pageable = productsSearchRequest.getPageData();
            validateFacets(productsSearchRequest);
            validatePageData(pageable);
            Map<String, String> mapping = productsSearchRequest.getKeyColumnMapping();
            Map<String, Aggregation> aggregationMap = new HashMap<>();
            if (productsSearchRequest.getFacets() != null) {
                productsSearchRequest.getFacets().forEach(mafFacet -> {
                    if(aggregationRequired)
                        aggregationMap.put(mafFacet.getKey(), TermsAggregation.of(t -> t.field(mapping.get(mafFacet.getKey())).size(defaultFacetSize))._toAggregation());
                    if (mapping.get(mafFacet.getKey()) != null && mafFacet.getSelectedValueList() != null && !mafFacet.getSelectedValueList().isEmpty()) {
                        queries.add(QueryBuilders.terms().field(mapping.get(mafFacet.getKey())).terms(t -> t.value(mafFacet.getSelectedValueList().stream().map(FieldValue::of).toList())).build()._toQuery());
                    } else if (!StringUtils.isBlank(mafFacet.getSelectedValue())) {
                        queries.add(QueryBuilders.match().field(mapping.get(mafFacet.getKey())).query(mafFacet.getSelectedValue()).build()._toQuery());
                    }
                });
            }

            boolQueryBuilder.must(queries);

            SearchRequest searchRequest = SearchRequest.of(s -> s
                    .index(indexName)
                    .query(boolQueryBuilder.build()._toQuery())
                    .aggregations(aggregationMap)
                    .from((pageable.getPage() - 1) * pageable.getCount())
                    .size(pageable.getCount())
                    .source(src -> applySourceFilter(src, productsSearchRequest))
                    .sort(sort -> sort.field(f -> f.field(productsSearchRequest.getSort().getSelectedValue().getFieldName().get(productsSearchRequest.getIndexType().getCode()))
                            .order(productsSearchRequest.getSort().getSelectedValue().getSortOrder())
                            .unmappedType(productsSearchRequest.getSort().getSelectedValue().getDataType())))
                    .trackTotalHits(th -> th.enabled(true))
            );
            return client.search(searchRequest, entityClass);
        } catch (ElasticsearchException | IOException e) {
            log.error("Error occurred while hitting the Elasticsearch", e);
            throw new MafElasticSearchException("Error occurred on Elasticsearch: "+e.getMessage());
        }
    }

    private ObjectBuilder<SourceConfig> applySourceFilter(SourceConfig.Builder src, ProductsSearchRequest productsSearchRequest) {
        if (!(productsSearchRequest.getSourceIncludes().isEmpty() || productsSearchRequest.getSourceExcludes().isEmpty())) {
            return src.filter(f -> f
                    .includes(productsSearchRequest.getSourceIncludes())
                    .excludes(productsSearchRequest.getSourceExcludes())
            );
        }
        if (!productsSearchRequest.getSourceIncludes().isEmpty()) {
            return src.filter(f -> f.includes(productsSearchRequest.getSourceIncludes()));
        }
        if (!productsSearchRequest.getSourceExcludes().isEmpty()) {
            return src.filter(f -> f.excludes(productsSearchRequest.getSourceExcludes()));
        }
        return src.filter(f->f.excludes(Collections.emptyList()));
    }


    @Override
    public <T, U> MafSearchResultData<T> transformResponse(SearchResponse<U> searchResponse, ProductsSearchRequest searchRequest, Class<T> responseClass) {
        MafSearchResultData<T> result = new MafSearchResultData<>();
        MafPageable pageable = new MafPageable();

        try {
            HitsMetadata<U> hits = searchResponse.hits();
            if (hits == null) return result;
            TotalHits totalHits = hits.total();
            if (totalHits == null) return result;
            pageable.setTotalCount(totalHits.value());
            pageable.setCount(hits.hits().size());
            pageable.setTotalPages(getTotalPages(totalHits.value(), searchRequest.getPageData().getCount()));
            pageable.setPage(searchRequest.getPageData().getPage());

            // based on responseClass convert hits.hits source<U> to responseClass

            result.setData(hits.hits().stream().map(Hit::source).map(e -> ProductResultMapper.INSTANCE.map(e, responseClass)).toList());
            result.setPageData(pageable);
            result.setSort(getSortableFields(searchRequest));
            result.setSearchBy(getSearchByFields(searchRequest));

            List<MafFacet> mafFacets = new ArrayList<>();
            if (searchResponse.aggregations() != null && !result.getData().isEmpty()) {
                searchResponse.aggregations().forEach((name, aggregation) -> {
                    MafFacet facet = new MafFacet();
                    facet.setKey(name);
                    if(aggregation.isSterms()) {
                        facet.setList(aggregation.sterms().buckets().array().stream().map(bucket -> {
                            MafFacetTerm term = new MafFacetTerm();
                            term.setKey(bucket.key().stringValue());
                            term.setCount(bucket.docCount());
                            return term;
                        }).toList());
                    }
                    if(aggregation.isLterms()) {
                        facet.setList(aggregation.lterms().buckets().array().stream().map(bucket -> {
                            MafFacetTerm term = new MafFacetTerm();
                            term.setKey(bucket.keyAsString());
                            term.setCount(bucket.docCount());
                            return term;
                        }).toList());
                    }
                    if (facet.getList().size() == 1) {
                        facet.setSelectedValue(facet.getList().getFirst().getKey());
                    }
                    mafFacets.add(facet);
                });
            }

            result.setFacets(mafFacets);
            return result;
        } catch (Exception e){
            log.error("Error occurred while transforming elastic search response", e);
            throw new MafElasticSearchException("Error occurred while transforming elastic search response : "+e.getMessage());
        }
    }

    private static void validateFacets(ProductsSearchRequest productsSearchRequest) {
        Map<String, String> configuredFacetsMapping = productsSearchRequest.getKeyColumnMapping();
        if (productsSearchRequest.getFacets() != null) {
            productsSearchRequest.getFacets().forEach(mafFacet -> {
                if (!configuredFacetsMapping.containsKey(mafFacet.getKey())) {
                    throw new MafElasticSearchException(String.format("%s facet not configured for search request, please add mapping in required search request", mafFacet.getKey()));
                }
            });
        }
    }

    private static void validatePageData(MafPageable pageable) {
        if (pageable.getCount() < 1 || pageable.getPage() < 1) {
            throw new MafElasticSearchException("Incorrect page data");
        }
    }

    private static int getTotalPages(long totalCount, int size) {
        if (totalCount > 0) {
            return (int) Math.ceil((double) totalCount / (double) size);
        } else {
            return 0;
        }
    }

    private MafSort getSortableFields(ProductsSearchRequest searchRequest) {
        IndexType indexType = searchRequest.getIndexType();
        final List<MafTerm> terms = new ArrayList<>();
        Arrays.stream(ProductsSort.values())
                .filter(sort -> sort.getFieldName().containsKey(indexType.getCode()))
                .forEach(sort -> {
                    MafTerm term = new MafTerm();
                    term.setKey(sort.getCode());
                    term.setLabel(sort.getValue());
                    terms.add(term);
                });
        final MafSort sort = new MafSort();
        sort.setSelectedValue(searchRequest.getSort().getSelectedValue());
        sort.setList(terms);
        return sort;
    }

    private MafSearchBy getSearchByFields(ProductsSearchRequest searchRequest) {
        final List<MafTerm> terms = getMafTerm(searchRequest.getIndexType());
        final MafSearchBy searchBy = new MafSearchBy();
        setSelectedValue(searchBy, searchRequest);
        searchBy.setList(terms);
        return searchBy;
    }

    private List<MafTerm> getMafTerm(IndexType indexType) {
        final List<MafTerm> terms = new ArrayList<>();
        Arrays.stream(SearchBy.values())
                .filter(searchBy -> searchBy.getFieldNames().containsKey(indexType.getCode()))
                .forEach(searchBy -> {
                    MafTerm term = new MafTerm();
                    term.setKey(searchBy.getCode());
                    term.setLabel(searchBy.getValue());
                    terms.add(term);
                });
        return terms;
    }

    private void setSelectedValue(MafSearchBy searchBy, ProductsSearchRequest searchRequest) {
        searchBy.setSelected(searchRequest.getSearchBy());
    }
}