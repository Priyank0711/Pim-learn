package com.maf.aiorchestrator.elastic.response;

import com.maf.aiorchestrator.elastic.utils.MafFacet;
import com.maf.aiorchestrator.elastic.utils.MafPageable;
import com.maf.aiorchestrator.elastic.utils.MafSearchBy;
import com.maf.aiorchestrator.elastic.utils.MafSort;
import lombok.Data;

import java.util.List;

@Data
public class MafSearchResultData<T> {

    private List<T> data;
    private List<MafFacet> facets;
    private MafPageable pageData;
    private MafSort sort;
    private MafSearchBy searchBy;
    private String searchTerm;

}