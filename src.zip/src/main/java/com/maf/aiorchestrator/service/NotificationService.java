package com.maf.aiorchestrator.service;


import com.maf.aiorchestrator.dto.jms.NotificationMessage;

public interface NotificationService {
	void sendNotification(NotificationMessage notificationMessage);
}
