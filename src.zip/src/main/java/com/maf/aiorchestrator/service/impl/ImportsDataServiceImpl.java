package com.maf.aiorchestrator.service.impl;

import com.maf.aiorchestrator.config.mongo.MafMongoTemplate;
import com.maf.aiorchestrator.dto.jms.NotificationMessage;
import com.maf.aiorchestrator.entities.ImportsData;
import com.maf.aiorchestrator.entities.ImportsDataCounter;
import com.maf.aiorchestrator.enums.ImportStatus;
import com.maf.aiorchestrator.repository.ImportsDataRepository;
import com.maf.aiorchestrator.service.ImportsDataService;
import com.maf.aiorchestrator.service.NotificationService;
import com.maf.aiorchestrator.utils.Constants;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Service;

@Slf4j
@Service
@RequiredArgsConstructor
public class ImportsDataServiceImpl implements ImportsDataService {

    private final ImportsDataRepository importsDataRepository;
    private final MafMongoTemplate mongoTemplate;
    private final NotificationService notificationService;

    @Override
    public void updateImportStatusInDb(ImportStatus status, String importId){
        // Define the query to find the document by ID
        log.info("updating import status in db");

        Query query = new Query(Criteria.where("importId").is(importId));

        // Define the update operation to set the new status
        Update update = new Update().set("status", status).currentDate("lastModifiedTime");

        // Execute the update
        mongoTemplate.updateFirst(query, update, ImportsData.class);

        if(status.equals(ImportStatus.APPROVED) || status.equals(ImportStatus.REJECTED)){
            sendNotification(status.name(), importId);
        }
    }

    public void sendNotification(String status, String importId) {
        NotificationMessage message = new NotificationMessage();
        message.setImportId(importId);
        message.setTemplateType("PIM_PRODUCT");
        message.setStatus(status);
        notificationService.sendNotification(message);
    }

    @Override
    public ImportsData save(ImportsData importsData){
        return importsDataRepository.save(importsData);
    }

    @Override
    public ImportsData saveScanImport(ImportsData importsData) {
        ImportsDataCounter importsDataCounter = mongoTemplate.getCounter(Query.query(Criteria.where("shopId").is(Constants.SCAN_IDENTIFIER))
                , ImportsDataCounter.class);
        importsData.setImportId(Constants.SCAN_IDENTIFIER + "_" + importsDataCounter.getCounter());
        return save(importsData);
    }

}
