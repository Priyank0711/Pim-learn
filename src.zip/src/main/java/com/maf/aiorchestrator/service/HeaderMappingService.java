package com.maf.aiorchestrator.service;

import com.maf.aiorchestrator.dto.file.HeaderData;
import com.maf.aiorchestrator.dto.pim.AttributeGroupDTO;
import com.maf.aiorchestrator.dto.pim.AttributeResponse;
import com.maf.aiorchestrator.enums.FileType;

import java.util.List;
import java.util.Map;
import java.util.Set;

public interface HeaderMappingService {

    Map<String, HeaderData> createLocalizedAttributeMap(List<String> headers, FileType fileType);

    void populateAndReflectPimClassAttributeHeader(Map<String, HeaderData> localizedAttributeMappingMap, AttributeResponse attributeResponse);

    Set<String> getNonLocalizedPimAttributeKeys(List<AttributeGroupDTO> attributeGroups);
}
