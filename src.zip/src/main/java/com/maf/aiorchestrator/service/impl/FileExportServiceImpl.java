package com.maf.aiorchestrator.service.impl;

import com.maf.aiorchestrator.entities.ElkProduct;
import com.maf.aiorchestrator.entities.ImportsData;
import com.maf.aiorchestrator.enums.Country;
import com.maf.aiorchestrator.enums.ImportStatus;
import com.maf.aiorchestrator.enums.ProductStatus;
import com.maf.aiorchestrator.exception.JobExecutionException;
import com.maf.aiorchestrator.repository.ImportsDataRepository;
import com.maf.aiorchestrator.service.ElkService;
import com.maf.aiorchestrator.service.FileExportService;
import com.maf.aiorchestrator.service.ProductService;
import com.maf.aiorchestrator.service.StorageService;
import com.maf.aiorchestrator.utils.Constants;
import com.maf.aiorchestrator.utils.CsvUtils;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;
import reactor.core.publisher.Mono;
import reactor.core.scheduler.Schedulers;

import java.io.File;
import java.io.IOException;
import java.time.Instant;
import java.util.*;
import java.util.stream.Collectors;

import static com.maf.aiorchestrator.utils.Constants.AI;
import static com.maf.aiorchestrator.utils.Constants.PIM_FILE_FORMAT;

@Slf4j
@Service
@AllArgsConstructor
public class FileExportServiceImpl implements FileExportService {

    private final ProductService productService;
    private final StorageService storageService;
    private final ImportsDataRepository importsDataRepository;
    private final ElkService elkService;

    @Override
    public void execute(Instant lastUpdated, Country country) {
        List<ElkProduct> elkProductList = elkService.getProductsByStatus(ProductStatus.APPROVED, lastUpdated, country);
        if (CollectionUtils.isEmpty(elkProductList)) {
            log.info("No products found for export.");
            return;
        }
        Map<String, List<ElkProduct>> categoryProductsMap = elkProductList.stream()
                .peek(p -> {
                    if (!StringUtils.hasText(p.getCategory())) {
                        p.setCategory(Constants.DEFAULT_CATEGORY_CODE);
                    }
                })
                .collect(Collectors.groupingBy(ElkProduct::getCategory));
        categoryProductsMap.keySet().parallelStream().forEach(category -> {
            File csvFile = null;
            try {
                List<ElkProduct> elkProducts = categoryProductsMap.get(category);
                ImportsData importsData = importsDataRepository.findByImportId(elkProducts.getFirst().getImportId());
                List<Map<String, String>> exportProductList = productService.getExportProductList(elkProducts);
                long timestamp = Instant.now().toEpochMilli();
                int shortId = (int) (timestamp % 1000000);
                String uuid = String.format("%06d", shortId);
                csvFile = createCsvFile(exportProductList, importsData, AI+uuid);
                storageService.uploadPimFile(csvFile, csvFile.getName(), country.getCode());
            } catch (IOException e) {
                throw new JobExecutionException(String.format("Error while publishing csv file to PIM for categoryCode : %s",
                        category), e);
            } finally {
                if(csvFile != null)
                    CsvUtils.cleanUpTempFiles(List.of(csvFile));
            }
        });
    }


    @Override
    public void publishImport(String importId) {
        log.info("Publishing import : {}", importId);
        Mono.fromRunnable(() -> publishApprovedImportsToPIM(importId))
                .subscribeOn(Schedulers.boundedElastic())
                .doOnError(e -> log.error("Error occurred while publishing import : {}", importId, e))
                .subscribe();
    }

    protected void publishApprovedImportsToPIM(String importId) {
        ImportsData importsData = importsDataRepository.findByImportId(importId);
        if(importsData != null && ImportStatus.APPROVED.equals(importsData.getStatus())) {
            File csvFile = null;
            try {
                List<Map<String, String>> products = productService.getProductsByImportIdForExport(importsData.getImportId(), importsData.getCountry().getCode());
                csvFile = createCsvFile(products, importsData, importsData.getShopId()+ "-" +importId);
                storageService.uploadPimFile(csvFile, csvFile.getName(), importsData.getCountry().getCode());
            } catch (Exception e) {
                throw new JobExecutionException(String.format("Error while publishing csv file to PIM for import id : %s", importsData.getImportId()), e);
            } finally {
                if(csvFile != null)
                    CsvUtils.cleanUpTempFiles(List.of(csvFile));
            }
        }
    }


    public File createCsvFile(List<Map<String, String>> exportProductList, ImportsData importsData, String fileName) throws IOException {
        List<String[]> rows = new ArrayList<>();
        String[] firstRow = {};
        // Add metadata row if available
        if (importsData != null && importsData.getFileData() != null) {
            firstRow = new String[]{importsData.getFileData().getCsvMetadata().getMetaDataString()};
        }

        // Collect all possible headers from all products
        String[] headerArray = exportProductList.stream()
                .flatMap(product -> product.keySet().stream()).distinct().toArray(String[]::new);
        rows.add(firstRow); //first template row
        rows.add(headerArray);  // Add headers
        rows.add(headerArray); //2nd header row
        // Convert each product map into a row, ensuring all headers are covered
        for (Map<String, String> product : exportProductList) {
            String[] row = Arrays.stream(headerArray)
                    .map(header -> product.getOrDefault(header, "")) // Fill missing attributes with empty value
                    .toArray(String[]::new);
            rows.add(row);
        }

        return CsvUtils.writeContentInNewCsv(rows, fileName + "-" + importsData.getCountry(), PIM_FILE_FORMAT);
    }

}
