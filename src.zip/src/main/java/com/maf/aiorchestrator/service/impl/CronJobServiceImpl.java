package com.maf.aiorchestrator.service.impl;

import com.maf.aiorchestrator.entities.CronJob;
import com.maf.aiorchestrator.repository.CronJobRepository;
import com.maf.aiorchestrator.service.CronJobService;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
@AllArgsConstructor
public class CronJobServiceImpl implements CronJobService {
    private final CronJobRepository cronJobRepository;

    @Override
    public Optional<CronJob> findJobById(String id){
        return cronJobRepository.findById(id);
    }

    @Override
    public CronJob save(CronJob eventhubJob){
        return cronJobRepository.save(eventhubJob);
    }

}
