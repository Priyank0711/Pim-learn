package com.maf.aiorchestrator.service;

import com.maf.aiorchestrator.entities.ImportsData;
import com.maf.aiorchestrator.enums.ImportStatus;

public interface ImportsDataService {

    void updateImportStatusInDb(ImportStatus status, String importId);

    ImportsData save(ImportsData importsData);

    ImportsData saveScanImport(ImportsData importsData);
}
