package com.maf.aiorchestrator.service;

import com.maf.aiorchestrator.dto.pim.AttributeResponse;
import com.maf.aiorchestrator.enums.Country;

public interface PimService {

    AttributeResponse getClassificationAttributes(Country countryCode, String categoryCode);

}
