package com.maf.aiorchestrator.service.impl;

import com.maf.aiorchestrator.entities.CronJob;
import com.maf.aiorchestrator.enums.JobStatus;
import com.maf.aiorchestrator.service.CronJobService;
import com.maf.aiorchestrator.service.JobService;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.Optional;
import java.util.function.Consumer;

@Service
@Slf4j
@AllArgsConstructor(onConstructor_ = {@Autowired})
public class JobServiceImpl implements JobService {

    private final CronJobService cronJobService;

    @Override
    public void executeJob(String jobCode, Consumer<CronJob> jobProcessor) {
        Optional<CronJob> optionalEventhubJob = cronJobService.findJobById(jobCode);
        if (optionalEventhubJob.isPresent()) {
            CronJob job = optionalEventhubJob.get();
            if (JobStatus.RUNNING.equals(job.getStatus())) {
                log.info("Previous execution of {} job started at {}, still in running state", jobCode, job.getStartDate());
                return;
            }

            job.setStatus(JobStatus.RUNNING);
            job.setStartDate(Instant.now());
            cronJobService.save(job);

            try {
                // Process the job using the passed functional method
                jobProcessor.accept(job);
                job.setStatus(JobStatus.FINISHED);
                job.setLastUpdated(job.getStartDate());
            } catch (Exception e) {
                log.error("Error while executing job: {}", e.getMessage(), e);
                job.setStatus(JobStatus.ERROR);
            } finally {
                job.setEndDate(Instant.now());
                cronJobService.save(job);
            }
        }
    }
}
