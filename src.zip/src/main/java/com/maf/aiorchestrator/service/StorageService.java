package com.maf.aiorchestrator.service;


import java.io.File;
import java.io.IOException;

/**
 * The interface Storage service.
 */
public interface StorageService {


	String uploadPimFile(File csvContent, String fileName, String country) throws IOException;

	File downloadFileFromCatalogBlob(String filePath, String id) throws IOException;
}