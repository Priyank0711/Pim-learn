package com.maf.aiorchestrator.service;

import com.maf.aiorchestrator.entities.CronJob;

import java.util.function.Consumer;

public interface JobService {

    void executeJob(String jobCode, Consumer<CronJob> jobProcessor);
}
