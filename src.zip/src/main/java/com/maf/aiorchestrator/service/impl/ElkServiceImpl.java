package com.maf.aiorchestrator.service.impl;

import com.maf.aiorchestrator.dto.EnrichedData;
import com.maf.aiorchestrator.dto.ProductElkUpdateDTO;
import com.maf.aiorchestrator.dto.ProductUpdateResponseDTO;
import com.maf.aiorchestrator.elastic.dto.ProductResultDTO;
import com.maf.aiorchestrator.elastic.request.ListingProductsSearchRequest;
import com.maf.aiorchestrator.elastic.response.MafSearchResultData;
import com.maf.aiorchestrator.elastic.service.ElasticSearchService;
import com.maf.aiorchestrator.elastic.utils.MafFacet;
import com.maf.aiorchestrator.elastic.utils.MafFacetTerm;
import com.maf.aiorchestrator.elastic.utils.MafPageable;
import com.maf.aiorchestrator.elastic.utils.MafSort;
import com.maf.aiorchestrator.entities.ElkProduct;
import com.maf.aiorchestrator.enums.Country;
import com.maf.aiorchestrator.enums.ImportStatus;
import com.maf.aiorchestrator.enums.ProductStatus;
import com.maf.aiorchestrator.exception.ApiErrors;
import com.maf.aiorchestrator.exception.ApiException;
import com.maf.aiorchestrator.exception.ErrorCodes;
import com.maf.aiorchestrator.factory.IndexFactory;
import com.maf.aiorchestrator.service.ElkService;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.elasticsearch.core.ElasticsearchOperations;
import org.springframework.data.elasticsearch.core.SearchHit;
import org.springframework.data.elasticsearch.core.SearchHits;
import org.springframework.data.elasticsearch.core.mapping.IndexCoordinates;
import org.springframework.data.elasticsearch.core.query.Criteria;
import org.springframework.data.elasticsearch.core.query.CriteriaQuery;
import org.springframework.data.elasticsearch.core.query.Query;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import java.time.Instant;
import java.util.*;

import java.util.HashMap;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@Service
@Slf4j
@AllArgsConstructor
public class ElkServiceImpl implements ElkService {

    private final ElasticsearchOperations elasticsearchOperations;
    private final IndexFactory indexFactory;
    private final ElasticSearchService elasticSearchService;

    @Override
    public void bulkUpload(List<ElkProduct> entries) {
        String indexName = indexFactory.getStagedProductIndexName(entries.getFirst().getCountry().name());
        elasticsearchOperations.save(entries, IndexCoordinates.of(indexName));
    }

    @Override
    public List<ElkProduct> getProductsByImportId(String importId, String status, String country) {
        String indexName = indexFactory.getStagedProductIndexName(country);
        Criteria criteria = new Criteria("importId").is(importId).and("status").is(status);
        Query query = new CriteriaQuery(criteria);
        return elasticsearchOperations.search(query, ElkProduct.class, IndexCoordinates.of(indexName)).stream().map(SearchHit::getContent).toList();
    }

    @Override
    public List<MafFacetTerm> getProductsStatusCountForImport(String importId, String country) {
        // Create ListingProductsSearchRequest with mafFacet of importID and size
        ListingProductsSearchRequest searchRequest = createSearchRequestForStatusCount(importId);

        // Call elasticSearchService.getStagedProductSearchResult with ListingProductsSearchRequest and country
        MafSearchResultData<ProductResultDTO> searchResult = elasticSearchService.getStagedProductSearchResult(searchRequest, country);

        // Return the result
        return searchResult.getFacets().stream()
                .filter(f -> "status".equals(f.getKey()))
                .findFirst()
                .map(MafFacet::getList)
                .orElse(Collections.emptyList());
    }

    private ListingProductsSearchRequest createSearchRequestForStatusCount(String importId) {
        ListingProductsSearchRequest searchRequest = new ListingProductsSearchRequest();
        MafFacet importIdFacet = new MafFacet();
        importIdFacet.setKey("importId");
        importIdFacet.setSelectedValue(importId);
        MafFacet statusFacet = new MafFacet();
        statusFacet.setKey("status");
        searchRequest.setFacets(List.of(importIdFacet, statusFacet));
        MafPageable pageable = new MafPageable();
        pageable.setCount(1);
        searchRequest.setPageData(pageable); // size 1
        searchRequest.setSort(new MafSort());
        searchRequest.setProperties();
        return searchRequest;
    }

    @Override
    public List<ElkProduct> getProductsByStatus(ProductStatus status, Instant instant, Country country) {
        Criteria criteria = new Criteria("status").is(status.toString()).and("lastModifiedTime").greaterThanEqual(instant.toString());
        Query query = new CriteriaQuery(criteria);
        SearchHits<ElkProduct> searchHits = elasticsearchOperations.search(query, ElkProduct.class, IndexCoordinates.of(indexFactory.getStagedProductIndexName(country.getCode())));
        if (searchHits.hasSearchHits())
            return searchHits.getSearchHits().stream().map(SearchHit::getContent).toList();
        return new ArrayList<>();
    }

    @Override
    public ElkProduct getProductByElasticId(String elasticId, String country) {
        String indexName = indexFactory.getStagedProductIndexName(country);
        Criteria criteria = new Criteria("_id").is(elasticId);
        Query query = new CriteriaQuery(criteria);
        SearchHits<ElkProduct> searchHits = elasticsearchOperations.search(query, ElkProduct.class, IndexCoordinates.of(indexName));
        if (searchHits.hasSearchHits())
            return searchHits.getSearchHit(0).getContent();
        throw new ApiException(new ApiErrors(ErrorCodes.PRODUCT_NOT_FOUND));
    }

    @Override
    public void updateProductStatus(List<String> elasticId, ProductStatus status, String country) {
        IndexCoordinates index = IndexCoordinates.of(indexFactory.getStagedProductIndexName(country));
        elasticId.forEach(id -> Optional.ofNullable(elasticsearchOperations.get(id, ElkProduct.class, index))
                .ifPresent(elkProduct -> {
                    elkProduct.setStatus(Optional.of(status)
                            .map(ProductStatus::toString)
                            .map(String::trim)
                            .orElse(ImportStatus.FAILED.name()));
                    elasticsearchOperations.save(elkProduct, index);
                }));
    }


    @Override
    public ProductUpdateResponseDTO updateProductByGettingFirst(ProductElkUpdateDTO productElkUpdateDTO, String country) {
        ProductUpdateResponseDTO updateResponseDTO = new ProductUpdateResponseDTO();
        String indexName = indexFactory.getStagedProductIndexName(country);
        ElkProduct elkProduct = Optional.ofNullable(elasticsearchOperations.get(productElkUpdateDTO.getId(), ElkProduct.class, IndexCoordinates.of(indexName)))
                .orElseThrow(() -> new ApiException(new ApiErrors(ErrorCodes.PRODUCT_NOT_FOUND)));
        if(elkProduct.getEnrichedData() == null){
            elkProduct.setEnrichedData(new EnrichedData());
        }
        updateMetaAttributes(productElkUpdateDTO.getEnrichedMetaAttributes(), elkProduct);
        updateClassAttributes(productElkUpdateDTO.getEnrichedClassAttributes(), elkProduct);

        elasticsearchOperations.save(elkProduct, IndexCoordinates.of(indexName));
        return updateResponseDTO;
    }

    private void updateMetaAttributes(Map<String, Map<String, String>> enrichedMetaAttributes, ElkProduct elkProduct) {
        if (!CollectionUtils.isEmpty(enrichedMetaAttributes)) {
            if (elkProduct.getEnrichedData().getMetaAttributes() == null) {
                elkProduct.getEnrichedData().setMetaAttributes(new HashMap<>());
            }
            enrichedMetaAttributes.forEach((key, value) -> elkProduct.getEnrichedData().getMetaAttributes()
                    .compute(key, (k, v) -> {
                        if(v == null){
                            v = new HashMap<>();
                        }
                        v.putAll(value);
                        return v;
                    }));
        }
    }

    private void updateClassAttributes(Map<String, Map<String, String>> enrichedClassAttributes, ElkProduct elkProduct) {
        if (!CollectionUtils.isEmpty(enrichedClassAttributes)) {
            if (elkProduct.getEnrichedData().getClassAttributes() == null) {
                elkProduct.getEnrichedData().setClassAttributes(new HashMap<>());
            }
            enrichedClassAttributes.forEach((key, value) -> elkProduct.getEnrichedData().getClassAttributes()
                    .compute(key, (k, v) -> {
                        if(v == null){
                            v = new HashMap<>();
                        }
                        v.putAll(value);
                        return v;
                    }));
        }
    }

}
