package com.maf.aiorchestrator.service;

import java.util.Collection;

public interface CacheService {

    void refreshAllCache(Collection<String> cacheNames);
}
