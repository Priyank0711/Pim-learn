package com.maf.aiorchestrator.service.impl;

import com.azure.storage.blob.BlobContainerClient;
import com.azure.storage.blob.models.BlobStorageException;
import com.azure.storage.blob.models.BlockBlobItem;
import com.azure.storage.blob.specialized.BlockBlobClient;
import com.maf.aiorchestrator.service.StorageService;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.io.*;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.MessageFormat;

/**
 * The Blob Storage service.
 */
@Component("storageService")
@Slf4j
public class StorageServiceImpl implements StorageService {

    private final BlobContainerClient blobContainerClient;
    private final BlobContainerClient pimBlobContainerClient;

        @Autowired
        public StorageServiceImpl(@Qualifier("blobContainerClient") BlobContainerClient blobContainerClient,
                                  @Qualifier("pimBlobContainerClient") BlobContainerClient pimBlobContainerClient) {
            this.blobContainerClient = blobContainerClient;
            this.pimBlobContainerClient = pimBlobContainerClient;
        }

    @Value("${pim.azure.storage.input.folder}")
    private String pimInputFolder;
    
    private final Logger logger = LoggerFactory.getLogger(StorageServiceImpl.class);


    private BlockBlobClient getBlockBlobClient(final String folderPathName) throws BlobStorageException {
		return blobContainerClient.getBlobClient(folderPathName).getBlockBlobClient();
	}

    private BlockBlobClient getPimBlockBlobClient(final String folderPathName) {
        return pimBlobContainerClient.getBlobClient(folderPathName).getBlockBlobClient();
    }

    protected BlockBlobItem uploadFile(BlockBlobClient blockBlobClient, final InputStream dataStream, String fileName) throws IOException {
        log.info("Started uploading file " + fileName + "...");
        final BufferedInputStream bufferedInputStream = new BufferedInputStream(dataStream);
        return blockBlobClient.upload(bufferedInputStream, bufferedInputStream.available(), true);
    }

    @Override
    public String uploadPimFile(File csvContent, String fileName, String country) throws IOException {
        //Upload to PIM Input Location
        String folderPathName = MessageFormat.format(pimInputFolder + "input/", country) + fileName;
        BlockBlobClient blockBlobClient = getPimBlockBlobClient(folderPathName);
        uploadFile(blockBlobClient, new FileInputStream(csvContent), fileName);
        return URLDecoder.decode(blockBlobClient.getBlobUrl(), StandardCharsets.UTF_8);
    }

    @Override
    public File downloadFileFromCatalogBlob(String filePath, String fileName) throws IOException {
        File temp = new File("data/skipped/" + fileName);
        temp.getParentFile().mkdirs();
        getBlockBlobClient(filePath.split("mkp-catalog-data/")[1]).downloadToFile(temp.getPath(),true);
        Files.readAllBytes(Paths.get(temp.getPath()));
        return temp;
    }
}
