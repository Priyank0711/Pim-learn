package com.maf.aiorchestrator.service.impl;

import com.maf.aiorchestrator.dto.file.HeaderData;
import com.maf.aiorchestrator.dto.file.StandardHeaderDetail;
import com.maf.aiorchestrator.dto.pim.AttributeDetailsDTO;
import com.maf.aiorchestrator.dto.pim.AttributeGroupDTO;
import com.maf.aiorchestrator.dto.pim.AttributeResponse;
import com.maf.aiorchestrator.entities.FileHeaderMapping;
import com.maf.aiorchestrator.enums.FileType;
import com.maf.aiorchestrator.repository.HeaderMappingRepository;
import com.maf.aiorchestrator.service.HeaderMappingService;
import com.maf.aiorchestrator.utils.Constants;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

@Slf4j
@Service
@AllArgsConstructor
public class HeaderMappingServiceImpl implements HeaderMappingService {

    private final HeaderMappingRepository headerMappingRepository;

    @Override
    public Map<String, HeaderData> createLocalizedAttributeMap(List<String> headers, FileType fileType) {
        Optional<FileHeaderMapping> attributeMapping = headerMappingRepository.findByFileType(fileType);
        Map<String, StandardHeaderDetail> attributeMap = attributeMapping.map(FileHeaderMapping::getAttributeMap)
                .orElseGet(HashMap::new);
        return headers.stream().collect(Collectors.toMap(s->s, s->{
                HeaderData headerData = new HeaderData();
                String language = "en";
                Pattern pattern = Pattern.compile(Constants.LOCALIZED_ATTR_REGEX);
                Matcher matcher = pattern.matcher(s);
                String key = s;
                if (matcher.find()) {
                    int matchingGroupIndex = getNonNullMatchingGroup(matcher);
                    key = matcher.group(matchingGroupIndex); // internal storage capacity
                    language = matcher.group(++matchingGroupIndex);
                }
                String value = key;
                if(attributeMap.containsKey(key)) {
                    value = attributeMap.get(key).getValue();
                }
                headerData.setKey(value);
                headerData.setLang(language);
                return headerData;
            })
        );
    }

    @Override
    public void populateAndReflectPimClassAttributeHeader(Map<String, HeaderData> localizedAttributeMappingMap, AttributeResponse attributeResponse) {
        try {
            List<AttributeGroupDTO> attributeGroups = attributeResponse.getAttributeGroups();
            List<String> classAttributes = attributeGroups.stream()
                    .skip(2) // skipping meta attributes
                    .flatMap(group -> group.getAttributeDetails().stream())
                    .map(AttributeDetailsDTO::getCode).toList();
            classAttributes.stream().filter(localizedAttributeMappingMap::containsKey)
                    .map(localizedAttributeMappingMap::get).forEach(headerUtil -> headerUtil.setClassificationAttribute(true));
        } catch (Exception e) {
            log.error("Error while populating classification header", e);
        }
    }

    @Override
    public Set<String> getNonLocalizedPimAttributeKeys(List<AttributeGroupDTO> attributeGroups) {
        try {
            return attributeGroups.stream()
                    .flatMap(group -> group.getAttributeDetails().stream())
                    .map(ad -> {
                        String s = ad.getCode();
                        Pattern pattern = Pattern.compile(Constants.LOCALIZED_ATTR_REGEX);
                        Matcher matcher = pattern.matcher(s);
                        String key = s;
                        if (matcher.find()) {
                            int matchingGroupIndex = getNonNullMatchingGroup(matcher);
                            key = matcher.group(matchingGroupIndex);
                        }
                        return key;
                    }).collect(Collectors.toSet());

        } catch (Exception e) {
            log.error("Error while getting localized meta attribute keys", e);
        }
        return Collections.emptySet();
    }


    private int getNonNullMatchingGroup(Matcher matcher) {
        int groupIndex = 0;
        boolean isFound = false;
        while (!isFound && matcher.groupCount() - 1 != groupIndex) {
            groupIndex++;
            isFound = matcher.group(groupIndex) != null;
        }
        return groupIndex;
    }
}
