package com.maf.aiorchestrator.service.impl;

import com.maf.aiorchestrator.config.client.ServiceConfiguration;
import com.maf.aiorchestrator.config.client.ServiceProperties;
import com.maf.aiorchestrator.dto.*;
import com.maf.aiorchestrator.dto.file.StandardHeaderDetail;
import com.maf.aiorchestrator.elastic.dto.DetailedProductResultDTO;
import com.maf.aiorchestrator.elastic.utils.MafFacetTerm;
import com.maf.aiorchestrator.entities.ElkProduct;
import com.maf.aiorchestrator.entities.FileHeaderMapping;
import com.maf.aiorchestrator.enums.FileType;
import com.maf.aiorchestrator.enums.ImportStatus;
import com.maf.aiorchestrator.enums.ProductStatus;
import com.maf.aiorchestrator.enums.ServiceName;
import com.maf.aiorchestrator.exception.ApiErrors;
import com.maf.aiorchestrator.exception.ApiException;
import com.maf.aiorchestrator.exception.ErrorCodes;
import com.maf.aiorchestrator.mapper.ProductAIDTOMapper;
import com.maf.aiorchestrator.repository.HeaderMappingRepository;
import com.maf.aiorchestrator.service.ElkService;
import com.maf.aiorchestrator.service.ImportsDataService;
import com.maf.aiorchestrator.service.ProductService;
import com.maf.aiorchestrator.utils.Constants;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.util.retry.Retry;

import java.time.Duration;
import java.util.*;
import java.util.stream.Collectors;

import static com.maf.aiorchestrator.utils.CommonUtils.filterEnglishOnlyMap;

@Slf4j
@Service
public class ProductServiceImpl implements ProductService {
    private final WebClient webClient;
    private final ElkService elkService;
    private final ServiceConfiguration serviceConfiguration;
    private final ImportsDataService importsDataService;
    private final HeaderMappingRepository headerMappingRepository;


    public ProductServiceImpl(@Qualifier("aiEngineWebClient") WebClient webClient, ElkService elkService,
                              ServiceConfiguration serviceConfiguration, ImportsDataService importsDataService, HeaderMappingRepository headerMappingRepository) {
        this.webClient = webClient;
        this.elkService = elkService;
        this.serviceConfiguration = serviceConfiguration;
        this.importsDataService = importsDataService;
        this.headerMappingRepository = headerMappingRepository;
    }

    @Override
    public Flux<ElkProduct> enrichProductsInBatch(List<String> tasks, List<ProductAIDTO> productList, String importId) {
        ServiceProperties properties = serviceConfiguration.get(ServiceName.AI_ENGINE);

        // Process the productList to include only English attributes
        if(CollectionUtils.isEmpty(productList)) {
            return Flux.empty();
        }
        List<ProductAIDTO> productListWithEnAttr = productList.stream()
                .map(this::filterEnglishAttributes)
                .toList();

        String products = productListWithEnAttr.stream().map(ProductAIDTO::getProductId)
                .collect(Collectors.joining(", "));

        return webClient.post()
                .uri("/prompt")
                .bodyValue(new AIRequestDTO(tasks, productListWithEnAttr))  // Send the list of product IDs
                .retrieve()
                .bodyToFlux(ProductAIDTO.class)
                .zipWith(Flux.fromIterable(productList))
                .map(tuple -> createElkProduct(tuple.getT2(), tuple.getT1(), importId))
                .retryWhen(Retry.backoff(properties.getNoOfRetries(), Duration.ofMillis(properties.getRetryDelay()))
                        .doBeforeRetry(retrySignal -> {
                            log.warn("Retrying for products {} importId {} due to error: {}. Attempt: {}",
                                    products, importId,
                                    retrySignal.failure().getMessage(),
                                    retrySignal.totalRetries() + 1); // Log before retrying
                        }))
                .onErrorResume(e -> {
                    log.error("Error occurred for products {} importId {} : {}", products, importId, e.getMessage(), e); // Log the error
                    // Fallback: Create ElkProducts using only request products
                    return Flux.fromIterable(productList)
                            .map(p -> createElkProduct(p, null, importId)); // Fallback with request products only
                }); // Graceful error handling
    }

    @Override
    public Mono<Void> enrichProductsAndSaveToELK(List<String> tasks, List<ProductAIDTO> productList, String importId) {
        // Filter the productList into valid and invalid products
        List<ProductAIDTO> validProducts = productList.stream()
                .filter(product -> !product.getStatus().equals(ProductStatus.VALIDATION_FAILED))
                .toList();

        List<ProductAIDTO> invalidProducts = productList.stream()
                .filter(product -> product.getStatus().equals(ProductStatus.VALIDATION_FAILED))
                .toList();
        // Combine both operations
        return Flux.concat(processValidProducts(tasks, validProducts, importId), processInvalidProducts(invalidProducts, importId))
                .collectList()
                .doOnNext(elkService::bulkUpload)
                .onErrorResume(e -> {
                    log.error("Error occurred while saving products to elastic: " + e.getMessage(), e);
                    return Mono.error(e);
                }).then();
    }

    private Flux<ElkProduct> processValidProducts(List<String> tasks, List<ProductAIDTO> validProducts, String importId) {
        if (CollectionUtils.isEmpty(validProducts)) {
            return Flux.empty();
        }
        log.info("processing valid products for ai enrichment and elk");
        return enrichProductsInBatch(tasks, validProducts, importId);
    }

    private Flux<ElkProduct> processInvalidProducts(List<ProductAIDTO> invalidProducts, String importId) {
        if (CollectionUtils.isEmpty(invalidProducts)) {
            return Flux.empty();
        }
        log.info("saving invalid products into elk");
        return Flux.fromIterable(invalidProducts.stream()
                .map(p -> createElkProduct(p, null, importId))
                .toList());
    }

    @Override
    public List<Map<String, String>> getProductsByImportIdForExport(String importId, String country) {
        List<ElkProduct> elkProducts = elkService.getProductsByImportId(importId, "APPROVED", country);
        return getExportProductList(elkProducts);
    }

    @Override
    public List<Map<String, String>> getExportProductList(List<ElkProduct> elkProducts) {
        Optional<FileHeaderMapping> attributeMapping = headerMappingRepository.findByFileType(FileType.PIM_PRODUCT);
        List<StandardHeaderDetail> standardHeaderDetails = attributeMapping.map(FileHeaderMapping::getAttributeMap)
                .orElseGet(HashMap::new).values().stream().toList();
        return elkProducts.stream().map(p -> createExportProductFromElkProduct(p, standardHeaderDetails)).toList();
    }

    @Override
    public UpdateProductStatusResponseDTO updateProductImportsStatus(UpdateStatusRequestDTO updateStatusRequestDTO, String country) {
        Optional<String> importIdOptional = Optional.ofNullable(updateStatusRequestDTO.getImportId());
        Optional<List<String>> optionalElasticIdList = Optional.ofNullable(updateStatusRequestDTO.getElasticIdList());
        UpdateProductStatusResponseDTO updateProductStatusResponseDTO = new UpdateProductStatusResponseDTO();
        if (optionalElasticIdList.isPresent() && !optionalElasticIdList.get().isEmpty()) {
            elkService.updateProductStatus(optionalElasticIdList.get(), updateStatusRequestDTO.getStatus(), country);
            updateProductStatusResponseDTO.setMessage(Constants.PRODUCT_REVIEWED);
        } else if (importIdOptional.isPresent()) {
            List<MafFacetTerm> facetTerms = elkService.getProductsStatusCountForImport(importIdOptional.get(), country);
//            Long pendingProductCount = facetTerms.stream().filter(f -> "PENDING".equals(f.getKey())).findFirst().map(MafFacetTerm::getCount).orElse(0L);
//            if (pendingProductCount > 0){
//                updateProductStatusResponseDTO.setMessage(String.format(Constants.PRODUCT_NOT_REVIEWED, pendingProductCount));
//            } else {
                importsDataService.updateImportStatusInDb(ImportStatus.valueOf(updateStatusRequestDTO.getStatus().name()), importIdOptional.get());
                updateProductStatusResponseDTO.setMessage(String.format(Constants.IMPORT_REVIEWED, updateStatusRequestDTO.getStatus().name()));
//            }
            updateProductStatusResponseDTO.setStatusCountList(facetTerms);
        } else {
            throw new ApiException(new ApiErrors(ErrorCodes.BAD_REQUEST), Constants.IMPORT_ID_OR_PRODUCT_ID_REQUIRED);
        }
        return updateProductStatusResponseDTO;
    }


    @Override
    public DetailedProductResultDTO getDetailedProductByElasticId(String elasticId, String country) {
        ElkProduct product = elkService.getProductByElasticId(elasticId, country);
        return elkProductToDetailedProductResult(product);
    }

    @Override
    public ProductUpdateResponseDTO updateProduct(ProductElkUpdateDTO productElkUpdateDTO, String country) {
        ProductUpdateResponseDTO updateResponseDTO = elkService.updateProductByGettingFirst(productElkUpdateDTO, country);
        updateResponseDTO.setResponseCode(200);
        updateResponseDTO.setMessage("Product updated successfully");
        return updateResponseDTO;
    }

    private ElkProduct createElkProduct(ProductAIDTO request, ProductAIDTO response, String importId) {
        ElkProduct product = ProductAIDTOMapper.INSTANCE.convertToElkProduct(request);
        if (Objects.nonNull(response)) {
            product.setEnrichedData(ProductAIDTOMapper.INSTANCE.covertToEnrichedData(response));
        }
        product.setImportId(importId);
        product.setStatus(request.getStatus().name());
        return product;
    }

    // Method to filter out only English attributes from ProductAIDTO
    private ProductAIDTO filterEnglishAttributes(ProductAIDTO productAIDTO) {
        ProductAIDTO productAIDTOCopy = ProductAIDTOMapper.INSTANCE.copyWithoutAttributes(productAIDTO);
        // Set the filtered attributes back to the product
        productAIDTOCopy.setMetaAttributes(filterEnglishOnlyMap(productAIDTO.getMetaAttributes()));
        productAIDTOCopy.setClassAttributes(filterEnglishOnlyMap(productAIDTO.getClassAttributes()));
        return productAIDTOCopy;
    }

    private Map<String, String> createExportProductFromElkProduct(ElkProduct elkProduct,
                                                                  List<StandardHeaderDetail> standardHeaderDetails) {
        Map<String, String> exportProductMap = new HashMap<>();
        String importId = elkProduct.getImportId();
        boolean isScanProduct = importId != null && importId.contains(Constants.SCAN_IDENTIFIER);

        transformAttributesMapToFileMap(elkProduct.getMetaAttributes(), exportProductMap, standardHeaderDetails,
                false, isScanProduct);
        transformAttributesMapToFileMap(elkProduct.getEnrichedData().getMetaAttributes(), exportProductMap,
                standardHeaderDetails, true, isScanProduct);

        if (StringUtils.isEmpty(elkProduct.getCategory()) || Constants.DEFAULT_CATEGORY_CODE.equals(elkProduct.getCategory())) {
            return exportProductMap;
        }

        transformAttributesMapToFileMap(elkProduct.getClassAttributes(), exportProductMap, standardHeaderDetails,
                false, isScanProduct);
        transformAttributesMapToFileMap(elkProduct.getEnrichedData().getClassAttributes(), exportProductMap,
                standardHeaderDetails, true, isScanProduct);

        return exportProductMap;
    }

    private void transformAttributesMapToFileMap(Map<String, Map<String, String>> originalMap, Map<String, String> finalMap,
                                                 List<StandardHeaderDetail> standardHeaderDetails, boolean isEnriched,
                                                 boolean isScanProduct) {
        // If the originalMap is empty or if it is a scan import do not include non-enriched attributes
        if(CollectionUtils.isEmpty(originalMap) || (isScanProduct && !isEnriched)) {
            return;
        }
        standardHeaderDetails.forEach(standardHeaderDetail -> {
            String value = standardHeaderDetail.getValue();
            if (originalMap.containsKey(value)) {
                Map<String, String> innerMap = originalMap.get(value);
                processInnerMap(innerMap, finalMap, value, standardHeaderDetail.isLocalizedField(), isEnriched);
            }
        });
        originalMap.forEach((outerKey, innerMap) -> {
            if (!finalMap.containsKey(outerKey)) {
                processInnerMap(innerMap, finalMap, outerKey, true, isEnriched);
            }
        });
    }

    private void processInnerMap(Map<String, String> innerMap, Map<String, String> finalMap, String key, boolean isLocalized, boolean isEnriched) {
        if (!isLocalized) {
            if (StringUtils.isNotBlank(innerMap.get("en")) || !isEnriched) {
                finalMap.put(key, innerMap.get("en"));
            }
        } else {
            innerMap.forEach((innerKey, innerValue) -> {
                if (StringUtils.isNotBlank(innerValue) || !isEnriched) {
                    String mapKey = key + "[" + innerKey.toLowerCase() + "]";
                    finalMap.put(mapKey, innerValue);
                }
            });
        }
    }

    private DetailedProductResultDTO elkProductToDetailedProductResult(ElkProduct product) {
        try {
            DetailedProductResultDTO detailedProductResultDto = new DetailedProductResultDTO();
            detailedProductResultDto.setId(product.getId());
            detailedProductResultDto.setImportId(product.getImportId());
            detailedProductResultDto.setProductId(product.getProductId());
            detailedProductResultDto.setProductName(product.getProductName());
            detailedProductResultDto.setStatus(product.getStatus());

            if (product.getMetaAttributes() != null)
                detailedProductResultDto.setMetaAttributesComparison(
                        createAttributesComparison(product.getMetaAttributes(),
                                (product.getEnrichedData() != null ? product.getEnrichedData().getMetaAttributes() : null))
                );

            if (product.getClassAttributes() != null)
                detailedProductResultDto.setClassAttributesComparison(
                        createAttributesComparison(product.getClassAttributes(),
                                (product.getEnrichedData() != null ? product.getEnrichedData().getClassAttributes() : null))
                );

            return detailedProductResultDto;
        } catch (RuntimeException e) {
            log.error("Error occurred while converting ElkProduct to DetailedProductResultDTO: {}", e.getMessage(), e);
            throw new ApiException(new ApiErrors(ErrorCodes.INTERNAL_SERVER_ERROR),
                    "Error occurred while converting ElkProduct to DetailedProductResultDTO: " + e.getMessage());
        }
    }

    private Map<String, Map<String, Map<String, String>>> createAttributesComparison(
            Map<String, Map<String, String>> originalAttributes,
            Map<String, Map<String, String>> enrichedAttributes) {
        Map<String, Map<String, Map<String, String>>> attributesComparison = new HashMap<>();
        Set<String> allKeys = new HashSet<>(originalAttributes.keySet());
        if (enrichedAttributes != null) {
            allKeys.addAll(enrichedAttributes.keySet());
        }
        for (String key : allKeys) {
            Map<String, Map<String, String>> comparison = new HashMap<>();
            comparison.put("original", originalAttributes.getOrDefault(key, new HashMap<>()));
            if (enrichedAttributes != null) {
                comparison.put("enriched", enrichedAttributes.getOrDefault(key, new HashMap<>()));
            }
            attributesComparison.put(key, comparison);
        }
        return attributesComparison;
    }
}
