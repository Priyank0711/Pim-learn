package com.maf.aiorchestrator.service.impl;

import com.maf.aiorchestrator.dto.pim.AttributeResponse;
import com.maf.aiorchestrator.enums.Country;
import com.maf.aiorchestrator.service.PimService;
import com.maf.aiorchestrator.utils.Constants;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

@Slf4j
@Service
public class PimServiceImpl implements PimService {

    private final WebClient pimServiceWebClient;

    public PimServiceImpl(@Qualifier("pimServiceWebClient") WebClient pimServiceWebClient) {
        this.pimServiceWebClient = pimServiceWebClient;
    }


    @Cacheable(value = Constants.PIM_ATTRIBUTES_CACHE, key = "#countryCode + #categoryCode")
    @Override
    public AttributeResponse getClassificationAttributes(Country countryCode, String categoryCode) {
        return pimServiceWebClient
                .get()
                .uri(uriBuilder -> uriBuilder
                        .path("/{countryCode}/attribute/category")
                        .queryParam("categoryCode", categoryCode)
                        .build(countryCode))
                .retrieve().bodyToMono(new ParameterizedTypeReference<AttributeResponse>() {}).block();
    }

}
