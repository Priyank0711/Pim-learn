package com.maf.aiorchestrator.service;

import com.maf.aiorchestrator.dto.jms.NotificationMessage;
import com.maf.aiorchestrator.elastic.request.OnlineProductsScanRequest;
import com.maf.aiorchestrator.entities.ImportsData;
import com.maf.aiorchestrator.enums.Country;
import com.maf.aiorchestrator.enums.FileType;

import java.io.IOException;

public interface ProcessImportService {

    void processSBImport(NotificationMessage message, ImportsData importsData) throws IOException;

    void processScanImport(ImportsData importsData, OnlineProductsScanRequest scanRequest) throws IOException;

    ImportsData createAndSaveImportsData(NotificationMessage message, FileType fileType, Country country);

    ImportsData createAndSaveScanImport(OnlineProductsScanRequest scanProductsRequest, String country);
}
