package com.maf.aiorchestrator.service.impl;

import com.maf.aiorchestrator.dto.ImportWrapperDTO;
import com.maf.aiorchestrator.dto.file.CsvMetadata;
import com.maf.aiorchestrator.dto.file.FileData;
import com.maf.aiorchestrator.dto.jms.FileDetails;
import com.maf.aiorchestrator.dto.jms.NotificationMessage;
import com.maf.aiorchestrator.elastic.request.OnlineProductsScanRequest;
import com.maf.aiorchestrator.elastic.utils.MafFacet;
import com.maf.aiorchestrator.entities.ImportsData;
import com.maf.aiorchestrator.enums.Country;
import com.maf.aiorchestrator.enums.FileType;
import com.maf.aiorchestrator.enums.ImportStatus;
import com.maf.aiorchestrator.enums.ImportType;
import com.maf.aiorchestrator.facade.ImportFacade;
import com.maf.aiorchestrator.repository.CategoryFormatRepository;
import com.maf.aiorchestrator.service.ImportsDataService;
import com.maf.aiorchestrator.service.ProcessImportService;
import com.maf.aiorchestrator.service.StorageService;
import com.maf.aiorchestrator.utils.Constants;
import com.maf.aiorchestrator.utils.CsvUtils;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

import static com.maf.aiorchestrator.utils.Constants.TEMPLATE_TYPE_HEADER;

@Slf4j
@Service
@AllArgsConstructor
public class ProcessImportServiceImpl implements ProcessImportService {

    private StorageService storageService;
    private ImportsDataService importsDataService;
    private ImportFacade importFacade;
    private final CategoryFormatRepository categoryFormatRepository;

    @Override
    public void processSBImport(NotificationMessage message, ImportsData importsData) throws IOException {
        String fileName = message.getTransformedFile().getName().replace("-transformed.csv", Constants.PIM_FILE_FORMAT);
        File file = storageService.downloadFileFromCatalogBlob(message.getTransformedFile().getLocation(), fileName);
        if(categoryFormatRepository.existsByCodeAndIsIncluded(message.getCategoryCode(), true)){
            ImportWrapperDTO importsWrapperDTO = new ImportWrapperDTO();
            importsWrapperDTO.setFile(file);
            importsWrapperDTO.setImportsData(importsData);
            importFacade.processImport(importsWrapperDTO);
            log.info("processing completed successfully for importId {}", message.getImportId());
        } else {
            storageService.uploadPimFile(file, file.getName(), importsData.getCountry().getCode());
            CsvUtils.cleanUpTempFiles(List.of(file));
        }
    }

    @Override
    public ImportsData createAndSaveImportsData(NotificationMessage message, FileType fileType, Country country) {
        FileDetails fileDetails = message.getTransformedFile();
        FileData fileData = new FileData();
        fileData.setLocation(fileDetails.getLocation());
        fileData.setName(fileDetails.getName());
        fileData.setFileType(fileType);

        ImportsData importsData = new ImportsData();
        importsData.setEnrichOptionsSelected(message.getEnrichRequest().getEnrichOptions());
        importsData.setImportId(message.getImportId());
        importsData.setStatus(ImportStatus.UPLOADED);
        importsData.setFileData(fileData);
        importsData.setType(ImportType.FILE);
        importsData.setCountry(country);
        importsData.setCategoryCode(message.getCategoryCode());
        importsData.setShopId(message.getShopId());
        importsDataService.save(importsData);
        return importsData;
    }

    @Override
    public void processScanImport(ImportsData importsData, OnlineProductsScanRequest scanRequest) throws IOException {
        ImportWrapperDTO importsWrapperDTO = new ImportWrapperDTO();
        importsWrapperDTO.setImportsData(importsData);
        importsWrapperDTO.setScanRequest(scanRequest);
        importFacade.processImport(importsWrapperDTO);
        log.info("processing completed successfully for scan importId {}", importsData.getImportId());
    }

    @Override
    public ImportsData createAndSaveScanImport(OnlineProductsScanRequest scanProductsRequest, String country) {
        String category = Optional.ofNullable(scanProductsRequest.getFacets())
                .stream()
                .flatMap(List::stream)
                .filter(f -> f.getKey().equals("category"))
                .map(MafFacet::getSelectedValue)
                .filter(Objects::nonNull)
                .findFirst()
                .orElse("");
        ImportsData importsData = new ImportsData();
        importsData.setCountry(Country.valueOf(country));
        importsData.setStatus(ImportStatus.UPLOADED);
        importsData.setType(ImportType.SCANNING);
        importsData.setEnrichOptionsSelected(scanProductsRequest.getEnrichOptions());
        if(!category.isBlank()) {
            importsData.setCategoryName(category.split("-")[1]);
            importsData.setCategoryCode(category.split("-")[0]);
        }
        importsData.setShopId(Constants.SCAN_IDENTIFIER);

        FileData fileData = new FileData();
        CsvMetadata csvMetadata = new CsvMetadata();
        csvMetadata.setMetaDataString(TEMPLATE_TYPE_HEADER);
        fileData.setCsvMetadata(csvMetadata);
        importsData.setFileData(fileData);
        return importsDataService.saveScanImport(importsData);
    }

}
