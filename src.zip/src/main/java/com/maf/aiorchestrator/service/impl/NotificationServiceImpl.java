package com.maf.aiorchestrator.service.impl;

import com.azure.messaging.servicebus.ServiceBusMessage;
import com.azure.messaging.servicebus.ServiceBusSenderClient;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.maf.aiorchestrator.dto.jms.NotificationMessage;
import com.maf.aiorchestrator.service.NotificationService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class NotificationServiceImpl implements NotificationService {

    private final ServiceBusSenderClient senderClient;
    private final ObjectMapper objectMapper;

    @Autowired
    public NotificationServiceImpl(ServiceBusSenderClient senderClient, ObjectMapper objectMapper) {
        this.senderClient = senderClient;
        this.objectMapper = objectMapper;
    }

    @Override
    public void sendNotification(NotificationMessage notificationMessage) {
        log.info("SENDING NOTIFICATION");
        String messageContent = "";
        try {
            messageContent = objectMapper.writeValueAsString(notificationMessage);
            senderClient.sendMessage(new ServiceBusMessage(messageContent));
            log.info(messageContent);
        } catch (Exception e) {
            log.error("Error while converting notification message to json", e);
        }
    }

}
