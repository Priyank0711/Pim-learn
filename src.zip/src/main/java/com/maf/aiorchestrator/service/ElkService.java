package com.maf.aiorchestrator.service;

import com.maf.aiorchestrator.dto.ProductElkUpdateDTO;
import com.maf.aiorchestrator.dto.ProductUpdateResponseDTO;
import com.maf.aiorchestrator.elastic.utils.MafFacetTerm;
import com.maf.aiorchestrator.entities.ElkProduct;
import com.maf.aiorchestrator.enums.Country;
import com.maf.aiorchestrator.enums.ProductStatus;

import java.time.Instant;
import java.util.List;

public interface ElkService {
    void bulkUpload(List<ElkProduct> entries);

    List<ElkProduct> getProductsByImportId(String importId, String status, String country);

    List<MafFacetTerm> getProductsStatusCountForImport(String importId, String country);

    List<ElkProduct> getProductsByStatus(ProductStatus status, Instant instant, Country country);

    ElkProduct getProductByElasticId(String elasticId, String country);

    void updateProductStatus(List<String> elasticId, ProductStatus status, String country);

    ProductUpdateResponseDTO updateProductByGettingFirst(ProductElkUpdateDTO productElkUpdateDTO, String country);

}
