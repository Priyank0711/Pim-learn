package com.maf.aiorchestrator.service;

import com.maf.aiorchestrator.entities.ImportsData;
import com.maf.aiorchestrator.enums.Country;

import java.io.File;
import java.io.IOException;
import java.time.Instant;
import java.util.List;
import java.util.Map;

public interface FileExportService {

    void execute(Instant lastUpdated, Country country);

    void publishImport(String importId);

    File createCsvFile(List<Map<String, String>> products, ImportsData importsData, String fileName) throws IOException;
}
