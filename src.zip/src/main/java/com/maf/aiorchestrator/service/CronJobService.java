package com.maf.aiorchestrator.service;

import com.maf.aiorchestrator.entities.CronJob;

import java.util.Optional;

public interface CronJobService {

    Optional<CronJob> findJobById(String id);

    CronJob save(CronJob eventhubJob);
}
