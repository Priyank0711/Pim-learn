package com.maf.aiorchestrator.service;

import com.maf.aiorchestrator.dto.*;
import com.maf.aiorchestrator.elastic.dto.DetailedProductResultDTO;
import com.maf.aiorchestrator.entities.ElkProduct;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.List;
import java.util.Map;

public interface ProductService {
    Flux<ElkProduct> enrichProductsInBatch(List<String> tasks, List<ProductAIDTO> productList, String importId);

    // Process products in batches using Flux.buffer()
    Mono<Void> enrichProductsAndSaveToELK(List<String> tasks, List<ProductAIDTO> productList, String importId);

    List<Map<String, String>> getProductsByImportIdForExport(String importId, String country);

    List<Map<String, String>> getExportProductList(List<ElkProduct> elkProducts);

    UpdateProductStatusResponseDTO updateProductImportsStatus(UpdateStatusRequestDTO updateStatusRequestDTO, String country);

    DetailedProductResultDTO getDetailedProductByElasticId(String elasticId, String country);

    ProductUpdateResponseDTO updateProduct(ProductElkUpdateDTO productElkUpdateDTO, String country);
}
