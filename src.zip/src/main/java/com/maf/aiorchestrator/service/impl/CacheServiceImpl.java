package com.maf.aiorchestrator.service.impl;


import com.maf.aiorchestrator.service.CacheService;
import com.maf.aiorchestrator.utils.Constants;
import lombok.extern.slf4j.Slf4j;
import org.springframework.cache.Cache;
import org.springframework.cache.CacheManager;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.util.Collection;

@Service
@Slf4j
public class CacheServiceImpl implements CacheService {

    private final CacheManager cacheManager;

    public CacheServiceImpl(CacheManager cacheManager) {
        this.cacheManager = cacheManager;
    }

    @Override
    public void refreshAllCache(Collection<String> cacheNames) {
        if(CollectionUtils.isEmpty(cacheNames)) {
            cacheNames = cacheManager.getCacheNames();
        }
        for (String cacheKey : cacheNames) {
            log.info("Cache Evicted for - {}", cacheKey);
            Cache c = cacheManager.getCache(cacheKey);
            if(c!=null){
                c.clear();
            }
        }
    }

    @CacheEvict(value = {Constants.PIM_ATTRIBUTES_CACHE, Constants.HEADER_MAPPING_CACHE}, allEntries = true)
    @Scheduled(cron = "${scheduler.cache.evict.cron.expression}")
    public void evictCache(){
        log.info("Full Cache Evicted");
    }
}
