package com.maf.aiorchestrator.listener;

import com.maf.aiorchestrator.dto.jms.NotificationMessage;
import com.maf.aiorchestrator.entities.ImportsData;
import com.maf.aiorchestrator.enums.Country;
import com.maf.aiorchestrator.enums.FileType;
import com.maf.aiorchestrator.service.ProcessImportService;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Objects;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;

@Component
@Slf4j
@AllArgsConstructor(onConstructor_ = {@Autowired})
public class AIOrchImportListener {

    private ProcessImportService processImportService;

    public void processMessage(NotificationMessage message) {
        Optional<FileType> fileType = FileType.getFileType(message.getTemplateType());
        Optional<Country> country = Country.getCountryCode(message.getCountry());
        if(fileType.isPresent() && country.isPresent() && Objects.nonNull(message.getEnrichRequest())){
            ImportsData importsData = processImportService.createAndSaveImportsData(message, fileType.get(), country.get());
            CompletableFuture.runAsync(() -> {
                try {
                    processImportService.processSBImport(message, importsData);
                } catch (Exception e) {
                    log.error("Error in processing import with id {}", message.getImportId(), e);
                }
            });
        }
    }
}
