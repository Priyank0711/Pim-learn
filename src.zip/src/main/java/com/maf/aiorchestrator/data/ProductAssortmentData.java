package com.maf.aiorchestrator.data;

import lombok.Data;

@Data
public class ProductAssortmentData {

    private String code;
}
