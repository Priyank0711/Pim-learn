package com.maf.aiorchestrator.data;

import lombok.Data;
@Data
public class FeatureValueData {
    private String value;
    private String value_ar;
}
