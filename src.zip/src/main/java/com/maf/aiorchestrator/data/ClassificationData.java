package com.maf.aiorchestrator.data;

import lombok.Data;

import java.util.Collection;

@Data
public class ClassificationData {
    private String code;
    private String name;
    private String name_ar;
    private Collection<FeatureData> features;
}
