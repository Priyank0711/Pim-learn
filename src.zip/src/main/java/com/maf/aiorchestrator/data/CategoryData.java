package com.maf.aiorchestrator.data;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class CategoryData {

    private String id;

    private String name;

    private String name_ar;

    private Integer level;

    private String url;

    private String code;

    private String categoryName;

    private String path;
    private String type;

    public static CategoryData createShallowCategoryData(CategoryData cd) {
        return CategoryData.builder()
                .id(cd.getId())
                .name(cd.getName())
                .name_ar(cd.getName_ar())
                .code(cd.getCode())
                .level(cd.getLevel())
                .path(cd.getPath())
                .type(cd.getType())
                .build();
    }
}
