package com.maf.aiorchestrator.data;

import lombok.Data;

@Data
public class ImageData {

    private String imageType;
    private String format;
    private String url;
    private String altText;
    private String mimeType;
}
