package com.maf.aiorchestrator.controller;

import com.maf.aiorchestrator.dto.*;
import com.maf.aiorchestrator.elastic.dto.DetailedProductResultDTO;
import com.maf.aiorchestrator.elastic.dto.OnlineProductListingDTO;
import com.maf.aiorchestrator.elastic.dto.ProductResultDTO;
import com.maf.aiorchestrator.elastic.request.ListingProductsSearchRequest;
import com.maf.aiorchestrator.elastic.request.OnlineProductsListingRequest;
import com.maf.aiorchestrator.elastic.request.OnlineProductsScanRequest;
import com.maf.aiorchestrator.elastic.response.MafSearchResultData;
import com.maf.aiorchestrator.elastic.service.ElasticSearchService;
import com.maf.aiorchestrator.elastic.utils.MafPageable;
import com.maf.aiorchestrator.entities.ImportsData;
import com.maf.aiorchestrator.enums.ImportStatus;
import com.maf.aiorchestrator.exception.ApiErrors;
import com.maf.aiorchestrator.exception.ApiException;
import com.maf.aiorchestrator.exception.ErrorCodes;
import com.maf.aiorchestrator.security.helper.RequestParamMapper;
import com.maf.aiorchestrator.service.FileExportService;
import com.maf.aiorchestrator.service.ProcessImportService;
import com.maf.aiorchestrator.service.ProductService;
import com.maf.aiorchestrator.utils.Constants;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;
import java.util.concurrent.CompletableFuture;


@RestController
@RequestMapping("{country}/product")
@RequiredArgsConstructor
@Slf4j
@Tag(name = "Product Controller", description = "APIs for managing staged products")
public class ProductController {

    private final ProductService productService;
    private final ElasticSearchService elasticSearchService;
    private final FileExportService fileExportService;
    private final ProcessImportService processImportService;
    private final RequestParamMapper requestParamMapper;


    @PutMapping("/updateStatus")
    @PreAuthorize("@authorityHelper.hasAuthorityContaining(authentication, 'PIM', #country)")
    @Operation(summary = "Update product/import status", description = "Updates the status of product imports")
    public ResponseEntity<Optional<UpdateProductStatusResponseDTO>> updateProductImportsStatus(
            @RequestBody UpdateStatusRequestDTO updateStatusRequestDTO,
            @PathVariable("country") String country) {
        UpdateProductStatusResponseDTO responseDTO = productService.updateProductImportsStatus(updateStatusRequestDTO, country);
        if (String.format(Constants.IMPORT_REVIEWED, ImportStatus.APPROVED.name()).equalsIgnoreCase(responseDTO.getMessage())) {
            fileExportService.publishImport(updateStatusRequestDTO.getImportId());
        }
        return ResponseEntity.ok(Optional.of(responseDTO));
    }


    @PostMapping("/getAllProducts")
    @PreAuthorize("@authorityHelper.hasAuthorityContaining(authentication, 'PIM', #country)")
    @Operation(summary = "Get all staged products", description = "Retrieves all staged products with facets aggregation")
    public ResponseEntity<MafSearchResultData<ProductResultDTO>> getAllStagedProducts(
            @RequestBody ListingProductsSearchRequest listingProductsSearchRequest,
            @PathVariable("country") String country) {
        MafPageable pageData = listingProductsSearchRequest.getPageData() == null ? new MafPageable() : listingProductsSearchRequest.getPageData();
        listingProductsSearchRequest.setPageData(pageData);
        listingProductsSearchRequest.setProperties();
        MafSearchResultData<ProductResultDTO> result = elasticSearchService.getStagedProductSearchResult(listingProductsSearchRequest, country);
        return ResponseEntity.ok(result);
    }

    @PostMapping("/getAllOnlineProducts")
    @PreAuthorize("@authorityHelper.hasAuthorityContaining(authentication, 'PIM', #country)")
    @Operation(summary = "Get all online products", description = "Retrieves all online products with facets aggregation")
    public ResponseEntity<MafSearchResultData<OnlineProductListingDTO>> getAllOnlineProducts(
            @RequestBody OnlineProductsListingRequest listingProductsSearchRequest,
            @PathVariable("country") String country) {
        MafPageable pageData = listingProductsSearchRequest.getPageData() == null ? new MafPageable() : listingProductsSearchRequest.getPageData();
        listingProductsSearchRequest.setPageData(pageData);
        listingProductsSearchRequest.setProperties();
        MafSearchResultData<OnlineProductListingDTO> result = elasticSearchService.getOnlineProductListingResult(listingProductsSearchRequest, country);
        return ResponseEntity.ok(result);
    }

    @PostMapping("/scan")
    @PreAuthorize("@authorityHelper.hasAuthorityContaining(authentication, 'PIM', #country)")
    @Operation(summary = "scan online product index foe enrichment", description = "scan online product index foe enrichment")
    public ResponseEntity<Object> scanOnlineProducts(
            @RequestBody OnlineProductsScanRequest scanProductsRequest,
            @PathVariable("country") String country) {
        validateScanRequest(scanProductsRequest);
        scanProductsRequest.setProperties();
        ImportsData importsData = processImportService.createAndSaveScanImport(scanProductsRequest, country);
        CompletableFuture.runAsync(() -> {
            try {
                processImportService.processScanImport(importsData, scanProductsRequest);
            } catch (Exception e) {
                log.error("Error in processing import with id {}", importsData.getImportId(), e);
            }
        });
        return ResponseEntity.accepted().body("Scan Requested with importId: " + importsData.getImportId());
    }

    @GetMapping("/getProduct")
    @PreAuthorize("@authorityHelper.hasAuthorityContaining(authentication, 'PIM', #country)")
    @Operation(summary = "Get detailed staged product by Elastic ID", description = "Retrieves detailed product information by Elastic ID")
    public ResponseEntity<DetailedProductResultDTO> getDetailedProductByElasticId(
            @RequestParam String elasticId,
            @PathVariable("country") String country) {
        return ResponseEntity.ok(productService.getDetailedProductByElasticId(elasticId, country));
    }

    @PutMapping("/update")
    @PreAuthorize("@authorityHelper.hasAuthorityContaining(authentication, 'PIM', #country)")
    @Operation(summary = "Update staged product", description = "Updates product information")
    public ResponseEntity<ProductUpdateResponseDTO> updateProduct(@RequestBody ProductElkUpdateDTO productElkUpdateDTO, @PathVariable("country") String country) {
        try {
            ProductUpdateResponseDTO updateResponseDTO = productService.updateProduct(productElkUpdateDTO, country);
            return ResponseEntity.ok(updateResponseDTO);
        } catch (ApiException e) {
            log.error("Error in updateProduct api - {}", e.getMessage(), e);
            throw e;
        } catch (Exception e) {
            log.error("Error in updateProduct api - {}", e.getMessage(), e);
            throw new ApiException(new ApiErrors(ErrorCodes.INTERNAL_SERVER_ERROR));
        }
    }

    private void validateScanRequest(OnlineProductsScanRequest scanProductsRequest) {
        if(CollectionUtils.isEmpty(scanProductsRequest.getEnrichOptions())) {
            throw new ApiException(new ApiErrors(ErrorCodes.SCAN_BAD_REQUEST), "enrichOptions are mandatory");
        }

        // either category facet is present or search by should present
        if (scanProductsRequest.getSearchBy() == null || !StringUtils.hasText(scanProductsRequest.getSearchTerm())) {
            boolean categoryPresent = scanProductsRequest.getFacets().stream()
                    .filter(f -> f.getKey().equals("category"))
                    .anyMatch(f -> StringUtils.hasText(f.getSelectedValue()));
            if (!categoryPresent) {
                throw new ApiException(new ApiErrors(ErrorCodes.SCAN_BAD_REQUEST), "category or searchBy is mandatory");
            }
        }
    }
}