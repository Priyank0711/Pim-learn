package com.maf.aiorchestrator.controller;

import com.maf.aiorchestrator.dto.ProductElkUpdateDTO;
import com.maf.aiorchestrator.dto.ProductUpdateResponseDTO;
import com.maf.aiorchestrator.dto.UpdateProductStatusResponseDTO;
import com.maf.aiorchestrator.dto.UpdateStatusRequestDTO;
import com.maf.aiorchestrator.elastic.dto.DetailedProductResultDTO;
import com.maf.aiorchestrator.elastic.dto.OnlineProductListingDTO;
import com.maf.aiorchestrator.elastic.dto.ProductResultDTO;
import com.maf.aiorchestrator.elastic.request.ListingProductsSearchRequest;
import com.maf.aiorchestrator.elastic.request.OnlineProductsListingRequest;
import com.maf.aiorchestrator.elastic.request.OnlineProductsScanRequest;
import com.maf.aiorchestrator.elastic.response.MafSearchResultData;
import com.maf.aiorchestrator.elastic.service.ElasticSearchService;
import com.maf.aiorchestrator.elastic.utils.MafFacet;
import com.maf.aiorchestrator.elastic.utils.MafPageable;
import com.maf.aiorchestrator.elastic.utils.SearchBy;
import com.maf.aiorchestrator.entities.ImportsData;
import com.maf.aiorchestrator.enums.EnrichOptionsEnum;
import com.maf.aiorchestrator.exception.ApiErrors;
import com.maf.aiorchestrator.exception.ApiException;
import com.maf.aiorchestrator.exception.ErrorCodes;
import com.maf.aiorchestrator.security.helper.RequestParamMapper;
import com.maf.aiorchestrator.service.FileExportService;
import com.maf.aiorchestrator.service.ProcessImportService;
import com.maf.aiorchestrator.service.ProductService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.http.ResponseEntity;

import java.io.IOException;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class ProductControllerTest {

    @Mock
    private ProductService productService;

    @Mock
    private ElasticSearchService elasticSearchService;

    @Mock
    private FileExportService fileExportService;

    @Mock
    private ProcessImportService processImportService;

    @Mock
    private RequestParamMapper requestParamMapper;

    @InjectMocks
    private ProductController productController;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void updateProductImportsStatus_approve_shouldUpdateStatus() {
        UpdateStatusRequestDTO requestDTO = new UpdateStatusRequestDTO();
        UpdateProductStatusResponseDTO responseDTO = new UpdateProductStatusResponseDTO();
        responseDTO.setMessage("Import is APPROVED");
        when(productService.updateProductImportsStatus(requestDTO, "UAE")).thenReturn(responseDTO);

        ResponseEntity<Optional<UpdateProductStatusResponseDTO>> response = productController.updateProductImportsStatus(requestDTO, "UAE");

        assertTrue(response.getBody().isPresent());
        assertEquals(responseDTO, response.getBody().get());
        verify(fileExportService).publishImport(requestDTO.getImportId());
    }

    @Test
    void updateProductImportsStatus_reject_shouldReturnEmptyResponse() {
        UpdateStatusRequestDTO requestDTO = new UpdateStatusRequestDTO();
        UpdateProductStatusResponseDTO responseDTO = new UpdateProductStatusResponseDTO();
        responseDTO.setMessage("Import is REJECTED");
        when(productService.updateProductImportsStatus(requestDTO, "UAE")).thenReturn(responseDTO);

        ResponseEntity<Optional<UpdateProductStatusResponseDTO>> response = productController.updateProductImportsStatus(requestDTO, "UAE");

        assertTrue(response.getBody().isPresent());
        assertEquals(responseDTO, response.getBody().get());
        verify(fileExportService, never()).publishImport(any());
    }

    @Test
    void getAllStagedProducts_validRequest_shouldReturnProducts() {
        ListingProductsSearchRequest request = new ListingProductsSearchRequest();
        MafSearchResultData<ProductResultDTO> resultData = new MafSearchResultData<>();
        when(elasticSearchService.getStagedProductSearchResult(request, "UAE")).thenReturn(resultData);

        ResponseEntity<MafSearchResultData<ProductResultDTO>> response = productController.getAllStagedProducts(request, "UAE");

        assertEquals(resultData, response.getBody());
    }

    @Test
    void getAllStagedProducts_validRequestWithPageData_shouldReturnProducts() {
        ListingProductsSearchRequest request = new ListingProductsSearchRequest();
        request.setPageData(new MafPageable());
        MafSearchResultData<ProductResultDTO> resultData = new MafSearchResultData<>();
        when(elasticSearchService.getStagedProductSearchResult(request, "UAE")).thenReturn(resultData);

        ResponseEntity<MafSearchResultData<ProductResultDTO>> response = productController.getAllStagedProducts(request, "UAE");

        assertEquals(resultData, response.getBody());
    }

    @Test
    void getAllOnlineProducts_validRequestWithPageData_shouldReturnProducts() {
        OnlineProductsListingRequest request = new OnlineProductsListingRequest();
        request.setPageData(new MafPageable());
        MafSearchResultData<OnlineProductListingDTO> resultData = new MafSearchResultData<>();
        when(elasticSearchService.getOnlineProductListingResult(request, "UAE")).thenReturn(resultData);

        ResponseEntity<MafSearchResultData<OnlineProductListingDTO>> response = productController.getAllOnlineProducts(request, "UAE");

        assertEquals(resultData, response.getBody());
    }

    @Test
    void getAllOnlineProducts_validRequest_shouldReturnProducts() {
        OnlineProductsListingRequest request = new OnlineProductsListingRequest();
        MafSearchResultData<OnlineProductListingDTO> resultData = new MafSearchResultData<>();
        when(elasticSearchService.getOnlineProductListingResult(request, "UAE")).thenReturn(resultData);

        ResponseEntity<MafSearchResultData<OnlineProductListingDTO>> response = productController.getAllOnlineProducts(request, "UAE");

        assertEquals(resultData, response.getBody());
    }

    @Test
    void scanOnlineProducts_validRequest_errorInProcessing_shouldReturnAccepted() throws IOException {
        OnlineProductsScanRequest request = new OnlineProductsScanRequest();
        ImportsData importsData = new ImportsData();
        importsData.setImportId("12345");
        request.setEnrichOptions(List.of(EnrichOptionsEnum.TITLE_GENERATION));
        request.setSearchBy(SearchBy.BY_PRODUCT_EAN);
        MafFacet facet = new MafFacet();
        facet.setKey("category");
        facet.setSelectedValue("1");
        request.setFacets(List.of(facet));
        when(processImportService.createAndSaveScanImport(request, "UAE")).thenReturn(importsData);
        Mockito.doThrow(new RuntimeException("test")).when(processImportService).processScanImport(importsData, request);
        ResponseEntity<Object> response = productController.scanOnlineProducts(request, "UAE");
        assertEquals("Scan Requested with importId: 12345", response.getBody());
    }


    @Test
    void scanOnlineProducts_validRequestWithCategory_shouldReturnAccepted() {
        OnlineProductsScanRequest request = new OnlineProductsScanRequest();
        ImportsData importsData = new ImportsData();
        importsData.setImportId("12345");
        request.setEnrichOptions(List.of(EnrichOptionsEnum.TITLE_GENERATION));
        MafFacet facet = new MafFacet();
        facet.setKey("category");
        facet.setSelectedValue("1");
        request.setFacets(List.of(facet));
        when(processImportService.createAndSaveScanImport(request, "UAE")).thenReturn(importsData);

        ResponseEntity<Object> response = productController.scanOnlineProducts(request, "UAE");

        assertEquals("Scan Requested with importId: 12345", response.getBody());
    }

    @Test
    void scanOnlineProducts_validRequestWithSearchBy_shouldReturnAccepted() {
        OnlineProductsScanRequest request = new OnlineProductsScanRequest();
        ImportsData importsData = new ImportsData();
        importsData.setImportId("12345");
        request.setEnrichOptions(List.of(EnrichOptionsEnum.TITLE_GENERATION));
        request.setSearchBy(SearchBy.BY_PRODUCT_EAN);
        request.setSearchTerm("Test");
        when(processImportService.createAndSaveScanImport(request, "UAE")).thenReturn(importsData);

        ResponseEntity<Object> response = productController.scanOnlineProducts(request, "UAE");

        assertEquals("Scan Requested with importId: 12345", response.getBody());
    }

    @Test
    void scanOnlineProducts_inValidRequest_missingEnrichOptions_shouldThrow() {
        OnlineProductsScanRequest request = new OnlineProductsScanRequest();
        ImportsData importsData = new ImportsData();
        importsData.setImportId("12345");
        when(processImportService.createAndSaveScanImport(request, "UAE")).thenReturn(importsData);

        assertThrows(ApiException.class, () -> productController.scanOnlineProducts(request, "UAE"));
    }

    @Test
    void scanOnlineProducts_inValidRequest_missingMandatoryFields_shouldThrow() {
        OnlineProductsScanRequest request = new OnlineProductsScanRequest();
        request.setEnrichOptions(List.of(EnrichOptionsEnum.TITLE_GENERATION));
        request.setFacets(List.of());
        ImportsData importsData = new ImportsData();
        importsData.setImportId("12345");
        when(processImportService.createAndSaveScanImport(request, "UAE")).thenReturn(importsData);

        assertThrows(ApiException.class, () -> productController.scanOnlineProducts(request, "UAE"));
    }

    @Test
    void getDetailedProductByElasticId_validId_shouldReturnProduct() {
        DetailedProductResultDTO productResultDTO = new DetailedProductResultDTO();
        when(productService.getDetailedProductByElasticId("elasticId", "UAE")).thenReturn(productResultDTO);

        ResponseEntity<DetailedProductResultDTO> response = productController.getDetailedProductByElasticId("elasticId", "UAE");

        assertEquals(productResultDTO, response.getBody());
    }

    @Test
    void updateProduct_validRequest_shouldUpdateProduct() {
        ProductElkUpdateDTO updateDTO = new ProductElkUpdateDTO();
        ProductUpdateResponseDTO responseDTO = new ProductUpdateResponseDTO();
        when(productService.updateProduct(updateDTO, "UAE")).thenReturn(responseDTO);

        ResponseEntity<ProductUpdateResponseDTO> response = productController.updateProduct(updateDTO, "UAE");

        assertEquals(responseDTO, response.getBody());
    }

    @Test
    void updateProduct_APIException_shouldUpdateProduct() {
        ProductElkUpdateDTO updateDTO = new ProductElkUpdateDTO();
        ProductUpdateResponseDTO responseDTO = new ProductUpdateResponseDTO();
        Mockito.doThrow(new ApiException(new ApiErrors(ErrorCodes.PRODUCT_NOT_FOUND))).when(productService).updateProduct(updateDTO, "UAE");
        assertThrows(ApiException.class, () -> productController.updateProduct(updateDTO, "UAE"));
    }

    @Test
    void updateProduct_Exception_shouldUpdateProduct() {
        ProductElkUpdateDTO updateDTO = new ProductElkUpdateDTO();
        ProductUpdateResponseDTO responseDTO = new ProductUpdateResponseDTO();
        Mockito.doThrow(new RuntimeException("test")).when(productService).updateProduct(updateDTO, "UAE");
        assertThrows(ApiException.class, () -> productController.updateProduct(updateDTO, "UAE"));
    }
}