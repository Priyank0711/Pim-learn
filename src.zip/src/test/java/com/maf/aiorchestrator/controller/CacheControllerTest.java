package com.maf.aiorchestrator.controller;


import com.maf.aiorchestrator.enums.Country;
import com.maf.aiorchestrator.service.CacheService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;

@ExtendWith(MockitoExtension.class)
class CacheControllerTest {
    @InjectMocks
    CacheController controller;

    @Mock
    CacheService service;

    @Test
    void testClearCache()
    {
        Mockito.doNothing().when(service).refreshAllCache(Mockito.any());
        assertDoesNotThrow(()->controller.clearCache(null, Country.UAE));
        assertDoesNotThrow(()->controller.clearCache(new ArrayList<>(), Country.UAE));
        assertDoesNotThrow(()->controller.clearCache(List.of("test"), Country.UAE));


    }
}
