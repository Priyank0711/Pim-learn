package com.maf.aiorchestrator.controller;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.springframework.http.ResponseEntity;

import java.util.Locale;

public class HealthCheckControllerTest {

    @InjectMocks
    private HealthCheckController healthCheckController;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testHome() {
        ResponseEntity<String> response = healthCheckController.home(new Locale("en"));
        Assertions.assertNotNull(response);
    }
}
