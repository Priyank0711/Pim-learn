package com.maf.aiorchestrator.service.impl;

import com.maf.aiorchestrator.config.mongo.MafMongoTemplate;
import com.maf.aiorchestrator.dto.jms.NotificationMessage;
import com.maf.aiorchestrator.entities.ImportsData;
import com.maf.aiorchestrator.enums.ImportStatus;
import com.maf.aiorchestrator.repository.ImportsDataRepository;
import com.maf.aiorchestrator.service.NotificationService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class ImportsDataServiceImplTest {

    @InjectMocks
    private ImportsDataServiceImpl importsDataService;

    @Mock
    private ImportsDataRepository importsDataRepository;

    @Mock
    private MafMongoTemplate mongoTemplate;

    @Mock
    private NotificationService notificationService;

    @Test
    void testUpdateImportStatusInDb() {
        String importId = "12345";
        ImportStatus status = ImportStatus.APPROVED;
        when(mongoTemplate.updateFirst(any(Query.class), any(Update.class), eq(ImportsData.class))).thenReturn(null);
        doNothing().when(notificationService).sendNotification(any(NotificationMessage.class));
        importsDataService.updateImportStatusInDb(status, importId);
        verify(mongoTemplate, times(1)).updateFirst(any(Query.class), any(Update.class), eq(ImportsData.class));
        verify(notificationService, times(1)).sendNotification(any(NotificationMessage.class));
    }

    @Test
    void testSave() {
        ImportsData importsData = new ImportsData();
        when(importsDataRepository.save(any(ImportsData.class))).thenReturn(importsData);
        ImportsData result = importsDataService.save(importsData);
        assertNotNull(result);
        verify(importsDataRepository, times(1)).save(any(ImportsData.class));
    }
}
