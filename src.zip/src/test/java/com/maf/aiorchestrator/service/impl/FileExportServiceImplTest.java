package com.maf.aiorchestrator.service.impl;

import com.maf.aiorchestrator.dto.file.CsvMetadata;
import com.maf.aiorchestrator.dto.file.FileData;
import com.maf.aiorchestrator.entities.ElkProduct;
import com.maf.aiorchestrator.entities.ImportsData;
import com.maf.aiorchestrator.enums.Country;
import com.maf.aiorchestrator.enums.ImportStatus;
import com.maf.aiorchestrator.enums.ProductStatus;
import com.maf.aiorchestrator.exception.JobExecutionException;
import com.maf.aiorchestrator.repository.ImportsDataRepository;
import com.maf.aiorchestrator.service.ElkService;
import com.maf.aiorchestrator.service.ProductService;
import com.maf.aiorchestrator.service.StorageService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.io.IOException;
import java.time.Instant;
import java.util.*;

import static com.maf.aiorchestrator.enums.FileType.PIM_PRODUCT;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class FileExportServiceImplTest {

    @InjectMocks
    private FileExportServiceImpl fileExportService;

    @Mock
    private ProductService productService;

    @Mock
    private StorageService storageService;

    @Mock
    private ImportsDataRepository importsDataRepository;

    @Mock
    private ElkService elkService;

    @Test
    void testExecute_NoProductsFound() {
        Instant lastUpdated = Instant.now();
        Country country = Country.UAE;

        when(elkService.getProductsByStatus(ProductStatus.APPROVED, lastUpdated, country)).thenReturn(Collections.emptyList());

        fileExportService.execute(lastUpdated, country);

        verify(elkService, times(1)).getProductsByStatus(ProductStatus.APPROVED, lastUpdated, country);
        verifyNoInteractions(productService, storageService, importsDataRepository);
    }

    @Test
    void testExecute_WithProducts() throws IOException {
        Instant lastUpdated = Instant.now();
        Country country = Country.UAE;
        ElkProduct elkProduct = new ElkProduct();
        elkProduct.setImportId("1234");
        elkProduct.setCountry(country);
        elkProduct.setCategoryCode("1893");
        elkProduct.setCategory("category1");

        ElkProduct elkProduct2 = new ElkProduct();
        elkProduct2.setImportId("1234");
        elkProduct2.setCountry(country);
        List<ElkProduct> elkProductList = List.of(elkProduct, elkProduct2);
        ImportsData importsData = getImportsData();


        List<Map<String, String>> exportProductList = createProductExportList();

        when(elkService.getProductsByStatus(ProductStatus.APPROVED, lastUpdated, country)).thenReturn(elkProductList);
        when(importsDataRepository.findByImportId(any())).thenReturn(importsData);
        when(productService.getExportProductList(anyList())).thenReturn(exportProductList);
        when(storageService.uploadPimFile(any(), anyString(), anyString())).thenReturn("file Uploaded");

        fileExportService.execute(lastUpdated, country);

        verify(elkService, times(1)).getProductsByStatus(any(), any(), any());
        verify(importsDataRepository, times(2)).findByImportId(anyString());
        verify(productService, times(2)).getExportProductList(anyList());
        verify(storageService, times(2)).uploadPimFile(any(), anyString(), anyString());
    }

    @Test
    void testExecute_IOException() throws IOException {
        Instant lastUpdated = Instant.now();
        Country country = Country.UAE;
        ElkProduct elkProduct = new ElkProduct();
        elkProduct.setImportId("1234");
        elkProduct.setCountry(country);
        elkProduct.setCategoryCode("1893");
        elkProduct.setCategory("category1");
        List<ElkProduct> elkProductList = List.of(elkProduct);
        ImportsData importsData = getImportsData();


        List<Map<String, String>> exportProductList = createProductExportList();

        when(elkService.getProductsByStatus(ProductStatus.APPROVED, lastUpdated, country)).thenReturn(elkProductList);
        when(importsDataRepository.findByImportId(any())).thenReturn(importsData);
        when(productService.getExportProductList(anyList())).thenReturn(exportProductList);
        doThrow(new IOException()).when(storageService).uploadPimFile(any(), anyString(), anyString());
        assertThrows(JobExecutionException.class, () -> fileExportService.execute(lastUpdated, country));
        verify(elkService, times(1)).getProductsByStatus(any(), any(), any());
        verify(importsDataRepository, times(1)).findByImportId(anyString());
        verify(productService, times(1)).getExportProductList(anyList());
        verify(storageService, times(1)).uploadPimFile(any(), anyString(), anyString());
    }

    @Test
    void testPublishImport() {
        fileExportService.publishImport("123");
    }

    @Test
    void testPublishImportToPIM() throws IOException {
        String importId = "1234";
        ImportsData importsData = getImportsData();
        List<Map<String, String>> exportProductList = createProductExportList();
        when(importsDataRepository.findByImportId(anyString())).thenReturn(importsData);
        when(productService.getProductsByImportIdForExport(any(), any())).thenReturn(exportProductList);

        fileExportService.publishApprovedImportsToPIM(importId);

        verify(importsDataRepository, times(1)).findByImportId(any());
        verify(productService, times(1)).getProductsByImportIdForExport(any(), any());
        verify(storageService, times(1)).uploadPimFile(any(), any(), any());

    }

    @Test
    void testPublishImportToPIM_NoImportFound() throws IOException {
        String importId = "1234";
        when(importsDataRepository.findByImportId(anyString())).thenReturn(null);

        fileExportService.publishApprovedImportsToPIM(importId);

        verify(importsDataRepository, times(1)).findByImportId(any());
        verify(productService, never()).getProductsByImportIdForExport(any(), any());
        verify(storageService, never()).uploadPimFile(any(), any(), any());


    }

    @Test
    void testPublishImportToPIM_ImportNotApproved() throws IOException {
        String importId = "1234";
        ImportsData importsData = getImportsData();
        importsData.setStatus(ImportStatus.REJECTED);
        when(importsDataRepository.findByImportId(anyString())).thenReturn(importsData);

        fileExportService.publishApprovedImportsToPIM(importId);

        verify(importsDataRepository, times(1)).findByImportId(any());
        verify(productService, never()).getProductsByImportIdForExport(any(), any());
        verify(storageService, never()).uploadPimFile(any(), any(), any());

    }

    @Test
    void testPublishImportToPIM_Exception() throws IOException {
        String importId = "1234";
        when(importsDataRepository.findByImportId(anyString())).thenReturn(getImportsData());
        when(productService.getProductsByImportIdForExport(any(), any())).thenThrow(new RuntimeException("TestException"));

        assertThrows(JobExecutionException.class, () -> fileExportService.publishApprovedImportsToPIM(importId));

        verify(importsDataRepository, times(1)).findByImportId(any());
        verify(storageService, never()).uploadPimFile(any(), any(), any());
    }


    private static FileData getFileData() {
        FileData fileData = new FileData();
        fileData.setFileType(PIM_PRODUCT);
        fileData.setName("carrefour-carrefour_378-UAE-transformed.csv");
        fileData.setLocation("src/test/resources/data/carrefour-1734607936523-UAE-CLASSIFICATION.csv");
        CsvMetadata csvMetadata = new CsvMetadata();
        csvMetadata.setCategoryCode("1893");
        csvMetadata.setTemplateType("PIM_PRODUCT");
        csvMetadata.setMetaDataString("onlineName,ean");
        fileData.setCsvMetadata(csvMetadata);
        return fileData;
    }

    private static ImportsData getImportsData(){
        ImportsData importsData = new ImportsData();
        importsData.setImportId("1234");
        importsData.setCountry(Country.UAE);
        importsData.setShopId("carrefour");
        importsData.setCategoryCode("1893");
        importsData.setStatus(ImportStatus.APPROVED);
        importsData.setFileData(getFileData());
        return importsData;
    }

    private static List<Map<String, String>> createProductExportList(){
        List<Map<String, String>> exportProductList = new ArrayList<>();
        Map<String, String> product = new HashMap<>();
        product.put("ean", "1234567890123");
        product.put("onlineName", "Test Product");
        exportProductList.add(product);
        Map<String, String> product2 = new HashMap<>();
        product2.put("ean", "1234567890124");
        product2.put("onlineName", "Test Product 2");
        exportProductList.add(product2);
        return exportProductList;
    }

}