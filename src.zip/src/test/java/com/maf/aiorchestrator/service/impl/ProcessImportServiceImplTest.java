package com.maf.aiorchestrator.service.impl;

import com.maf.aiorchestrator.dto.ImportWrapperDTO;
import com.maf.aiorchestrator.dto.file.CsvMetadata;
import com.maf.aiorchestrator.dto.file.FileData;
import com.maf.aiorchestrator.dto.jms.AIEnrichRequest;
import com.maf.aiorchestrator.dto.jms.FileDetails;
import com.maf.aiorchestrator.dto.jms.NotificationMessage;
import com.maf.aiorchestrator.elastic.request.OnlineProductsScanRequest;
import com.maf.aiorchestrator.elastic.utils.MafFacet;
import com.maf.aiorchestrator.entities.ImportsData;
import com.maf.aiorchestrator.enums.*;
import com.maf.aiorchestrator.facade.ImportFacade;
import com.maf.aiorchestrator.repository.CategoryFormatRepository;
import com.maf.aiorchestrator.service.ImportsDataService;
import com.maf.aiorchestrator.service.StorageService;
import com.maf.aiorchestrator.utils.Constants;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.io.File;
import java.io.IOException;
import java.util.List;

import static com.maf.aiorchestrator.enums.FileType.PIM_PRODUCT;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class ProcessImportServiceImplTest {

    @InjectMocks
    private ProcessImportServiceImpl processImportService;

    @Mock
    private StorageService storageService;

    @Mock
    private ImportsDataService importsDataService;

    @Mock
    private ImportFacade importFacade;

    @Mock
    private CategoryFormatRepository categoryFormatRepository;


    @Test
    void testProcessData_WithCategoryIncluded() throws IOException {
        NotificationMessage message = new NotificationMessage();
        FileDetails fd = new FileDetails();
        fd.setLocation("location");
        fd.setName("name-transformed.csv");

        message.setTransformedFile(fd);
        message.setCategoryCode("categoryCode");
        message.setImportId("importId");
        File file = new File("test.csv");

        when(storageService.downloadFileFromCatalogBlob(anyString(), anyString())).thenReturn(file);
        when(categoryFormatRepository.existsByCodeAndIsIncluded(anyString(), eq(true))).thenReturn(true);
        doNothing().when(importFacade).processImport(any());
        processImportService.processSBImport(message, getImportsData());

        verify(importFacade, times(1)).processImport(any());
        verify(storageService, times(1)).downloadFileFromCatalogBlob(anyString(), anyString());
    }

    @Test
    void testProcessData_WithCategoryNotIncluded() throws IOException {
        NotificationMessage message = new NotificationMessage();

        FileDetails fd = new FileDetails();
        fd.setLocation("location");
        fd.setName("name-transformed.csv");

        message.setTransformedFile(fd);
        message.setCategoryCode("categoryCode");
        message.setImportId("importId");
        File file = new File("test.csv");

        when(storageService.downloadFileFromCatalogBlob(anyString(), anyString())).thenReturn(file);
        when(categoryFormatRepository.existsByCodeAndIsIncluded(anyString(), eq(true))).thenReturn(false);
        when(storageService.uploadPimFile(any(),anyString(),anyString())).thenReturn("uploaded");

        processImportService.processSBImport(message, getImportsData());

        verify(importFacade, never()).processImport(any(ImportWrapperDTO.class));
        verify(storageService, times(1)).uploadPimFile(any(File.class), anyString(), anyString());
    }

    @Test
    void testCreateAndSaveImportsData() {
        NotificationMessage message = new NotificationMessage();
        FileDetails fd = new FileDetails();
        fd.setLocation("location");
        fd.setName("name-transformed.csv");

        message.setTransformedFile(fd);
        message.setImportId("importId");
        message.setCategoryCode("categoryCode");
        message.setShopId("shopId");
        Country country = Country.UAE;
        message.setEnrichRequest(new AIEnrichRequest("ai", List.of(EnrichOptionsEnum.ENRICH_ATTRIBUTE)));
        when(importsDataService.save(any(ImportsData.class))).thenReturn(getImportsData());



        ImportsData importsData = processImportService.createAndSaveImportsData(message, FileType.PIM_PRODUCT, country);

        assertNotNull(importsData);
        assertEquals("importId", importsData.getImportId());
        assertEquals(ImportStatus.UPLOADED, importsData.getStatus());
        assertEquals(country, importsData.getCountry());
        assertEquals(FileType.PIM_PRODUCT, importsData.getFileData().getFileType());
        verify(importsDataService, times(1)).save(any(ImportsData.class));
    }

    @Test
    void processScanImport_SuccessfulProcessing() throws IOException {
        ImportsData importsData = getImportsData();
        OnlineProductsScanRequest scanRequest = new OnlineProductsScanRequest();
        ImportWrapperDTO importsWrapperDTO = new ImportWrapperDTO();
        importsWrapperDTO.setImportsData(importsData);
        importsWrapperDTO.setScanRequest(scanRequest);

        doNothing().when(importFacade).processImport(any(ImportWrapperDTO.class));

        processImportService.processScanImport(importsData, scanRequest);

        verify(importFacade, times(1)).processImport(any(ImportWrapperDTO.class));
        verifyNoMoreInteractions(importFacade);
    }

    @Test
    void processScanImport_ThrowsIOException() throws IOException {
        ImportsData importsData = getImportsData();
        OnlineProductsScanRequest scanRequest = new OnlineProductsScanRequest();

        doThrow(IOException.class).when(importFacade).processImport(any(ImportWrapperDTO.class));

        assertThrows(IOException.class, () -> processImportService.processScanImport(importsData, scanRequest));

        verify(importFacade, times(1)).processImport(any(ImportWrapperDTO.class));
        verifyNoMoreInteractions(importFacade);
    }

    @Test
    void createAndSaveScanImport_SuccessfulCreation() {
        OnlineProductsScanRequest scanRequest = new OnlineProductsScanRequest();
        MafFacet categoryFacet = new MafFacet();
        categoryFacet.setKey("category");
        categoryFacet.setSelectedValue("1234-Electronics");
        scanRequest.setFacets(List.of(categoryFacet));
        scanRequest.setEnrichOptions(List.of(EnrichOptionsEnum.ENRICH_ATTRIBUTE));
        ImportsData importsData = getImportsData();
        importsData.setType(ImportType.SCANNING);
        importsData.setShopId(Constants.SCAN_IDENTIFIER);
        when(importsDataService.saveScanImport(any(ImportsData.class))).thenReturn(importsData);

        ImportsData result = processImportService.createAndSaveScanImport(scanRequest, "UAE");

        assertNotNull(result);
        assertEquals(Country.UAE, result.getCountry());
        assertEquals(ImportStatus.UPLOADED, result.getStatus());
        assertEquals(ImportType.SCANNING, result.getType());
        assertEquals(Constants.SCAN_IDENTIFIER, result.getShopId());
        verify(importsDataService, times(1)).saveScanImport(any(ImportsData.class));
    }

    @Test
    void createAndSaveScanImport_NoCategoryFacet() {
        OnlineProductsScanRequest scanRequest = new OnlineProductsScanRequest();
        scanRequest.setEnrichOptions(List.of(EnrichOptionsEnum.ENRICH_ATTRIBUTE));
        assertDoesNotThrow(() -> processImportService.createAndSaveScanImport(scanRequest, "UAE"));
    }

    @Test
    void createAndSaveScanImport_InvalidCountry() {
        OnlineProductsScanRequest scanRequest = new OnlineProductsScanRequest();
        MafFacet categoryFacet = new MafFacet();
        categoryFacet.setKey("category");
        categoryFacet.setSelectedValue("1234-Electronics");
        scanRequest.setFacets(List.of(categoryFacet));
        scanRequest.setEnrichOptions(List.of(EnrichOptionsEnum.ENRICH_ATTRIBUTE));

        assertThrows(IllegalArgumentException.class, () -> processImportService.createAndSaveScanImport(scanRequest, "INVALID_COUNTRY"));
        verify(importsDataService, never()).saveScanImport(any(ImportsData.class));
    }

    private static FileData getFileData() {
        FileData fileData = new FileData();
        fileData.setFileType(PIM_PRODUCT);
        fileData.setName("carrefour-carrefour_378-UAE-transformed.csv");
        fileData.setLocation("src/test/resources/data/carrefour-1734607936523-UAE-CLASSIFICATION.csv");
        CsvMetadata csvMetadata = new CsvMetadata();
        csvMetadata.setCategoryCode("1893");
        csvMetadata.setTemplateType("PIM_PRODUCT");
        csvMetadata.setMetaDataString("onlineName,ean");
        fileData.setCsvMetadata(csvMetadata);
        return fileData;
    }

    private static ImportsData getImportsData(){
        ImportsData importsData = new ImportsData();
        importsData.setImportId("1234");
        importsData.setCountry(Country.UAE);
        importsData.setShopId("carrefour");
        importsData.setCategoryCode("1893");
        importsData.setStatus(ImportStatus.UPLOADED);
        importsData.setFileData(getFileData());
        return importsData;
    }
}
