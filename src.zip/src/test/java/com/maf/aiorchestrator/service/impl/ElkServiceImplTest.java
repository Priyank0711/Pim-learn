package com.maf.aiorchestrator.service.impl;

import com.maf.aiorchestrator.dto.EnrichedData;
import com.maf.aiorchestrator.dto.ProductElkUpdateDTO;
import com.maf.aiorchestrator.dto.ProductUpdateResponseDTO;
import com.maf.aiorchestrator.entities.ElkProduct;
import com.maf.aiorchestrator.enums.Country;
import com.maf.aiorchestrator.enums.ProductStatus;
import com.maf.aiorchestrator.exception.ApiException;
import com.maf.aiorchestrator.factory.IndexFactory;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.elasticsearch.core.ElasticsearchOperations;
import org.springframework.data.elasticsearch.core.SearchHits;
import org.springframework.data.elasticsearch.core.mapping.IndexCoordinates;
import org.springframework.data.elasticsearch.core.query.CriteriaQuery;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class ElkServiceImplTest {

    @Mock
    private ElasticsearchOperations elasticsearchOperations;

    @Mock
    private IndexFactory indexFactory;

    @InjectMocks
    private ElkServiceImpl elkService;

    @Test
    public void testBulkUpload() {
        ElkProduct elkProduct = new ElkProduct();
        elkProduct.setCountry(Country.UAE);
        elkProduct.setProductId("23234");
        elkService.bulkUpload(List.of(elkProduct));
        assertEquals("23234", elkProduct.getProductId());
    }


    @Test
    void testGetProductsByImportId() {
        String importId = "12345";
        String status = "ACTIVE";
        String country = "UAE";
        SearchHits<ElkProduct> searchHits = mock(SearchHits.class);

        when(indexFactory.getStagedProductIndexName(country)).thenReturn("product-index");
        when(elasticsearchOperations.search(any(CriteriaQuery.class), eq(ElkProduct.class), any(IndexCoordinates.class)))
                .thenReturn(searchHits);

        List<ElkProduct> result = elkService.getProductsByImportId(importId, status, country);
        verify(elasticsearchOperations).search(any(CriteriaQuery.class), eq(ElkProduct.class), any(IndexCoordinates.class));

        assertNotNull(result);
    }

    @Test
    void testGetProductByElasticId_NotFound() {
        String elasticId = "1";
        String country = "UAE";

        when(indexFactory.getStagedProductIndexName(country)).thenReturn("product-index");
        when(elasticsearchOperations.search(any(CriteriaQuery.class), eq(ElkProduct.class), any(IndexCoordinates.class)))
                .thenReturn(mock(SearchHits.class));

        assertThrows(ApiException.class, () -> elkService.getProductByElasticId(elasticId, country));
    }

    @Test
    void testUpdateProductStatus2() {
        List<String> elasticIds = List.of("1");
        ProductStatus status = ProductStatus.APPROVED;
        String country = "UAE";
        ElkProduct elkProduct = createElkProduct();  // Ensure this returns a proper ElkProduct
        IndexCoordinates indexCoordinates = IndexCoordinates.of("product-index");
        when(indexFactory.getStagedProductIndexName(country)).thenReturn("product-index");
        when(elasticsearchOperations.get(eq("1"), eq(ElkProduct.class), eq(indexCoordinates)))
                .thenReturn(elkProduct);
        when(elasticsearchOperations.save(eq(elkProduct), eq(indexCoordinates))).thenReturn(elkProduct);
        elkService.updateProductStatus(elasticIds, status, country);
        verify(elasticsearchOperations, times(1)).save(eq(elkProduct), eq(indexCoordinates));
    }


    @Test
    void testUpdateProductByGettingFirst() {
        String country = "UAE";
        String productId = "123";
        ProductElkUpdateDTO productElkUpdateDTO = new ProductElkUpdateDTO();
        productElkUpdateDTO.setId(productId);
        productElkUpdateDTO.setEnrichedMetaAttributes(Map.of("onlineName", Map.of("en", "Motorola")));
        productElkUpdateDTO.setEnrichedClassAttributes(Map.of("3G_uae", Map.of("en", "NO")));
        ElkProduct elkProduct = createElkProduct();

        when(indexFactory.getStagedProductIndexName(country)).thenReturn("product-index");
        when(elasticsearchOperations.get(eq(productId), eq(ElkProduct.class), any(IndexCoordinates.class)))
                .thenReturn(elkProduct);

        ProductUpdateResponseDTO response = elkService.updateProductByGettingFirst(productElkUpdateDTO, country);

        assertNotNull(response);
        verify(elasticsearchOperations).save(eq(elkProduct), any(IndexCoordinates.class));
    }

    @Test
    void testUpdateProductByGettingFirstWithNoEnrichedData() {
        String country = "UAE";
        String productId = "123";
        ProductElkUpdateDTO productElkUpdateDTO = new ProductElkUpdateDTO();
        productElkUpdateDTO.setId(productId);
        productElkUpdateDTO.setEnrichedMetaAttributes(Map.of("onlineName", Map.of("en", "Motorola")));
        productElkUpdateDTO.setEnrichedClassAttributes(Map.of("3G_uae", Map.of("en", "NO")));
        ElkProduct elkProduct = createElkProduct();
        elkProduct.setEnrichedData(null);
        when(indexFactory.getStagedProductIndexName(country)).thenReturn("product-index");
        when(elasticsearchOperations.get(eq(productId), eq(ElkProduct.class), any(IndexCoordinates.class)))
                .thenReturn(elkProduct);

        ProductUpdateResponseDTO response = elkService.updateProductByGettingFirst(productElkUpdateDTO, country);

        assertNotNull(response);
        verify(elasticsearchOperations).save(eq(elkProduct), any(IndexCoordinates.class));
    }

    @Test
    void testUpdateProductByGettingFirstWithNoEnrichedMetaData() {
        String country = "UAE";
        String productId = "123";
        ProductElkUpdateDTO productElkUpdateDTO = new ProductElkUpdateDTO();
        productElkUpdateDTO.setId(productId);
        productElkUpdateDTO.setEnrichedMetaAttributes(Map.of("onlineName", Map.of("en", "Motorola")));
        productElkUpdateDTO.setEnrichedClassAttributes(Map.of("3G_uae", Map.of("en", "NO")));
        ElkProduct elkProduct = createElkProduct();
        elkProduct.getEnrichedData().setMetaAttributes(null);
        elkProduct.getEnrichedData().setClassAttributes(null);
        when(indexFactory.getStagedProductIndexName(country)).thenReturn("product-index");
        when(elasticsearchOperations.get(eq(productId), eq(ElkProduct.class), any(IndexCoordinates.class)))
                .thenReturn(elkProduct);

        ProductUpdateResponseDTO response = elkService.updateProductByGettingFirst(productElkUpdateDTO, country);

        assertNotNull(response);
        verify(elasticsearchOperations).save(eq(elkProduct), any(IndexCoordinates.class));
    }

    private ElkProduct createElkProduct(){
        ElkProduct product = new ElkProduct();
        product.setProductId("123");
        product.setStatus("ENRICHED");
        EnrichedData ed = new EnrichedData();
        Map<String, Map<String, String>> classAttributes = new HashMap<>();

        Map<String, String> classAtr1 = new HashMap<>();
        classAtr1.put("en", "GSM");
        Map<String, String> classAtr2 = new HashMap<>();
        classAtr2.put("en", "YES");
        classAttributes.put("2G_standards_uae", classAtr1);
        classAttributes.put("3G_uae", classAtr2);

        Map<String, Map<String, String>> metaAttributes = new HashMap<>();
        Map<String, String> metaAtr1 = new HashMap<>();
        metaAtr1.put("en", "Motorola Edge");
        metaAttributes.put("onlineName", metaAtr1);

        ed.setMetaAttributes(metaAttributes);
        ed.setClassAttributes(classAttributes);
        product.setEnrichedData(ed);
        return product;
    }

    @Test
    void testUpdateProductByGettingFirst_ProductNotFound() {
        String country = "US";
        String productId = "123";
        ProductElkUpdateDTO productElkUpdateDTO = new ProductElkUpdateDTO();
        productElkUpdateDTO.setId(productId);

        when(indexFactory.getStagedProductIndexName(country)).thenReturn("product-index");
        when(elasticsearchOperations.get(eq(productId), eq(ElkProduct.class), any(IndexCoordinates.class)))
                .thenReturn(null);

        assertThrows(ApiException.class, () -> elkService.updateProductByGettingFirst(productElkUpdateDTO, country));
    }
}

