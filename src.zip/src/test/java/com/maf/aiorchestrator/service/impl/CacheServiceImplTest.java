package com.maf.aiorchestrator.service.impl;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.cache.CacheManager;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;

@ExtendWith(MockitoExtension.class)
class CacheServiceImplTest {

    @InjectMocks
    private CacheServiceImpl cacheService;

    @Mock
    private CacheManager cacheManager;

    @Test
    void testRefreshAllCache() {
        assertDoesNotThrow(() -> cacheService.refreshAllCache(null));
        assertDoesNotThrow(() -> cacheService.refreshAllCache(new ArrayList<>()));
        assertDoesNotThrow(() -> cacheService.refreshAllCache(List.of("test")));
        assertDoesNotThrow(() -> cacheService.refreshAllCache(List.of("test")));

    }

    @Test
    void testEvictCache(){
        assertDoesNotThrow(()->cacheService.evictCache());
    }

}