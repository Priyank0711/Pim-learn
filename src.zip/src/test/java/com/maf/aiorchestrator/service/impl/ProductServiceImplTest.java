package com.maf.aiorchestrator.service.impl;

import com.maf.aiorchestrator.config.client.ServiceConfiguration;
import com.maf.aiorchestrator.config.client.ServiceProperties;
import com.maf.aiorchestrator.dto.*;
import com.maf.aiorchestrator.dto.file.StandardHeaderDetail;
import com.maf.aiorchestrator.elastic.dto.DetailedProductResultDTO;
import com.maf.aiorchestrator.elastic.utils.MafFacetTerm;
import com.maf.aiorchestrator.entities.ElkProduct;
import com.maf.aiorchestrator.entities.FileHeaderMapping;
import com.maf.aiorchestrator.enums.Country;
import com.maf.aiorchestrator.enums.FileType;
import com.maf.aiorchestrator.enums.ProductStatus;
import com.maf.aiorchestrator.enums.ServiceName;
import com.maf.aiorchestrator.exception.ApiException;
import com.maf.aiorchestrator.repository.HeaderMappingRepository;
import com.maf.aiorchestrator.service.ElkService;
import com.maf.aiorchestrator.service.ImportsDataService;
import com.maf.aiorchestrator.utils.Constants;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Flux;

import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class ProductServiceImplTest {

    @InjectMocks
    @Spy
    private ProductServiceImpl productServiceImpl;

    @Mock
    private WebClient aiEngineWebClient;

    @Mock
    private WebClient.RequestBodyUriSpec requestBodyUriSpec;

    @Mock
    private WebClient.RequestBodySpec requestBodySpec;

    @SuppressWarnings("rawtypes")
    @Mock
    private WebClient.RequestHeadersSpec requestHeadersSpec;

    @Mock
    private WebClient.ResponseSpec responseSpec;

    @Mock
    private ElkService elkService;

    @Mock
    private ServiceConfiguration serviceConfiguration;

    @Mock
    private ImportsDataService importsDataService;

    @Mock
    private HeaderMappingRepository headerMappingRepository;


    @Test
    void enrichProductsInBatch_withValidProducts_shouldReturnEnrichedProducts() {
        List<String> tasks = List.of("task1");
        ProductAIDTO request = new ProductAIDTO();
        List<ProductAIDTO> productList = List.of(request);
        ProductAIDTO response = new ProductAIDTO();
        Flux<ProductAIDTO> responseFlux = Flux.just(response);

        String importId = "importId";
        ServiceProperties properties = new ServiceProperties();
        properties.setNoOfRetries(3);
        properties.setRetryDelay(1000L);
        when(serviceConfiguration.get(any())).thenReturn(properties);
        when(aiEngineWebClient.post()).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.uri(anyString())).thenReturn(requestBodySpec);
        when(requestBodySpec.bodyValue(any())).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
        when(responseSpec.bodyToFlux(eq(ProductAIDTO.class))).thenReturn(responseFlux);

        Flux<ElkProduct> result = productServiceImpl.enrichProductsInBatch(tasks, productList, importId);

        List<ElkProduct> elkProducts = result.collectList().block();
        assertNotNull(elkProducts);
        assertEquals(1, elkProducts.size());
        assertEquals(importId, elkProducts.getFirst().getImportId());
        assertNotNull(elkProducts.getFirst().getEnrichedData());
    }

    @Test
    void enrichProductsInBatch_withEmptyProductList_shouldReturnEmptyFlux() {
        List<String> tasks = List.of("task1");
        List<ProductAIDTO> productList = List.of();
        String importId = "importId";
        when(serviceConfiguration.get(ServiceName.AI_ENGINE)).thenReturn(new ServiceProperties());

        Flux<ElkProduct> result = productServiceImpl.enrichProductsInBatch(tasks, productList, importId);

        assertNotNull(result);
        assertEquals(0, Objects.requireNonNull(result.collectList().block()).size());
    }

    @Test
    void enrichProductsInBatch_withNullResponse_shouldFallbackToRequestProducts() {
        List<String> tasks = List.of("task1");
        ProductAIDTO productAIDTO = new ProductAIDTO();
        productAIDTO.setCategoryCode("code");
        productAIDTO.setCategoryName("name");
        List<ProductAIDTO> productList = List.of(productAIDTO);
        String importId = "importId";
        ServiceProperties properties = new ServiceProperties();
        properties.setNoOfRetries(1);
        properties.setRetryDelay(1000L);
        when(serviceConfiguration.get(any())).thenReturn(properties);
        when(aiEngineWebClient.post()).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.uri(anyString())).thenReturn(requestBodySpec);
        when(requestBodySpec.bodyValue(any())).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
        when(responseSpec.bodyToFlux(eq(ProductAIDTO.class))).thenReturn(Flux.error(new RuntimeException("Error")));

        Flux<ElkProduct> result = productServiceImpl.enrichProductsInBatch(tasks, productList, importId);

        List<ElkProduct> elkProducts = result.collectList().block();
        assertNotNull(elkProducts);
        assertEquals(1, elkProducts.size());
        assertEquals(importId, elkProducts.getFirst().getImportId());
        assertNull(elkProducts.getFirst().getEnrichedData());
        assertEquals("code-name", elkProducts.getFirst().getCategory());
    }

    @Test
    void enrichProductsAndSaveToELK_elkError() {
        List<String> tasks = List.of("task1");
        List<ProductAIDTO> productList = List.of(new ProductAIDTO());
        productList.getFirst().setStatus(ProductStatus.VALIDATION_FAILED);
        String importId = "importId";

        Mockito.doThrow(new RuntimeException()).when(elkService).bulkUpload(anyList());

        productServiceImpl.enrichProductsAndSaveToELK(tasks, productList, importId).subscribe();

        verify(elkService, times(1)).bulkUpload(anyList());
        verify(productServiceImpl, never()).enrichProductsInBatch(anyList(), anyList(), anyString());
    }

    @Test
    void enrichProductsAndSaveToELK_withInvalidProducts_shouldSaveToELK() {
        List<String> tasks = List.of("task1");
        List<ProductAIDTO> productList = List.of(new ProductAIDTO(), new ProductAIDTO());
        productList.getFirst().setStatus(ProductStatus.VALIDATION_FAILED);
        productList.getLast().setStatus(ProductStatus.VALIDATION_FAILED);
        String importId = "importId";

        Mockito.doNothing().when(elkService).bulkUpload(anyList());

        productServiceImpl.enrichProductsAndSaveToELK(tasks, productList, importId).subscribe();

        verify(elkService, times(1)).bulkUpload(anyList());
        verify(productServiceImpl, never()).enrichProductsInBatch(anyList(), anyList(), anyString());
    }

    @Test
    void enrichProductsAndSaveToELK_withValidProducts_shouldSaveToELK() {
        List<String> tasks = List.of("task1");
        List<ProductAIDTO> productList = List.of(new ProductAIDTO());
        String importId = "importId";

        Mockito.doNothing().when(elkService).bulkUpload(anyList());
        ServiceProperties properties = new ServiceProperties();
        properties.setNoOfRetries(0);
        properties.setRetryDelay(1000L);
        when(serviceConfiguration.get(any())).thenReturn(properties);
        when(aiEngineWebClient.post()).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.uri(anyString())).thenReturn(requestBodySpec);
        when(requestBodySpec.bodyValue(any())).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
        when(responseSpec.bodyToFlux(eq(ProductAIDTO.class))).thenReturn(Flux.just(new ProductAIDTO()));

        productServiceImpl.enrichProductsAndSaveToELK(tasks, productList, importId).subscribe();

        verify(elkService, times(1)).bulkUpload(anyList());
        verify(productServiceImpl, times(1)).enrichProductsInBatch(anyList(), anyList(), anyString());
    }

    @Test
    void getProductsByImportIdForExport_withValidImportId_shouldReturnProductList() {
        String importId = "importId";
        String country = "UAE";
        ElkProduct product = createElkProduct();
        List<ElkProduct> elkProducts = List.of(product);
        when(elkService.getProductsByImportId(importId, "APPROVED", country)).thenReturn(elkProducts);
        when(headerMappingRepository.findByFileType(FileType.PIM_PRODUCT)).thenReturn(Optional.of(createHeaderMapping()));

        List<Map<String, String>> result = productServiceImpl.getProductsByImportIdForExport(importId, country);

        assertNotNull(result);
    }

    @Test
    void getExportProductList_withValidScanImportId_shouldReturnProductList() {
        ElkProduct product = createElkProduct();
        product.setImportId(Constants.SCAN_IDENTIFIER+1);
        product.setCategory("");
        product.setCategoryCode("");
        product.setCategoryName("");
        List<ElkProduct> elkProducts = List.of(product);
        when(headerMappingRepository.findByFileType(FileType.PIM_PRODUCT)).thenReturn(Optional.of(createHeaderMapping()));

        List<Map<String, String>> result = productServiceImpl.getExportProductList(elkProducts);

        assertNotNull(result);
    }

    @Test
    void updateProductImportsStatus_withValidElasticIdList_shouldUpdateStatus() {
        UpdateStatusRequestDTO requestDTO = new UpdateStatusRequestDTO();
        requestDTO.setElasticIdList(List.of("elasticId"));
        requestDTO.setStatus(ProductStatus.APPROVED);
        String country = "UAE";

        UpdateProductStatusResponseDTO result = productServiceImpl.updateProductImportsStatus(requestDTO, country);

        assertEquals(Constants.PRODUCT_REVIEWED, result.getMessage());
    }

    @Test
    void updateProductImportsStatus_withValidImportId_shouldUpdateStatus() {
        UpdateStatusRequestDTO requestDTO = new UpdateStatusRequestDTO();
        requestDTO.setImportId("importId");
        requestDTO.setStatus(ProductStatus.APPROVED);
        String country = "UAE";
        MafFacetTerm facetTerm = new MafFacetTerm();
        facetTerm.setCount(1L);
        facetTerm.setKey("APPROVED");
        when(elkService.getProductsStatusCountForImport("importId", country)).thenReturn(List.of(facetTerm));

        UpdateProductStatusResponseDTO result = productServiceImpl.updateProductImportsStatus(requestDTO, country);

        assertEquals(String.format(Constants.IMPORT_REVIEWED, requestDTO.getStatus().name()), result.getMessage());
    }

    @Test
    void updateProductImportsStatus_withValidImportId_havingPendingProducts() {
        UpdateStatusRequestDTO requestDTO = new UpdateStatusRequestDTO();
        requestDTO.setImportId("importId");
        requestDTO.setStatus(ProductStatus.APPROVED);
        requestDTO.setElasticIdList(List.of());
        String country = "UAE";
        MafFacetTerm facetTerm = new MafFacetTerm();
        facetTerm.setCount(1L);
        facetTerm.setKey("PENDING");
        when(elkService.getProductsStatusCountForImport("importId", country)).thenReturn(List.of(facetTerm));

        UpdateProductStatusResponseDTO result = productServiceImpl.updateProductImportsStatus(requestDTO, country);

//        assertEquals(String.format(Constants.PRODUCT_NOT_REVIEWED,1), result.getMessage());
    }

    @Test
    void updateProductImportsStatus_badRequest() {
        UpdateStatusRequestDTO requestDTO = new UpdateStatusRequestDTO();
        requestDTO.setStatus(ProductStatus.APPROVED);
        requestDTO.setElasticIdList(List.of());
        String country = "UAE";
        MafFacetTerm facetTerm = new MafFacetTerm();
        facetTerm.setCount(1L);
        facetTerm.setKey("PENDING");
        assertThrows(ApiException.class, () ->productServiceImpl.updateProductImportsStatus(requestDTO, country));
    }

    @Test
    void getDetailedProductByElasticId_withValidElasticId_shouldReturnDetailedProduct() {
        String elasticId = "elasticId";
        String country = "UAE";
        ElkProduct elkProduct = createElkProduct();
        when(elkService.getProductByElasticId(elasticId, country)).thenReturn(elkProduct);

        DetailedProductResultDTO result = productServiceImpl.getDetailedProductByElasticId(elasticId, country);

        assertNotNull(result);
    }

    @Test
    void getDetailedProductByElasticId_withInvalidProduct_shouldReturnDetailedProduct() {
        String elasticId = "elasticId";
        String country = "UAE";
        ElkProduct elkProduct = createElkProduct();
        elkProduct.setMetaAttributes(null);
        elkProduct.setClassAttributes(null);
        elkProduct.setEnrichedData(null);
        elkProduct.setStatus(ProductStatus.VALIDATION_FAILED.name());
        when(elkService.getProductByElasticId(elasticId, country)).thenReturn(elkProduct);

        DetailedProductResultDTO result = productServiceImpl.getDetailedProductByElasticId(elasticId, country);

        assertNotNull(result);
    }

    @Test
    void getDetailedProductByElasticId_withoutEnrichedData_shouldReturnDetailedProduct() {
        String elasticId = "elasticId";
        String country = "UAE";
        ElkProduct elkProduct = createElkProduct();
        elkProduct.setEnrichedData(null);
        when(elkService.getProductByElasticId(elasticId, country)).thenReturn(elkProduct);

        DetailedProductResultDTO result = productServiceImpl.getDetailedProductByElasticId(elasticId, country);

        assertNotNull(result);
    }

    @Test
    void getDetailedProductByElasticId_withNullProduct_Error() {
        String elasticId = "elasticId";
        String country = "UAE";
        when(elkService.getProductByElasticId(elasticId, country)).thenReturn(null);

        assertThrows(ApiException.class, () -> productServiceImpl.getDetailedProductByElasticId(elasticId, country));
    }

    @Test
    void updateProduct_withValidProductElkUpdateDTO_shouldUpdateProduct() {
        ProductElkUpdateDTO productElkUpdateDTO = new ProductElkUpdateDTO();
        String country = "UAE";
        ProductUpdateResponseDTO responseDTO = new ProductUpdateResponseDTO();
        when(elkService.updateProductByGettingFirst(productElkUpdateDTO, country)).thenReturn(responseDTO);

        ProductUpdateResponseDTO result = productServiceImpl.updateProduct(productElkUpdateDTO, country);

        assertEquals("Product updated successfully", result.getMessage());
    }

    private ElkProduct createElkProduct(){
        ElkProduct product = new ElkProduct();
        product.setClassAttributes(Map.of("key", Map.of("en", "value"), "key2", Map.of("en", "")));
        product.setMetaAttributes(Map.of("keyC", Map.of("en", "value"), "keyC2", Map.of("en", "value")));
        EnrichedData enrichedData = new EnrichedData();
        enrichedData.setClassAttributes(Map.of("key", Map.of("en", "value", "ar", "قيمة"), "key3", Map.of("en", "value")));
        enrichedData.setMetaAttributes(Map.of("keyC", Map.of("en", "value", "ar", "قيمة"), "keyC3", Map.of("en", "value")));
        product.setEnrichedData(enrichedData);
        product.setCountry(Country.UAE);
        product.setImportId("importId");
        product.setStatus("APPROVED");
        product.setCategoryCode("code");
        product.setCategoryName("name");
        product.setCategory("code-name");
        product.setId("id");
        return product;
    }

    private FileHeaderMapping createHeaderMapping(){
        FileHeaderMapping headerMapping = new FileHeaderMapping();
        headerMapping.setFileType(FileType.PIM_PRODUCT);
        headerMapping.setAttributeMap(Map.of("key", new StandardHeaderDetail("key", false)));
        return headerMapping;
    }
}