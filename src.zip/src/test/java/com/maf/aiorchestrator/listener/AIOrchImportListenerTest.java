package com.maf.aiorchestrator.listener;

import com.maf.aiorchestrator.dto.jms.AIEnrichRequest;
import com.maf.aiorchestrator.dto.jms.NotificationMessage;
import com.maf.aiorchestrator.entities.ImportsData;
import com.maf.aiorchestrator.enums.Country;
import com.maf.aiorchestrator.enums.ImportStatus;
import com.maf.aiorchestrator.service.ProcessImportService;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
public class AIOrchImportListenerTest {

    @InjectMocks
    AIOrchImportListener aiOrchImportListener;

    @Mock
    private ProcessImportService processImportService;

    @Test
    void test_processMessage() {
        NotificationMessage message = new NotificationMessage();
        message.setTemplateType("PIM_PRODUCT");
        message.setCountry("UAE");
        message.setEnrichRequest(new AIEnrichRequest());
        ImportsData importsData = new ImportsData();
        importsData.setImportId("1234");
        importsData.setCountry(Country.UAE);
        importsData.setStatus(ImportStatus.PENDING);
        Mockito.when(processImportService.createAndSaveImportsData(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(importsData);
        aiOrchImportListener.processMessage(message);
        Assertions.assertNotNull(importsData);
    }

    @Test
    void test_processMessageException() {
        NotificationMessage message = new NotificationMessage();
        message.setTemplateType("PIM_PRODUCT");
        message.setCountry("UAE");
        message.setEnrichRequest(new AIEnrichRequest());
        ImportsData importsData = new ImportsData();
        importsData.setImportId("1234");
        importsData.setCountry(Country.UAE);
        importsData.setStatus(ImportStatus.PENDING);
        Mockito.when(processImportService.createAndSaveImportsData(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(importsData);
        aiOrchImportListener.processMessage(message);
    }

}
