package com.maf.aiorchestrator.factory;

import com.maf.aiorchestrator.properties.ElasticSearchIndexes;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Map;

@ExtendWith(MockitoExtension.class)
public class IndexFactoryTest {

    @InjectMocks
    IndexFactory indexFactory;

    @Mock
    ElasticSearchIndexes elasticSearchIndexes;

    @Test
    void test_getStagedProductIndexName() {
        String countryCode = "UAE";
        Map<String, String> idx = Map.of("UAE", "product-staged-uae");
        Mockito.when(elasticSearchIndexes.getStagedProductIndex()).thenReturn(idx);
        String indexName = indexFactory.getStagedProductIndexName(countryCode);
        Assertions.assertNotNull(indexName);
        Assertions.assertEquals("product-staged-uae", indexName);
    }

    @Test
    void test_getOnlineProductIndexName() {
        String countryCode = "UAE";
        Map<String, String> idx = Map.of("UAE", "product-online-uae");
        Mockito.when(elasticSearchIndexes.getOnlineProductIndex()).thenReturn(idx);
        String indexName = indexFactory.getOnlineProductIndexName(countryCode);
        Assertions.assertNotNull(indexName);
        Assertions.assertEquals("product-online-uae", indexName);
    }

}
