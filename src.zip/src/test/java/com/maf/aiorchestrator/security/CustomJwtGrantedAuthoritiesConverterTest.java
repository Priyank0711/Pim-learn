package com.maf.aiorchestrator.security;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.oauth2.jwt.Jwt;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(MockitoExtension.class)
class CustomJwtGrantedAuthoritiesConverterTest {

    @InjectMocks
    private CustomJwtGrantedAuthoritiesConverter customJwtGrantedAuthoritiesConverter;

    @Mock
    private Jwt jwt;

    @Test
    void test_convert(){
        Mockito.when(jwt.getClaim("permissions")).thenReturn("seller-standard");
        customJwtGrantedAuthoritiesConverter.setAuthoritiesClaimName("permissions");
        customJwtGrantedAuthoritiesConverter.setAuthorityPrefix("");
        customJwtGrantedAuthoritiesConverter.setRoleClaimName("https://marketplace.carrefour" + "/roles");
        Collection<GrantedAuthority> grantedAuthorities = customJwtGrantedAuthoritiesConverter.convert(jwt);
        GrantedAuthority grantedAuthority = grantedAuthorities.iterator().next();
        assertEquals("seller-standard", grantedAuthority.getAuthority());
    }

    @Test
    void test_convert_emptyClaims_permissions(){
        Mockito.when(jwt.getClaim("permissions")).thenReturn("");
        customJwtGrantedAuthoritiesConverter.setAuthoritiesClaimName("permissions");
        customJwtGrantedAuthoritiesConverter.setAuthorityPrefix("");
        customJwtGrantedAuthoritiesConverter.setRoleClaimName("https://marketplace.carrefour" + "/roles");
        assertTrue(customJwtGrantedAuthoritiesConverter.convert(jwt).isEmpty());
    }

    @Test
    void test_convert_emptyClaims(){
        final List<String> list = new ArrayList<>();
        list.add("seller-standard");
        customJwtGrantedAuthoritiesConverter.setAuthorityPrefix("");
        customJwtGrantedAuthoritiesConverter.setRoleClaimName("https://marketplace.carrefour" + "/roles");
        assertTrue(customJwtGrantedAuthoritiesConverter.convert(jwt).isEmpty());
        assertEquals("https://marketplace.carrefour/roles", customJwtGrantedAuthoritiesConverter.getRoleClaimName());
    }

    @Test
    void test_convert_emptyClaimNameAuth(){
        customJwtGrantedAuthoritiesConverter.setAuthorityPrefix("");
        customJwtGrantedAuthoritiesConverter.setRoleClaimName("https://marketplace.carrefour" + "/roles");
        assertTrue(customJwtGrantedAuthoritiesConverter.convert(jwt).isEmpty());
    }

    @Test
    void test_convert_emptyRoleClaimName(){
        customJwtGrantedAuthoritiesConverter.setAuthorityPrefix("");
        assertTrue(customJwtGrantedAuthoritiesConverter.convert(jwt).isEmpty());
    }

    @Test
    void test_convert_emptyClaimCollection(){
        final List<String> list = new ArrayList<>();
        list.add("seller-standard");
        Mockito.when(jwt.getClaim("permissions")).thenReturn(list);
        Mockito.when(jwt.getClaim("https://marketplace.carrefour/roles")).thenReturn("seller-standard");
        customJwtGrantedAuthoritiesConverter.setAuthoritiesClaimName("permissions");
        customJwtGrantedAuthoritiesConverter.setAuthorityPrefix("");
        customJwtGrantedAuthoritiesConverter.setRoleClaimName("https://marketplace.carrefour" + "/roles");
        Collection<GrantedAuthority> grantedAuthorities = customJwtGrantedAuthoritiesConverter.convert(jwt);
        GrantedAuthority grantedAuthority = grantedAuthorities.iterator().next();
        assertEquals("seller-standard", grantedAuthority.getAuthority());
    }

    @Test
    void test_convert_emptyClaimCollection_empty(){
        final List<String> list = new ArrayList<>();
        list.add("seller-standard");
        Mockito.when(jwt.getClaim("permissions")).thenReturn(list);
        Mockito.when(jwt.getClaim("https://marketplace.carrefour/roles")).thenReturn("");
        customJwtGrantedAuthoritiesConverter.setAuthoritiesClaimName("permissions");
        customJwtGrantedAuthoritiesConverter.setAuthorityPrefix("");
        customJwtGrantedAuthoritiesConverter.setRoleClaimName("https://marketplace.carrefour" + "/roles");
        Collection<GrantedAuthority> grantedAuthorities = customJwtGrantedAuthoritiesConverter.convert(jwt);
        GrantedAuthority grantedAuthority = grantedAuthorities.iterator().next();
        assertEquals("seller-standard", grantedAuthority.getAuthority());
    }

}
