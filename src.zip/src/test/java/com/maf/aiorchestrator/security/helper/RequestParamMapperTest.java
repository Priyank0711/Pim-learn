package com.maf.aiorchestrator.security.helper;

import com.maf.aiorchestrator.dto.JwtTokenParams;
import com.maf.aiorchestrator.enums.UserRole;
import com.maf.aiorchestrator.utils.Constants;
import net.minidev.json.JSONArray;
import org.json.JSONException;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;


@ExtendWith(MockitoExtension.class)
class RequestParamMapperTest {

    @InjectMocks
    RequestParamMapper requestParamMapper;

    @Mock
    private JwtTokenDetail jwtTokenDetail;

    @Test
    void getTokenParams_with_AdminRole() throws JSONException {
        Map<String,Object> requestClaims = getRequestClaims(Collections.singletonList(UserRole.ROLE_PIM_UAE.getRole()));
        Mockito.when(jwtTokenDetail.getClaims()).thenReturn(requestClaims);
        final JwtTokenParams paramsWithAdminRole = requestParamMapper.getTokenParams(new JwtTokenParams());
        assertEquals("UAE" , paramsWithAdminRole.getCountry().stream().findFirst().get().name());
        requestClaims = getRequestClaims(Collections.singletonList(UserRole.ROLE_PIM_UAE.getRole()));
        Mockito.when(jwtTokenDetail.getClaims()).thenReturn(requestClaims);
        final JwtTokenParams paramsWithKSAAdminRole = requestParamMapper.getTokenParams(new JwtTokenParams());
        assertEquals("UAE" , paramsWithKSAAdminRole.getCountry().stream().findFirst().get().name());
    }

    @Test
    void getTokenParams_without_AdminRole() throws JSONException {
        Map<String,Object> requestClaims = getRequestClaims(Collections.singletonList(UserRole.ROLE_PIM_UAE.getRole()));
        Mockito.when(jwtTokenDetail.getClaims()).thenReturn(requestClaims);
        final JwtTokenParams params = requestParamMapper.getTokenParams(new JwtTokenParams());
        assertEquals("UAE" , params.getCountry().stream().findFirst().get().name());

    }

    public static Map<String,Object> getRequestClaims(List<String> roles){
        JSONArray array =  new JSONArray();
        array.addAll(roles);

        Map<String,Object> requestClaims = new HashMap<>();
        requestClaims.put(Constants.JWT_CLAIM_ROLES_KEY, array);
        requestClaims.put(Constants.JWT_CLAIM_COUNTRY_KEY, "UAE");
        return requestClaims;
    }

}