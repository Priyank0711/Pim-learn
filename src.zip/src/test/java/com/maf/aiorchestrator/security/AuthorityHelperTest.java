package com.maf.aiorchestrator.security;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.when;

class AuthorityHelperTest {

    @Mock
    private Authentication authentication;

    @Mock
    private GrantedAuthority authority1;

    @Mock
    private GrantedAuthority authority2;

    private AuthorityHelper authorityHelper;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        authorityHelper = new AuthorityHelper();
    }

    @Test
    void testHasAuthorityContaining_withRoleAndCountry_shouldReturnTrue() {
        when(authority1.getAuthority()).thenReturn("ROLE_PIM_UAE");
        when(authority2.getAuthority()).thenReturn("ROLE_PIM_LBN");
        Mockito.doReturn(List.of(authority1, authority2)).when(authentication).getAuthorities();
        boolean result = authorityHelper.hasAuthorityContaining(authentication, "PIM", "UAE");
        assertTrue(result);
    }

    @Test
    void testHasAuthorityContaining_emptyAuthorities_shouldReturnFalse() {
        when(authentication.getAuthorities()).thenReturn(List.of());
        boolean result = authorityHelper.hasAuthorityContaining(authentication, "ROLE_ADMIN", "US");
        assertFalse(result);
    }

    @Test
    void testHasAuthorityContaining_withRoleOnly_shouldReturnFalse() {
        Mockito.doReturn(List.of(authority1, authority2)).when(authentication).getAuthorities();
        when(authority1.getAuthority()).thenReturn("ROLE_PIM_UAE");
        when(authority2.getAuthority()).thenReturn("ROLE_PIM_LBN");

        boolean result = authorityHelper.hasAuthorityContaining(authentication, "CORE", "US");
        assertFalse(result);
    }

}
