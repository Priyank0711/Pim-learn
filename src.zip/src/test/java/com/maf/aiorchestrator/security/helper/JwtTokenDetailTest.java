package com.maf.aiorchestrator.security.helper;

import com.maf.aiorchestrator.exception.InvalidToken;
import com.maf.aiorchestrator.exception.JwtClaimNotFound;
import com.maf.aiorchestrator.security.config.MafAzureJWTIssuer;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.Authentication;
import org.springframework.security.oauth2.jwt.Jwt;
import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

import java.lang.reflect.Field;
import java.util.*;

public class JwtTokenDetailTest {

    private JwtTokenDetail jwtTokenDetail;

    @Mock
    private MafAzureJWTIssuer mafAzureJWTIssuer;

    @Mock
    private Jwt jwt;

    @BeforeEach
    public void setUp() throws NoSuchFieldException, IllegalAccessException {
        MockitoAnnotations.openMocks(this);
        jwtTokenDetail = new JwtTokenDetail();
        Field field = JwtTokenDetail.class.getDeclaredField("mafAzureJWTIssuer"); // "myDependency" is the private field in MyService
        field.setAccessible(true);
        field.set(jwtTokenDetail, mafAzureJWTIssuer);
    }

    @Test
    public void testGetClaims_Success() {
        // Prepare mock claims
        Map<String, Object> claims = new HashMap<>();
        claims.put("issuer", "https://issuer.example.com");
        claims.put("iss", "https://issuer.example.com");
        claims.put("roles", new String[]{"ROLE_USER"});
        claims.put("email", "user@example.com");

        // Mock the SecurityContext
        Authentication authentication = mock(Authentication.class);
        when(authentication.getPrincipal()).thenReturn(jwt);
        SecurityContextHolder.getContext().setAuthentication(authentication);

        // Mock JWT behavior
        when(jwt.getClaims()).thenReturn(claims);
        when(mafAzureJWTIssuer.getIssuerUri()).thenReturn("https://issuer.example.com");
        when(mafAzureJWTIssuer.getRoleClaimName()).thenReturn("roles");

        // Call the method under test
        Map<String, Object> result = jwtTokenDetail.getClaims();

        // Assertions
        assertNotNull(result);
        assertEquals(2, result.size());
        assertTrue(result.containsKey("/roles"));
        assertTrue(result.containsKey("/email"));
        assertEquals(Collections.singletonList("ROLE_USER"), result.get("/roles"));
    }

    @Test
    public void testGetClaims_InvalidPrincipal() {
        // Mock the SecurityContext with a non-JWT principal
        Authentication authentication = mock(Authentication.class);
        when(authentication.getPrincipal()).thenReturn("Non-JwtPrincipal");
        SecurityContextHolder.getContext().setAuthentication(authentication);

        // Call the method under test and assert that it throws an exception
        InvalidToken exception = assertThrows(InvalidToken.class, () -> jwtTokenDetail.getClaims());
        assertEquals("Principal is not instance of JWT", exception.getMessage());
    }

    @Test
    public void testGetClaims_MissingClaim() {
        // Prepare mock claims with missing required claim
        Map<String, Object> claims = new HashMap<>();
        claims.put("roles", new String[]{"ROLE_USER"});

        // Mock the SecurityContext
        Authentication authentication = mock(Authentication.class);
        when(authentication.getPrincipal()).thenReturn(jwt);
        SecurityContextHolder.getContext().setAuthentication(authentication);

        // Mock JWT behavior
        when(jwt.getClaims()).thenReturn(claims);

        // Mock MafPingJWTIssuer
        when(mafAzureJWTIssuer.getIssuerUri()).thenReturn("https://issuer.example.com");
        when(mafAzureJWTIssuer.getRoleClaimName()).thenReturn("roles");

        // Call the method under test and assert that it throws an exception due to missing email claim
        JwtClaimNotFound exception = assertThrows(JwtClaimNotFound.class, () -> jwtTokenDetail.getClaims());
        assertTrue(exception.getMessage().contains(" claim iss  not found in JWT token "));
    }

    @Test
    public void testJwtClaimToRequestClaimMap_ValidRole() {
        // Prepare mock claims with roles
        Map<String, Object> claims = new HashMap<>();
        claims.put("issuer", "https://issuer.example.com");
        claims.put("iss", "https://issuer.example.com");
        claims.put("roles", new String[]{"ROLE_ADMIN", "ROLE_USER"});
        claims.put("email", "admin@example.com");

        // Mock the SecurityContext
        Authentication authentication = mock(Authentication.class);
        when(authentication.getPrincipal()).thenReturn(jwt);
        SecurityContextHolder.getContext().setAuthentication(authentication);

        // Mock JWT behavior
        when(jwt.getClaims()).thenReturn(claims);

        // Mock MafPingJWTIssuer
        when(mafAzureJWTIssuer.getIssuerUri()).thenReturn("https://issuer.example.com");
        when(mafAzureJWTIssuer.getRoleClaimName()).thenReturn("roles");

        // Call the method under test
        Map<String, Object> result = jwtTokenDetail.getClaims();

        // Assertions
        assertNotNull(result);
        assertTrue(result.containsKey("/email"));
        assertEquals(Arrays.asList("ROLE_ADMIN", "ROLE_USER"), result.get("/roles"));
    }

    @Test
    public void testJwtClaimToRequestClaimMap_SingleRole() {
        // Prepare mock claims with roles
        Map<String, Object> claims = new HashMap<>();
        claims.put("issuer", "https://issuer.example.com");
        claims.put("iss", "https://issuer.example.com");
        claims.put("roles", "ROLE_ADMIN");
        claims.put("email", "admin@example.com");

        Authentication authentication = mock(Authentication.class);
        when(authentication.getPrincipal()).thenReturn(jwt);
        SecurityContextHolder.getContext().setAuthentication(authentication);
        when(jwt.getClaims()).thenReturn(claims);
        when(mafAzureJWTIssuer.getIssuerUri()).thenReturn("https://issuer.example.com");
        when(mafAzureJWTIssuer.getRoleClaimName()).thenReturn("roles");

        Map<String, Object> result = jwtTokenDetail.getClaims();
        assertNotNull(result);
    }

    @Test
    public void testJwtClaimToRequestClaimMap_SingleRoleObj() {
        // Prepare mock claims with roles
        Map<String, Object> claims = new HashMap<>();
        claims.put("issuer", "https://issuer.example.com");
        claims.put("iss", "https://issuer.example.com");
        claims.put("roles", List.of("ROLE_ADMIN"));
        claims.put("email", "admin@example.com");

        Authentication authentication = mock(Authentication.class);
        when(authentication.getPrincipal()).thenReturn(jwt);
        SecurityContextHolder.getContext().setAuthentication(authentication);
        when(jwt.getClaims()).thenReturn(claims);
        when(mafAzureJWTIssuer.getIssuerUri()).thenReturn("https://issuer.example.com");
        when(mafAzureJWTIssuer.getRoleClaimName()).thenReturn("roles");

        Map<String, Object> result = jwtTokenDetail.getClaims();
        assertNotNull(result);
    }

    @Test
    public void testAddRolesAndEmailInRequestClaimMap_MissingRoles() {
        // Prepare mock claims without roles
        Map<String, Object> claims = new HashMap<>();
        claims.put("issuer", "https://issuer.example.com");
        claims.put("email", "admin@example.com");

        // Mock the SecurityContext
        Authentication authentication = mock(Authentication.class);
        when(authentication.getPrincipal()).thenReturn(jwt);
        SecurityContextHolder.getContext().setAuthentication(authentication);

        // Mock JWT behavior
        when(jwt.getClaims()).thenReturn(claims);

        // Mock MafPingJWTIssuer
        when(mafAzureJWTIssuer.getIssuerUri()).thenReturn("https://issuer.example.com");
        when(mafAzureJWTIssuer.getRoleClaimName()).thenReturn("roles");

        // Call the method under test and assert that exception is thrown
        JwtClaimNotFound exception = assertThrows(JwtClaimNotFound.class, () -> jwtTokenDetail.getClaims());
        assertTrue(exception.getMessage().contains(" claim iss  not found in JWT token "));
    }
}

