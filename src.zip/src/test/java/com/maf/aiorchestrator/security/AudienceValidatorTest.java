package com.maf.aiorchestrator.security;


import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.oauth2.core.OAuth2TokenValidatorResult;
import org.springframework.security.oauth2.jwt.Jwt;

import java.util.ArrayList;
import java.util.List;

@ExtendWith(MockitoExtension.class)
class AudienceValidatorTest {

    @Mock
    Jwt jwt;

    @Test
    void validate_audiences() {

        final AudienceValidator audienceValidator = new AudienceValidator("https://marketplace.carrefour");
        final List<String> audiences = new ArrayList<>();
        audiences.add("https://marketplace.carrefour");
        audiences.add("https://sit.maf-dev.auth0.com/userinfo");
        Mockito.when(jwt.getAudience()).thenReturn(audiences);
        Assertions.assertEquals(audienceValidator.validate(jwt), OAuth2TokenValidatorResult.success());


    }

    @Test
    void validate_invalid_audiences() {

        final AudienceValidator audienceValidator = new AudienceValidator("https://invalid");
        final List<String> audiences = new ArrayList<>();
        audiences.add("https://marketplace.carrefour");
        audiences.add("https://sit.maf-dev.auth0.com/userinfo");
        Mockito.when(jwt.getAudience()).thenReturn(audiences);
        Assertions.assertTrue(audienceValidator.validate(jwt).hasErrors());

    }
}
