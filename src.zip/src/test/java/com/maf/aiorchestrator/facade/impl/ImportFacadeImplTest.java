package com.maf.aiorchestrator.facade.impl;

import com.maf.aiorchestrator.dto.ImportWrapperDTO;
import com.maf.aiorchestrator.dto.PromptsAndRequiredAttributes;
import com.maf.aiorchestrator.entities.EnrichOption;
import com.maf.aiorchestrator.entities.ImportsData;
import com.maf.aiorchestrator.entities.CategoryFormat;
import com.maf.aiorchestrator.enums.EnrichOptionsEnum;
import com.maf.aiorchestrator.enums.ImportStatus;
import com.maf.aiorchestrator.enums.ImportType;
import com.maf.aiorchestrator.reader.ProductReader;
import com.maf.aiorchestrator.repository.EnrichOptionsRepository;
import com.maf.aiorchestrator.repository.CategoryFormatRepository;
import com.maf.aiorchestrator.service.ImportsDataService;
import com.maf.aiorchestrator.service.ProductService;
import com.maf.aiorchestrator.utils.ProductReaderFactory;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import reactor.core.publisher.Flux;

import java.util.*;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.*;

class ImportFacadeImplTest {

    @InjectMocks
    private ImportFacadeImpl importFacadeImpl;

    @Mock
    private EnrichOptionsRepository enrichOptionsRepository;

    @Mock
    private ProductReaderFactory productReaderFactory;

    @Mock
    private ProductService productService;

    @Mock
    private ImportsDataService importsDataService;

    @Mock
    private CategoryFormatRepository categoryFormatRepository;

    @Mock
    private ImportWrapperDTO importWrapperDTO;

    @Mock
    private ImportsData importsData;

    @Mock
    private ProductReader productReader;

    @Mock
    private EnrichOption enrichOption;

    @Mock
    private CategoryFormat categoryFormat;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        when(importWrapperDTO.getImportsData()).thenReturn(importsData);
        when(importsData.getType()).thenReturn(ImportType.FILE);
        when(importsData.getCategoryCode()).thenReturn("someCategory");
    }

    @Test
    void testProcessImport_withNoProductReader() {
        when(productReaderFactory.findStrategy(ImportType.FILE)).thenReturn(Optional.empty());
        importFacadeImpl.processImport(importWrapperDTO);

        verify(productService, never()).enrichProductsAndSaveToELK(any(), any(), any());
        verify(importsDataService).updateImportStatusInDb(ImportStatus.ENRICHED, importsData.getId());
    }

    @Test
    void testProcessImport_handlesError() {
        when(productReaderFactory.findStrategy(ImportType.FILE)).thenReturn(Optional.of(productReader));
        when(productReader.getProducts(Mockito.any(), Mockito.anyList())).thenReturn(Flux.error(new RuntimeException("Test error")));
        when(importsData.getId()).thenReturn("importId");

        importFacadeImpl.processImport(importWrapperDTO);

        verify(importsDataService).updateImportStatusInDb(ImportStatus.FAILED, null);
    }

    @Test
    void testGetPromptsAndRequiredAttributes() {
        when(importsData.getEnrichOptionsSelected()).thenReturn(List.of(EnrichOptionsEnum.ENRICH_ATTRIBUTE));
        when(enrichOptionsRepository.findByNameInOrUiEnabledFalse(anyList())).thenReturn(Collections.singletonList(enrichOption));
        when(enrichOption.getPrompt()).thenReturn(Collections.singletonList("Prompt"));
        when(enrichOption.getRequiredAttributes()).thenReturn(Arrays.asList("attr1", "attr2"));
        when(categoryFormatRepository.findByCode("someCategory")).thenReturn(categoryFormat);

        Map<String, String> enrichmentFields = new HashMap<>();
        enrichmentFields.put("OPTION1", "fieldValue");
        when(categoryFormat.getEnrichmentFields()).thenReturn(enrichmentFields);

        PromptsAndRequiredAttributes result = importFacadeImpl.getPromptsAndRequiredAttributes(importsData);

        assertNotNull(result);
        assertEquals(1, result.getPrompts().size());
        assertEquals(2, result.getRequiredAttributes().size());
    }

    @Test
    void testGetPromptsAndRequiredAttributesWithEnhancePrompt() {
        when(importsData.getEnrichOptionsSelected()).thenReturn(List.of(EnrichOptionsEnum.ENRICH_ATTRIBUTE));
        when(enrichOptionsRepository.findByNameInOrUiEnabledFalse(anyList())).thenReturn(Collections.singletonList(enrichOption));
        when(enrichOption.getPrompt()).thenReturn(Collections.singletonList("Prompt"));
        when(enrichOption.getRequiredAttributes()).thenReturn(Arrays.asList("attr1", "attr2"));
        when(enrichOption.isEnhancePrompt()).thenReturn(Boolean.TRUE);
        when(categoryFormatRepository.findByCode("someCategory")).thenReturn(categoryFormat);

        Map<String, String> enrichmentFields = new HashMap<>();
        enrichmentFields.put("OPTION1", "fieldValue");
        when(categoryFormat.getEnrichmentFields()).thenReturn(enrichmentFields);

        PromptsAndRequiredAttributes result = importFacadeImpl.getPromptsAndRequiredAttributes(importsData);
        assertNotNull(result);
        assertEquals(1, result.getPrompts().size());
        assertEquals(2, result.getRequiredAttributes().size());
    }

    @Test
    void testGetPromptsAndRequiredAttributesWithoutCategory() {

        when(importsData.getEnrichOptionsSelected()).thenReturn(List.of(EnrichOptionsEnum.ENRICH_ATTRIBUTE, EnrichOptionsEnum.TITLE_GENERATION));
        when(enrichOptionsRepository.findByNameInOrUiEnabledFalse(anyList())).thenReturn(getEnrichOptions());
        when(enrichOption.getPrompt()).thenReturn(Collections.singletonList("Prompt"));
        when(enrichOption.getRequiredAttributes()).thenReturn(Arrays.asList("attr1", "attr2"));
        when(categoryFormatRepository.findByCode("someCategory")).thenReturn(null);
        when(importsData.getCategoryCode()).thenReturn(null);
        PromptsAndRequiredAttributes result = importFacadeImpl.getPromptsAndRequiredAttributes(importsData);

        assertNotNull(result);
        assertEquals(1, result.getPrompts().size());
        assertEquals(2, result.getRequiredAttributes().size());
    }

    private List<EnrichOption> getEnrichOptions() {
        List<EnrichOption> enrichOptions = new ArrayList<>();
        EnrichOption enrichOption = new EnrichOption();
        enrichOption.setName(EnrichOptionsEnum.ENRICH_ATTRIBUTE);
        enrichOption.setPrompt(List.of("Prompt"));
        enrichOption.setRequiredAttributes(List.of("attr1", "attr2"));
        enrichOptions.add(enrichOption);

        EnrichOption enrichOption2 = new EnrichOption();
        enrichOption2.setName(EnrichOptionsEnum.TITLE_GENERATION);
        enrichOption2.setPrompt(List.of("Prompt"));
        enrichOption2.setRequiredAttributes(List.of("attr1", "attr2"));
        enrichOption2.setEnhancePrompt(true);
        enrichOptions.add(enrichOption2);
        return enrichOptions;
    }
}
