package com.maf.aiorchestrator.reader;

import com.maf.aiorchestrator.dto.ImportWrapperDTO;
import com.maf.aiorchestrator.dto.ProductAIDTO;
import com.maf.aiorchestrator.dto.file.FileData;
import com.maf.aiorchestrator.dto.file.HeaderData;
import com.maf.aiorchestrator.dto.pim.AttributeResponse;
import com.maf.aiorchestrator.entities.ImportsData;
import com.maf.aiorchestrator.enums.Country;
import com.maf.aiorchestrator.enums.EnrichOptionsEnum;
import com.maf.aiorchestrator.enums.ImportStatus;
import com.maf.aiorchestrator.enums.ImportType;
import com.maf.aiorchestrator.service.HeaderMappingService;
import com.maf.aiorchestrator.service.ImportsDataService;
import com.maf.aiorchestrator.service.PimService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import reactor.core.publisher.Flux;

import java.io.File;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import static com.maf.aiorchestrator.enums.FileType.PIM_PRODUCT;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class FileProductReaderTest {

    @Mock
    private HeaderMappingService headerMappingService;

    @Mock
    private ImportsDataService importsDataService;

    @Mock
    private PimService pimService;

    @InjectMocks
    private FileProductReader fileProductReader;

    @Test
    void testGetImportType() {
        assertEquals(ImportType.FILE, fileProductReader.getImportType());
    }

    @Test
    void testGetProductsSuccess() {
        // Arrange
        ImportWrapperDTO importWrapperDTO = createImportWrapperDTO();
        ImportsData importsData = createImportsData();
        List<String> requiredAttributes = List.of("ean", "onlineName");
        AttributeResponse attributeResponse = new AttributeResponse();
        attributeResponse.setCountry(Country.UAE.name());
        attributeResponse.setCategoryCode("1893");
        attributeResponse.setCategoryName("Smartphone");

        Map<String, HeaderData> headerMap = createHeaderMap();

        when(importsDataService.save(any())).thenReturn(importsData);
        when(pimService.getClassificationAttributes(any(), anyString())).thenReturn(attributeResponse);
        when(headerMappingService.createLocalizedAttributeMap(anyList(), any())).thenReturn(headerMap);
        doNothing().when(headerMappingService).populateAndReflectPimClassAttributeHeader(any(), any());
        Flux<ProductAIDTO> result = fileProductReader.getProducts(importWrapperDTO, requiredAttributes);
        assertEquals(2, Objects.requireNonNull(result.collectList().block()).size());
    }

    @Test
    void testGetProductsSuccess_withNoHeaderMap() {
        // Arrange
        ImportWrapperDTO importWrapperDTO = createImportWrapperDTO();
        ImportsData importsData = createImportsData();
        List<String> requiredAttributes = List.of("ean", "onlineName");
        AttributeResponse attributeResponse = new AttributeResponse();
        attributeResponse.setCountry(Country.UAE.name());
        attributeResponse.setCategoryCode("1893");
        attributeResponse.setCategoryName("Smartphone");

        Map<String, HeaderData> headerMap = new HashMap<>();

        when(importsDataService.save(any())).thenReturn(importsData);
        when(pimService.getClassificationAttributes(any(), anyString())).thenReturn(attributeResponse);
        when(headerMappingService.createLocalizedAttributeMap(anyList(), any())).thenReturn(headerMap);
        doNothing().when(headerMappingService).populateAndReflectPimClassAttributeHeader(any(), any());
        Flux<ProductAIDTO> result = fileProductReader.getProducts(importWrapperDTO, requiredAttributes);
        assertEquals(2, Objects.requireNonNull(result.collectList().block()).size());
    }

    @Test
    void testGetProductsErrorHandling() {
        ImportWrapperDTO importWrapperDTO = createImportWrapperDTO();
        List<String> requiredAttributes = List.of("ean", "onlineName");
        AttributeResponse attributeResponse = new AttributeResponse();
        attributeResponse.setCountry(Country.UAE.name());
        attributeResponse.setCategoryCode("1893");
        attributeResponse.setCategoryName("Smartphone");

        doThrow(new RuntimeException("Test Exception")).when(importsDataService).save(any());

        when(pimService.getClassificationAttributes(Mockito.any(), anyString())).thenReturn(attributeResponse);
        Flux<ProductAIDTO> result = fileProductReader.getProducts(importWrapperDTO, requiredAttributes);
        assertNotNull(result);
        verify(pimService, times(1)).getClassificationAttributes(any(),any());
    }

    private ImportWrapperDTO createImportWrapperDTO(){
        ImportWrapperDTO importWrapperDTO = new ImportWrapperDTO();
        File file = new File("src/test/resources/data/carrefour-1734607936523-UAE-CLASSIFICATION.csv");
        importWrapperDTO.setFile(file);
        importWrapperDTO.setImportsData(createImportsData());
        return importWrapperDTO;
    }

    private ImportsData createImportsData(){
        ImportsData importsData = new ImportsData();
        importsData.setId("67767ac2d93c8856033f5c17");
        importsData.setImportId("1234");
        importsData.setCountry(Country.UAE);
        importsData.setStatus(ImportStatus.PROCESSING);
        importsData.setType(ImportType.FILE);
        importsData.setCategoryCode("1893");
        importsData.setEnrichOptionsSelected(List.of(EnrichOptionsEnum.ENRICH_ATTRIBUTE));
        FileData fileData = new FileData();
        fileData.setFileType(PIM_PRODUCT);
        fileData.setName("carrefour-carrefour_378-UAE-transformed.csv");
        fileData.setLocation("src/test/resources/data/carrefour-1734607936523-UAE-CLASSIFICATION.csv");
        importsData.setFileData(fileData);
        return importsData;
    }

    private Map<String, HeaderData> createHeaderMap(){
        Map<String, HeaderData> headerMap = new HashMap<>();
        HeaderData hd1 = new HeaderData();
        hd1.setKey("Processor_model_uae[en]");
        hd1.setLang("en");
        hd1.setClassificationAttribute(true);
        headerMap.put("Processor_model_uae[en]", hd1);
        HeaderData hd2 = new HeaderData();
        hd2.setKey("productColor");
        hd2.setLang("en");
        hd2.setClassificationAttribute(false);
        headerMap.put("productColor[en]", hd2);
        HeaderData hd3 = new HeaderData();
        hd3.setKey("productSize");
        hd3.setLang("en");
        hd3.setClassificationAttribute(false);
        headerMap.put("productSize", hd3);
        HeaderData hd4 = new HeaderData();
        hd4.setKey("3G_uae");
        hd4.setLang("en");
        hd4.setClassificationAttribute(true);
        headerMap.put("3G_uae[en]", hd4);
        HeaderData hd5 = new HeaderData();
        hd5.setKey("onlineName");
        hd5.setLang("en");
        hd5.setClassificationAttribute(false);
        headerMap.put("onlineName[en]", hd5);
        HeaderData hd6 = new HeaderData();
        hd6.setKey("ean");
        hd6.setLang("en");
        hd6.setClassificationAttribute(false);
        headerMap.put("ean", hd6);
        return headerMap;
    }

}