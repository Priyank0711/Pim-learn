package com.maf.aiorchestrator.reader;

import com.maf.aiorchestrator.data.ClassificationData;
import com.maf.aiorchestrator.data.FeatureData;
import com.maf.aiorchestrator.data.FeatureValueData;
import com.maf.aiorchestrator.dto.ImportWrapperDTO;
import com.maf.aiorchestrator.dto.ProductAIDTO;
import com.maf.aiorchestrator.dto.pim.AttributeDetailsDTO;
import com.maf.aiorchestrator.dto.pim.AttributeGroupDTO;
import com.maf.aiorchestrator.dto.pim.AttributeResponse;
import com.maf.aiorchestrator.elastic.request.OnlineProductsScanRequest;
import com.maf.aiorchestrator.elastic.response.MafSearchResultData;
import com.maf.aiorchestrator.elastic.service.ElasticSearchService;
import com.maf.aiorchestrator.elastic.utils.MafPageable;
import com.maf.aiorchestrator.entities.ImportsData;
import com.maf.aiorchestrator.entities.OnlineProduct;
import com.maf.aiorchestrator.enums.Country;
import com.maf.aiorchestrator.enums.EnrichOptionsEnum;
import com.maf.aiorchestrator.enums.ImportType;
import com.maf.aiorchestrator.enums.ProductStatus;
import com.maf.aiorchestrator.service.HeaderMappingService;
import com.maf.aiorchestrator.service.PimService;
import com.maf.aiorchestrator.utils.Constants;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import reactor.core.publisher.Flux;

import java.util.List;
import java.util.Objects;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class ScanningProductReaderTest {

    @Mock
    private ElasticSearchService elasticSearchService;

    @Mock
    private PimService pimService;

    @Mock
    private HeaderMappingService headerMappingService;

    @InjectMocks
    private ScanningProductReader scanningProductReader;

    @Test
    void getImportType_shouldReturnScanning() {
        assertEquals(ImportType.SCANNING, scanningProductReader.getImportType());
    }

    @Test
    void getProducts_withValidInputs_shouldReturnFluxOfProductAIDTO() {
        ImportsData importsData = createMockImportsData();
        OnlineProductsScanRequest scanRequest = createMockScanRequest();
        OnlineProduct onlineProduct = createMockOnlineProduct();
        ImportWrapperDTO importWrapperDTO = new ImportWrapperDTO();
        importWrapperDTO.setImportsData(importsData);
        importWrapperDTO.setScanRequest(scanRequest);
        List<String> requiredAttributes = List.of("onlineName");
        MafSearchResultData<OnlineProduct> productPage = new MafSearchResultData<>();
        productPage.setPageData(new MafPageable());
        productPage.setData(List.of(onlineProduct));
        when(elasticSearchService.getOnlineProductScanPage(any(), anyString())).thenReturn(productPage);
        when(pimService.getClassificationAttributes(any(), anyString())).thenReturn(createMockAttributeResponse());
        when(headerMappingService.getNonLocalizedPimAttributeKeys(any())).thenReturn(Set.of("onlineName"));

        Flux<ProductAIDTO> result = scanningProductReader.getProducts(importWrapperDTO, requiredAttributes);

        assertNotNull(result);
        assertEquals(1, Objects.requireNonNull(result.collectList().block()).size());
        assertEquals(ProductStatus.PENDING, Objects.requireNonNull(result.collectList().block()).getFirst().getStatus());
    }

    @Test
    void getProducts_withValidAndInvalidProduct_shouldReturnFluxOfProductAIDTO() {
        ImportsData importsData = createMockImportsData();
        OnlineProductsScanRequest scanRequest = createMockScanRequest();

        OnlineProduct onlineProduct = createMockOnlineProduct();
        onlineProduct.setEan(null);
        OnlineProduct onlineProduct2 = createMockOnlineProduct();
        onlineProduct2.setClassifications(null);

        ImportWrapperDTO importWrapperDTO = new ImportWrapperDTO();
        importWrapperDTO.setImportsData(importsData);
        importWrapperDTO.setScanRequest(scanRequest);
        List<String> requiredAttributes = List.of("ean", "onlineName");
        MafSearchResultData<OnlineProduct> productPage = new MafSearchResultData<>();
        productPage.setPageData(new MafPageable());
        productPage.setData(List.of(onlineProduct, onlineProduct2));
        when(elasticSearchService.getOnlineProductScanPage(any(), anyString())).thenReturn(productPage);
        when(pimService.getClassificationAttributes(any(), anyString())).thenReturn(createMockAttributeResponse());
        when(headerMappingService.getNonLocalizedPimAttributeKeys(any())).thenReturn(Set.of("ean", "onlineName", "metaKey"));

        Flux<ProductAIDTO> result = scanningProductReader.getProducts(importWrapperDTO, requiredAttributes);

        assertNotNull(result);
        assertEquals(2, Objects.requireNonNull(result.collectList().block()).size());
        assertEquals(ProductStatus.VALIDATION_FAILED, Objects.requireNonNull(result.collectList().block()).getFirst().getStatus());
        assertEquals(ProductStatus.PENDING, Objects.requireNonNull(result.collectList().block()).getLast().getStatus());

    }

    @Test
    void getProducts_withInValidProduct_shouldReturnFluxOfInvalidProductAIDTO() {
        ImportsData importsData = createMockImportsData();
        importsData.setCategoryCode(null);
        importsData.setCategoryName(null);
        OnlineProductsScanRequest scanRequest = createMockScanRequest();
        OnlineProduct onlineProduct = createMockOnlineProduct();
        onlineProduct.setEan(null);
        onlineProduct.setOnlineName(null);
        ImportWrapperDTO importWrapperDTO = new ImportWrapperDTO();
        importWrapperDTO.setImportsData(importsData);
        importWrapperDTO.setScanRequest(scanRequest);
        List<String> requiredAttributes = List.of("ean", "onlineName");
        MafSearchResultData<OnlineProduct> productPage = new MafSearchResultData<>();
        productPage.setPageData(new MafPageable());
        productPage.setData(List.of(onlineProduct));
        when(elasticSearchService.getOnlineProductScanPage(any(), anyString())).thenReturn(productPage);
        when(pimService.getClassificationAttributes(any(), anyString())).thenReturn(createMockAttributeResponse());
        when(headerMappingService.getNonLocalizedPimAttributeKeys(any())).thenReturn(Set.of("ean"));

        Flux<ProductAIDTO> result = scanningProductReader.getProducts(importWrapperDTO, requiredAttributes);

        assertNotNull(result);
        assertEquals(1, Objects.requireNonNull(result.collectList().block()).size());
        assertEquals(ProductStatus.VALIDATION_FAILED, Objects.requireNonNull(result.collectList().block()).getFirst().getStatus());
    }

    @Test
    void getProducts_withScanningException_shouldReturnErrorFlux() {
        ImportsData importsData = createMockImportsData();
        OnlineProductsScanRequest scanRequest = createMockScanRequest();
        OnlineProduct onlineProduct = createMockOnlineProduct();
        ImportWrapperDTO importWrapperDTO = new ImportWrapperDTO();
        importWrapperDTO.setImportsData(importsData);
        importWrapperDTO.setScanRequest(scanRequest);
        List<String> requiredAttributes = List.of("ean", "onlineName");
        MafSearchResultData<OnlineProduct> productPage = new MafSearchResultData<>();
        productPage.setPageData(new MafPageable());
        productPage.setData(List.of(onlineProduct));
        when(elasticSearchService.getOnlineProductScanPage(any(), anyString())).thenThrow(new RuntimeException("Error"));

        Flux<ProductAIDTO> result = scanningProductReader.getProducts(importWrapperDTO, requiredAttributes);

        assertNotNull(result);
        assertEquals("Error", assertThrows(RuntimeException.class, result::blockFirst).getMessage());
    }

    private OnlineProduct createMockOnlineProduct() {
        ClassificationData classificationData = new ClassificationData();
        FeatureValueData featureValueData = new FeatureValueData();
        featureValueData.setValue("value");
        FeatureData featureData = new FeatureData();
        featureData.setFeatureValues(List.of(featureValueData));
        classificationData.setFeatures(List.of(featureData));
        OnlineProduct onlineProduct = new OnlineProduct();
        onlineProduct.setEan("1234567890123");
        onlineProduct.setCode("code");
        onlineProduct.setOnlineName("name");
        onlineProduct.setClassifications(List.of(classificationData));
        return onlineProduct;
    }

    private OnlineProductsScanRequest createMockScanRequest() {
        OnlineProductsScanRequest scanRequest = new OnlineProductsScanRequest();
        scanRequest.setPageData(new MafPageable());
        return scanRequest;
    }

    private ImportsData createMockImportsData() {
        ImportsData importsData = new ImportsData();
        importsData.setCountry(Country.UAE);
        importsData.setShopId(Constants.SCAN_IDENTIFIER);
        importsData.setCategoryName("name");
        importsData.setCategoryCode("code");
        importsData.setEnrichOptionsSelected(List.of(EnrichOptionsEnum.TITLE_GENERATION));
        return importsData;
    }

    private AttributeResponse createMockAttributeResponse() {
        AttributeResponse attributeResponse = new AttributeResponse();
        AttributeGroupDTO attributeGroupDTO = new AttributeGroupDTO();
        AttributeDetailsDTO attributeDetailsDTO = new AttributeDetailsDTO();
        attributeDetailsDTO.setCode("test");
        attributeGroupDTO.setAttributeDetails(List.of(attributeDetailsDTO));
        attributeResponse.setAttributeGroups(List.of(attributeGroupDTO));
        return attributeResponse;
    }

}