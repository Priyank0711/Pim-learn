package com.maf.pim.constants;


public class Constants {
    public Constants(){
        throw new IllegalStateException("Utility class.");
    }
    public static final String FILE_PATTERN = "^\\d+_(main|\\d+)\\.(jpg|jpeg|png|gif)$";
    public static final long MAX_FILE_SIZE_KB = 204800;
    public static final String TEMP_FILENAME_PATTERN = "(\\d+)_([a-zA-Z0-9]+)\\.(jpg|jpeg|png|gif)";
    public static final String HOST_KEY = "StrictHostKeyChecking";
    public static final String SFTP_CONFIG = "no";
    public static final String ARCHIVE_PATH = "archive/";
    public static final String ERROR_PATH = "error/";
    public static final String INPUT_PATH = "input/";
    public static final String OFF_HOURS_INPUT_PATH = "offhoursinput/";
    public static final String MAIN_FILE = "main";
    public static final String GICA_FILE_PATTERN = "input_(.+?)#";
    public static final String CSV_EXTENSION = ".CSV";
    public static final String SUCCESS = "_SUCCESS";
    public static final String ERROR = "_ERROR";
    public static final String KILO = "Kilo";
    public static final String PIM = "pim";

    public static final double KILO_UNIT_IN_GRAMS = 1000.0;

    public static final String PIECE = "piece";
    public static final String EXPRESS = "express";
    public static final String BULK = "bulk";
    public static final String LBN_EXPORT_JOB_CODE = "maflbn-export-products";
    public static final String JOR_EXPORT_SUPPLIER_PRODUCT_JOB_CODE = "mafjor-exportSupplierProducts";
    public static final String KEN_EXPORT_JOB_CODE = "mafken-export-products";
    public static final String PAK_EXPORT_JOB_CODE = "mafpak-export-products";
    public static final String JOR_EXPORT_JOB_CODE = "mafjor-export-products";
    public static final String KWT_EXPORT_JOB_CODE = "mafkwt-export-products";

    public static final String KWT_EXPORT_SUPPLIER_PRODUCT_JOB_CODE = "mafkwt-exportSupplierProducts";
    public static final String BHR_EXPORT_JOB_CODE = "mafbhr-export-products";

    public static final String BHR_EXPORT_SUPPLIER_PRODUCT_JOB_CODE = "mafbhr-exportSupplierProducts";
    public static final String SAU_EXPORT_JOB_CODE = "mafsau-export-products";

    public static final String SAU_MKP_EXPORT_JOB_CODE = "mafsau-mkp-export-products";

    public static final String UAE_EXPORT_JOB_CODE = "mafuae-export-products";

    public static final String UAE_MKP_EXPORT_JOB_CODE = "mafuae-mkp-export-products";

    public static final String UAE_EXPORT_SUPPLIER_PRODUCT_JOB_CODE = "mafuae-exportSupplierProducts";
    public static final String QAT_EXPORT_JOB_CODE = "mafqat-export-products";

    public static final String QAT_EXPORT_SUPPLIER_PRODUCT_JOB_CODE = "mafqat-exportSupplierProducts";

    public static final String EGY_EXPORT_JOB_CODE = "mafegy-export-products";

    public static final String EGY_MKP_EXPORT_JOB_CODE = "mafegy-mkp-export-products";

    public static final String OMN_EXPORT_JOB_CODE = "mafomn-export-products";

    public static final String OMN_EXPORT_SUPPLIER_PRODUCT_JOB_CODE = "mafomn-exportSupplierProducts";

    public static final String OMN_SANITY_EXPORT_JOB_CODE = "mafomn-sanity-export-products";


    public static final String UAE_EXPORT_VARIANT_JOB_CODE = "mafuae-export-variants";



    public static final String PRODUCT_ID = "productId";

    public static final String VERSION = "version";
    public static final String FORMAT = "format";
    public static final String FULL_NAME = "fullName";
    public static final String REMOTE_PATH_PATTERN = "https://[^/]+/(.+)$";
    public static final String LOCALIZED_ATTR_REGEX = "\\s*([\\S\\s]*[^\\s])\\s*\\[\\s*(\\S+)\\s*]\\s*\\[\\s*(\\S+)\\s*]|\\s*([\\S\\s]*[^\\s])\\s*\\[\\s*(\\S+)\\s*]";
    public static final String MEDIA_NAME_REGEX = "[^a-zA-Z0-9._]";
    public static final String SUPER_CATEGORY_CACHE = "superCategories";
    public static final String CATEGORY_CLASSIFICATION_CACHE = "classificationByCategory";
    public static final String CATEGORY_CLASSIFICATION_WITH_PARENT_CACHE = "classificationWithParentByCategory";
    public static final String CLASSIFICATION_ATTRIBUTE_ASSIGNMENT_CACHE = "attributeAssignmentByClassification";

    public static final String GICA_REFERENCE_CACHE = "gicaReferenceCache";
    public static final String CATEGORY_CACHE = "categoryCache";

    public static final String PIM_PRODUCT_TEMPLATE = "PIM_PRODUCT";
    public static final String MKP_PRODUCT_TEMPLATE = "PRODUCT";
    public static final String PIM_CATALOG_TEMPLATE = "PIM_CATALOG";

    public static final String INTEGER = "Integer";
    public static final String INSTANT = "Instant";
    public static final String BOOLEAN = "Boolean";
    public static final String DOUBLE = "Double";
    public static final String STRING = "String";
    public static final String PRODUCT_TYPE = "ProductType";
    public static final String DELETE = "DELETE";
    public static final String CATEGORY_TYPE = "CategoryType";
    public static final String SERVICE_PROPOSITION = "ServiceProposition";
    public static final String FEATURE_TYPE = "FeatureType";


    public static final String ROLE_KEY = "role";
    public static final String EMAIL_ID_KEY = "emailId";

    public static class Attribute {
        public static final String[] ATTRIBUTESMEDIA = {"MAIN_IMAGE_URL", "IMAGE_2_URL", "IMAGE_3_URL", "IMAGE_4_URL", "IMAGE_5_URL"};
        private Attribute() {
        }
    }
}
