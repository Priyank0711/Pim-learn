package com.maf.pim.constants;

import com.maf.pim.enums.Language;

public class AttributesRecordFieldsConstants {

    private AttributesRecordFieldsConstants() {
        throw new IllegalStateException("Utility class");
    }

    private static final String EN_LANG_SUFFIX = " [" + Language.EN.getCode().toLowerCase() + "]";
    public static final String CATEGORY_CODE = "CATEGORY_CODE";
    public static final String PARENT_CLASSIFICATION_CODE = "PARENT_CLASSIFICATION_CODE";
    public static final String CLASSIFICATION_CODE = "CLASSIFICATION_CODE";
    public static final String CLASSIFICATION = "CLASSIFICATION";
    public static final String ATTRIBUTE = "ATTRIBUTE";
    public static final String ATTRIBUTE_EN = ATTRIBUTE+EN_LANG_SUFFIX;
    public static final String CLASSIFICATION_EN = CLASSIFICATION+EN_LANG_SUFFIX;
    public static final String FEATURE_TYPE = "FEATURE_TYPE";
    public static final String DISPLAY_ORDER = "DISPLAY_ORDER";}
