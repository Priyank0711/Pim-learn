package com.maf.pim.easyjob;

import com.maf.pim.easyjob.fileprocessor.EasyBatchProcessor;
import com.maf.pim.easyjob.record.BasicRecord;
import com.maf.pim.enums.Country;
import com.maf.pim.enums.FileResultTpe;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.FilenameUtils;
import org.jeasy.batch.core.filter.HeaderRecordFilter;
import org.jeasy.batch.core.job.*;
import org.jeasy.batch.core.marshaller.RecordMarshaller;
import org.jeasy.batch.core.reader.BlockingQueueRecordReader;
import org.jeasy.batch.core.reader.IterableRecordReader;
import org.jeasy.batch.core.record.Record;
import org.jeasy.batch.core.writer.BlockingQueueRecordWriter;
import org.jeasy.batch.core.writer.CollectionRecordWriter;
import org.jeasy.batch.core.writer.FileRecordWriter;
import org.jeasy.batch.flatfile.FlatFileRecordReader;
import org.springframework.stereotype.Component;

import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.Future;
import java.util.concurrent.LinkedBlockingQueue;

@Component
@Slf4j
public class BatchJob {

    private static final long QUEUE_TIMEOUT = 1000;

    private static final int THREAD_POOL_SIZE = 10;

    protected static final int BATCH_SIZE = 100;

    public BatchJobResult processFile(Path path, EasyBatchProcessor easyBatchFileProcessor, Country country) {
        BatchJobResult result = null;
        Collection<BasicRecord> syncCollection = Collections.synchronizedCollection(new ArrayList<>());
        BlockingQueue<Record<BasicRecord>> workQueue = new LinkedBlockingQueue<>();
        // Build jobs
        List<Job> jobs = new ArrayList<>();
        try (JobExecutor jobExecutor = new JobExecutor(THREAD_POOL_SIZE)) {

            //creating Master and worker jobs to read the file and process Blocking Queue
            jobs.add(buildMasterJob(path, workQueue, easyBatchFileProcessor, country));
            jobs.addAll(buildWorkerJobs(workQueue, easyBatchFileProcessor, syncCollection));

            //merging job reports
            List<Future<JobReport>> partialReports = jobExecutor.submitAll(jobs);
            JobReportMerger reportMerger = new DefaultJobReportMerger();
            JobReport finalReport = null;
            for (Future<JobReport> report : partialReports) {
                if( finalReport != null) {
                    finalReport = reportMerger.mergerReports(finalReport, report.get());
                } else {
                    finalReport = report.get();
                }
            }
            log.info("Job report for reading the input file and creating blocking queue... " +path +" Final report..." +finalReport.toString());

            //creating success and error files method
            result = createResult(jobExecutor, path, easyBatchFileProcessor, syncCollection);

        } catch (InterruptedException e) {
            // Re-interrupt the thread and log the interruption
            Thread.currentThread().interrupt();
            log.error("Thread interrupted during job execution.", e);
            if(result == null) {
                result = new BatchJobResult(path,  FileResultTpe.FAILED);
            }
        } catch (Exception e) {
            if(result == null) {
                result = new BatchJobResult(path,  FileResultTpe.FAILED);
            }
            log.error("Exception in easy batch processing of file: " + path + "Exception Message.." + e.getMessage(), e);
        }
        return result;
    }

    protected Job buildMasterJob(Path filePath, BlockingQueue<Record<BasicRecord>> workQueue, EasyBatchProcessor processor, Country country) {
        return new JobBuilder<String, BasicRecord>()
                .named("master-job")
                .reader(new FlatFileRecordReader(filePath))
                .mapper(processor.getMapper())
                .filter(new HeaderRecordFilter<>())
                .processor(record -> {
                    BasicRecord payload = (BasicRecord) record.getPayload();
                    payload.setCountry(country);
                    return record;
                })
                .writer(new BlockingQueueRecordWriter<>(workQueue))
                .build();
    }

    private List<Job> buildWorkerJobs(BlockingQueue<Record<BasicRecord>> workQueue,
                                      EasyBatchProcessor processor, Collection<BasicRecord> output) {
        List<Job> workerJobs = new ArrayList<>();
        for (int i = 0; i < processor.getNumberOfWorkers() ; i++) {
            workerJobs.add(new JobBuilder<BasicRecord, String>()
                    .named("worker-job" + i)
                    .reader(new BlockingQueueRecordReader<>(workQueue, QUEUE_TIMEOUT))
                    .validator(processor.getValidator())
                    .processor(processor.getRecordProcessor())
                    .writer(new CollectionRecordWriter(output))
                    .batchSize(BATCH_SIZE)
                    .build());
        }
        return workerJobs;
    }


    protected Job buildJResultJob(Path filePath, String jobName, EasyBatchProcessor processor, Collection<BasicRecord> collection) {
        FileRecordWriter recordWriter = new FileRecordWriter(filePath);
        RecordMarshaller marshaller;
        FileRecordWriter.HeaderCallback headerCallback;
        if(jobName.equals("failure-writer")) {
            marshaller = processor.getErrorResultMarshaller();
            headerCallback = processor.getErrorHeaderWriter();
            recordWriter.setHeaderCallback(headerCallback);
        } else {
            marshaller = processor.getMarshaller();
            headerCallback = processor.getHeaderWriter();
            recordWriter.setHeaderCallback(headerCallback);
        }
        return new JobBuilder()
                .reader(new IterableRecordReader(collection))
                .named(jobName)
                .mapper(processor.getResultMapper())
                .marshaller(marshaller)
                .writer(recordWriter)
                .batchSize(BATCH_SIZE)
                .build();
    }

    protected BatchJobResult createResult(JobExecutor jobExecutor, Path filePath, EasyBatchProcessor processor, Collection<BasicRecord> syncCollection) {

        List<BasicRecord> successCollection = new ArrayList<>();
        List<BasicRecord> errorCollection = new ArrayList<>();
        for(BasicRecord record : syncCollection){
            if(record.isProcessed()){
                successCollection.add(record);
            } else {
                errorCollection.add(record);
            }
        }
        //creating result object
        FileResultTpe status = errorCollection.isEmpty() ? FileResultTpe.PROCESSED : successCollection.isEmpty() ?
                FileResultTpe.ERROR : FileResultTpe.PARTIALLY_PROCESSED;
        BatchJobResult result = new BatchJobResult(filePath,  status);
        result.setErrorCount(errorCollection.size());
        result.setSuccessCount(successCollection.size());

        if (successCollection.isEmpty() && errorCollection.isEmpty()){
            result.setErrorFile(filePath.toFile());
            return result;
        }

         try {
             String filePathString = filePath.toString();
            if(!successCollection.isEmpty()) {
                Path successFilePath = Path.of(FilenameUtils.removeExtension(filePathString).concat("_SUCCESS.").concat(FilenameUtils.getExtension(filePathString)));
                Job job1 = buildJResultJob(successFilePath, "success-writer", processor, successCollection);
                Future<JobReport> report1 = jobExecutor.submit(job1);
                result.setSuccessFile(successFilePath.toFile());
                log.info("Job report for reading blocking queue and creating success file..." +filePath+ " Success Job Report..." +report1.get());
            }
            if(!errorCollection.isEmpty()) {
                Path errorFilePath = Path.of(FilenameUtils.removeExtension(filePathString).concat("_ERROR.").concat(FilenameUtils.getExtension(filePathString)));
                Job job2 = buildJResultJob(errorFilePath, "failure-writer", processor, errorCollection);
                Future<JobReport> report2 = jobExecutor.submit(job2);
                result.setErrorFile(errorFilePath.toFile());
                log.info("Job report for reading blocking queue and creating failure file..." +filePath+ " Failure Job Report..." +report2.get());
            }

        } catch (InterruptedException e) {
            // Re-interrupt the thread and log the interruption
            Thread.currentThread().interrupt();
            result.setStatus(FileResultTpe.FAILED);
            log.error("Thread interrupted during job execution.", e);
        } catch (Exception e) {
            result.setStatus(FileResultTpe.FAILED);
            log.error("Exception in easy batch creation of result file for..."+filePath+ "Error Message..." + e.getMessage(), e);
        }
        return result;
    }
}