package com.maf.pim.easyjob;

import com.maf.pim.easyjob.fileprocessor.EasyBatchProcessor;
import com.maf.pim.easyjob.record.BasicRecord;
import com.maf.pim.easyjob.record.DynamicRecord;
import com.maf.pim.enums.Country;
import com.opencsv.CSVParser;
import com.opencsv.CSVParserBuilder;
import com.opencsv.CSVReader;
import com.opencsv.CSVReaderBuilder;
import com.opencsv.exceptions.CsvValidationException;
import lombok.extern.slf4j.Slf4j;
import org.jeasy.batch.core.job.Job;
import org.jeasy.batch.core.job.JobBuilder;
import org.jeasy.batch.core.reader.IterableRecordReader;
import org.jeasy.batch.core.record.Record;
import org.jeasy.batch.core.writer.BlockingQueueRecordWriter;
import org.jeasy.batch.core.writer.FileRecordWriter;
import org.springframework.stereotype.Component;

import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Path;
import java.util.Collection;
import java.util.Optional;
import java.util.concurrent.BlockingQueue;

@Component
@Slf4j
public class DynamicBatchJob extends BatchJob {
    @Override
    protected Job buildMasterJob(Path filePath, BlockingQueue<Record<BasicRecord>> workQueue, EasyBatchProcessor processor, Country country) {
        boolean isEnriched = filePath.toString().contains("AI_ENRICHED");
        return new JobBuilder<String, BasicRecord>()
                .named("master-job")
                .reader(processor.getRecordReader(filePath))
                .filter(record -> {
                    Long num = record.getHeader().getNumber();
                    if (num == 1 || num == 2) {
                        return null;
                    }
                    return record;
                })
                .mapper(processor.getMapper())
                .processor(record -> {
                    if (record.getHeader().getNumber() == 3) {
                        return null;
                    }
                    DynamicRecord payload = (DynamicRecord) record.getPayload();
                    payload.setCountry(country);
                    payload.setEnriched(isEnriched);
                    return record;
                })
                .writer(new BlockingQueueRecordWriter<>(workQueue))
                .build();
    }

    @Override
    protected Job buildJResultJob(Path filePath, String jobName, EasyBatchProcessor processor, Collection<BasicRecord> collection) {
        FileRecordWriter recordWriter = new FileRecordWriter(filePath);
        FileRecordWriter.HeaderCallback headerCallback;
        Optional<BasicRecord> obj = collection.stream().findFirst();
        if(obj.isPresent()) {
            headerCallback = getHeaderCallBack(filePath);
            recordWriter.setHeaderCallback(headerCallback);
        }
        return new JobBuilder()
                .reader(new IterableRecordReader(collection))
                .named(jobName)
                .mapper(processor.getResultMapper())
                .marshaller(processor.getMarshaller())
                .writer(recordWriter)
                .batchSize(BATCH_SIZE)
                .build();
    }

    protected FileRecordWriter.HeaderCallback getHeaderCallBack(Path filePath) {
        String filename = filePath.toString().replace("_SUCCESS", "").replace("_ERROR", "");
        StringBuilder headerLines = new StringBuilder();
        try {
            FileReader fileReader = new FileReader(filename);
            CSVParser parser = new CSVParserBuilder().withSeparator('#').build();
            try (CSVReader csvReader = new CSVReaderBuilder(fileReader)
                    .withCSVParser(parser)
                    .build()) {
                String[] nextRecord;
                int i = 0;
                while ((nextRecord = csvReader.readNext()) != null && i < 3) {
                    headerLines.append(String.join("|", nextRecord));
                    headerLines.append("\n");
                    i++;
                }
            }
            headerLines.deleteCharAt(headerLines.lastIndexOf("\n")).append("|errMsg");
        } catch (CsvValidationException|IOException e) {
            throw new RuntimeException(e);
        }
        return writer -> writer.write(headerLines.toString());
    }
}
