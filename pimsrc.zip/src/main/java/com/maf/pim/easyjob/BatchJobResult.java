package com.maf.pim.easyjob;

import com.maf.pim.enums.FileResultTpe;
import lombok.Getter;
import lombok.Setter;

import java.io.File;
import java.nio.file.Path;

@Getter
@Setter
public class BatchJobResult {

    Path filePath;

    FileResultTpe status;

    File successFile;

    File errorFile;

    Integer successCount;

    Integer errorCount;

    public BatchJobResult(Path filePath, FileResultTpe status) {
        this.filePath = filePath;
        this.status = status;
    }

    @Override
    public String toString() {
        return "BatchJobResult {" +
                "filePath=" + filePath +
                ", status='" + status.toString() +
                '}';
    }
}
