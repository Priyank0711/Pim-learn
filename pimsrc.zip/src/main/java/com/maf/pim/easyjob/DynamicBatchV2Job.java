package com.maf.pim.easyjob;

import com.maf.pim.easyjob.fileprocessor.EasyBatchProcessor;
import com.maf.pim.easyjob.fileprocessor.MarketPlaceFileProcessor;
import com.maf.pim.easyjob.record.BasicRecord;
import com.maf.pim.easyjob.record.DynamicRecord;
import com.maf.pim.enums.Country;
import com.maf.pim.util.CommonUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;
import org.jeasy.batch.core.job.Job;
import org.jeasy.batch.core.job.JobBuilder;
import org.jeasy.batch.core.reader.IterableRecordReader;
import org.jeasy.batch.core.record.Record;
import org.jeasy.batch.core.writer.BlockingQueueRecordWriter;
import org.jeasy.batch.core.writer.FileRecordWriter;
import org.springframework.stereotype.Component;

import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Path;
import java.util.*;
import java.util.concurrent.BlockingQueue;

@Component
@Slf4j
public class DynamicBatchV2Job extends BatchJob {
    @Override
    protected Job buildMasterJob(Path filePath, BlockingQueue<Record<BasicRecord>> workQueue, EasyBatchProcessor processor, Country country) {
        return new JobBuilder<String, BasicRecord>()
                .named("master-job")
                .reader(processor.getRecordReader(filePath))
                .filter(record -> {
                    Long num = record.getHeader().getNumber();
                    if (num <= processor.getNumberOfHeaderLines() - 1 ) {
                        return null;
                    }
                    return record;
                })
                .mapper(processor.getMapper())
                .processor(record -> {
                    if (record.getHeader().getNumber() <= processor.getNumberOfHeaderLines()) {
                        return null;
                    }
                    BasicRecord payload = (BasicRecord) record.getPayload();
                    payload.setCountry(country);
                    if(processor instanceof MarketPlaceFileProcessor) {
                        DynamicRecord mktRec = (DynamicRecord) payload;
                        mktRec.setSellerId(CommonUtils.extractFileName(filePath.getFileName().toString()).split("-")[0]);
                    }
                    return record;
                })
                .writer(new BlockingQueueRecordWriter<>(workQueue))
                .build();
    }

    @Override
    protected Job buildJResultJob(Path filePath, String jobName, EasyBatchProcessor processor, Collection<BasicRecord> collection) {
        FileRecordWriter recordWriter = new FileRecordWriter(filePath);
        FileRecordWriter.HeaderCallback headerCallback;
        Optional<BasicRecord> obj = collection.stream().findFirst();
        if(obj.isPresent()) {
            try {
                headerCallback = getHeaderCallBack(filePath, jobName, processor);
            } catch (IOException e) {
                log.error("Exception when writing headers to reault file " + e.getMessage());
                throw new RuntimeException(e);
            }
            recordWriter.setHeaderCallback(headerCallback);
        }
        return new JobBuilder()
                .reader(new IterableRecordReader(collection))
                .named(jobName)
                .mapper(processor.getResultMapper())
                .marshaller(processor.getMarshaller())
                .writer(recordWriter)
                .batchSize(BATCH_SIZE)
                .build();
    }

    private FileRecordWriter.HeaderCallback getHeaderCallBack(Path filePath, String jobName, EasyBatchProcessor processor) throws IOException {
        String filename = filePath.toString().replace("_SUCCESS", "").replace("_ERROR", "");
        StringBuilder headerLines = new StringBuilder();
        CSVParser csvParser = null;
        try (FileReader fileReader = new FileReader(filename)) {
            CSVFormat csvFormat = CSVFormat.DEFAULT.builder().setDelimiter(processor.getDelimiter().charAt(0)).build();
            csvParser = new CSVParser(fileReader, csvFormat);
            Iterator<CSVRecord> csvRecordIterator = csvParser.iterator();
            String[] nextRecord;
            int i = 0;
            while (i < processor.getNumberOfHeaderLines() && (nextRecord = csvRecordIterator.next().values()) != null) {
                if (i == 0 && processor instanceof MarketPlaceFileProcessor) {
                    i++;
                    continue;
                }
                if(i != 0 && !headerLines.isEmpty()) {
                    headerLines.append("\n");
                }
                if (i == processor.getNumberOfHeaderLines() - 1) {
                    if (jobName.equals("success-writer")) {
                        nextRecord = processor.updateSuccessHeader(nextRecord);
                    } else {
                        nextRecord = processor.updateErrorHeader(nextRecord);
                    }
                }
                headerLines.append(String.join(processor.getDelimiter(), nextRecord));
                i++;
            }
            headerLines.append(processor.getDelimiter()).append("errMsg");
        } finally {
            if(csvParser != null) {
                csvParser.close();
            }
        }
        return writer -> writer.write(headerLines.toString());
    }
}
