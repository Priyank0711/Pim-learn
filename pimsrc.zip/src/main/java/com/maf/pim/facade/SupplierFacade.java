package com.maf.pim.facade;

import com.maf.pim.data.SupplierData;
import com.maf.pim.dto.ProductSuppliersDto;
import com.maf.pim.dto.ProductSuppliersResponse;
import com.maf.pim.entity.Supplier;
import com.maf.pim.enums.Country;

import java.util.List;

public interface SupplierFacade {

    List<ProductSuppliersResponse> getProductSuppliersList(Country country, List<ProductSuppliersDto> productSuppliersDtoList, boolean reqSecSuppliers);

    SupplierData getSupplierData(Supplier supplier);
}
