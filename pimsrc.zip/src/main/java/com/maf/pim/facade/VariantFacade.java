package com.maf.pim.facade;

import com.maf.pim.context.SessionContext;
import com.maf.pim.data.VariantData;
import com.maf.pim.request.VariantRequest;

import java.time.Instant;
import java.util.List;
import java.util.Optional;

public interface VariantFacade {
    void exportVariants(Instant lastModifiedDate, SessionContext context);

    List<VariantData> exportVariants(Instant lastModifiedDate, SessionContext context, Optional<VariantRequest> variantRequest);
}
