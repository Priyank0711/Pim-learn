package com.maf.pim.facade;

import com.maf.pim.data.SupplierGimaData;
import com.maf.pim.entity.SupplierGima;

import java.util.List;

public interface SupplierGimaFacade {
    List<SupplierGimaData> getSupplierGimaDataList(List<SupplierGima> supplierGimas);
}
