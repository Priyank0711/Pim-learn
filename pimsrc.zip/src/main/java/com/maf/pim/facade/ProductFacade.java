package com.maf.pim.facade;

import com.maf.pim.context.SessionContext;
import com.maf.pim.data.ProductData;
import com.maf.pim.dto.ProductPatchRequest;
import com.maf.pim.entity.Product;
import com.maf.pim.enums.Country;
import com.maf.pim.enums.ProductPicker;
import com.maf.pim.enums.ProductSection;
import com.maf.pim.request.ExportProductPagesRequest;
import com.maf.pim.request.ProductRequest;
import com.maf.pim.response.ProductInformationResponse;

import java.time.Instant;
import java.util.List;
import java.util.Set;

public interface ProductFacade {

    List<ProductData> getProductDetails(final List<Product> productList, final SessionContext context);

    void exportProducts(Instant lastModifiedDate, SessionContext context);

    void exportPagedProducts(Country country, ExportProductPagesRequest request);

    void exportSupplierProducts(Instant lastModifiedDate, SessionContext context);

    List<ProductData> searchProductDetails(ProductRequest productRequest, Country country);

    ProductData getProductData(Product product, SessionContext context, List<ProductPicker> productPickers);

    ProductInformationResponse getProductInformation(Country country, String code, Set<ProductSection> sections);

    ProductInformationResponse updateProduct(ProductPatchRequest patchProductRequest);
}
