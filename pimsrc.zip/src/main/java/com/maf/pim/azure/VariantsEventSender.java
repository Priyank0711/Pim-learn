package com.maf.pim.azure;

import com.azure.messaging.eventhubs.EventData;
import com.azure.messaging.eventhubs.EventDataBatch;
import com.azure.messaging.eventhubs.EventHubProducerClient;
import com.google.common.collect.Lists;
import com.google.gson.*;
import com.maf.pim.data.VariantData;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;

import java.nio.charset.Charset;
import java.time.Instant;
import java.util.List;

@Component("VariantsEventSender")
@Slf4j
public class VariantsEventSender {

    public static final int MAX_BATCH_SIZE = 1024 * 1000;
    private final Gson gson;
    EventHubProducerClient eventHubProducerClient;

    @Value("${azure.variants.eventhub.batch.size}")
    private int batchSize;

    @Value("${azure.variants.eventhub.enable}")
    private boolean enabled;

    public VariantsEventSender(@Qualifier("variantEventHubProducerClient") EventHubProducerClient eventHubProducerClient) {
        this.eventHubProducerClient = eventHubProducerClient;
        gson = new GsonBuilder()
                .registerTypeAdapter(Instant.class, (JsonSerializer<Instant>) (src, typeOfSrc, context) -> new JsonPrimitive(src.toString()))
                .registerTypeAdapter(Instant.class, (JsonDeserializer<Instant>) (json, typeOfT, context) -> Instant.parse(json.getAsString()))
                .create();
    }

    @Async("pimVariantEventhubTaskExecutor")
    public void sendData(List<VariantData> variants) {
        if (enabled) {
            List<List<VariantData>> smallerLists = Lists.partition(variants, batchSize);
            for (List<VariantData> variantList : smallerLists) {
                createBatchAndSend(variantList);
            }
        }
    }

    private void createBatchAndSend(List<VariantData> variants) {
        try {
            EventDataBatch batch = eventHubProducerClient.createBatch();
            log.info("Sending {} variants to Event Hub", gson.toJson(variants));
            byte[] bytes = gson.toJson(variants).getBytes(Charset.defaultCharset());

            if (bytes.length > MAX_BATCH_SIZE && variants.size() > 1) {
                List<List<VariantData>> subSmallerLists = Lists.partition(variants, variants.size() / 2);
                subSmallerLists.forEach(this::createBatchAndSend);
            } else {
                EventData eventData = new EventData(bytes);

                batch.tryAdd(eventData);
                eventHubProducerClient.send(batch);
            }
        } catch (Exception e) {
            log.error(String.format("Error occurred while sending %d Variants to Event Hub. Variant ids - %s",
                            variants.size(),
                            variants.stream().map(VariantData::getId).toList()),
                    e);
            if (log.isDebugEnabled())
                log.debug("Failed variants - {}", variants);
        }
    }
}
