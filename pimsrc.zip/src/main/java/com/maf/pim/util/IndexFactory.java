package com.maf.pim.util;

import com.maf.pim.properties.ElasticSearchIndexes;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Component;

@Component
@AllArgsConstructor
public class IndexFactory {
    private final ElasticSearchIndexes indexes;

    public String getProductIndexName(String countryCode) {
        return indexes.getIndexes().get(countryCode);
    }

}
