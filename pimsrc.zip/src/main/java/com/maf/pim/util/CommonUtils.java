package com.maf.pim.util;

import com.maf.pim.constants.Constants;
import com.maf.pim.enums.Country;
import lombok.experimental.UtilityClass;
import org.apache.commons.lang3.StringUtils;

import java.time.Instant;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@UtilityClass
public class CommonUtils {

    public static String extractFileName(String inputString) {
        Pattern pattern = Pattern.compile(Constants.GICA_FILE_PATTERN);
        Matcher matcher = pattern.matcher(inputString);
        int index = StringUtils.lastIndexOf(inputString,".");
        String extension = StringUtils.substring(inputString,index);
        if (matcher.find()) {
            return matcher.group(1)+extension;
        } else {
            return StringUtils.EMPTY;
        }
    }

    public static Instant getUTCInstantFromStringPattern(String date, String pattern, Country country) {
        DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern(pattern);
        ZonedDateTime dateTime = ZonedDateTime.parse(date, dateTimeFormatter.withZone(country.getZoneId()));
        return dateTime.toInstant();
    }
}
