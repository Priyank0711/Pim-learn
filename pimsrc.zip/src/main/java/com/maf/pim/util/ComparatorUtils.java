package com.maf.pim.util;

import com.maf.pim.dto.TemplateAttributeDetails;
import com.maf.pim.entity.AttributeAssignment;
import lombok.experimental.UtilityClass;

import java.util.Comparator;

@UtilityClass
public class ComparatorUtils {
    public static final Comparator<AttributeAssignment> assignmentComparator = Comparator.comparing(AttributeAssignment::getDisplayOrder,
            Comparator.nullsLast(Comparator.naturalOrder()));

    public static final Comparator<TemplateAttributeDetails> templateAttributeComparator = Comparator.comparing(TemplateAttributeDetails::getDisplayOrder,
            Comparator.nullsLast(Comparator.naturalOrder()));
}
