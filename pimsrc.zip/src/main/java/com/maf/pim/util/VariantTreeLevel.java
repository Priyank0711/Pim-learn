package com.maf.pim.util;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class VariantTreeLevel {
        private String code;
        private VariantAttrNameExtractor nameExtractor;
        private boolean imageLevel;
}