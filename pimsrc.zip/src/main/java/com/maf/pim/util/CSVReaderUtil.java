package com.maf.pim.util;

import com.maf.pim.enums.Language;
import lombok.experimental.UtilityClass;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;

import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
@Slf4j
@UtilityClass
public class CSVReaderUtil {

    public static Map<String, String> readColumn(String csvFilePath, String headerName, int noOfHeaderRows) throws IOException {
        Map<String, String> columnData = new HashMap<>();
        List<String> headers = getHeaders(csvFilePath, noOfHeaderRows);
        try (Reader reader = new FileReader(csvFilePath)) {
            CSVFormat csvFormat = CSVFormat.DEFAULT.builder()
                    .setHeader(headers.toArray(new String[0]))
                    .setDelimiter("|")
                    .build();
            CSVParser csvParser = new CSVParser(reader, csvFormat);
            for (CSVRecord csvRecord : csvParser) {
                if(csvRecord.getRecordNumber() <= noOfHeaderRows) {
                    continue;
                }
                String arabicName = "";
                try {
                    arabicName  = csvRecord.get(headerName + "_" + Language.AR);
                } catch (IllegalArgumentException illegalArgumentException) {
                    columnData.put(csvRecord.get(headerName), arabicName);
                    continue;
                }
                columnData.put(csvRecord.get(headerName), arabicName);
            }
        }
        return columnData;
    }

    public static String readFirstLine(String csvFilePath) throws IOException {
        try (Reader reader = new FileReader(csvFilePath)) {
            CSVFormat csvFormat = CSVFormat.DEFAULT.builder()
                    .setDelimiter("|")
                    .build();
            CSVParser csvParser = new CSVParser(reader, csvFormat);
            CSVRecord firstRecord = csvParser.iterator().next();
            return firstRecord.values()[0];
        }
    }

    private static List<String> getHeaders(String csvFilePath, int noOfHeaderRows) throws IOException {
        List<String> headers = new ArrayList<>();
        try (Reader reader = new FileReader(csvFilePath)) {
            CSVParser csvParser = new CSVParser(reader, CSVFormat.DEFAULT.builder().setDelimiter("|").build());
            for (int i = 0; i < noOfHeaderRows - 1; i++) {
                csvParser.iterator().next();
            }
            CSVRecord headerRecord = csvParser.iterator().next();
            for (String s : headerRecord) {
                headers.add(s);
            }
        }
        return headers;
    }
}