package com.maf.pim.util;

import lombok.Getter;
import lombok.experimental.UtilityClass;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Getter
@UtilityClass
public final class CategoryIdSpecialCharacterMapper {

    private static final Pattern SPECIAL_CHAR_PATTERN = Pattern.compile("[^a-zA-Z0-9_]");

    public static String encode(String input) {
        Matcher matcher = SPECIAL_CHAR_PATTERN.matcher(input);
        StringBuilder stringBuilder = new StringBuilder();

        while (matcher.find()) {
            matcher.appendReplacement(stringBuilder, getEncodeStringForCharacter(matcher.group()));
        }
        matcher.appendTail(stringBuilder);
        return stringBuilder.toString();
    }

    public static String getEncodeStringForCharacter(String specialChar) {
        return "_" + (int) specialChar.charAt(0) + "_";
    }
}
