package com.maf.pim.util;

import com.maf.pim.entity.Product;
import com.maf.pim.enums.ProductType;
import lombok.experimental.UtilityClass;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.BooleanUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.web.util.HtmlUtils;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;

@UtilityClass
@Slf4j
public class ProductUtils {

    public static String escapeString(String Value) {
        return StringUtils.isNotEmpty(Value) ? HtmlUtils.htmlEscape(Value) : Value;
    }

    public static String urlSafe(final String text)
    {
        if (text == null || text.isEmpty())
        {
            return "";
        }

        String encodedText;
        try
        {
            encodedText = URLEncoder.encode(text, "utf-8");
        }
        catch (final UnsupportedEncodingException encodingException)
        {
            encodedText = text;
            log.debug(encodingException.getMessage(), encodingException);
        }

        // Cleanup the text
        String cleanedText = encodedText;
        cleanedText = cleanedText.replaceAll("%2F", "/");
        cleanedText = cleanedText.replaceAll("[^%A-Za-z0-9\\-]+", "-");
        cleanedText = cleanedText.replaceAll("%[A-Za-z0-9][A-Za-z0-9]", "-");
        cleanedText = cleanedText.replaceAll("-+", "-");
        return cleanedText.toLowerCase();
    }

    public String getBrandCode(String brand) {
        return "MKT-" + brand;
    }

    public boolean isBuyNowProduct(Product product){
        return (product.getProductType() != null && ProductType.NONFOOD.equals(product.getProductType())) ||
                BooleanUtils.isTrue(product.getMarketplaceProduct());
    }
}
