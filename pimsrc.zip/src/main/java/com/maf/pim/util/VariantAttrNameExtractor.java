package com.maf.pim.util;

import com.maf.pim.entity.translation.CategoryTranslation;

@FunctionalInterface
public interface VariantAttrNameExtractor {
    String extractCategoryAttrName(CategoryTranslation translation);
}