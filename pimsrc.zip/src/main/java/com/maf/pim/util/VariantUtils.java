package com.maf.pim.util;

import com.maf.pim.context.SessionContext;
import com.maf.pim.data.*;
import com.maf.pim.entity.Category;
import com.maf.pim.entity.Product;
import com.maf.pim.entity.ProductId;
import com.maf.pim.entity.translation.CategoryTranslation;
import com.maf.pim.enums.Language;
import com.maf.pim.projections.ProductAttrValueProjection;
import lombok.experimental.UtilityClass;
import lombok.extern.slf4j.Slf4j;
import org.springframework.util.StringUtils;

import java.util.*;
import java.util.stream.Collectors;

@Slf4j
@UtilityClass
public class VariantUtils {

    public static VariantData buildVariantTree(Map<String, List<ProductAttrValueProjection>> groupedPAVs,
                                               Map<ProductId, Product> productMap, Map<Long, String> attributeAssignmentMap, Category variant,
                                               List<VariantTreeLevel> treeLevels, SessionContext context) {
        // Create the VariantData object
        VariantData variantData = new VariantData();
        variantData.setId(variant.getCode());
        variantData.setName(getLocalizedName(context.getLanguages(), variant, CategoryTranslation::getName));
        variantData.setProductIds(new ArrayList<>());
        variantData.setStoreId(context.getCountry().getStoreId());

        // Prepare the root node
        VariantAttributeData rootNode = new VariantAttributeData();
        rootNode.setCode(variant.getL1AttrCode());
        rootNode.setName(getLocalizedName(context.getLanguages(), variant, CategoryTranslation::getL1AttrName));
        rootNode.setVariants(new ArrayList<>());

        // Build the tree recursively
        for (Map.Entry<ProductId, Product> entry : productMap.entrySet()) {
            String productCode = entry.getKey().getCode();
            if(groupedPAVs.containsKey(productCode)) {
                Map<String, List<ProductAttrValueProjection>> attrMap = groupedPAVs.get(productCode).stream()
                        .collect(Collectors.groupingBy(pav -> attributeAssignmentMap.get(pav.getAssignmentId())));

                if(treeLevels.stream().map(VariantTreeLevel::getCode).allMatch(attrMap::containsKey)) {
                    buildTreeRecursive(variant, rootNode, treeLevels, attrMap, context.getLanguages(), entry.getValue(), 0);
                    variantData.getProductIds().add(productCode);
                } else {
                    log.info("Product {} does not have all the required attributes for variant {}", productCode, variant.getCode());
                }
            }
        }

        // Set the root node to the VariantData
        variantData.setData(rootNode);
        return variantData;
    }

    public static void buildTreeRecursive(Category variant, VariantAttributeData parentNode, List<VariantTreeLevel> treeLevels,
                                          Map<String, List<ProductAttrValueProjection>> attrMap, List<Language> languages,
                                          Product product, int level) {

        VariantTreeLevel currentLevel = treeLevels.get(level);
        Map<String, String> localizedValue = getLocalizedAttrVal(languages, attrMap.get(currentLevel.getCode()));
        String value = localizedValue.get("en");

        VariantAttributeValue detail = parentNode.getVariants().stream()
                .filter(d -> d.getValue().equals(value))
                .findFirst()
                .orElseGet(() -> {
                    VariantAttributeValue newDetail = createVariantDetail(value, localizedValue);
                    parentNode.getVariants().add(newDetail);
                    return newDetail;
                });
        if(currentLevel.isImageLevel() && !StringUtils.hasText(detail.getImage()) && Objects.nonNull(product.getMedia())) {
            detail.setImage(product.getMedia().getUrl());
        }

        if (level+1 == treeLevels.size()) {
            // Set the product for the leaf node
            VariantProduct p = new VariantProduct();
            p.setProductId(product.getId().getCode());
            detail.setProduct(p);
            return;
        }

        if (detail.getChildren() == null) {
            VariantTreeLevel nextLevel = treeLevels.get(level+1);
            VariantAttributeData childNode = new VariantAttributeData();
            childNode.setCode(nextLevel.getCode());
            childNode.setName(getLocalizedName(languages, variant, nextLevel.getNameExtractor()));
            childNode.setVariants(new ArrayList<>());
            detail.setChildren(childNode);
        }

        buildTreeRecursive(variant, detail.getChildren(), treeLevels, attrMap, languages, product, level + 1);
    }

    public static Map<String, String> getLocalizedAttrVal(List<Language> languages,
                                                           List<ProductAttrValueProjection> pavs) {
        return pavs.stream()
                .filter(pav -> languages.contains(pav.getLang()))
                .collect(Collectors.toMap(
                        pav -> pav.getLang().getCode().toLowerCase(),
                        ProductAttrValueProjection::getValue
                ));
    }

    // Helper method to create and add a VariantDetail to the parent node
    public static VariantAttributeValue createVariantDetail(String val, Map<String, String> localizedValue) {
        VariantAttributeValue newDetail = new VariantAttributeValue();
        newDetail.setValue(val);
        newDetail.setLocalizedValue(localizedValue);
        return newDetail;
    }

    public static Map<String, String> getLocalizedName(List<Language> languages, Category variant, VariantAttrNameExtractor nameExtractor) {
        return variant.getCategoryTranslations().stream()
                .filter(translation -> languages.contains(translation.getLanguage()))
                .filter(translation -> Objects.nonNull(nameExtractor.extractCategoryAttrName(translation)))
                .collect(Collectors.toMap(
                        t -> t.getLanguage().getCode().toLowerCase(),
                        nameExtractor::extractCategoryAttrName
                ));
    }
}