package com.maf.pim.util;

import com.maf.pim.constants.Constants;
import com.maf.pim.enums.CategoryType;
import com.maf.pim.enums.FeatureType;
import com.maf.pim.enums.ProductType;
import com.maf.pim.enums.ServicePropostion;
import lombok.experimental.UtilityClass;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.List;
import java.util.function.Consumer;

@UtilityClass
@Slf4j
public class ValueParser {

    public static final List<String> VALID_TRUE_VALUES = List.of("true", "yes", "y", "1");
    public static final List<String> VALID_FALSE_VALUES = List.of("false", "no", "n", "0");
    public static final String DATE_FORMAT_MM_DD_YYYY = "MM-dd-yyyy";


    /**
     * Parses the string argument as a boolean after doing a case-insensitive match.
     * Returns True for any value in list - "true", "yes", "y", "1"
     * Returns False for any value in list - "false", "no", "n", "0"
     * For a null or empty string argument and any other case, null is returned.
     *
     * @param value - the String containing the boolean representation to be parsed
     */
    public static Boolean parseBoolean(String value) {
        Boolean result = null;
        if (StringUtils.isNotBlank(value)) {
            if (VALID_TRUE_VALUES.stream().anyMatch(valid -> valid.equalsIgnoreCase(value.trim()))) {
                return Boolean.TRUE;
            } else if (VALID_FALSE_VALUES.stream().anyMatch(valid -> valid.equalsIgnoreCase(value.trim()))) {
                return Boolean.FALSE;
            }
        }
        return result;
    }

    public static Integer parseInteger(String value) {
        if (StringUtils.isNotBlank(value)) {
            try {
                return Integer.parseInt(value);
            } catch (NumberFormatException e) {
                log.warn("Unable to parse Integer value {}", value);
            }
        }
        return null;
    }

    public static Double parseDouble(String value) {
        if (StringUtils.isNotBlank(value)) {
            try {
                return Double.parseDouble(value);
            } catch (NumberFormatException e) {
                log.warn("Unable to parse Double value {}", value);
            }
        }
        return null;
    }

    public static Instant parseDate(String value) {
        if (StringUtils.isNotBlank(value)) {
            try {
                return LocalDate.parse(
                        value, DateTimeFormatter.ofPattern(DATE_FORMAT_MM_DD_YYYY)
                ).atStartOfDay(ZoneId.of("UTC")).toInstant();
            } catch (DateTimeParseException e){
                log.warn("Unable to parse Date value {}", value, e);
            }
        }
        return null;
    }

    public static String parseString(String value) {
        return StringUtils.isNotBlank(value) ? value : null;
    }

    public String parseAttributeString(String attributeValue) {
        return "REMOVE".equalsIgnoreCase(attributeValue) ? null : attributeValue;
    }
    public static <T> void parseAttributeValue(String attributeValue, Consumer<T> setter, String parseType) {
        if(StringUtils.isNotBlank(attributeValue)){
            String s = parseAttributeString(attributeValue);
            if(s==null) {
                setter.accept(null);
                return;
            }
            T val = switch (parseType) {
                case Constants.DOUBLE -> (T) parseDouble(s);
                case Constants.INTEGER -> (T) parseInteger(s);
                case Constants.BOOLEAN -> (T) parseBoolean(s);
                case Constants.PRODUCT_TYPE -> (T) ProductType.getTypeByValue(s);
                case Constants.CATEGORY_TYPE -> (T) CategoryType.getTypeByValue(s);
                case Constants.INSTANT -> (T) parseDate(s);
                case Constants.STRING -> (T) s;
                case Constants.SERVICE_PROPOSITION -> (T) ServicePropostion.getPropositionByValueList(s);
                case Constants.FEATURE_TYPE -> (T) FeatureType.valueOf(s);
                default -> null;
            };
            if(val!=null){
                setter.accept(val);
            }
        }
    }
}
