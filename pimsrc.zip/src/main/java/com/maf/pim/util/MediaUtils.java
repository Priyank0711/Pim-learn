package com.maf.pim.util;

import com.maf.pim.entity.Media;
import com.maf.pim.enums.Country;
import lombok.experimental.UtilityClass;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import java.time.Instant;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static com.maf.pim.constants.Constants.*;

@Slf4j
@UtilityClass
public class MediaUtils {

    public boolean validateFile(String filename, long size) {
        if (!filename.matches(FILE_PATTERN)) {
            log.debug("Filename is not valid: {}",filename);
            return false;
        }
        if (size > MAX_FILE_SIZE_KB * 1024) {
            log.debug("File size not valid: {}",size);
            return false;
        }
        return true;
    }

    public Map<String, String> extractFileName(String tempFileName) {
        Map<String, String> filename = new HashMap<>();
        Pattern pattern = Pattern.compile(TEMP_FILENAME_PATTERN);
        Matcher matcher = pattern.matcher(tempFileName);

        if (matcher.find()) {
            String productId = matcher.group(1);
            String type = matcher.group(2);
            String format = matcher.group(3);
            String fullName = productId + "_" + type + "." + format;

            filename.put(PRODUCT_ID, productId);
            filename.put(VERSION, type);
            filename.put(FORMAT, format);
            filename.put(FULL_NAME, fullName);
        } else {
            return null;
        }
        return filename;
    }

    public Media createMedia(String url, Map<String, String> fileAttr, Country country, String relativePath, String contentType, String masterUrl) {
        log.debug("Creating the media for {}",fileAttr.get(FULL_NAME));
        Media media = Media.from(fileAttr.get(FULL_NAME),country);
        media.setUrl(url);
        media.setName(StringUtils.join(fileAttr.get(PRODUCT_ID), "_", fileAttr.get(VERSION)));
        media.setFormat(contentType);
        media.setRelativePath(relativePath);
        media.setMasterUrl(masterUrl);
        return media;
    }

    public String getFolderPath(Country country, String azureFolderPath, String productCode, String currentJobUniqueId) {
        return String.format("%s%s/%s/%s", country, azureFolderPath, productCode, currentJobUniqueId);
    }

    public String getUniqueId() {
        return String.valueOf(Instant.now().getEpochSecond());
    }

    public String getRemotePath (String url){
        Pattern pattern = Pattern.compile(REMOTE_PATH_PATTERN);
        Matcher matcher = pattern.matcher(url);
        if (matcher.find()) {
            return matcher.group(1);
        } else {
            return StringUtils.EMPTY;
        }
    }

    public String getContentType(String extension) {
        return String.format("image/%s", extension);
    }
}
