package com.maf.pim.config;

import com.maf.pim.entity.Product;
import jakarta.persistence.EntityGraph;
import jakarta.persistence.EntityManager;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class EntityGraphConfiguration {

    @Bean("productWithCategoriesEntityGraph")
    public EntityGraph<Product> productWithCategoriesEntityGraph(EntityManager entityManager) {
        EntityGraph<Product> entityGraph = entityManager.createEntityGraph(Product.class);
        entityGraph.addAttributeNodes("categories");
        return entityGraph;
    }

    @Bean("productWithGalleryEntityGraph")
    public EntityGraph<Product> productWithGalleryEntityGraph(EntityManager entityManager) {
        EntityGraph<Product> entityGraph = entityManager.createEntityGraph(Product.class);
        entityGraph.addAttributeNodes("gallery");
        return entityGraph;
    }
}