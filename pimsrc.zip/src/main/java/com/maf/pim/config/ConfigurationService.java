package com.maf.pim.config;

import com.maf.pim.enums.Country;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.config.ScheduledTaskRegistrar;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
@Slf4j
public class ConfigurationService {

    public static final String TEN_MINUTES_CRON_EXPRESSION = "0 0/2 * * * *";
    public static final String OFF_HOURS_DAILY_CRON_EXPRESSION = "0 0 19 * * *";
    private static final String MIDNIGHT_CRON_EXPRESSION = "@midnight";
    public static final String APPROVE_MARKETPLACE_PRODUCTS_CRON_EXPRESSION = "0 15 */6 * * *";
    public static final String FIVE_PASS_TEN_MINUTES_CRON_EXPRESSION = "0 5/10 * * * *";

    @Value("${enabled.country.list}")
    private List<Country> enabledCountries;

    public String gicaSchedulerCronForCountry(Country country) {
        if (!enabledCountries.contains(country)) {
            log.info("Gica Scheduler disabled for {}", country);
            return ScheduledTaskRegistrar.CRON_DISABLED;
        } else {
            log.info("Gica Scheduler enabled for {}", country);
            return TEN_MINUTES_CRON_EXPRESSION;
        }
    }

    public String exportProductsSchedulerCronForCountry(Country country) {
        if (!enabledCountries.contains(country)) {
            log.info("Export Products Scheduler disabled for {}", country);
            return ScheduledTaskRegistrar.CRON_DISABLED;
        } else {
            log.info("Export Products Scheduler enabled for {}", country);
            return TEN_MINUTES_CRON_EXPRESSION;
        }
    }

    public String exportVariantsSchedulerCronForCountry(Country country) {
        if (!enabledCountries.contains(country)) {
            log.info("Export Variants Scheduler disabled for {}", country);
            return ScheduledTaskRegistrar.CRON_DISABLED;
        } else {
            log.info("Export Variants Scheduler enabled for {}", country);
            return FIVE_PASS_TEN_MINUTES_CRON_EXPRESSION;
        }
    }

    public String supplierSchedulerCronForCountry(Country country) {
        if (!enabledCountries.contains(country)) {
            log.info("Supplier Scheduler disabled for {}", country);
            return ScheduledTaskRegistrar.CRON_DISABLED;
        } else {
            log.info("Supplier Scheduler enabled for {}", country);
            return MIDNIGHT_CRON_EXPRESSION;
        }
    }

    public String approveMarketplaceProductsSchedulerCronForCountry(Country country) {
        if (!enabledCountries.contains(country)) {
            log.info("Approve Marketplace Product Scheduler disabled for {}", country);
            return ScheduledTaskRegistrar.CRON_DISABLED;
        } else {
            log.info("Approve Marketplace Product Scheduler enabled for {}", country);
            return APPROVE_MARKETPLACE_PRODUCTS_CRON_EXPRESSION;
        }
    }

    public String offHoursGicaSchedulerCronForCountry(Country country) {
        if (!enabledCountries.contains(country)) {
            log.info("OffHours Gica Scheduler disabled for {}", country);
            return ScheduledTaskRegistrar.CRON_DISABLED;
        } else {
            log.info("OffHours Gica Scheduler enabled for {}", country);
            return OFF_HOURS_DAILY_CRON_EXPRESSION;
        }
    }

    public boolean isCountryEnabled(Country country) {
        return enabledCountries.contains(country);
    }
}
