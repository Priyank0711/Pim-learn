package com.maf.pim.config;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

@Component
public class ErrorMessageComponent {
    private final ErrorMessageConfiguration errorMessageConfiguration;
    private static final String PROPERTY_FORMAT = "%s.%s.%s";
    public ErrorMessageComponent(ErrorMessageConfiguration errorMessageConfiguration) {
        this.errorMessageConfiguration = errorMessageConfiguration;
    }
    public String getErrorMessageFromProperties(String fileType, String msgType, String errorCode) {
        String message = errorMessageConfiguration.getProperty(String.format(PROPERTY_FORMAT, fileType, msgType, errorCode).toLowerCase());
        if(StringUtils.isEmpty(message))
            message = getDefaultErorMessage(msgType);
        return message;
    }
    private String getDefaultErorMessage(String msgType) {
        return "incorrect value for " + msgType;
    }
}
