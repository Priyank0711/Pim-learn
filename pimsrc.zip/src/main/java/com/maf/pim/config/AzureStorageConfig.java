package com.maf.pim.config;

import com.azure.storage.blob.BlobContainerClient;
import com.azure.storage.blob.BlobServiceClient;
import com.azure.storage.blob.BlobServiceClientBuilder;
import com.maf.pim.properties.StorageProperties;
import lombok.Data;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Data
@Configuration
public class AzureStorageConfig {

    @Value("${media.azure.remotePath}")
    String azureFolderPath;

    @Bean
    @ConfigurationProperties("azure.storage")
    public StorageProperties storageProperties() {
        return new StorageProperties();
    }

    @Bean
    public BlobServiceClient blobServiceClient(){
        return new BlobServiceClientBuilder()
                .connectionString(storageProperties().getConnectionString())
                .buildClient();
    }

    @Bean
    public BlobContainerClient blobContainerClient(){
       return blobServiceClient().getBlobContainerClient(storageProperties().getMediaContainerName());
    }

    @Bean
    public BlobContainerClient integrationContainerClient(){
        return blobServiceClient().getBlobContainerClient(storageProperties().getIntegrationContainerName());
    }

    @Bean
    @ConfigurationProperties("catalog.azure.storage")
    public StorageProperties catalogStorageProperties() {
        return new StorageProperties();
    }

    @Bean
    public BlobServiceClient catalogBlobServiceClient(){
        return new BlobServiceClientBuilder()
                .connectionString(catalogStorageProperties().getConnectionString())
                .buildClient();
    }

    @Bean
    public BlobContainerClient catalogBlobContainerClient(){
        return catalogBlobServiceClient().getBlobContainerClient(catalogStorageProperties().getIntegrationContainerName());
    }

}
