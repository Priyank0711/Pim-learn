package com.maf.pim.config;

import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;
import com.maf.pim.constants.Constants;
import com.maf.pim.properties.SftpProperties;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class SftpStorageConfig {
    private Session session;
    private ChannelSftp channelSftp;

    @Bean
    @ConfigurationProperties("sftp.storage")
    public SftpProperties sftpProperties() {
        return new SftpProperties();
    }

    public void disconnect() {
        if (channelSftp != null) {
            channelSftp.disconnect();
        }
        if (session != null) {
            session.disconnect();
        }
    }
    public ChannelSftp getChannelSftp() throws JSchException {

        if (channelSftp == null || !channelSftp.isConnected()) {
            JSch jSch = new JSch();
            session = jSch.getSession(sftpProperties().getUser(), sftpProperties().getHost(), sftpProperties().getPort());
            session.setPassword(sftpProperties().getPassword());
            session.setConfig(Constants.HOST_KEY, Constants.SFTP_CONFIG);
            session.connect();
            channelSftp = (ChannelSftp) session.openChannel("sftp");
            channelSftp.connect();
        }
        return channelSftp;
    }




}
