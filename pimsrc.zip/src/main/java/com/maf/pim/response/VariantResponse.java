package com.maf.pim.response;

import com.maf.pim.data.VariantData;
import lombok.Data;

import java.util.List;

@Data
public class VariantResponse {
    List<VariantData> variantDataList;
}
