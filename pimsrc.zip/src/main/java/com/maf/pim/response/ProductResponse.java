package com.maf.pim.response;

import com.maf.pim.data.ProductData;
import lombok.Data;

import java.util.List;

@Data
public class ProductResponse {
    List<ProductData> productDataList;
}
