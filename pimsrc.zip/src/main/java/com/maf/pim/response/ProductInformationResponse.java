package com.maf.pim.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.maf.pim.enums.Language;
import com.maf.pim.dto.productsection.AttributesDTO;
import com.maf.pim.dto.productsection.CategoriesDTO;
import com.maf.pim.dto.productsection.MultimediaDTO;
import com.maf.pim.dto.productsection.PropertiesDTO;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ProductInformationResponse {

    private List<Language> languages;
    private PropertiesDTO properties;
    private CategoriesDTO categories;
    private AttributesDTO attributes;
    private MultimediaDTO multimedia;
}
