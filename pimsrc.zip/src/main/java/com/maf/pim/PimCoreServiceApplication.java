package com.maf.pim;

import com.cosium.spring.data.jpa.entity.graph.repository.support.EntityGraphJpaRepositoryFactoryBean;
import com.maf.pim.enums.Country;
import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.servers.Server;
import lombok.extern.slf4j.Slf4j;
import net.javacrumbs.shedlock.spring.annotation.EnableSchedulerLock;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.context.ApplicationListener;
import org.springframework.data.jpa.repository.config.EnableJpaAuditing;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.annotation.EnableScheduling;

import java.util.List;

@SpringBootApplication
@EnableJpaRepositories(repositoryFactoryBeanClass = EntityGraphJpaRepositoryFactoryBean.class)
@EnableCaching
@EnableJpaAuditing
@EnableScheduling
@EnableSchedulerLock(defaultLockAtMostFor = "PT30M")
@OpenAPIDefinition(servers = {@Server(url = "/", description = "Default Server URL")})
@Slf4j
@EnableAsync
public class PimCoreServiceApplication implements ApplicationListener<ApplicationReadyEvent> {

	@Value("${background.jobs.enable}")
	private String backgroundJobsEnable;

	@Value("${reader.jobs.enable}")
	private String readerJobsEnable;

	@Value("${azure.products.eventhub.enable}")
	private String enableEventHub;

	@Value("${enabled.country.list}")
	private List<Country> enabledCountries;

	public static void main(String[] args) {
		SpringApplication.run(PimCoreServiceApplication.class, args);
	}

	@Override
	public void onApplicationEvent(ApplicationReadyEvent event) {
		log.info("Application Started for {} countries, With BackGround Jobs: {}, Reader Jobs: {}, Eventhub Jobs: {} v2",
				enabledCountries,
				backgroundJobsEnable,
				readerJobsEnable,
				enableEventHub);
	}
}