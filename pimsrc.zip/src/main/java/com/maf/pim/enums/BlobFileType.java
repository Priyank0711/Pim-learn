package com.maf.pim.enums;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

public enum BlobFileType {

    GICAREFERENCE("GICAREFERENCE", 0),
    GICASUPPLIER("GICASUPPLIER", 1),
    GICAITEM("GICAITEM", 2),
    GICABARCODEDEPRECATED("GICABARCODEDEPRECATED",3),
    GICANEWBARCODE("GICANEWBARCODE",4),

    CLASSIFICATION("CLASSIFICATION",5),
    MARKETPLACE("MARKETPLACE",6),

    PRODUCTAPPROVAL("PRODUCTAPPROVAL", 7),
    UNPUBLISHEDITEMS("UNPUBLISHEDITEMS", 8),

    SUPPLIERGIMA("SUPPLIERGIMA", 9),


    CATEGORY("CATEGORY", 10),
    MARKETPLACE_CATEGORY_MAPPING("MKP_CAT_MAPPING",11),
    ATTRIBUTES("ATTRIBUTES", 12),
    OTHER("OTHER", 13);

    private static final Map<String, BlobFileType> BY_FILETYPE = new HashMap<>();

    static {
        for (BlobFileType e: values()) {
            BY_FILETYPE.put(e.fileType, e);
        }
    }

    public final String fileType;
    public final int priority;

    BlobFileType(String fileType, int priority) {
        this.fileType = fileType;
        this.priority = priority;
    }

    public static Optional<BlobFileType> getFileType(String fileName) {
       return BY_FILETYPE.values().stream().filter(obj -> fileName.contains(obj.fileType)).findFirst();
    }

    public Boolean isSupplierFile() {
        return this.equals(SUPPLIERGIMA) || this.equals(GICASUPPLIER);
    }

    public Boolean isMarketplaceFile() {
        return this.equals(MARKETPLACE) || this.equals(MARKETPLACE_CATEGORY_MAPPING);
    }
}
