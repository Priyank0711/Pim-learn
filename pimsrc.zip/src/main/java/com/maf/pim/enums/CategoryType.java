package com.maf.pim.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;

@AllArgsConstructor
@Getter
@Slf4j
public enum CategoryType {
    GICA("GICA", false),
    BRAND("BRAND", false),
    NAVIGATION("NAVIGATION", true),
    PROMOTION("PROMOTION", false),
    CLASSIFICATION("CLASSIFICATION", true),
    MARKETPLACE("MARKETPLACE", true),
    CATEGORY("CATEGORY", false),
    VARIANT("VARIANT", false);
    final String code;
    final boolean relatedToClassification;

    public static CategoryType getTypeByValue(String value) {
        try {
            return CategoryType.valueOf(value);
        } catch (IllegalArgumentException exception) {
            log.warn("No Category type Enum Found " + value);
        }
        return null;
    }

    public static boolean isValid(String name) {
        try {
            CategoryType.valueOf(name);
        } catch (IllegalArgumentException e) {
            return false;
        }
        return true;
    }

}
