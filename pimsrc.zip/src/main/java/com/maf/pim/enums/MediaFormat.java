package com.maf.pim.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
@Getter
public enum MediaFormat {
    PRODUCT_ZOOM("productZoom", 1700),
    PDP("pdp",480),
    PDP_PREVIEW("pdpPreview", 146),
    CART_THUMBNAIL("cartThumbnail", 32),
    PLP_THUMBNAIL("plpThumbnail", 200);

    private String format;
    private Integer size;
}
