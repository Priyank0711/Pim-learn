package com.maf.pim.enums;

public interface FeatureTypeParser {
    Object parseValue(String value);
}
