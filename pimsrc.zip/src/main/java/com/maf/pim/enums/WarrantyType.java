package com.maf.pim.enums;


import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
@Getter
public enum WarrantyType {
    EXTENDED_WARRANTY,
    ACCIDENTAL_DAMAGE;
}
