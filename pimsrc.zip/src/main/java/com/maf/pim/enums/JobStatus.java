package com.maf.pim.enums;

public enum JobStatus {
    RUNNING,

    ERROR,
    FINISHED;
}
