package com.maf.pim.enums;


import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
@Getter
public enum ApprovalStatus {
    CHECK,
    MARKETPLACEAPPROVED,
    NEW,
    APPROVED,
    UNAPPROVED;
}
