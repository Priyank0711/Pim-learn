package com.maf.pim.enums;


import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;

@AllArgsConstructor
@Getter
@Slf4j
public enum ProductNature {
    FRESH,
    DRY,
    FROZEN,
    NONFOOD;

    public static ProductNature getNatureByValue(String value) {
        try {
            return ProductNature.valueOf(value);
        } catch (IllegalArgumentException exception) {
            log.warn("No Product Nature Enum Found " + value);
        }
        return null;
    }
}
