package com.maf.pim.enums;


import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;

@AllArgsConstructor
@Getter
@Slf4j
public enum AttributeGroup {
    REQUIRED("REQUIRED",1),
    PRODUCT_ENHANCEMENT("PRODUCT ENHANCEMENT",2),
    OTHER("OTHER",3);

    public final String val;
    public final int priority;
    public static AttributeGroup getTypeByValue(String value) {
        try {
            return AttributeGroup.valueOf(value);
        } catch (IllegalArgumentException exception) {
            return AttributeGroup.OTHER;
        }
    }
}
