package com.maf.pim.enums;

import com.maf.pim.enums.option.ProductOption;
import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

@AllArgsConstructor
@Getter
public enum ProductPicker {
    BASIC(List.of()),
    TRANSLATION_ATTRIBUTES(List.of(ProductOption.TRANSLATION)),
    EXTENDED_ATTRIBUTES(List.of()),
    GALLERY(List.of(ProductOption.MEDIA, ProductOption.GALLERY)),
    CATEGORY(List.of(ProductOption.CATEGORY, ProductOption.CATEGORY_TRANSLATION)),
    CLASSIFICATION(List.of()),
    SUPPLIER(List.of(ProductOption.SUPPLIER)),
    SUPPLIER_GIMA(List.of()),
    MARKETPLACE(List.of());

    private final List<ProductOption> productOptions;

    public static List<ProductPicker> toList() {
        return Arrays.stream(values()).collect(Collectors.toList());
    }

    public static List<ProductPicker> getProductPickers(Country country) {
        List<ProductPicker> productPickers = new ArrayList<>(Arrays.asList(BASIC, TRANSLATION_ATTRIBUTES, EXTENDED_ATTRIBUTES, GALLERY, CATEGORY, CLASSIFICATION));
        if (country.isSupplierEnabled()) {
            productPickers.add(SUPPLIER);
            productPickers.add(SUPPLIER_GIMA);
        }

        if (country.isMarketplaceEnabled()) {
            productPickers.add(MARKETPLACE);
        }

        return productPickers;
    }

    public static List<ProductPicker> getProductPickersMkt(Country country) {
        List<ProductPicker> productPickers = new ArrayList<>(Arrays.asList(BASIC, TRANSLATION_ATTRIBUTES, EXTENDED_ATTRIBUTES, GALLERY, CATEGORY, CLASSIFICATION));

        if (country.isMarketplaceEnabled()) {
            productPickers.add(MARKETPLACE);
        }

        return productPickers;
    }
}
