package com.maf.pim.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

import java.time.ZoneId;
import java.util.Collections;
import java.util.List;

@AllArgsConstructor
@Getter
public enum Country {
    ALL("ALL", null, Collections.emptyList(), ZoneId.systemDefault(), false, false, false),

    LBN("LBN", "maflbn", List.of(Language.EN,Language.AR), ZoneId.of("Asia/Beirut"), false, false, false),
    KEN("KEN", "mafken", List.of(Language.EN,Language.AR), ZoneId.of("Africa/Nairobi"), false, false, false),
    PAK("PAK", "mafpak", List.of(Language.EN,Language.AR), ZoneId.of("Asia/Karachi"), false, false, false),
    JOR("JOR", "mafjor", List.of(Language.EN,Language.AR), ZoneId.of("Asia/Amman"), true, false, false),

    BHR("BHR", "mafbhr",List.of(Language.EN,Language.AR), ZoneId.of("Asia/Bahrain"), true, false, false),
    KWT("KWT", "mafkwt",List.of(Language.EN,Language.AR), ZoneId.of("Asia/Kuwait"), true, false, false),
    EGY("EGY", "mafegy", List.of(Language.EN,Language.AR), ZoneId.of("Egypt"), false, true, false),

    SAU("SAU", "mafsau",List.of(Language.EN,Language.AR), ZoneId.of("Asia/Riyadh"), false, true, false),
    OMN("OMN", "mafomn",List.of(Language.EN,Language.AR), ZoneId.of("Asia/Muscat"), true, false, false),
    QAT("QAT", "mafqat",List.of(Language.EN,Language.AR), ZoneId.of("Asia/Qatar"), true, false, false),

    UAE("UAE", "mafuae", List.of(Language.EN,Language.AR), ZoneId.of("Asia/Dubai"), true, true, true);

    String code;
    String storeId;
    List<Language> languages;
    ZoneId zoneId;
    final boolean supplierEnabled;
    final boolean marketplaceEnabled;
    final boolean includeParentClassif;
}
