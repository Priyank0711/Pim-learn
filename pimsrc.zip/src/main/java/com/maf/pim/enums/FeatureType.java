package com.maf.pim.enums;


import com.maf.pim.util.ValueParser;
import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.HashMap;
import java.util.Map;

@AllArgsConstructor
@Getter
public enum FeatureType {
    STRING,
    BOOLEAN,
    NUMBER;

    private static final Map<FeatureType, FeatureTypeParser> PARSER_MAP = new HashMap<>();

    static {
            PARSER_MAP.put(BOOLEAN, ValueParser::parseBoolean);
            PARSER_MAP.put(NUMBER, ValueParser::parseDouble);
            PARSER_MAP.put(STRING, ValueParser::parseString);
    }

    public static FeatureTypeParser getFeatureTypeParser(FeatureType featureType) {
        return PARSER_MAP.get(featureType);
    }

    public static boolean isValid(String name) {
        try {
            FeatureType.valueOf(name);
        } catch (IllegalArgumentException e) {
            return false;
        }
        return true;
    }
}
