package com.maf.pim.enums;


import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;

@AllArgsConstructor
@Getter
@Slf4j
public enum ProductType {
    FOOD("FOOD"),
    NONFOOD("NONFOOD"),
    DIGITAL_PRODUCT("DIGITALPRODUCT"),
    SERVICE_PRODUCT("SERVICE"),
    PRODUCT("PRODUCT");

    private String code;

    public static ProductType getTypeByValue(String value) {
        try {
            return ProductType.valueOf(value);
        } catch (IllegalArgumentException exception) {
            log.warn("No Product Nature Enum Found " + value);
        }
        return null;
    }
}
