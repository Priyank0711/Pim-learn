package com.maf.pim.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
@Getter
public enum MediaType {
    PRIMARY ,
    GALLERY
}
