package com.maf.pim.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
@Getter
public enum Language {

    EN("EN"),
    AR("AR");

    private String code;
}
