package com.maf.pim.enums;

import lombok.extern.slf4j.Slf4j;

import java.util.Arrays;
import java.util.Set;
import java.util.stream.Collectors;

@Slf4j
public enum ProductSection {
    PROPERTIES,
    ATTRIBUTES,
    CATEGORIES,
    MULTIMEDIA;

    public static boolean isValid(String name) {
        try {
            ProductSection.valueOf(name);
        } catch (IllegalArgumentException e) {
            return false;
        }
        return true;
    }

    public static Set<ProductSection> toSet() {
        return Arrays.stream(values()).collect(Collectors.toSet());
    }
}
