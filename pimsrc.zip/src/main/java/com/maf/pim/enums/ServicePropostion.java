package com.maf.pim.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.util.StringUtils;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

@AllArgsConstructor
@Getter
@Slf4j
public enum ServicePropostion {

    BULK("BULK"),
    STANDARD("STANDARD"),
    EXPRESS("EXPRESS"),
    DEFAULT("DEFAULT"),
    CLICK_N_COLLECT("CLICK_N_COLLECT"),
    QCOMM("QCOMM"),
    SAME_DAY_DELIVERY("SAME_DAY_DELIVERY");

    private final String value;

    public static List<ServicePropostion> getPropositionByValueList(String value) {
        if (!StringUtils.hasText(value)) {
            return Collections.emptyList();
        }

        return Arrays.stream(value.split(","))
                .map(String::trim)
                .map(v -> {
                    try {
                        return ServicePropostion.valueOf(v);
                    } catch (IllegalArgumentException e) {
                        log.warn("No Product Nature Enum Found: " + v);
                        return null;
                    }
                })
                .filter(Objects::nonNull)
                .collect(Collectors.toList());
    }
}
