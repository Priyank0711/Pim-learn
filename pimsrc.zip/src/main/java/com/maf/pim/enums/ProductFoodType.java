package com.maf.pim.enums;


import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;

@AllArgsConstructor
@Getter
@Slf4j
public enum ProductFoodType {
    NORMAL,
    SCALABLE;

    public static ProductFoodType getProductFoodTypeByValue(String value) {
        try {
            return ProductFoodType.valueOf(value);
        } catch (IllegalArgumentException exception) {
            log.warn("No Product Food Type Enum Found " + value);
        }
        return null;
    }
}
