package com.maf.pim.enums;
public enum FileResultTpe {
        PROCESSED,
        PARTIALLY_PROCESSED,
        FAILED,
        ERROR

}
