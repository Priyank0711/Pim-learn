package com.maf.pim.entity;

import com.maf.pim.comparator.MediaComparator;
import com.maf.pim.entity.translation.ProductTranslation;
import com.maf.pim.enums.*;
import com.maf.pim.util.Auditable;
import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.BatchSize;
import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import java.time.Instant;
import java.util.*;
import java.util.stream.Collectors;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class ProductNative extends Product {

    private String supplierIdNative;
    private String[] assortmentsNative;
    private String natureNative;
    private String countryNative;
    private String productTypeNative;
    private String productFoodTypeNative;

    public static ProductNative from(String code, Country country) {
        ProductNative product = new ProductNative();
        product.setId(ProductId.from(code, country));
        product.setApprovalStatus(ApprovalStatus.NEW);
        product.setCreationTime(Instant.now());
        product.setCountryNative(country.name());
        return product;
    }
}