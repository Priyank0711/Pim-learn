package com.maf.pim.entity;

import com.maf.pim.enums.AttributeGroup;
import com.maf.pim.enums.Country;
import com.maf.pim.enums.ProductType;
import com.maf.pim.util.Auditable;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Objects;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Entity
@Table(name = "core_attribute", uniqueConstraints={@UniqueConstraint(columnNames={"attrCode", "attrType", "groupCode","country"})})
public class CoreAttribute extends Auditable<Long> {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String attrCode;
    private String attrName;
    private String attrLevel;
    @Enumerated(EnumType.STRING)
    private ProductType attrType;
    @Enumerated(EnumType.STRING)
    private AttributeGroup groupCode;
    private String dataType;
    @Enumerated(EnumType.STRING)
    private Country country;
    private boolean active = true;
    private String example;
    private String definition;
    private Integer displayOrder;
    private boolean multiLang;

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        CoreAttribute that = (CoreAttribute) o;
        return Objects.equals(getAttrCode(), that.getAttrCode()) && getAttrType() == that.getAttrType() && getGroupCode() == that.getGroupCode() && getCountry() == that.getCountry();
    }

    @Override
    public int hashCode() {
        return Objects.hash(getAttrCode(), getAttrType(), getGroupCode(), getCountry());
    }

}
