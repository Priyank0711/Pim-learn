package com.maf.pim.entity;

public interface SupplierGimaStatusesProjection {

    String getProductCode();
    String getSupplierId();
    String[] getSupplierGimaStatuses();

    void setProductCode(String productCode);
    void setSupplierId(String supplierId);
    void setSupplierGimaStatuses(String[] supplierGimaStatuses);
}
