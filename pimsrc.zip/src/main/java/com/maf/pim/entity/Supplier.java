package com.maf.pim.entity;

import com.maf.pim.enums.Country;
import com.maf.pim.util.Auditable;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(onlyExplicitlyIncluded = true, callSuper = false)
@Entity
@Table(name = "supplier", uniqueConstraints = {@UniqueConstraint(columnNames = {"code", "country"})})
public class Supplier extends Auditable<String> {

    @EqualsAndHashCode.Include
    @Id
    private String id;

    @EqualsAndHashCode.Include
    private String code;

    @EqualsAndHashCode.Include
    @Enumerated(EnumType.STRING)
    private Country country;

    private String description;

    private String contactName;

    private String streetName;

    private String firstAddress;

    private String secondAddress;

    private String poBox;

    private String city;

    private String regionCode;

    private String countryCode;

    private String telephone;

    private String telephonePost;

    private String faxNumber;

    private String currency;

    private String email;

    private String codeCountry;

    public static Supplier from(String code, Country country) {
        Supplier supplier = new Supplier();
        supplier.setId(createSupplierId(code, country));
        supplier.setCountry(country);
        return supplier;
    }

    public static String createSupplierId(String code, Country country) {
        return code+"_"+country.getCode().toLowerCase();
    }

    public static String getSupplierCodeFromSupplierId(String id, Country country) {
        int lastIndexOf = id.lastIndexOf("_"+country.getCode().toLowerCase());
        return id.substring(0, lastIndexOf);
    }
}
