package com.maf.pim.entity;

import com.maf.pim.enums.JobStatus;
import com.maf.pim.util.Auditable;
import jakarta.persistence.*;
import lombok.Data;

import java.time.Instant;

@Data
@Entity
@Table(name = "cron_job")
public class CronJob extends Auditable<String> {
    @Id
    private String id;
    @Enumerated(EnumType.STRING)
    private JobStatus status;
    private Instant lastUpdated;
    private Instant startDate;
    private Instant endDate;

}
