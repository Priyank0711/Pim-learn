package com.maf.pim.entity;

import com.maf.pim.enums.FeatureType;
import com.maf.pim.util.Auditable;
import jakarta.persistence.*;
import lombok.*;

import java.util.Objects;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Entity
@Table(name = "attribute_assignment", uniqueConstraints={@UniqueConstraint(columnNames={"attribute_id","classification_id"})})
public class AttributeAssignment extends Auditable<Long> {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private Boolean multiLang;

    @Enumerated(EnumType.STRING)
    private FeatureType featureType;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "attribute_id")
    private Attribute attribute;

    @ToString.Exclude
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "classification_id") // Explicitly specifying foreign key column
    private ClassificationClass classificationClass;

    private Integer displayOrder;
    private boolean comparable;

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        AttributeAssignment that = (AttributeAssignment) o;
        return id != null &&
                id.equals(that.getId());
    }

    @Override
    public int hashCode() {
        return id!=null? Objects.hash(id):getClass().hashCode();
    }
}
