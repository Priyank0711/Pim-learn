package com.maf.pim.entity;

import com.maf.pim.comparator.MediaComparator;
import com.maf.pim.entity.translation.ProductTranslation;
import com.maf.pim.enums.*;
import com.maf.pim.util.Auditable;
import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.BatchSize;
import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import java.time.Instant;
import java.util.*;
import java.util.stream.Collectors;

@AllArgsConstructor
@NoArgsConstructor
@Data
@EqualsAndHashCode(onlyExplicitlyIncluded = true, callSuper = false)
@EntityListeners(value = AuditingEntityListener.class)
@Entity
@Table(name = "product")
@DynamicUpdate
@DynamicInsert
public class Product extends Auditable<ProductId> {

    @EmbeddedId
    @EqualsAndHashCode.Include
    private ProductId id;

    @ManyToMany( fetch = FetchType.LAZY)
    @JoinTable(
            name = "product_category", inverseJoinColumns = {@JoinColumn(name = "category_id", referencedColumnName = "id")}
    )
    @BatchSize(size = 50)
    private Set<Category> categories;

    @OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "id.product")
    @BatchSize(size = 50)
    private Set<ProductTranslation> productTranslations;

    private String ean;
    private Boolean expressProduct;
    @Enumerated(EnumType.STRING)
    private ProductType productType;

    @Enumerated(EnumType.STRING)
    private ApprovalStatus approvalStatus;
    private Instant statusStartDate;
    private Instant statusEndDate;
    private String department;
    private String section;
    private String family;
    private String subFamily;
    private String itemStatus;
    private Double grossWeight;
    private Integer minOrderQuantity;
    private Double width;
    private Double weight;
    private Double height;
    private Double depth;
    private Integer maxToOrder;
    private Integer unitItem;
    private List<String> barcodes;
    private List<String> assortments;
    private Boolean marketplaceProduct;
    private String itemMeasure;
    private Integer loyaltyPoint;
    private Integer deliveryTime;
    @Enumerated(EnumType.STRING)
    private ProductNature nature;
    private Double weightIncrement;
    private Double averageWeightByPiece;
    private Double weightVariation;
    private Integer nbrOfMonth;
    private Integer averagePieceByKg;
    @Enumerated(EnumType.STRING)
    private ProductFoodType productFoodType;
    private Boolean freeDelivery;
    private Boolean freeInstallation;
    private Boolean genuineStock;
    private Boolean onDemand;
    private Boolean preorder;
    private Instant preOrderDeliveryTime;
    private String codeDeliveryGica;

    private Boolean warranty;
    @Enumerated(EnumType.STRING)
    private WarrantyType warrantyType;
    private Integer yearOfWarranty;

    @OneToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private Media media;

    @OneToOne(fetch = FetchType.LAZY)
    private Supplier supplier;

    @OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @JoinTable(name = "product_gallery",
            joinColumns = {@JoinColumn(name = "product_country", referencedColumnName = "country"), @JoinColumn(name = "product_code", referencedColumnName = "code")},
            inverseJoinColumns = {@JoinColumn(name = "media_country", referencedColumnName = "country"), @JoinColumn(name = "media_code", referencedColumnName = "code")}
    )
    @BatchSize(size = 50)
    private Set<Media> gallery;

    private String gicaVatCod;
    private String gicaVatPer;
    private Boolean substituted;
    private Integer maxOrderQuantity;
    private Instant loyaltyPointsStartDate;
    private Instant loyaltyPointsEndDate;
    private Double minimumWeightToOrder;
    private Boolean nonReplenishable;
    private Double numberOfUnit;
    private Instant creationTime;
    private List<String> unpublishedPos;
    private String sellerId;
    private String superSellerId;
    private boolean enriched;
    @Enumerated(EnumType.STRING)
    private List<ServicePropostion> serviceProposition;

    @Setter(AccessLevel.NONE)
    @OneToMany(fetch = FetchType.LAZY)
    @JoinColumns(value = {@JoinColumn(name = "productCode", referencedColumnName = "code", insertable = false, updatable = false), @JoinColumn(name = "country", referencedColumnName = "country", insertable = false, updatable = false)})
    private Set<SupplierGima> supplierGimas;

    public Set<Media> getGallery() {
        return this.gallery != null ? gallery.stream()
                .sorted(Comparator.nullsLast(new MediaComparator()))
                .collect(Collectors.toCollection(LinkedHashSet::new)) : new HashSet<>();
    }

    public static Product from(String code, Country country) {
        Product product = new Product();
        product.setId(ProductId.from(code, country));
        product.setApprovalStatus(ApprovalStatus.NEW);
        product.setCreationTime(Instant.now());
        return product;
    }

    public static Product getNewMarketPlaceProduct(String code, Country country) {
        Product product = new Product();
        product.setId(ProductId.from(code, country));
        product.setEan(code);
        product.setApprovalStatus(ApprovalStatus.APPROVED);
        product.setCreationTime(Instant.now());
        product.setMarketplaceProduct(true);
        product.setProductType(ProductType.NONFOOD);
        return product;
    }

}