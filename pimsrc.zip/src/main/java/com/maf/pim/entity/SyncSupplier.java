package com.maf.pim.entity;

import com.maf.pim.enums.Country;
import jakarta.persistence.*;
import lombok.Data;

import java.util.Set;
import java.util.stream.Collectors;

@Entity
@Data
@Table(name = "sync_suppliers",uniqueConstraints = {@UniqueConstraint(columnNames = "country")})
public class SyncSupplier {

    @Id
    @Enumerated(EnumType.STRING)
    private Country country;
    private Set<String> suppliers;

    public static Set<String> createSupplierIds(Set<String> suppliers, Country country) {
        return suppliers.stream()
                .map(code -> Supplier.createSupplierId(code, country))
                .collect(Collectors.toSet());
    }
}
