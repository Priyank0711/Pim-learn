package com.maf.pim.entity;

import com.maf.pim.entity.translation.ClassificationClassTranslation;
import com.maf.pim.enums.Country;
import com.maf.pim.util.Auditable;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.BatchSize;

import java.util.Set;

@AllArgsConstructor
@NoArgsConstructor
@Data
@EqualsAndHashCode(onlyExplicitlyIncluded = true, callSuper = false)
@Entity
@Table(name = "classification_class", uniqueConstraints={@UniqueConstraint(columnNames={"code","country"})})
public class ClassificationClass extends Auditable<String> {

    @EqualsAndHashCode.Include
    @Id
    private String id;
    @EqualsAndHashCode.Include
    private String code;

    @EqualsAndHashCode.Include
    @Enumerated(EnumType.STRING)
    private Country country;

    @OneToMany(cascade = { CascadeType.ALL }, fetch = FetchType.LAZY, mappedBy = "classificationClass")
    private Set<ParentClassification> parentClassifications;

    @BatchSize(size = 50)
    @OneToMany(cascade = { CascadeType.ALL }, fetch = FetchType.LAZY, mappedBy = "classificationClass")
    private Set<ClassificationClassTranslation> classificationClassTranslations;

    @OneToMany(cascade = { CascadeType.ALL }, fetch = FetchType.LAZY, mappedBy = "classificationClass")
    private Set<AttributeAssignment> attributeAssignments;

    public static ClassificationClass from(String code, Country country) {
        ClassificationClass classificationClass = new ClassificationClass();
        classificationClass.setId(createClassificationClassId(code, country));
        classificationClass.setCode(code);
        classificationClass.setCountry(country);
        return classificationClass;
    }

    public static String createClassificationClassId(String code, Country country) {
        return code+"_"+country.getCode().toLowerCase();
    }

}
