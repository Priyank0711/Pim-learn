package com.maf.pim.entity;

import com.maf.pim.enums.Country;
import jakarta.persistence.Embeddable;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Embeddable
public class MediaId implements Serializable {
    private String code;

    @Enumerated(EnumType.STRING)
    private Country country;

    public static MediaId from(String code, Country country) {
        return new MediaId(code, country);
    }
}
