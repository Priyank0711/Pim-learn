package com.maf.pim.entity;

import com.maf.pim.enums.Country;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Embeddable
public class SupplierGimaId {

    private String productCode;

    @Enumerated(EnumType.STRING)
    private Country country;

    private String pos;

    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "supplier_id")
    private Supplier supplier;

    public static SupplierGimaId from(String productCode, Country country, String pos, Supplier supplier) {
        return new SupplierGimaId(productCode, country, pos, supplier);
    }
}
