package com.maf.pim.entity;

import com.maf.pim.enums.Country;
import com.maf.pim.util.Auditable;
import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

@AllArgsConstructor
@NoArgsConstructor
@Data
@EqualsAndHashCode(onlyExplicitlyIncluded = true, callSuper = false)
@Entity
@Table(name = "media")
@DynamicUpdate
@DynamicInsert
public class Media extends Auditable<MediaId> {
    @EqualsAndHashCode.Include
    @EmbeddedId
    private MediaId id;
    private String name;
    private String format;
    private String masterUrl;
    private String url;
    private String relativePath;

    public static Media from(String code, Country country) {
        Media media = new Media();
        media.setId(MediaId.from(code, country));
        return media;
    }
}
