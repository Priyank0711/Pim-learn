package com.maf.pim.entity;

import com.maf.pim.util.Auditable;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.util.Objects;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Entity
@Table(name = "parent_classification", uniqueConstraints={@UniqueConstraint(columnNames={"child_id","parent_id"})})
public class ParentClassification extends Auditable<Long> {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ToString.Exclude
    @ManyToOne
    @JoinColumn(name = "child_id")
    private ClassificationClass classificationClass;

    private String parentId;

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ParentClassification that = (ParentClassification) o;
        return id != null &&
                id.equals(that.getId());
    }

    @Override
    public int hashCode() {
        return id!=null? Objects.hash(id):getClass().hashCode();
    }

    public static ParentClassification from(ClassificationClass classificationClass, String parentId) {
        ParentClassification parentClassification = new ParentClassification();
        parentClassification.setClassificationClass(classificationClass);
        parentClassification.setParentId(parentId);
        return parentClassification;
    }
}
