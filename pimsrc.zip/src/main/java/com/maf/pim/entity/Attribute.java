package com.maf.pim.entity;

import com.maf.pim.entity.translation.AttributeTranslation;
import com.maf.pim.enums.Country;
import com.maf.pim.util.Auditable;
import jakarta.persistence.*;
import lombok.*;

import java.util.Set;

@AllArgsConstructor
@NoArgsConstructor
@Data
@EqualsAndHashCode(onlyExplicitlyIncluded = true, callSuper = false)
@Entity
@Table(name = "attribute", uniqueConstraints={@UniqueConstraint(columnNames={"code","country"})})
public class Attribute extends Auditable<String> {

    @EqualsAndHashCode.Include
    @Id
    private String id;

    @EqualsAndHashCode.Include
    private String code;

    @EqualsAndHashCode.Include
    @Enumerated(EnumType.STRING)
    private Country country;

    @OneToMany(cascade = { CascadeType.ALL }, fetch = FetchType.LAZY, mappedBy = "attribute")
    private Set<AttributeTranslation> attributeTranslations;

    public static Attribute from(String enAttributeCode, Country country) {
        Attribute attribute = new Attribute();
        attribute.setId(Attribute.createAttributeId(enAttributeCode, country));
        attribute.setCode(enAttributeCode);
        attribute.setCountry(country);
        return attribute;
    }

    /**
     * 
     * @param enAttributeCode English attribute code
     * @param country country
     * @return Attribute id
     */
    public static String createAttributeId(String enAttributeCode, Country country) {
        String[] attributeParts = enAttributeCode.split(" ");
        return String.join("_", attributeParts).concat("_"+country.getCode().toLowerCase());
    }
}
