package com.maf.pim.entity;

import com.maf.pim.enums.Country;
import jakarta.persistence.Embeddable;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Embeddable
public class GicaReferenceId {
    private String department;
    private String section;
    private String family;
    private String subFamily;
    @Enumerated(EnumType.STRING)
    private Country country;

    public static GicaReferenceId from(String department, String section, String family, String subFamily, Country country) {
        return new GicaReferenceId(department, section, family, subFamily, country);
    }
}
