package com.maf.pim.entity;

import com.maf.pim.dto.LTreeType;
import com.maf.pim.entity.translation.CategoryTranslation;
import com.maf.pim.enums.CategoryType;
import com.maf.pim.enums.Country;
import com.maf.pim.util.Auditable;
import com.maf.pim.util.CategoryIdSpecialCharacterMapper;
import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.BatchSize;
import org.hibernate.annotations.Type;

import java.time.Instant;
import java.util.HashSet;
import java.util.Set;

@AllArgsConstructor
@NoArgsConstructor
@Data
@EqualsAndHashCode(onlyExplicitlyIncluded = true, callSuper = false)
@Entity
@Table(name = "category", uniqueConstraints={@UniqueConstraint(columnNames={"code","country"})})
public class Category extends Auditable<String> {

    @EqualsAndHashCode.Include
    @Id
    private String id;

    @EqualsAndHashCode.Include
    private String code;

    @EqualsAndHashCode.Include
    @Enumerated(EnumType.STRING)
    private Country country;

    private String parentId;

    @Enumerated(EnumType.STRING)
    private CategoryType categoryType;

    @Column(name="path", nullable = false, columnDefinition="ltree")
    @Type(LTreeType.class)
    private String path;

    private Boolean substituted;

    @ManyToMany( fetch = FetchType.LAZY)
    @JoinTable(
            name = "category_classification", inverseJoinColumns = {@JoinColumn(name = "classification_id",referencedColumnName = "id")}
    )
    @BatchSize(size = 50)
    private Set<ClassificationClass> classifications;

    @OneToMany(cascade = { CascadeType.ALL }, fetch = FetchType.LAZY, mappedBy = "category")
    @BatchSize(size = 50)
    private Set<CategoryTranslation> categoryTranslations;

    @ToString.Exclude
    @Getter(AccessLevel.NONE)
    @Setter(AccessLevel.NONE)
    @EqualsAndHashCode.Exclude
    @ManyToMany(mappedBy = "categories", fetch = FetchType.LAZY)
    private Set<Product> product = new HashSet<>();

    //Variants attributes
    @Column(name = "l1_attr_code")
    private String l1AttrCode;
    @Column(name = "l2_attr_code")
    private String l2AttrCode;
    @Column(name = "l3_attr_code")
    private String l3AttrCode;
    private Integer variantImageLevel;

    private boolean comparable;


    public static Category from(String code, Country country) {
        Category category = new Category();
        category.setId(CategoryIdSpecialCharacterMapper.encode(code + "_" + country.getCode().toLowerCase()));
        category.setCode(code);
        category.setCountry(country);
        category.setModifiedDate(Instant.now());
        return category;
    }
}
