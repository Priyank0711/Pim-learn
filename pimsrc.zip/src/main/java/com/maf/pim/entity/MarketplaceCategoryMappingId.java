package com.maf.pim.entity;

import com.maf.pim.enums.CategoryType;
import com.maf.pim.enums.Country;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Embeddable
public class MarketplaceCategoryMappingId {

    @Enumerated(EnumType.STRING)
    private Country country;

    @OneToOne
    @JoinColumn(name = "source_category")
    private Category sourceCategory;

    @Enumerated(EnumType.STRING)
    private CategoryType categoryType;

    public static MarketplaceCategoryMappingId from(Country country, Category sourceCategory, CategoryType categoryType) {
        return new MarketplaceCategoryMappingId(country, sourceCategory, categoryType);
    }
}
