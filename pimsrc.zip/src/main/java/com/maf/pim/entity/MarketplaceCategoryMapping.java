package com.maf.pim.entity;

import com.maf.pim.util.Auditable;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(onlyExplicitlyIncluded = true, callSuper = false)
@Entity
@Table(name = "marketplace_category_mapping")
public class MarketplaceCategoryMapping extends Auditable<MarketplaceCategoryMappingId> {

    @EmbeddedId
    @EqualsAndHashCode.Include
    private MarketplaceCategoryMappingId id;

    @OneToOne
    @JoinColumn(name = "target_category")
    private Category targetCategory;

    public static MarketplaceCategoryMapping from(MarketplaceCategoryMappingId id) {
        MarketplaceCategoryMapping mcm = new MarketplaceCategoryMapping();
        mcm.setId(id);
        return mcm;
    }
}
