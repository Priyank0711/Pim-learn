package com.maf.pim.entity;

import com.maf.pim.enums.ProductNature;
import com.maf.pim.enums.ProductType;
import com.maf.pim.util.Auditable;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
@EqualsAndHashCode(onlyExplicitlyIncluded = true, callSuper = false)
@Entity
@Table(name = "gica_reference")
public class GicaReference extends Auditable<GicaReferenceId> {

    @EqualsAndHashCode.Include
    @EmbeddedId
    private GicaReferenceId id;
    private String category;
    private String classification;
    @Enumerated(EnumType.STRING)
    private ProductType type;
    @Enumerated(EnumType.STRING)
    private ProductNature nature;

}
