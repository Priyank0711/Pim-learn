package com.maf.pim.entity;

import com.maf.pim.enums.Language;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Embeddable
public class ProductTranslationId {
    @Enumerated(EnumType.STRING)
    private Language language;

    @ToString.Exclude
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumns(value = {@JoinColumn(name = "product_code", referencedColumnName = "code", insertable = false, updatable = false), @JoinColumn(name = "product_country", referencedColumnName = "country", insertable = false, updatable = false)})
    private Product product;
}
