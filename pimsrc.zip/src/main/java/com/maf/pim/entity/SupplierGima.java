package com.maf.pim.entity;

import com.maf.pim.enums.Country;
import com.maf.pim.util.Auditable;
import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import lombok.*;
import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

@Data
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(onlyExplicitlyIncluded = true, callSuper = false)
@Entity
@DynamicUpdate
@DynamicInsert
@Table(name = "supplier_gima")
public class SupplierGima extends Auditable<SupplierGimaId> {

    @EmbeddedId
    @EqualsAndHashCode.Include
    private SupplierGimaId id;

    private String status;

    private String reference;

    public static SupplierGima from(String productCode, Country productCountry, String pos, Supplier supplier) {
        SupplierGima supplierGima = new SupplierGima();
        supplierGima.setId(new SupplierGimaId(productCode, productCountry, pos, supplier));
        return supplierGima;
    }
}