package com.maf.pim.scheduler;

import com.maf.pim.constants.Constants;
import com.maf.pim.context.SessionContext;
import com.maf.pim.enums.Country;
import com.maf.pim.service.ExportVariantsService;
import lombok.extern.slf4j.Slf4j;
import net.javacrumbs.shedlock.spring.annotation.SchedulerLock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;

@Slf4j
public class ExportVariantsScheduler {
    @Autowired
    private ExportVariantsService exportVariantsService;


    @Scheduled(cron = "#{configurationService.exportVariantsSchedulerCronForCountry('UAE')}")
    @SchedulerLock(name = "uae_exportVariant_Job", lockAtLeastFor="${uae.variant.export.job.shedlock.lockAtLeastFor.duration}",lockAtMostFor = "${uae.variant.export.job.shedlock.lockAtMostFor.duration}")
    public void exportSchedulerJobUae() {
        log.info("uae_exportVariant_Job started.");
        final SessionContext context = new SessionContext();
        context.setCountry(Country.UAE);
        context.setLanguages(Country.UAE.getLanguages());
        exportVariantsService.executeJob(Constants.UAE_EXPORT_VARIANT_JOB_CODE,context);
        log.info("uae_exportVariant_Job ended.");
    }

}
