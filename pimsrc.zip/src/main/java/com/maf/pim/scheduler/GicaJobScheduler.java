package com.maf.pim.scheduler;

import com.maf.pim.enums.Country;
import com.maf.pim.service.BlobFileService;
import lombok.extern.slf4j.Slf4j;
import net.javacrumbs.shedlock.spring.annotation.SchedulerLock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;

import static com.maf.pim.constants.Constants.OFF_HOURS_INPUT_PATH;

@Slf4j
public class GicaJobScheduler {
    @Autowired
    BlobFileService blobFileService;

    @Scheduled(cron = "#{configurationService.gicaSchedulerCronForCountry('LBN')}")
    @SchedulerLock(name = "gica_integration_scheduleJob", lockAtLeastFor="${lbn.scheduler.job.shedlock.lockAtLeastFor.duration}",lockAtMostFor = "${lbn.scheduler.job.shedlock.lockAtMostFor.duration}")
    public void gicaIntegrationLbnSchedulerJob() {
        log.info("gica_integration_scheduleJob started for LBN.");
        blobFileService.executeJob(Country.LBN);
    }

    @Scheduled(cron = "#{configurationService.gicaSchedulerCronForCountry('KEN')}")
    @SchedulerLock(name = "gica_integration_ken_scheduleJob", lockAtLeastFor="${ken.scheduler.job.shedlock.lockAtLeastFor.duration}",lockAtMostFor = "${ken.scheduler.job.shedlock.lockAtMostFor.duration}")
    public void gicaIntegrationKenSchedulerJob() {
        log.info("gica_integration_scheduleJob started for KEN.");
        blobFileService.executeJob(Country.KEN);
    }

    @Scheduled(cron = "#{configurationService.gicaSchedulerCronForCountry('PAK')}")
    @SchedulerLock(name = "gica_integration_pak_scheduleJob", lockAtLeastFor="${pak.scheduler.job.shedlock.lockAtLeastFor.duration}",lockAtMostFor = "${pak.scheduler.job.shedlock.lockAtMostFor.duration}")
    public void gicaIntegrationPakSchedulerJob() {
        log.info("gica_integration_scheduleJob started for PAK.");
        blobFileService.executeJob(Country.PAK);
    }

    @Scheduled(cron = "#{configurationService.gicaSchedulerCronForCountry('JOR')}")
    @SchedulerLock(name = "gica_integration_jor_scheduleJob", lockAtLeastFor="${jor.scheduler.job.shedlock.lockAtLeastFor.duration}",lockAtMostFor = "${jor.scheduler.job.shedlock.lockAtMostFor.duration}")
    public void gicaIntegrationJorSchedulerJob() {
        log.info("gica_integration_scheduleJob started for JOR.");
        blobFileService.executeJob(Country.JOR);
    }

    @Scheduled(cron = "#{configurationService.gicaSchedulerCronForCountry('KWT')}")
    @SchedulerLock(name = "gica_integration_kwt_scheduleJob", lockAtLeastFor="${kwt.scheduler.job.shedlock.lockAtLeastFor.duration}",lockAtMostFor = "${kwt.scheduler.job.shedlock.lockAtMostFor.duration}")
    public void gicaIntegrationKwtSchedulerJob() {
        log.info("gica_integration_scheduleJob started for KWT.");
        blobFileService.executeJob(Country.KWT);
    }

    @Scheduled(cron = "#{configurationService.gicaSchedulerCronForCountry('BHR')}")
    @SchedulerLock(name = "gica_integration_bhr_scheduleJob", lockAtLeastFor="${bhr.scheduler.job.shedlock.lockAtLeastFor.duration}",lockAtMostFor = "${bhr.scheduler.job.shedlock.lockAtMostFor.duration}")
    public void gicaIntegrationBhrSchedulerJob() {
        log.info("gica_integration_scheduleJob started for BHR.");
        blobFileService.executeJob(Country.BHR);
    }

    @Scheduled(cron = "#{configurationService.gicaSchedulerCronForCountry('SAU')}")
    @SchedulerLock(name = "gica_integration_sau_scheduleJob", lockAtLeastFor="${sau.scheduler.job.shedlock.lockAtLeastFor.duration}",lockAtMostFor = "${sau.scheduler.job.shedlock.lockAtMostFor.duration}")
    public void gicaIntegrationSauSchedulerJob() {
        log.info("gica_integration_scheduleJob started for SAU.");
        blobFileService.executeJob(Country.SAU);
    }

    @Scheduled(cron = "#{configurationService.gicaSchedulerCronForCountry('UAE')}")
    @SchedulerLock(name = "gica_integration_uae_scheduleJob", lockAtLeastFor="${uae.scheduler.job.shedlock.lockAtLeastFor.duration}",lockAtMostFor = "${uae.scheduler.job.shedlock.lockAtMostFor.duration}")
    public void gicaIntegrationUaeSchedulerJob() {
        log.info("gica_integration_scheduleJob started for UAE.");
        blobFileService.executeJob(Country.UAE);
    }

    @Scheduled(cron = "#{configurationService.gicaSchedulerCronForCountry('QAT')}")
    @SchedulerLock(name = "gica_integration_qat_scheduleJob", lockAtLeastFor="${qat.scheduler.job.shedlock.lockAtLeastFor.duration}",lockAtMostFor = "${qat.scheduler.job.shedlock.lockAtMostFor.duration}")
    public void gicaIntegrationQatSchedulerJob() {
        log.info("gica_integration_scheduleJob started for QAT.");
        blobFileService.executeJob(Country.QAT);
    }

    @Scheduled(cron = "#{configurationService.gicaSchedulerCronForCountry('EGY')}")
    @SchedulerLock(name = "gica_integration_egy_scheduleJob", lockAtLeastFor="${egy.scheduler.job.shedlock.lockAtLeastFor.duration}",lockAtMostFor = "${egy.scheduler.job.shedlock.lockAtMostFor.duration}")
    public void gicaIntegrationEgySchedulerJob() {
        log.info("gica_integration_scheduleJob started for EGY.");
        blobFileService.executeJob(Country.EGY);
    }

    @Scheduled(cron = "#{configurationService.gicaSchedulerCronForCountry('OMN')}")
    @SchedulerLock(name = "gica_integration_omn_scheduleJob", lockAtLeastFor="${omn.scheduler.job.shedlock.lockAtLeastFor.duration}",lockAtMostFor = "${omn.scheduler.job.shedlock.lockAtMostFor.duration}")
    public void gicaIntegrationOmnSchedulerJob() {
        log.info("gica_integration_scheduleJob started for OMN.");
        blobFileService.executeJob(Country.OMN);
    }

    @Scheduled(cron = "#{configurationService.offHoursGicaSchedulerCronForCountry('UAE')}", zone = "Asia/Dubai")
    @SchedulerLock(name = "offhours_gica_integration_uae_scheduleJob", lockAtLeastFor="${uae.offhours.scheduler.job.shedlock.lockAtLeastFor.duration}",lockAtMostFor = "${uae.offhours.scheduler.job.shedlock.lockAtMostFor.duration}")
    public void offHoursGicaIntegrationUae() {
        log.info("offhours_gica_integration_uae_scheduleJob started for UAE.");
        blobFileService.executeJob(Country.UAE, OFF_HOURS_INPUT_PATH);
    }
}