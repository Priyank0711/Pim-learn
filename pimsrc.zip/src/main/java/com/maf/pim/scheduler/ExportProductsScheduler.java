package com.maf.pim.scheduler;

import com.maf.pim.constants.Constants;
import com.maf.pim.context.SessionContext;
import com.maf.pim.enums.Country;
import com.maf.pim.enums.ProductPicker;
import com.maf.pim.service.ExportProductsService;
import lombok.extern.slf4j.Slf4j;
import net.javacrumbs.shedlock.spring.annotation.SchedulerLock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;

@Slf4j
public class ExportProductsScheduler {
    @Autowired
    private ExportProductsService exportProductsService;

    @Scheduled(cron = "#{configurationService.exportProductsSchedulerCronForCountry('LBN')}")
    @SchedulerLock(name = "lbn_exportProduct_Job", lockAtLeastFor="${lbn.export.job.shedlock.lockAtLeastFor.duration}",lockAtMostFor = "${lbn.export.job.shedlock.lockAtMostFor.duration}")
    public void exportSchedulerJob() {
        log.info("lbn_exportProduct_Job started.");
        final SessionContext context = new SessionContext();
        context.setCountry(Country.LBN);
        context.setLanguages(Country.LBN.getLanguages());
        context.setProductPickers(ProductPicker.getProductPickers(Country.LBN));
        exportProductsService.executeJob(Constants.LBN_EXPORT_JOB_CODE,context);
        log.info("lbn_exportProduct_Job ended.");
    }

    @Scheduled(cron = "#{configurationService.exportProductsSchedulerCronForCountry('KEN')}")
    @SchedulerLock(name = "ken_exportProduct_Job", lockAtLeastFor="${ken.export.job.shedlock.lockAtLeastFor.duration}",lockAtMostFor = "${ken.export.job.shedlock.lockAtMostFor.duration}")
    public void exportSchedulerJobKen() {
        log.info("ken_exportProduct_Job started.");
        final SessionContext context = new SessionContext();
        context.setCountry(Country.KEN);
        context.setLanguages(Country.KEN.getLanguages());
        context.setProductPickers(ProductPicker.getProductPickers(Country.KEN));
        exportProductsService.executeJob(Constants.KEN_EXPORT_JOB_CODE,context);
        log.info("ken_exportProduct_Job ended.");
    }

    @Scheduled(cron = "#{configurationService.exportProductsSchedulerCronForCountry('PAK')}")
    @SchedulerLock(name = "pak_exportProduct_Job", lockAtLeastFor="${pak.export.job.shedlock.lockAtLeastFor.duration}",lockAtMostFor = "${pak.export.job.shedlock.lockAtMostFor.duration}")
    public void exportSchedulerJobPak() {
        log.info("pak_exportProduct_Job started.");
        final SessionContext context = new SessionContext();
        context.setCountry(Country.PAK);
        context.setLanguages(Country.PAK.getLanguages());
        context.setProductPickers(ProductPicker.getProductPickers(Country.PAK));
        exportProductsService.executeJob(Constants.PAK_EXPORT_JOB_CODE,context);
        log.info("pak_exportProduct_Job ended.");
    }

    @Scheduled(cron = "#{configurationService.exportProductsSchedulerCronForCountry('JOR')}")
    @SchedulerLock(name = "jor_exportProduct_Job", lockAtLeastFor="${jor.export.job.shedlock.lockAtLeastFor.duration}",lockAtMostFor = "${jor.export.job.shedlock.lockAtMostFor.duration}")
    public void exportSchedulerJobJor() {
        log.info("jor_exportProduct_Job started.");
        final SessionContext context = new SessionContext();
        context.setCountry(Country.JOR);
        context.setLanguages(Country.JOR.getLanguages());
        context.setProductPickers(ProductPicker.getProductPickers(Country.JOR));
        exportProductsService.executeJob(Constants.JOR_EXPORT_JOB_CODE,context);
        log.info("jor_exportProduct_Job ended.");
    }

    @Scheduled(cron = "#{configurationService.exportProductsSchedulerCronForCountry('KWT')}")
    @SchedulerLock(name = "kwt_exportProduct_Job", lockAtLeastFor="${kwt.export.job.shedlock.lockAtLeastFor.duration}",lockAtMostFor = "${kwt.export.job.shedlock.lockAtMostFor.duration}")
    public void exportSchedulerJobKwt() {
        log.info("kwt_exportProduct_Job started.");
        final SessionContext context = new SessionContext();
        context.setCountry(Country.KWT);
        context.setLanguages(Country.KWT.getLanguages());
        context.setProductPickers(ProductPicker.getProductPickers(Country.KWT));
        exportProductsService.executeJob(Constants.KWT_EXPORT_JOB_CODE,context);
        log.info("kwt_exportProduct_Job ended.");
    }

    @Scheduled(cron = "#{configurationService.exportProductsSchedulerCronForCountry('BHR')}")
    @SchedulerLock(name = "bhr_exportProduct_Job", lockAtLeastFor="${bhr.export.job.shedlock.lockAtLeastFor.duration}",lockAtMostFor = "${bhr.export.job.shedlock.lockAtMostFor.duration}")
    public void exportSchedulerJobBhr() {
        log.info("bhr_exportProduct_Job started.");
        final SessionContext context = new SessionContext();
        context.setCountry(Country.BHR);
        context.setLanguages(Country.BHR.getLanguages());
        context.setProductPickers(ProductPicker.getProductPickers(Country.BHR));
        exportProductsService.executeJob(Constants.BHR_EXPORT_JOB_CODE,context);
        log.info("bhr_exportProduct_Job ended.");
    }

    @Scheduled(cron = "#{configurationService.exportProductsSchedulerCronForCountry('SAU')}")
    @SchedulerLock(name = "sau_exportProduct_mkt_Job", lockAtLeastFor="${sau.export.job.shedlock.lockAtLeastFor.duration}",lockAtMostFor = "${sau.export.job.shedlock.lockAtMostFor.duration}")
    public void exportSchedulerJobSauMtK() {
        log.info("sau_exportProduct_mkt_Job marketplace started.");
        final SessionContext context = new SessionContext();
        context.setCountry(Country.SAU);
        context.setLanguages(Country.SAU.getLanguages());
        context.setProductPickers(ProductPicker.getProductPickersMkt(Country.SAU));
        context.setMarketplaceProduct(true);
        exportProductsService.executeJob(Constants.SAU_MKP_EXPORT_JOB_CODE,context);
        log.info("sau_exportProduct_mkt_Job marketplace ended.");
    }

    @Scheduled(cron = "#{configurationService.exportProductsSchedulerCronForCountry('SAU')}")
    @SchedulerLock(name = "sau_exportProduct_Job", lockAtLeastFor="${sau.export.job.shedlock.lockAtLeastFor.duration}",lockAtMostFor = "${sau.export.job.shedlock.lockAtMostFor.duration}")
    public void exportSchedulerJobSau() {
        log.info("sau_exportProduct_Job Retail started.");
        final SessionContext context = new SessionContext();
        context.setCountry(Country.SAU);
        context.setLanguages(Country.SAU.getLanguages());
        context.setProductPickers(ProductPicker.getProductPickers(Country.SAU));
        exportProductsService.executeJob(Constants.SAU_EXPORT_JOB_CODE,context);
        log.info("sau_exportProduct_Job retail ended.");
    }

    @Scheduled(cron = "#{configurationService.exportProductsSchedulerCronForCountry('UAE')}")
    @SchedulerLock(name = "uae_exportProduct_Job", lockAtLeastFor="${uae.export.job.shedlock.lockAtLeastFor.duration}",lockAtMostFor = "${uae.export.job.shedlock.lockAtMostFor.duration}")
    public void exportSchedulerJobUae() {
        log.info("uae_exportProduct_Job started.");
        final SessionContext context = new SessionContext();
        context.setCountry(Country.UAE);
        context.setLanguages(Country.UAE.getLanguages());
        context.setProductPickers(ProductPicker.getProductPickers(Country.UAE));
        exportProductsService.executeJob(Constants.UAE_EXPORT_JOB_CODE,context);
        log.info("uae_exportProduct_Job ended.");
    }

    @Scheduled(cron = "#{configurationService.exportProductsSchedulerCronForCountry('UAE')}")
    @SchedulerLock(name = "uae_exportProduct_mkt_Job", lockAtLeastFor="${uae.export.job.shedlock.lockAtLeastFor.duration}",lockAtMostFor = "${uae.export.job.shedlock.lockAtMostFor.duration}")
    public void exportSchedulerJobUaeMtK() {
        log.info("uae_exportProduct_mkt_Job marketplace started.");
        final SessionContext context = new SessionContext();
        context.setCountry(Country.UAE);
        context.setLanguages(Country.UAE.getLanguages());
        context.setProductPickers(ProductPicker.getProductPickersMkt(Country.UAE));
        context.setMarketplaceProduct(true);
        exportProductsService.executeJob(Constants.UAE_MKP_EXPORT_JOB_CODE,context);
        log.info("uae_exportProduct_mkt_Job marketplace ended.");
    }

    @Scheduled(cron = "#{configurationService.exportProductsSchedulerCronForCountry('QAT')}")
    @SchedulerLock(name = "qat_exportProduct_Job", lockAtLeastFor="${qat.export.job.shedlock.lockAtLeastFor.duration}",lockAtMostFor = "${qat.export.job.shedlock.lockAtMostFor.duration}")
    public void exportSchedulerJobQat() {
        log.info("qat_exportProduct_Job Retail started.");
        final SessionContext context = new SessionContext();
        context.setCountry(Country.QAT);
        context.setLanguages(Country.QAT.getLanguages());
        context.setProductPickers(ProductPicker.getProductPickers(Country.QAT));
        exportProductsService.executeJob(Constants.QAT_EXPORT_JOB_CODE,context);
        log.info("qat_exportProduct_Job retail ended.");
    }

    @Scheduled(cron = "#{configurationService.exportProductsSchedulerCronForCountry('EGY')}")
    @SchedulerLock(name = "egy_exportProduct_mkt_Job", lockAtLeastFor="${egy.export.job.shedlock.lockAtLeastFor.duration}",lockAtMostFor = "${egy.export.job.shedlock.lockAtMostFor.duration}")
    public void exportSchedulerJobEgyMtK() {
        log.info("egy_exportProduct_mkt_Job marketplace started.");
        final SessionContext context = new SessionContext();
        Country country = Country.EGY;
        context.setCountry(country);
        context.setLanguages(country.getLanguages());
        context.setProductPickers(ProductPicker.getProductPickersMkt(country));
        context.setMarketplaceProduct(true);
        exportProductsService.executeJob(Constants.EGY_MKP_EXPORT_JOB_CODE,context);
        log.info("egy_exportProduct_mkt_Job marketplace ended.");
    }

    @Scheduled(cron = "#{configurationService.exportProductsSchedulerCronForCountry('EGY')}")
    @SchedulerLock(name = "egy_exportProduct_Job", lockAtLeastFor="${egy.export.job.shedlock.lockAtLeastFor.duration}",lockAtMostFor = "${egy.export.job.shedlock.lockAtMostFor.duration}")
    public void exportSchedulerJobEgy() {
        log.info("egy_exportProduct_Job Retail started.");
        final SessionContext context = new SessionContext();
        Country country = Country.EGY;
        context.setCountry(country);
        context.setLanguages(country.getLanguages());
        context.setProductPickers(ProductPicker.getProductPickers(country));
        exportProductsService.executeJob(Constants.EGY_EXPORT_JOB_CODE,context);
        log.info("egy_exportProduct_Job retail ended.");
    }

    @Scheduled(cron = "#{configurationService.exportProductsSchedulerCronForCountry('OMN')}")
    @SchedulerLock(name = "omn_exportProduct_Job", lockAtLeastFor="${omn.export.job.shedlock.lockAtLeastFor.duration}",lockAtMostFor = "${omn.export.job.shedlock.lockAtMostFor.duration}")
    public void exportSchedulerJobOmn() {
        log.info("omn_exportProduct_Job Retail started.");
        final SessionContext context = new SessionContext();
        context.setCountry(Country.OMN);
        context.setLanguages(Country.OMN.getLanguages());
        context.setProductPickers(ProductPicker.getProductPickers(Country.OMN));
        exportProductsService.executeJob(Constants.OMN_EXPORT_JOB_CODE,context);
        log.info("omn_exportProduct_Job retail ended.");
    }
}
