package com.maf.pim.scheduler;

import com.maf.pim.constants.Constants;
import com.maf.pim.context.SessionContext;
import com.maf.pim.enums.Country;
import com.maf.pim.enums.ProductPicker;
import com.maf.pim.service.ExportProductsService;
import lombok.extern.slf4j.Slf4j;
import net.javacrumbs.shedlock.spring.annotation.SchedulerLock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;

@Slf4j
public class SanityExportProductsScheduler {
    @Autowired
    private ExportProductsService exportProductsService;

    @Scheduled(cron="0 0/10 * * * *")
    @SchedulerLock(name = "sanity_omn_exportProduct_Job", lockAtLeastFor="${omn.export.job.shedlock.lockAtLeastFor.duration}",lockAtMostFor = "${omn.export.job.shedlock.lockAtMostFor.duration}")
    public void exportSchedulerJob() {
        log.info("sanity_omn_exportProduct_Job started.");
        final SessionContext context = new SessionContext();
        Country country = Country.OMN;
        context.setCountry(country);
        context.setLanguages(country.getLanguages());
        context.setProductPickers(ProductPicker.getProductPickers(country));
        exportProductsService.executeJob(Constants.OMN_SANITY_EXPORT_JOB_CODE,context);
        log.info("sanity_omn_exportProduct_Job ended.");
    }
}
