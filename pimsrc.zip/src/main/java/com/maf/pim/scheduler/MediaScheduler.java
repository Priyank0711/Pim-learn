package com.maf.pim.scheduler;

import com.maf.pim.service.MediaUploadService;
import lombok.extern.slf4j.Slf4j;
import net.javacrumbs.shedlock.spring.annotation.SchedulerLock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;

@Slf4j
public class MediaScheduler {

    @Autowired
    MediaUploadService mediaUploadService;

    @Scheduled(cron="0 0/10 * * * *")
    @SchedulerLock(name = "media_upload_scheduleJob", lockAtLeastFor="${media.scheduler.job.shedlock.lockAtLeastFor.duration}",lockAtMostFor = "${media.scheduler.job.shedlock.lockAtMostFor.duration}")
    public void scheduleJob() {
        log.info("media_upload_scheduleJob started.");
        mediaUploadService.uploadMedia();
    }
}
