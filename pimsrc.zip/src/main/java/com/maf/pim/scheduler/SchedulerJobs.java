package com.maf.pim.scheduler;

import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class SchedulerJobs {
    @Bean
    @ConditionalOnProperty(value = "background.jobs.enable", matchIfMissing = true, havingValue = "true")
    public GicaJobScheduler gicaJobScheduler() { return new GicaJobScheduler(); }

    @Bean
    @ConditionalOnProperty(value = "background.jobs.enable", matchIfMissing = true, havingValue = "true")
    public MediaScheduler mediaSftpStorageConfig() { return new MediaScheduler(); }

    @Bean
    @ConditionalOnProperty(value = "reader.jobs.enable", matchIfMissing = true, havingValue = "true")
    public ExportProductsScheduler exportProductsScheduler() { return new ExportProductsScheduler(); }

    @Bean
    @ConditionalOnProperty(value = "reader.jobs.enable", matchIfMissing = true, havingValue = "true")
    public ExportVariantsScheduler exportVariantsScheduler() { return new ExportVariantsScheduler(); }

    @Bean
    @ConditionalOnProperty(value = "reader.sanity.jobs.enable", havingValue = "true")
    public SanityExportProductsScheduler sanityExportProductsScheduler() { return new SanityExportProductsScheduler(); }

    @Bean
    @ConditionalOnProperty(value = "reader.jobs.enable", matchIfMissing = true, havingValue = "true")
    public ExportSupplierProductsScheduler exportSupplierProductsScheduler() { return new ExportSupplierProductsScheduler(); }
}
