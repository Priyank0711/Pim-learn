package com.maf.pim.scheduler;

import com.maf.pim.constants.Constants;
import com.maf.pim.context.SessionContext;
import com.maf.pim.enums.Country;
import com.maf.pim.enums.ProductPicker;
import com.maf.pim.service.ExportSupplierProductsService;
import lombok.extern.slf4j.Slf4j;
import net.javacrumbs.shedlock.spring.annotation.SchedulerLock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;

@Slf4j
public class ExportSupplierProductsScheduler {

    @Autowired
    private ExportSupplierProductsService exportSupplierProductsService;

    @Scheduled(cron="#{configurationService.supplierSchedulerCronForCountry('JOR')}", zone = "Asia/Amman")
    @SchedulerLock(name = "jor_exportSupplierProducts_Job", lockAtLeastFor="${jor.export.job.shedlock.lockAtLeastFor.duration}",lockAtMostFor = "${jor.export.job.shedlock.lockAtMostFor.duration}")
    public void exportSchedulerJob() {
        log.info("jor_exportSupplierProducts_Job started.");
        final SessionContext sessionContext = new SessionContext();
        sessionContext.setCountry(Country.JOR);
        sessionContext.setLanguages(Country.JOR.getLanguages());
        sessionContext.setProductPickers(ProductPicker.getProductPickers(Country.JOR));
        exportSupplierProductsService.executeJob(Constants.JOR_EXPORT_SUPPLIER_PRODUCT_JOB_CODE, sessionContext);

        log.info("jor_exportSupplierProducts_Job ended.");
    }

    @Scheduled(cron="#{configurationService.supplierSchedulerCronForCountry('KWT')}", zone = "Asia/Kuwait")
    @SchedulerLock(name = "kwt_exportSupplierProducts_Job", lockAtLeastFor="${kwt.export.job.shedlock.lockAtLeastFor.duration}",lockAtMostFor = "${kwt.export.job.shedlock.lockAtMostFor.duration}")
    public void exportKwtSchedulerJob() {
        log.info("kwt_exportSupplierProducts_Job started.");
        final SessionContext sessionContext = new SessionContext();
        sessionContext.setCountry(Country.KWT);
        sessionContext.setLanguages(Country.KWT.getLanguages());
        sessionContext.setProductPickers(ProductPicker.getProductPickers(Country.KWT));
        exportSupplierProductsService.executeJob(Constants.KWT_EXPORT_SUPPLIER_PRODUCT_JOB_CODE, sessionContext);

        log.info("kwt_exportSupplierProducts_Job ended.");
    }

    @Scheduled(cron="#{configurationService.supplierSchedulerCronForCountry('BHR')}", zone = "Asia/Bahrain")
    @SchedulerLock(name = "bhr_exportSupplierProducts_Job", lockAtLeastFor="${bhr.export.job.shedlock.lockAtLeastFor.duration}",lockAtMostFor = "${bhr.export.job.shedlock.lockAtMostFor.duration}")
    public void exportBhrSchedulerJob() {
        log.info("bhr_exportSupplierProducts_Job started.");
        final SessionContext sessionContext = new SessionContext();
        sessionContext.setCountry(Country.BHR);
        sessionContext.setLanguages(Country.BHR.getLanguages());
        sessionContext.setProductPickers(ProductPicker.getProductPickers(Country.BHR));
        exportSupplierProductsService.executeJob(Constants.BHR_EXPORT_SUPPLIER_PRODUCT_JOB_CODE, sessionContext);

        log.info("bhr_exportSupplierProducts_Job ended.");
    }

    @Scheduled(cron="#{configurationService.supplierSchedulerCronForCountry('UAE')}", zone = "Asia/Dubai")
    @SchedulerLock(name = "uae_exportSupplierProducts_Job", lockAtLeastFor="${uae.export.job.shedlock.lockAtLeastFor.duration}",lockAtMostFor = "${uae.export.job.shedlock.lockAtMostFor.duration}")
    public void exportUaeSchedulerJob() {
        log.info("uae_exportSupplierProducts_Job started.");
        final SessionContext sessionContext = new SessionContext();
        sessionContext.setCountry(Country.UAE);
        sessionContext.setLanguages(Country.UAE.getLanguages());
        sessionContext.setProductPickers(ProductPicker.getProductPickers(Country.UAE));
        exportSupplierProductsService.executeJob(Constants.UAE_EXPORT_SUPPLIER_PRODUCT_JOB_CODE, sessionContext);

        log.info("uae_exportSupplierProducts_Job ended.");
    }

    @Scheduled(cron="#{configurationService.supplierSchedulerCronForCountry('QAT')}", zone = "Asia/Qatar")
    @SchedulerLock(name = "qat_exportSupplierProducts_Job", lockAtLeastFor="${qat.export.job.shedlock.lockAtLeastFor.duration}",lockAtMostFor = "${qat.export.job.shedlock.lockAtMostFor.duration}")
    public void exportQatSchedulerJob() {
        log.info("qat_exportSupplierProducts_Job started.");
        final SessionContext sessionContext = new SessionContext();
        sessionContext.setCountry(Country.QAT);
        sessionContext.setLanguages(Country.QAT.getLanguages());
        sessionContext.setProductPickers(ProductPicker.getProductPickers(Country.QAT));
        exportSupplierProductsService.executeJob(Constants.QAT_EXPORT_SUPPLIER_PRODUCT_JOB_CODE, sessionContext);

        log.info("qat_exportSupplierProducts_Job ended.");
    }

    @Scheduled(cron="#{configurationService.supplierSchedulerCronForCountry('OMN')}", zone = "Asia/Muscat")
    @SchedulerLock(name = "omn_exportSupplierProducts_Job", lockAtLeastFor="${omn.export.job.shedlock.lockAtLeastFor.duration}",lockAtMostFor = "${omn.export.job.shedlock.lockAtMostFor.duration}")
    public void exportOmnSchedulerJob() {
        log.info("omn_exportSupplierProducts_Job started.");
        final SessionContext sessionContext = new SessionContext();
        sessionContext.setCountry(Country.OMN);
        sessionContext.setLanguages(Country.OMN.getLanguages());
        sessionContext.setProductPickers(ProductPicker.getProductPickers(Country.OMN));
        exportSupplierProductsService.executeJob(Constants.OMN_EXPORT_SUPPLIER_PRODUCT_JOB_CODE, sessionContext);

        log.info("omn_exportSupplierProducts_Job ended.");
    }
    
}
