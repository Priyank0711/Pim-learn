package com.maf.pim.service;

import com.maf.pim.dto.NotificationMessage;

public interface NotificationService {
	void sendNotification(NotificationMessage notificationMessage);
}
