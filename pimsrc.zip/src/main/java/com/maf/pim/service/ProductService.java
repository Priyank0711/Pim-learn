package com.maf.pim.service;

import com.maf.pim.dto.PatchProductRequest;
import com.maf.pim.dto.PatchProductResponse;
import com.maf.pim.entity.AttributeAssignment;
import com.maf.pim.entity.Category;
import com.maf.pim.entity.Product;
import com.maf.pim.entity.ProductId;
import com.maf.pim.enums.ApprovalStatus;
import com.maf.pim.enums.Country;
import com.maf.pim.enums.option.GenericOption;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.time.Instant;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;

public interface ProductService {

    Optional<Product> findByCodeAndCountry(String code, Country country);

    Optional<Product> findByEanAndCountryWithOptions(String ean, Country country, List<GenericOption> options);

    Optional<Product> findByCodeAndCountryWithOptions(String code, Country country, List<GenericOption> options);

    Page<ProductId> findProductIdsAndMarketplaceProductByModifiedDate(Country country, Boolean marketplaceProduct, Instant modifiedDate, Pageable pageable);

    Optional<Product> findProductWithCategoriesByCodeAndCountry(String code, Country country);

    Optional<Product> findProductWithMediaAndGalleryByCodeAndCountry(String code, Country country);

    Product save(Product product);
    void upsert(Product product);

    int updateProductBarcodes(String productCode, Country country, String[] barcodes);

    void updateCategories(Product product, List<Category> categories);

    List<Product> findByProductIds(List<ProductId> productIds, List<GenericOption> options);

    Set<Category> getCategoriesByProduct(Product source);

    Map<String, List<AttributeAssignment>> getAttributeAssignmentMapByName(Product source);

    Map<String, List<AttributeAssignment>> getAttributeAssignmentMap(Product source);

    List<AttributeAssignment> getAttributeAssignmentForProduct(Product source);

    PatchProductResponse patchProduct(PatchProductRequest patchProductRequest);

    void removeMedia(String productCode, String mediaCode, Country country);

    Page<ProductId> findAllSupplierProductIds(Country country, Pageable pageable);

    Page<ProductId> findSupplierProductIdsByModifiedDate(Country country, Instant modifiedDate, Set<String> supplierIds, Pageable pageable);

    boolean updateApprovalStatus(String code, Country country, ApprovalStatus approvalStatus, Instant startDate, Instant endDate);

    boolean updateUnpublishedPos(String code, Country country, List<String> unpublishedPos);

    void insertCategoriesForProduct(List<Category> newCategories, Country country, String code);

    void deleteCategoriesForProduct(List<Category> categoriesToBeDeleted, Country country, String code);

    void updateProductTranslations(String productCode, Country country, String productNameEn, String productNameAr);

    Optional<Product> findByIdOrEan(String code, Country country);
}