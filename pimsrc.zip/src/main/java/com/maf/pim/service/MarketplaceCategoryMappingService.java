package com.maf.pim.service;

import com.maf.pim.entity.Category;
import com.maf.pim.entity.MarketplaceCategoryMapping;
import com.maf.pim.entity.MarketplaceCategoryMappingId;
import com.maf.pim.enums.CategoryType;
import com.maf.pim.enums.Country;

import java.util.List;
import java.util.Optional;

public interface MarketplaceCategoryMappingService {

    Optional<MarketplaceCategoryMapping> findById(MarketplaceCategoryMappingId id);

    MarketplaceCategoryMapping save(MarketplaceCategoryMapping marketplaceCategoryMapping);

    List<MarketplaceCategoryMapping> findSourceCategories(Country country, CategoryType categoryType, Category targetCategory);
}
