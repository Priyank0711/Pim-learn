package com.maf.pim.service;

import com.maf.pim.entity.ClassificationClass;
import com.maf.pim.enums.Country;
import com.maf.pim.enums.option.GenericOption;

import java.util.Collection;
import java.util.List;
import java.util.Optional;

public interface ClassificationClassService {

    Optional<ClassificationClass> findByCodeAndCountry(String code, Country country);

    Optional<ClassificationClass> findByCodeAndCountryWithOptions(String code, Country country, List<GenericOption> options);

    ClassificationClass save(ClassificationClass classificationClass);

    List<ClassificationClass> getParentClassifications(Collection<ClassificationClass> classifications);

}
