package com.maf.pim.service;

import com.maf.pim.easyjob.BatchJobResult;

public interface CatalogService {

    void uploadResultToCatalogBlob(String filePath, BatchJobResult result, String templateType);

}
