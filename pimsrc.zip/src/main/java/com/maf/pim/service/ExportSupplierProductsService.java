package com.maf.pim.service;

import com.maf.pim.context.SessionContext;

public interface ExportSupplierProductsService {

    void executeJob(final String jobCode, SessionContext context);
}
