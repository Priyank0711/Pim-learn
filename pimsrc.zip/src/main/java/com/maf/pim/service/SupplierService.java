package com.maf.pim.service;

import com.maf.pim.entity.Supplier;

import java.util.Optional;

public interface SupplierService {

    Supplier save(Supplier supplier);

    Optional<Supplier> findById(String id);

    Supplier getSupplierReference(String supplierId);
}
