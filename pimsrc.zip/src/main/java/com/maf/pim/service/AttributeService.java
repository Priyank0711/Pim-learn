package com.maf.pim.service;

import com.maf.pim.entity.Attribute;
import com.maf.pim.enums.Country;
import com.maf.pim.enums.option.GenericOption;

import java.util.List;
import java.util.Optional;

public interface AttributeService {

    Attribute save(Attribute attribute);

    Optional<Attribute> findByCodeAndCountry(String code, Country country);

    Optional<Attribute> findByCodeAndCountryWithOptions(String code, Country country, List<GenericOption> options);
}
