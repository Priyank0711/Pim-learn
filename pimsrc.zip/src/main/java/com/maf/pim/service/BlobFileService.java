package com.maf.pim.service;

import com.maf.pim.enums.Country;

public interface BlobFileService {

    void executeJob(final Country country);
    void executeJob(final Country country, final String inputPath);

}
