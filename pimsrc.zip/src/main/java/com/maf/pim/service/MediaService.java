package com.maf.pim.service;

import com.maf.pim.entity.Media;

import java.io.IOException;
import java.io.InputStream;
import java.net.URL;

public interface MediaService {

    Media saveMedia(Media media);

    String uploadDataStreamToStorageLocation(String folderPath, final String mediaAttribute, InputStream dataStream, String mediaName) throws IOException;

    InputStream downloadMediaIntoDataStream(URL sourceUrl) throws IOException;
}
