package com.maf.pim.service;

import com.maf.pim.entity.GicaReference;
import com.maf.pim.enums.Country;

import java.util.Optional;

public interface GicaReferenceService {

    Optional<GicaReference> findGicaReference(String department, String section, String family, String subFamily, Country country);

    GicaReference save(GicaReference gicaReference);

}
