package com.maf.pim.service;

import com.maf.pim.data.elastic.ElasticProduct;

import java.util.List;

public interface ElasticService {

    void bulkUpload(List<ElasticProduct> entries);
}
