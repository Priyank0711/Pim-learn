package com.maf.pim.service;

import com.maf.pim.dto.AttributeResponse;
import com.maf.pim.enums.Country;

public interface TemplateAttributeService {

    AttributeResponse getAttributesForTemplate(String categoryCode, Country country);
}
