package com.maf.pim.service;

import java.util.Collection;

public interface CacheService {

    void refreshAllCache(Collection<String> cacheNames);
}
