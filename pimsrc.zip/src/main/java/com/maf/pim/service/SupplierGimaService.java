package com.maf.pim.service;


import com.maf.pim.entity.Supplier;
import com.maf.pim.entity.SupplierGima;
import com.maf.pim.entity.SupplierGimaId;
import com.maf.pim.entity.SupplierGimaStatusesProjection;
import com.maf.pim.enums.Country;

import java.util.List;
import java.util.Optional;

public interface SupplierGimaService {

    SupplierGima save(SupplierGima supplierGima);

    void upsert(SupplierGima supplierGima);

    Optional<SupplierGima> findById(SupplierGimaId id);

    List<SupplierGima> getSupplierGimasWithSupplier(String productCode, Country country, String pos,List<String> INACTIVE_STATUS_LIST);

    List<SupplierGimaStatusesProjection> getSuppliersGimaStatuses(List<String> productCodes, Country country);

    List<Supplier> getSupplierGimaWithSupplierWithoutPos(String productCode, Country country,List<String> INACTIVE_STATUS_LIST);


}
