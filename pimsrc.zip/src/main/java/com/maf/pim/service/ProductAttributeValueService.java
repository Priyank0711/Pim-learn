package com.maf.pim.service;

import com.maf.pim.entity.ProductAttributeValue;
import com.maf.pim.entity.ProductId;
import com.maf.pim.enums.Country;
import com.maf.pim.projections.ProductAttrValueProjection;

import java.util.List;
import java.util.Set;

public interface ProductAttributeValueService {
    List<ProductAttributeValue> findAttributeValueByProductIdWithAttribute(List<ProductId> productIds);

    List<ProductAttributeValue> findAttributesByIdProductId(ProductId productId);

    List<ProductAttributeValue> findAttributeValuesByProductAndAssignment(ProductId productId, Long assignmentId);

    void saveAll(List<ProductAttributeValue> productAttributeValues);

    void deleteAll(List<ProductAttributeValue> productAttributeValues);

    List<ProductAttrValueProjection> findAttributeValueByProductIdsAndAttributeIds(Country country, Set<String> productIds, Set<Long> assignmentIds);
}