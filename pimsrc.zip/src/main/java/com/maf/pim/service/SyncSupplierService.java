package com.maf.pim.service;

import com.maf.pim.dto.SyncSupplierResponse;
import com.maf.pim.enums.Country;
import com.maf.pim.entity.SyncSupplier;

import java.util.Optional;
import java.util.Set;

public interface SyncSupplierService {

    SyncSupplierResponse syncSuppliers(Set<String> supplierSet, Country country);

    Optional<SyncSupplier> findById(Country country);

    void deleteByCountry(Country country);

    Set<String> getSupplierIds(Country country);
}
