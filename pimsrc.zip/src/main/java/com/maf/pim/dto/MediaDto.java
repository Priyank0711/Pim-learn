package com.maf.pim.dto;

import com.maf.pim.constants.Constants;
import com.maf.pim.enums.Country;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.Pattern;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serial;
import java.io.Serializable;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class MediaDto implements Serializable {
    @Serial
    private static final long serialVersionUID = 5228826352477277903L;
    private String code;
    private Country country;
    @NotEmpty(message = "Media name is mandatory")
    @Pattern(regexp = Constants.FILE_PATTERN, flags = {Pattern.Flag.CASE_INSENSITIVE}, message = "Media name needs to be in following format : productcode_main/numeral.extension, allowed file types - jpg,jpeg,png,gif")
    private String name;
    private String format;
    private String masterUrl;
    private String url;
    private String relativePath;
}
