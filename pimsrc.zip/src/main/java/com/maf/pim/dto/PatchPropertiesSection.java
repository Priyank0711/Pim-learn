package com.maf.pim.dto;

import com.maf.pim.enums.*;
import lombok.Data;

import java.time.Instant;
import java.util.HashMap;
import java.util.List;
import java.util.Optional;

@Data
public class PatchPropertiesSection {

    private transient Optional<String> ean;
    private transient Optional<Boolean> expressProduct;
    private transient Optional<ProductType> productType;
    private transient Optional<String> storeId;
    private transient Optional<ApprovalStatus> approvalStatus;
    private transient Optional<String> department;
    private transient Optional<String> section;
    private transient Optional<String> family;
    private transient Optional<String> subFamily;
    private transient Optional<String> itemStatus;
    private transient Optional<Double> grossWeight;
    private transient Optional<Integer> minOrderQuantity;
    private transient Optional<Double> width;
    private transient Optional<Double> weight;
    private transient Optional<Double> height;
    private transient Optional<Double> depth;
    private transient Optional<Integer> maxToOrder;
    private transient Optional<Integer> unitItem;
    private transient Optional<HashMap<Language,String>> name;
    private transient Optional<HashMap<Language,String>> onlineName;
    private transient Optional<HashMap<Language,String>> description;
    private transient Optional<HashMap<Language,String>> bulkMessage;
    private transient Optional<HashMap<Language,String>> marketingText;
    private transient Optional<HashMap<Language,String>> metaTitle;
    private transient Optional<HashMap<Language,String>> metaDescription;
    private transient Optional<HashMap<Language,String>> metaKeywords;
    private transient Optional<HashMap<Language,String>> ingredients;
    private transient Optional<HashMap<Language,String>> brandMarketingMessage;
    private transient Optional<HashMap<Language,String>> storageConditions;
    private transient Optional<HashMap<Language,String>> allergyAdvice;
    private transient Optional<HashMap<Language,String>> preparationAndUsage;
    private transient Optional<HashMap<Language,String>> size;
    private transient Optional<HashMap<Language,String>> countryOrigin;
    private transient Optional<HashMap<Language,String>> tipsAndVideos;
    private transient Optional<HashMap<Language,String>> productColor;
    private transient Optional<HashMap<Language,String>> preorderDescription;
    private transient Optional<HashMap<Language,String>> safetyWarnings;
    private transient Optional<List<String>> barcodes;
    private transient Optional<List<String>> assortments;
    private transient Optional<Boolean> marketplaceProduct;
    private transient Optional<String> itemMeasure;
    private transient Optional<Integer> loyaltyPoint;
    private transient Optional<Integer> deliveryTime;
    private transient Optional<ProductNature> nature;
    private transient Optional<Double> weightIncrement;
    private transient Optional<Double> averageWeightByPiece;
    private transient Optional<Double> weightVariation;
    private transient Optional<Integer> nbrOfMonth;
    private transient Optional<Integer> averagePieceByKg;
    private transient Optional<ProductFoodType> productFoodType;
    private transient Optional<Boolean> freeDelivery;
    private transient Optional<Boolean> freeInstallation;
    private transient Optional<Boolean> genuineStock;
    private transient Optional<Boolean> onDemand;
    private transient Optional<Boolean> preorder;
    private transient Optional<Instant> preOrderDeliveryTime;
    private transient Optional<String> codeDeliveryGica;
    private transient Optional<Boolean> warranty;
    private transient Optional<WarrantyType> warrantyType;
    private transient Optional<Integer> yearOfWarranty;
    private transient Optional<String> gicaVatCod;
    private transient Optional<String> gicaVatPer;
    private transient Optional<Boolean> substituted;
    private transient Optional<Integer> maxOrderQuantity;
    private transient Optional<Instant> loyaltyPointsStartDate;
    private transient Optional<Instant> loyaltyPointsEndDate;
    private transient Optional<Double> minimumWeightToOrder;
    private transient Optional<Boolean> nonReplenishable;
    private transient Optional<Double> numberOfUnit;
    private transient Optional<List<String>> unpublishedPos;
    private transient Optional<String> sellerId;
    private transient Optional<String> superSellerId;

}
