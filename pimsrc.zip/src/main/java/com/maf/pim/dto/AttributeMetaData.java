package com.maf.pim.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class AttributeMetaData {

    private Integer displayOrder;

    private String groupCode;

    private String groupName;

    private Integer[] rgbColors;

    private List<TemplateAttributeDetails> attributeDetails =  new ArrayList<>();

    public void addAttributeDetail(TemplateAttributeDetails attributeDetail){
        attributeDetails.add(attributeDetail);
    }
}
