package com.maf.pim.dto;

import jakarta.validation.Valid;
import lombok.Data;

import java.util.List;

@Data
public class MediaPropertiesSection {

     @Valid
     private transient MediaDto media;
     @Valid
     private transient List<MediaDto> gallery;

}
