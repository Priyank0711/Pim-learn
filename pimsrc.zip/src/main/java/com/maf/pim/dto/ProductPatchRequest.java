package com.maf.pim.dto;

import com.maf.pim.enums.*;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotEmpty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Set;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ProductPatchRequest {

    private String code;
    private Country country;
    private PatchPropertiesSection properties;
    @Valid
    private MediaPropertiesSection multimedia;

    @Valid
    private PatchAttributesSection attributes;
    @NotEmpty(message = "Sections must not be empty or null")
    private Set<ProductSection> sections;
}
