package com.maf.pim.dto;

import com.maf.pim.enums.Language;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serial;
import java.io.Serializable;
import java.util.Optional;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class PatchProductTranslationRequest implements Serializable {
    @Serial
    private static final long serialVersionUID = -2732575892245338289L;
    private Language language;
    private transient Optional<String> name;
    private transient Optional<String> onlineName;
    private transient Optional<String> description;
    private transient Optional<String> bulkMessage;
    private transient Optional<String> marketingText;
    private transient Optional<String> metaTitle;
    private transient Optional<String> metaDescription;
    private transient Optional<String> metaKeywords;
    private transient Optional<String> ingredients;
    private transient Optional<String> brandMarketingMessage;
    private transient Optional<String> storageConditions;
    private transient Optional<String> allergyAdvice;
    private transient Optional<String> preparationAndUsage;
    private transient Optional<String> size;
    private transient Optional<String> countryOrigin;
    private transient Optional<String> tipsAndVideos;
    private transient Optional<String> productColor;
    private transient Optional<String> safetyWarnings;
    private transient Optional<String> preorderDescription;
}
