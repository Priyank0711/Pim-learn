package com.maf.pim.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.io.Serial;
import java.io.Serializable;
import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class CategoryResponseDto implements Serializable {

    @Serial
    private static final long serialVersionUID = 5566710316198881582L;
    private String id;
    private String categoryCode;
    private String categoryName;
    private String parentId;
    private String countryCode;
    private List<CategoryResponsePathDto> categoryPath;
}
