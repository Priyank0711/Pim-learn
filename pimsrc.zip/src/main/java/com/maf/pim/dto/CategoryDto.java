package com.maf.pim.dto;

import com.maf.pim.enums.CategoryType;
import com.maf.pim.enums.Country;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serial;
import java.io.Serializable;
import java.util.Set;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class CategoryDto implements Serializable {

    @Serial
    private static final long serialVersionUID = -9010654590438249822L;
    private String id;

    private String code;

    private Country country;
    private Long parentId;
    private String path;
    private CategoryType categoryType;
    private Set<ClassificationClassDto> classifications;

    private Set<CategoryTranslationDto> categoryTranslations;
}
