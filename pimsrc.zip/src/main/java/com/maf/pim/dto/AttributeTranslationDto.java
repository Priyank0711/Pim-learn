package com.maf.pim.dto;

import com.maf.pim.enums.Language;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serial;
import java.io.Serializable;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class AttributeTranslationDto implements Serializable {
    @Serial
    private static final long serialVersionUID = -3423790704250762773L;
    private Long id;
    private Language language;
    private String name;
}
