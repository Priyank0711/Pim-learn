package com.maf.pim.dto;

import com.maf.pim.enums.Country;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serial;
import java.io.Serializable;
import java.util.Set;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class ClassificationClassDto implements Serializable {

    @Serial
    private static final long serialVersionUID = 4035575878756698332L;
    private String id;
    private String code;
    private Country country;
    private Set<ParentClassificationDto> parentClassifications;
    private Set<ClassificationClassTranslationDto> classificationClassTranslations;
    private Set<AttributeAssignmentDto> attributeAssignment;

}
