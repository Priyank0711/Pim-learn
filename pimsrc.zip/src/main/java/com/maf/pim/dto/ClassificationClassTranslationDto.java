package com.maf.pim.dto;

import com.maf.pim.enums.Language;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serial;
import java.io.Serializable;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class ClassificationClassTranslationDto implements Serializable {
    @Serial
    private static final long serialVersionUID = -6015310565760677089L;
    private Long id;
    private Language language;
    private String name;
}
