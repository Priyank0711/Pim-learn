package com.maf.pim.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.maf.pim.enums.Language;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serial;
import java.io.Serializable;

@AllArgsConstructor
@NoArgsConstructor
@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class PatchProductTranslationResponse implements Serializable {
    @Serial
    private static final long serialVersionUID = -2732575892245338289L;
    private Language language;
    private String name;
    private String onlineName;
    private String description;
    private String bulkMessage;
    private String marketingText;
    private String metaTitle;
    private String metaDescription;
    private String metaKeywords;
    private String ingredients;
    private String brandMarketingMessage;
    private String storageConditions;
    private String allergyAdvice;
    private String preparationAndUsage;
    private String size;
    private String countryOrigin;
    private String tipsAndVideos;
    private String productColor;
    private String safetyWarnings;
    private String preOrderDescription;
}
