package com.maf.pim.dto;

import com.maf.pim.enums.Country;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serial;
import java.io.Serializable;
import java.util.Set;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class AttributeDto implements Serializable {

    @Serial
    private static final long serialVersionUID = -434774662784208662L;

    private String id;
    private String code;
    private Country country;
    private Set<AttributeTranslationDto> attributeTranslations;
}
