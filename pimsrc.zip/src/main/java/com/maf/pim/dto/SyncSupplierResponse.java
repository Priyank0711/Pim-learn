package com.maf.pim.dto;

import lombok.Data;

import java.util.Set;

@Data
public class SyncSupplierResponse {

   private String country;
   private Set<String> suppliers;

}
