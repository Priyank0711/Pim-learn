package com.maf.pim.dto;

import com.maf.pim.enums.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serial;
import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Set;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class ProductDto implements Serializable {

    @Serial
    private static final long serialVersionUID = -8029563431760682989L;
    private Long productId;
    private String code;
    private Country country;

    private Set<CategoryDto> categories;
    private Set<ProductTranslationDto> productTranslations;

    private String ean;
    private Boolean expressProduct;
    private ProductType productType;
    private String storeId;
    private ApprovalStatus approvalStatus;
    private String department;
    private String section;
    private String family;
    private String subFamily;
    private String itemStatus;
    private Double grossWeight;
    private Integer minOrderQuantity;
    private Double width;
    private Double weight;
    private Double height;
    private Double depth;
    private Integer maxToOrder;
    private Integer unitItem;
    private List<String> barcodes;
    private List<String> assortments;
    private Boolean marketplaceProduct;
    private String itemMeasure;
    private Integer loyaltyPoint;
    private Integer deliveryTime;
    private String safetyWarnings;
    private ProductNature nature;
    private Double weightIncrement;
    private Double averageWeightByPiece;
    private Double weightVariation;
    private Integer nbrOfMonth;
    private Integer averagePieceByKg;
    private ProductFoodType productFoodType;
    private Boolean freeDelivery;
    private Boolean freeInstallation;
    private Boolean genuineStock;
    private Boolean onDemand;
    private Boolean preorder;
    private LocalDateTime preOrderDeliveryTime;
    private String codeDeliveryGica;
    private String preorderDescription;
    private Boolean warranty;
    private WarrantyType warrantyType;
    private Integer yearOfWarranty;
    private MediaDto media;
    private List<MediaDto> gallery;
    private String gicaVatCod;
    private String gicaVatPer;
    private Boolean substituted;
    private Integer maxOrderQuantity;
    private LocalDateTime loyaltyPointsStartDate;
    private LocalDateTime loyaltyPointsEndDate;
    private Double minimumWeightToOrder;
    private Boolean nonReplenishable;
    private Double numberOfUnit;




}
