package com.maf.pim.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.maf.pim.data.SupplierData;
import com.maf.pim.data.SupplierGimaData;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ProductSuppliersResponse {

    private String productCode;

    private String pos;

    private SupplierData primarySupplier;

    private List<SupplierGimaData> secondarySuppliers;

    private String error;
}
