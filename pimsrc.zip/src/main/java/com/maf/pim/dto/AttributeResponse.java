package com.maf.pim.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class AttributeResponse {

    private String categoryCode;
    private String categoryName;
    private List<AttributeMetaData> attributeGroups;
    private String country;
}
