
package com.maf.pim.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serial;
import java.io.Serializable;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class NotificationMessage implements Serializable{

    @Serial
    private static final long serialVersionUID = -8702604324506624171L;
    private String importId;
    private String shopId;
    private String country;
    private FileDetails successFile;
    private FileDetails errorFile;
    private String templateType;
    private String role;
    private Boolean aster;
    private String emailId;

}
