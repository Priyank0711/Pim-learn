package com.maf.pim.dto;

import lombok.Builder;
import lombok.Data;

import java.io.Serial;
import java.io.Serializable;
import java.util.List;

@Builder
@Data
public class CategoryResponsePageDto implements Serializable{

    @Serial
    private static final long serialVersionUID = -6410176105845651031L;

    private List<CategoryResponseDto> data;

    private int currentPage;
    private long totalElements;
    private int totalPages;
    private int pageSize;
}
