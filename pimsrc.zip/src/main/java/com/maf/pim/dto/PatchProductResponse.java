package com.maf.pim.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.maf.pim.enums.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serial;
import java.io.Serializable;
import java.time.Instant;
import java.util.List;
import java.util.Set;

@AllArgsConstructor
@NoArgsConstructor
@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class PatchProductResponse implements Serializable {

    @Serial
    private static final long serialVersionUID = -8029563431760682989L;
    private String code;
    private Country country;

    private Set<PatchProductTranslationResponse> productTranslations;

    private String ean;
    private Boolean expressProduct;
    private ProductType productType;
    private ApprovalStatus approvalStatus;
    private String department;
    private String section;
    private String family;
    private String subFamily;
    private String itemStatus;
    private Double grossWeight;
    private Integer minOrderQuantity;
    private Double width;
    private Double weight;
    private Double height;
    private Double depth;
    private Integer maxToOrder;
    private Integer unitItem;
    private List<String> barcodes;
    private List<String> assortments;
    private Boolean marketplaceProduct;
    private String itemMeasure;
    private Integer loyaltyPoint;
    private Integer deliveryTime;
    private ProductNature nature;
    private Double weightIncrement;
    private Double averageWeightByPiece;
    private Double weightVariation;
    private Integer nbrOfMonth;
    private Integer averagePieceByKg;
    private ProductFoodType productFoodType;
    private Boolean freeDelivery;
    private Boolean freeInstallation;
    private Boolean genuineStock;
    private Boolean onDemand;
    private Boolean preorder;
    private Instant preOrderDeliveryTime;
    private String codeDeliveryGica;
    private Boolean warranty;
    private WarrantyType warrantyType;
    private Integer yearOfWarranty;
    private String gicaVatCod;
    private String gicaVatPer;
    private Boolean substituted;
    private Integer maxOrderQuantity;
    private Instant loyaltyPointsStartDate;
    private Instant loyaltyPointsEndDate;
    private Double minimumWeightToOrder;
    private Boolean nonReplenishable;
    private Double numberOfUnit;




}
