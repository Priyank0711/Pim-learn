package com.maf.pim.dto;

import com.maf.pim.enums.FeatureType;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serial;
import java.io.Serializable;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class AttributeAssignmentDto implements Serializable {

    @Serial
    private static final long serialVersionUID = -434774662784208662L;

    private Long id;

    private Boolean multiLang;

    private FeatureType featureType;

    private AttributeDto attribute;

}
