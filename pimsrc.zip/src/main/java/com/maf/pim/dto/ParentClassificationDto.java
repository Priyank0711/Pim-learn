package com.maf.pim.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serial;
import java.io.Serializable;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class ParentClassificationDto implements Serializable {
    @Serial
    private static final long serialVersionUID = 2901345909365018999L;
    private Long id;
    private String parentId;
}
