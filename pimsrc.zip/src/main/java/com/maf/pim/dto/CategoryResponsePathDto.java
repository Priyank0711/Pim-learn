package com.maf.pim.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.io.Serial;
import java.io.Serializable;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class CategoryResponsePathDto implements Serializable {

    @Serial
    private static final long serialVersionUID = 2188627834168848775L;
    private String id;
    private String categoryName;
    private String categoryCode;
    private Integer level;
}
