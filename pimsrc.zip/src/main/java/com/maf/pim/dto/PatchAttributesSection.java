package com.maf.pim.dto;

import com.maf.pim.enums.Language;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

import java.util.List;
import java.util.Map;
import java.util.Optional;

@Data
public class PatchAttributesSection {

    @Valid
    private List<@Valid FeatureDTORequest> features;

    @Data
    public static class FeatureDTORequest {
        @NotNull(message = "Assignment id is mandatory")
        private Long assignmentId;
        private Map<Language, Optional<String>> value;
    }
}
