package com.maf.pim.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class TemplateAttributeDetails {

    private String value;

    private String code;

    private Integer displayOrder;

    private List<String> allowedValueList;

    private String example;

    private String definition;

}
