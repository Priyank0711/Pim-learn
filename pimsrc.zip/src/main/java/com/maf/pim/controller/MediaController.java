package com.maf.pim.controller;

import com.maf.pim.enums.Country;
import com.maf.pim.service.MediaUploadService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.ws.rs.Path;

@RestController
@Slf4j
@RequestMapping("/{country}/media")
public class MediaController {

    @Autowired
    MediaUploadService mediaUploadService;

    @PostMapping(value = {"/upload"})
    @ResponseBody
    public ResponseEntity<String> uploadMedia(@PathVariable("country") Country country) {
        mediaUploadService.uploadMedia();
        return ResponseEntity.status(HttpStatus.OK).body("Successfully Uploaded for " + country);
    }
}
