package com.maf.pim.controller;

import com.maf.pim.dto.ProductSuppliersDto;
import com.maf.pim.dto.ProductSuppliersResponse;
import com.maf.pim.dto.SyncSupplierResponse;
import com.maf.pim.enums.Country;
import com.maf.pim.exceptions.ApiErrors;
import com.maf.pim.exceptions.ApiException;
import com.maf.pim.exceptions.ErrorCodes;
import com.maf.pim.facade.SupplierFacade;
import com.maf.pim.request.ProductSupplierRequestV1;
import com.maf.pim.request.SyncSupplierRequest;
import com.maf.pim.service.SyncSupplierService;
import io.swagger.v3.oas.annotations.Operation;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotEmpty;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/{country}/supplier")
@Validated
@Slf4j
@RequiredArgsConstructor
public class SupplierController {

    private final SupplierFacade supplierFacade;

    private final SyncSupplierService syncSupplierService;

    /**
     *
     * @param country country
     * @param productSuppliersDtoList list of ProductSuppliersDto
     * @return list of primary and secondary suppliers for each product
     */
    @Operation(description = "Fetches product and its primary and secondary suppliers based on given country, product code and pos.")
    @PostMapping("/")
    public ResponseEntity<List<ProductSuppliersResponse>> getProductSuppliers(@PathVariable("country") Country country,
                                                                             @RequestBody @Valid @NotEmpty(message = "request list can't be empty") List<ProductSuppliersDto> productSuppliersDtoList) {
        List<ProductSuppliersResponse> response;
        try {
            response = supplierFacade.getProductSuppliersList(country, productSuppliersDtoList, true);
        } catch (Exception e) {
            log.error("Error while fetching product and its suppliers - {}", e.getMessage(), e);
            throw new ApiException(new ApiErrors(ErrorCodes.INTERNAL_SERVER_ERROR));
        }
        return ResponseEntity.ok().body(response);
    }

    /**
     *
     * @param country country
     * @param requestV1 request for api v1
     * @return list of primary and secondary suppliers for each product
     */

    @Operation(description = "Fetches product and its primary and secondary suppliers (if reqSecSupplier is true) based on given country, product code and pos.")
    @PostMapping("/v1")
    public ResponseEntity<List<ProductSuppliersResponse>> getProductSuppliersV1(@PathVariable("country") Country country,
                                                                                @RequestBody @Valid ProductSupplierRequestV1 requestV1) {
        List<ProductSuppliersResponse> response;
        try {
            response = supplierFacade.getProductSuppliersList(country, requestV1.getProductSuppliersDtoList(), requestV1.isReqSecSuppliers());
        } catch (Exception e) {
            log.error("Error while fetching product and its suppliers - {}", e.getMessage(), e);
            throw new ApiException(new ApiErrors(ErrorCodes.INTERNAL_SERVER_ERROR));
        }
        return ResponseEntity.ok().body(response);
    }

    /**
     *
     * @param syncSupplierRequest contains list of supplier ids
     * @param country country
     * @return SyncSupplierResponseDTO
     */
    @Operation(description = "Saves provided supplier ids to be used later in supplier sync process.")
    @PostMapping("/sync")
    public ResponseEntity<SyncSupplierResponse> saveSupplierIds(@RequestBody SyncSupplierRequest syncSupplierRequest,
                                                                @PathVariable("country") Country country){
        try{
            SyncSupplierResponse updatedSupplierList = syncSupplierService.syncSuppliers(syncSupplierRequest.getSuppliersIds(), country);
            return ResponseEntity.status(HttpStatus.OK).body(updatedSupplierList);
        } catch(Exception e){
            log.error("Error while updating suppliers - {}",e.getMessage(), e);
            throw new ApiException(new ApiErrors(ErrorCodes.INTERNAL_SERVER_ERROR));
        }
    }
}