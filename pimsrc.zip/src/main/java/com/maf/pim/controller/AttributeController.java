package com.maf.pim.controller;

import com.maf.pim.dto.AttributeResponse;
import com.maf.pim.enums.Country;
import com.maf.pim.exceptions.ApiErrors;
import com.maf.pim.exceptions.ApiException;
import com.maf.pim.exceptions.ErrorCodes;
import com.maf.pim.service.TemplateAttributeService;
import io.swagger.v3.oas.annotations.Operation;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/{country}/attribute")
@Slf4j
@AllArgsConstructor
@Validated
public class AttributeController {

    private final TemplateAttributeService templateAttributeService;


    /**
     * @param categoryCode category code
     * @param country country code
     * @return returns List of attributeMetaData
     */
    @GetMapping("/template")
    @ResponseStatus(HttpStatus.OK)
    @Operation(description = "Fetch template attributes based on category and country code.")
    public ResponseEntity<Object> getAttributesForTemplate(
            @RequestParam(name = "categoryCode") String categoryCode,
            @PathVariable("country") Country country) {
        try {
            return ResponseEntity.ok(templateAttributeService.getAttributesForTemplate(categoryCode, country).getAttributeGroups());
        } catch (ApiException e){
            throw e;
        } catch (Exception e){
            log.error("Error in fetch template attribute api - {}", e.getMessage(), e);
            throw new ApiException(new ApiErrors(ErrorCodes.INTERNAL_SERVER_ERROR));
        }
    }

    @GetMapping("/category")
    @ResponseStatus(HttpStatus.OK)
    @Operation(description = "Fetch attributes based on category and country code.")
    public ResponseEntity<AttributeResponse> getAttributesForCategory(
                                                @RequestParam(name = "categoryCode") String categoryCode,
                                                @PathVariable("country") Country country) {
        try {
            return ResponseEntity.ok(templateAttributeService.getAttributesForTemplate(categoryCode, country));
        } catch (ApiException e){
            throw e;
        } catch (Exception e){
            log.error("Error in fetch template attribute api - {}", e.getMessage(), e);
            throw new ApiException(new ApiErrors(ErrorCodes.INTERNAL_SERVER_ERROR));
        }
    }
}
