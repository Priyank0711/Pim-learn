package com.maf.pim.controller;

import com.maf.pim.dto.PatchProductRequest;
import com.maf.pim.dto.PatchProductResponse;
import com.maf.pim.dto.ProductPatchRequest;
import com.maf.pim.enums.Country;
import com.maf.pim.enums.ProductSection;
import com.maf.pim.exceptions.ApiErrors;
import com.maf.pim.exceptions.ApiException;
import com.maf.pim.exceptions.ErrorCodes;
import com.maf.pim.facade.ProductFacade;
import com.maf.pim.request.MediaRequest;
import com.maf.pim.request.ExportProductPagesRequest;
import com.maf.pim.request.ProductRequest;
import com.maf.pim.response.ProductInformationResponse;
import com.maf.pim.response.ProductResponse;
import com.maf.pim.service.ProductService;
import io.swagger.v3.oas.annotations.Operation;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;
import java.util.Set;

@RestController
@Slf4j
@RequestMapping("/{country}/product")
@Validated
public class ProductController {
    private final ProductFacade productFacade;
    private final ProductService productService;

    public ProductController(ProductFacade productFacade, ProductService productService) {
        this.productFacade = productFacade;
        this.productService = productService;
    }

    @PostMapping(value = {"/export"})
    public ResponseEntity<ProductResponse> getProduct(@PathVariable("country") Country country,
                                                      @RequestBody @Valid ProductRequest request){
        ProductResponse productResponse = new ProductResponse();
        productResponse.setProductDataList(productFacade.searchProductDetails(request, country));
        return ResponseEntity.status(HttpStatus.OK).body(productResponse);
    }

    @PostMapping(value = {"/export/paged"})
    public ResponseEntity<Void> exportPagedProduct(@PathVariable("country") Country country,
                                                   @RequestBody @Valid ExportProductPagesRequest request) {
        log.info("Received paged export products request for {}, {}", country, request);
        productFacade.exportPagedProducts(country, request);
        return ResponseEntity.ok().build();
    }

    @PatchMapping(value = {"/{code}"})
    @Operation(description = "Applies the provided patch to the product")
    public ResponseEntity<ProductInformationResponse> patchProductDetails(@PathVariable @NotBlank(message = "Code must not be blank") String code,
                                                             @PathVariable Country country,
                                                             @RequestBody @NotNull @Valid ProductPatchRequest patchProductRequest) {
        patchProductRequest.setCode(code);
        patchProductRequest.setCountry(country);
        return ResponseEntity.ok().body(productFacade.updateProduct(patchProductRequest));
    }

    @PostMapping(value = "/removeMedia")
    public ResponseEntity removeMedia(@RequestBody @Valid MediaRequest mediaRequest, @PathVariable("country") Country country) {
        try {
            productService.removeMedia(mediaRequest.getProductCode(), mediaRequest.getMediaCode(), country);
            return ResponseEntity.status(HttpStatus.OK).body("Media Removed successfully for the given product");
        } catch (ApiException e) {
            throw e;
        } catch (Exception e) {
            log.error("Error in removeMedia api - {}", e.getMessage(), e);
            throw new ApiException(new ApiErrors(ErrorCodes.INTERNAL_SERVER_ERROR));
        }
    }

    @Operation(description = "Provides complete product information")
    @GetMapping("/{code}")
    public ResponseEntity<ProductInformationResponse> getProductInformation(@PathVariable("country") Country country,
                                                                            @PathVariable @NotBlank(message = "Code must not be blank") String code,
                                                                            @RequestParam(required = false) Set<ProductSection> sections) {
        sections = CollectionUtils.isEmpty(sections) ? ProductSection.toSet() : sections;
        return ResponseEntity.ok().body(productFacade.getProductInformation(country, code, sections));
    }
}
