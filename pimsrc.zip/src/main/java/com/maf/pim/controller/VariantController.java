package com.maf.pim.controller;

import com.maf.pim.context.SessionContext;
import com.maf.pim.enums.Country;
import com.maf.pim.facade.VariantFacade;
import com.maf.pim.request.VariantRequest;
import com.maf.pim.response.VariantResponse;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@RestController
@Slf4j
@RequestMapping("/{country}/variant")
@Validated
public class VariantController {
    private final VariantFacade variantFacade;

    public VariantController(VariantFacade variantFacade) {
        this.variantFacade = variantFacade;
    }

    @PostMapping(value = {"/export"})
    public ResponseEntity<VariantResponse> getVariant(@PathVariable("country") Country country,
                                                      @RequestBody @Valid VariantRequest request){
        SessionContext sessionContext = new SessionContext();
        sessionContext.setCountry(country);
        sessionContext.setLanguages(country.getLanguages());
        VariantResponse variantResponse = new VariantResponse();
        variantResponse.setVariantDataList(variantFacade.exportVariants(null, sessionContext, Optional.of(request)));
        return ResponseEntity.status(HttpStatus.OK).body(variantResponse);
    }

}
