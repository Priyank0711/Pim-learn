package com.maf.pim.controller;

import com.maf.pim.enums.CategoryType;
import com.maf.pim.enums.Country;
import com.maf.pim.exceptions.ApiErrors;
import com.maf.pim.exceptions.ApiException;
import com.maf.pim.exceptions.ErrorCodes;
import com.maf.pim.service.CategoryService;
import io.swagger.v3.oas.annotations.Operation;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.Objects;

@RestController
@RequestMapping("/{country}/category")
@Slf4j
@AllArgsConstructor
@Validated
public class CategoryController {

    private final CategoryService categoryService;


    /**
     * @param id category id
     * @param page page number
     * @param size page size
     * @param type category type
     * @param country country code
     * @return returns categoryResponsePageDto
     */
    @GetMapping()
    @ResponseStatus(HttpStatus.OK)
    @Operation(description = "Fetch category based on id, country code and status code provided along with its direct descendants.")
    public ResponseEntity<Object> getCategories(@RequestParam(name = "page", defaultValue = "0") @Min(0) int page,
                                                @RequestParam(name = "size", defaultValue = "50") @Min(0) @Max(100) int size,
                                                @RequestParam(name = "id", required = false) String id,
                                                @RequestParam(name = "type", required = false) CategoryType type,
                                                @PathVariable("country") Country country) {
        try {
            Pageable pageable = PageRequest.of(page, size, Sort.by(Sort.Direction.ASC, "id"));
            type = Objects.isNull(type) ? CategoryType.CLASSIFICATION : type;
            return Objects.isNull(id) ?
                    ResponseEntity.ok(categoryService.getTopLevelCategories(country, type, pageable)) :
                    ResponseEntity.ok(categoryService.getChildCategoryById(id, country, pageable));
        } catch (ApiException e){
            throw e;
        } catch (Exception e){
            log.error("Error in browse category api - {}", e.getMessage(), e);
            throw new ApiException(new ApiErrors(ErrorCodes.INTERNAL_SERVER_ERROR));
        }
    }

    /**
     * @param search search keyword
     * @param type category type
     * @param country country code
     * @return returns list of categoryResponseDto
     */
    @GetMapping("/search")
    @ResponseStatus(HttpStatus.OK)
    @Operation(description = "Fetch categories which matches provided key word.")
    public ResponseEntity<Object> searchCategories(@RequestParam(name = "search") @NotBlank @Size(min = 3, max = 60) String search,
                                                   @RequestParam(name = "type", required = false) CategoryType type,
                                                   @PathVariable("country") Country country) {
        try {
            type = Objects.isNull(type) ? CategoryType.CLASSIFICATION : type;
            return ResponseEntity.ok(categoryService.getCategoriesBySearchWord(search, country, type));
        } catch (ApiException e){
            throw e;
        } catch (Exception e){
            log.error("Error in browse category api - {}", e.getMessage(), e);
            throw new ApiException(new ApiErrors(ErrorCodes.INTERNAL_SERVER_ERROR));
        }
    }
}
