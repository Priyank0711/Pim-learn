package com.maf.pim.mapper;

import com.maf.pim.dto.productsection.CategoryDTO;
import com.maf.pim.entity.Category;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper(componentModel = "spring")
public interface CategoryDTOMapper {

    CategoryDTOMapper INSTANCE = Mappers.getMapper(CategoryDTOMapper.class);

    CategoryDTO toCategoryDTO(Category category);
}
