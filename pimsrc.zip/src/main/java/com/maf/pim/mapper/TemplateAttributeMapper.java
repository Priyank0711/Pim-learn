package com.maf.pim.mapper;

import com.maf.pim.dto.TemplateAttributeDetails;
import com.maf.pim.entity.CoreAttribute;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

@Mapper(componentModel = "spring")
public interface TemplateAttributeMapper {

    TemplateAttributeMapper INSTANCE = Mappers.getMapper(TemplateAttributeMapper.class);


    @Mapping(source = "attrCode", target = "code")
    @Mapping(source = "attrName", target = "value")
    TemplateAttributeDetails coreAttributeToAttributeDetail(CoreAttribute attribute);
}