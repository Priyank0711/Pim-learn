package com.maf.pim.mapper;

import com.maf.pim.data.CategoryData;
import com.maf.pim.data.ProductData;
import com.maf.pim.data.elastic.ElasticProduct;
import com.maf.pim.enums.CategoryType;
import org.apache.commons.collections4.CollectionUtils;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import java.util.List;

@Mapper(componentModel = "spring")
public interface ElasticProductMapper {

    ElasticProductMapper INSTANCE = Mappers.getMapper(ElasticProductMapper.class);

    @Mapping(target = "l1NavCategory", expression = "java(getNavCategoryName(productData.getCategoriesHierarchy(), 0))")
    @Mapping(target = "l2NavCategory", expression = "java(getNavCategoryName(productData.getCategoriesHierarchy(), 1))")
    @Mapping(target = "l3NavCategory", expression = "java(getNavCategoryName(productData.getCategoriesHierarchy(), 2))")
    @Mapping(target = "l4NavCategory", expression = "java(getNavCategoryName(productData.getCategoriesHierarchy(), 3))")
    @Mapping(target = "classCategory", expression = "java(getClassCategory(productData.getCategories()))")
    @Mapping(target = "type", source = "productType")
    @Mapping(target = "express", source = "isExpressEnabled")
    @Mapping(target = "loyaltyPointStartDate", source = "startDate")
    @Mapping(target = "loyaltyPointEndDate", source = "endDate")
    @Mapping(target = "preorderDate", source = "preOrderDeliveryTime")
    @Mapping(target = "storageCondition", source = "storageConditions")
    @Mapping(target = "storageCondition_ar", source = "storageConditions_ar")
    @Mapping(target = "preparationAndUsage", source = "preparationAndUSage")
    @Mapping(target = "preparationAndUsage_ar", source = "preparationAndUSage_ar")
    @Mapping(target = "productSize", source = "size")
    @Mapping(target = "productSize_ar", source = "size_ar")
    @Mapping(target = "serviceProposition", source = "serviceProposition")
    ElasticProduct convertToOnlineProductObject(ProductData productData);

    List<ElasticProduct> convertToOnlineProductObject(List<ProductData> productDataList);

    default String getNavCategoryName(List<CategoryData> categoryDataList, int level) {
        if (categoryDataList != null && categoryDataList.size() > level) {
            return categoryDataList.get(level).getName();
        }
        return null;
    }

    default String getClassCategory(List<CategoryData> categories) {
        if (CollectionUtils.isNotEmpty(categories)) {
            return categories.stream()
                    .filter(categoryData -> categoryData.getType().equals(CategoryType.CLASSIFICATION))
                    .map(categoryData -> categoryData.getCode() + "-" + categoryData.getCategoryName())
                    .findFirst().orElse(null);
        }
        return null;
    }
}