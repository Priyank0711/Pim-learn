package com.maf.pim.mapper;

import com.maf.pim.dto.productsection.PropertiesDTO;
import com.maf.pim.entity.Product;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

@Mapper(componentModel = "spring")
public interface PropertiesDTOMapper {

    PropertiesDTOMapper INSTANCE = Mappers.getMapper(PropertiesDTOMapper.class);

    @Mapping(source = "id.code", target = "id")
    PropertiesDTO toPropertiesDTO(Product product);
}
