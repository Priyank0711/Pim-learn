package com.maf.pim.mapper;

import com.maf.pim.dto.CategoryResponseDto;
import com.maf.pim.entity.Category;
import com.maf.pim.entity.translation.CategoryTranslation;
import com.maf.pim.enums.Language;
import org.apache.commons.lang3.StringUtils;
import org.mapstruct.*;
import org.mapstruct.factory.Mappers;

import java.util.List;
import java.util.Objects;
import java.util.Set;

@Mapper(componentModel = "spring")
public interface CategoryResponseMapper {

    CategoryResponseMapper INSTANCE = Mappers.getMapper(CategoryResponseMapper.class);


    @Mapping(source = "code", target = "categoryCode")
    @Mapping(source = "country", target = "countryCode")
    @Mapping(source = "categoryTranslations", target = "categoryName", qualifiedByName = "englishName")
    @Mapping(target = "categoryPath", ignore = true)
    CategoryResponseDto categoryToCategoryResponseDto(Category category);

    @Named(value = "englishName")
    default String englishName(Set<CategoryTranslation> translations){
        if(Objects.nonNull(translations))
            return translations.stream().filter(t -> Language.EN.equals(t.getLanguage())).map(CategoryTranslation::getName)
                    .findFirst().orElse(StringUtils.EMPTY);
        return StringUtils.EMPTY;
    }
    List<CategoryResponseDto> categoryToCategoryResponseDto(List<Category> categories);


}