package com.maf.pim.mapper;

import com.maf.pim.dto.CategoryResponsePathDto;
import com.maf.pim.entity.Category;
import com.maf.pim.mapper.impl.CatgeoryResponseMapperDecoratorImpl;
import org.mapstruct.DecoratedWith;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import java.util.List;

@Mapper(componentModel = "spring")
@DecoratedWith(CatgeoryResponseMapperDecoratorImpl.class)
public interface CategoryResponseMapperDecorator {

    CategoryResponseMapperDecorator INSTANCE = Mappers.getMapper(CategoryResponseMapperDecorator.class);

    default CategoryResponsePathDto objectArrayToCategoryPathDto(Object[] objectArray) {
        throw new IllegalArgumentException();
    }

    default List<CategoryResponsePathDto> objectArrayToCategoryPathDto(List<Object[]> objectArrays) {
        throw new IllegalArgumentException();
    }

    default List<Category> objectArrayToCategoryWithTranslation(List<Object[]> objectArrays) {
        throw new IllegalArgumentException();
    }


    default Category objectArrayToCategoryWithTranslation(Object[] objectArray){
        throw new IllegalArgumentException();
    }
}