package com.maf.pim.mapper;

import com.maf.pim.dto.PatchProductResponse;
import com.maf.pim.dto.PatchProductTranslationResponse;
import com.maf.pim.entity.Product;
import com.maf.pim.entity.translation.ProductTranslation;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

@Mapper(componentModel = "spring")
public interface PatchProductResponseMapper {

    PatchProductResponseMapper INSTANCE = Mappers.getMapper(PatchProductResponseMapper.class);

    @Mapping(source = "id.code", target = "code")
    @Mapping(source = "id.country", target = "country")
    PatchProductResponse productToProductResponse(Product product);

    @Mapping(source = "id.language", target = "language")
    PatchProductTranslationResponse productTranslationToProductTranslationResponse(ProductTranslation productTranslations);
}