package com.maf.pim.entitygraph;

import com.cosium.spring.data.jpa.entity.graph.domain2.DynamicEntityGraph;
import com.maf.pim.enums.option.GenericOption;

import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

public class EntityGraphFactory {
    public static DynamicEntityGraph getEntityGraph(List<GenericOption> productOptions){
        return DynamicEntityGraph.fetching(productOptions.stream()
                .map(GenericOption::getAttribute)
                .filter(Objects::nonNull)
                .collect(Collectors.toList()));
    }
}
