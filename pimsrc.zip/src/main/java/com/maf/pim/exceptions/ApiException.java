package com.maf.pim.exceptions;

import lombok.Getter;
import lombok.Setter;

import java.io.Serial;
import java.io.Serializable;

@Getter
@Setter
public class ApiException extends RuntimeException implements Serializable {

    @Serial
    private static final long serialVersionUID = -1568038561698864895L;

    private final ApiErrors apiErrors;

    public ApiException(ApiErrors apiErrors) {
        super(apiErrors.message);
        this.apiErrors = apiErrors;
    }

}
