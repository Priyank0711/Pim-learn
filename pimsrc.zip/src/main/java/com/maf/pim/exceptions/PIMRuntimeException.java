package com.maf.pim.exceptions;

import lombok.Data;

@Data
public class PIMRuntimeException extends RuntimeException {

    private String errorCode;

    public PIMRuntimeException(String message) {
        super(message);
    }

    public PIMRuntimeException(String message, String errorCode) {
        super(message);
        this.errorCode = errorCode;
    }
}
