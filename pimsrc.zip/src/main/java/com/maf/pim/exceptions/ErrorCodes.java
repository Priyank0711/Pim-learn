package com.maf.pim.exceptions;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum ErrorCodes {

    INTERNAL_SERVER_ERROR(500001, "Something went wrong, Please try after sometime."),
    CATEGORY_NOT_FOUND(404001, "no categories found"),
    PRODUCT_NOT_FOUND(404002, "Product not found"),
    TEMPLATE_ATTRIBUTE_NOT_FOUND(404003,"no attributes found for given template category"),
    MEDIA_NOT_FOUND(404004, "Media not found"),
    ATTRIBUTE_ASSIGNMENT_NOT_FOUND(404005, "Attribute not found for given product"),
    INVALID_ATTRIBUTE_VALUE(400005, "Invalid attribute value for given feature type"),
    INVALID_BOOLEAN_ATTRIBUTE_VALUES(400005, "Multiple values found for a boolean type attribute"),
    DUPLICATE_MEDIA_FOUND(404005, "Duplicate media Found, media already exists"),
    MEDIA_EXISTS(404006, "Media name already exists");

    final Integer code;
    final String message;

}
