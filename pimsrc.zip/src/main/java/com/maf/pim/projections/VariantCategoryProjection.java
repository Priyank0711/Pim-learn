package com.maf.pim.projections;

import com.maf.pim.entity.Category;
import com.maf.pim.entity.ProductId;

public interface VariantCategoryProjection {
    Category getVariantCategory();
    ProductId getProductId();
}
