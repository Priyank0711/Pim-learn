package com.maf.pim.projections;

import com.maf.pim.enums.Country;
import com.maf.pim.enums.Language;

public interface ProductAttrValueProjection {
    String getProductCode();
    Long getAssignmentId();
    String getProductCountry();
    String getLanguage();
    String getValue();

    default Country getCountry() {
        return Country.valueOf(getProductCountry());
    }

    default Language getLang() {
        return Language.valueOf(getLanguage());
    }

}
