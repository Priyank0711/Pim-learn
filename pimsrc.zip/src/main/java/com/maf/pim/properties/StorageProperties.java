package com.maf.pim.properties;

import jakarta.validation.constraints.NotEmpty;
import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;


@ConfigurationProperties("azure.storage")
@Data
public class StorageProperties {
    @NotEmpty
    private String accountName;

    @NotEmpty
    private String mediaContainerName;

    @NotEmpty
    private String integrationContainerName;

    @NotEmpty
    private String connectionString;

    private boolean enableHttps = false;

}