package com.maf.pim.properties;

import lombok.Data;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

import java.util.Map;

@Data
@Configuration
public class ElasticSearchIndexes {

    @Value("#{${online-product.indexes}}")
    private Map<String, String> indexes;

}
