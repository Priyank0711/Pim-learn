package com.maf.pim.properties;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;

@ConfigurationProperties("sftp.storage")
@Data
public class SftpProperties {
    private String host;
    private int port;
    private String user;
    private String password;
}
