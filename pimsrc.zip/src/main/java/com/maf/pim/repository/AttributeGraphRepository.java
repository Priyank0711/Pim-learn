package com.maf.pim.repository;

import com.cosium.spring.data.jpa.entity.graph.domain2.DynamicEntityGraph;
import com.cosium.spring.data.jpa.entity.graph.repository.EntityGraphJpaRepository;
import com.maf.pim.entity.Attribute;
import com.maf.pim.enums.Country;

import java.util.Optional;

public interface AttributeGraphRepository extends EntityGraphJpaRepository<Attribute, String> {
    Optional<Attribute> findByCodeAndCountry(String code, Country country, DynamicEntityGraph entityGraph);
}
