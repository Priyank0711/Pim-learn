package com.maf.pim.repository;

import com.cosium.spring.data.jpa.entity.graph.domain2.DynamicEntityGraph;
import com.cosium.spring.data.jpa.entity.graph.repository.EntityGraphJpaRepository;
import com.maf.pim.entity.Category;
import com.maf.pim.enums.Country;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface CategoryGraphRepository extends EntityGraphJpaRepository<Category, String> {
    Optional<Category> findByCountryAndCode(Country country, String code, DynamicEntityGraph entityGraph);
}
