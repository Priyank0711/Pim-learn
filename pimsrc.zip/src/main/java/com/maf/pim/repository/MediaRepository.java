package com.maf.pim.repository;

import com.maf.pim.entity.Media;
import com.maf.pim.entity.MediaId;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface MediaRepository extends JpaRepository<Media, MediaId> {
}
