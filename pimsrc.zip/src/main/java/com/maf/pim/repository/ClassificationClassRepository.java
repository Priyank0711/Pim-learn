package com.maf.pim.repository;

import com.maf.pim.entity.ClassificationClass;
import com.maf.pim.enums.Country;
import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

import java.util.List;

public interface ClassificationClassRepository extends JpaRepository<ClassificationClass, String> {

    Optional<ClassificationClass> findByCodeAndCountry(String code, Country country);

    @Override
    @EntityGraph(attributePaths = {"classificationClassTranslations"})
    List<ClassificationClass> findAllById(Iterable<String> ids);
}
