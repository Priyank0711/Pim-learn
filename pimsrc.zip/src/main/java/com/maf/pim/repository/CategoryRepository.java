package com.maf.pim.repository;

import com.maf.pim.entity.Category;
import com.maf.pim.enums.CategoryType;
import com.maf.pim.enums.Country;
import com.maf.pim.enums.Language;
import com.maf.pim.projections.VariantCategoryProjection;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.util.List;
import java.util.Optional;

@Repository
public interface CategoryRepository extends JpaRepository<Category, String> {

    List<Category> findAllByCountryAndCodeIn(Country country, List<String> codes);
    Optional<Category> findByCodeAndCountry(String code, Country country);

    @Query(value = "Select * from category where nlevel(path)=3 and country =:country and category_type = :type", nativeQuery = true)
    Page<Category> findTopLevelCategories(@Param("country") String country, @Param("type") String type, Pageable pageable);

    Page<Category> findAllByParentId(@Param("parentId") String parentId, Pageable pageable);

    List<Category> findByCountryAndCategoryTypeAndCategoryTranslationsLanguageAndCategoryTranslationsNameContainsIgnoreCase(
            Country country, CategoryType type, Language language, String searchWord);

    @Query(value = "select mc.id,mc.code,mc.category_type,mc.country,mc.modified_date,mc.parent_id, mc.path \\:\\: text AS " +
            "path, nlevel(path) as level, ct.language, ct.name, ct.category_id, ct.id, mc.substituted from category mc " +
            "LEFT JOIN category_translation ct on ct.category_id = mc.id where mc.path @> CAST((:path) AS ltree) " +
            "and nlevel(mc.path) > :level order by path desc",nativeQuery = true)
    List<Object[]> findAncestorForCategoryPath(@Param("path") String path, @Param("level") int level);

    @Query(value = "select * from category mc where mc.path <@ CAST((:path) AS ltree) order by path", nativeQuery = true)
    List<Category> findDescendantsForCategoryPath(@Param("path") String path);

    @Transactional
    @Modifying
    @Query(value = "update category set modified_date=CURRENT_TIMESTAMP at time zone 'UTC' where id IN (:ids)", nativeQuery = true)
    void updateDescendantsPath(@Param("ids") List<String> ids);

    @Query(value = "select mc.id,mc.code,mc.category_type,mc.country,mc.modified_date,mc.parent_id, mc.path \\:\\: text AS path, mc.substituted, " +
            "mc.l1_attr_code, mc.l2_attr_code, mc.l3_attr_code, mc.variant_image_level" +
            " from category mc JOIN category_translation ct on ct.category_id = mc.id where mc.country=:country and mc.category_type = 'BRAND' and ct.language='EN' and ct.name ilike :brandName", nativeQuery = true)
    List<Category>  getBrandCategories(String brandName, String country);

    @Query(value = "select c.* from product_category pc inner join category c " +
            "on pc.category_id = c.id and c.country= :country where pc.product_code = :productCode", nativeQuery = true)
    List<Category> findForProduct(String country, String productCode);

    @Transactional
    @Modifying
    @Query(value = "Insert into product_category(product_code, product_country, category_id) " +
            "select trim(product_code), :productCountry, :categoryId from unnest(:productIds) AS product_code on conflict do nothing", nativeQuery = true)
    void attachProducts(String[] productIds, String categoryId, String productCountry);

    @Transactional
    @Modifying
    @Query(value = "delete from product_category where product_country = :country and category_id = :categoryId", nativeQuery = true)
    void detachAllProducts(String categoryId, String country);

    @Query(value = "select c as variantCategory, p.id as productId from Category c left join fetch c.categoryTranslations join c.product p where c.country = :country and c.categoryType = :categoryType ")
    List<VariantCategoryProjection> findAllByCountryAndCategoryType(Country country, CategoryType categoryType);

    @Query(value = "select c as variantCategory, p.id as productId from Category c " +
            "left join fetch c.categoryTranslations join c.product p where c.country = :country and p.id.country = :country " +
            "and c.categoryType = :categoryType and " +
            "(c.modifiedDate > :lastModifiedDate or EXISTS (SELECT 1 FROM Product p JOIN p.categories pc WHERE pc = c AND p.modifiedDate > :lastModifiedDate)) ")
    List<VariantCategoryProjection> findAllByCountryAndCategoryTypeAndModifiedDateAndProductModifiedDate(Country country, CategoryType categoryType, Instant lastModifiedDate);

    @Query(value = "select c as variantCategory, p.id as productId from Category c left join fetch c.categoryTranslations join c.product p where c.country = :country and c.code in (:variantCodes) and c.categoryType = :categoryType ")
    List<VariantCategoryProjection> findAllByCountryAndCodeInAndType(Country country, List<String> variantCodes, CategoryType categoryType);
}
