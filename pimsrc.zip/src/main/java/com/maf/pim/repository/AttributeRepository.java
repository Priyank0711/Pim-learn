package com.maf.pim.repository;

import com.maf.pim.entity.Attribute;
import com.maf.pim.enums.Country;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface AttributeRepository extends JpaRepository<Attribute, String> {

    Optional<Attribute> findByCodeAndCountry(String code, Country country);
}
