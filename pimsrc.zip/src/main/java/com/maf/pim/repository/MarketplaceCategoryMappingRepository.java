package com.maf.pim.repository;

import com.maf.pim.entity.Category;
import com.maf.pim.entity.MarketplaceCategoryMapping;
import com.maf.pim.entity.MarketplaceCategoryMappingId;
import com.maf.pim.enums.CategoryType;
import com.maf.pim.enums.Country;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface MarketplaceCategoryMappingRepository extends JpaRepository<MarketplaceCategoryMapping, MarketplaceCategoryMappingId> {

    List<MarketplaceCategoryMapping> findByIdCountryAndIdCategoryTypeAndTargetCategory(Country country, CategoryType categoryType, Category targetCategory);
}
