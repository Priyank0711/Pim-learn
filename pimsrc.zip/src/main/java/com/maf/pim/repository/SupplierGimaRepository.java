package com.maf.pim.repository;

import com.maf.pim.entity.Supplier;
import com.maf.pim.entity.SupplierGima;
import com.maf.pim.entity.SupplierGimaId;
import com.maf.pim.entity.SupplierGimaStatusesProjection;
import com.maf.pim.enums.Country;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Repository
public interface SupplierGimaRepository extends JpaRepository<SupplierGima, SupplierGimaId> {

    @Transactional
    @Modifying
    @Query(value = "INSERT INTO supplier_gima (product_code, country, pos, supplier_id, status, reference, modified_date) VALUES (:#{#supplierGima.id.productCode}, :#{#supplierGima.id.country.name()}, :#{#supplierGima.id.pos}, :#{#supplierGima.id.supplier.id}, :#{#supplierGima.status}, :#{#supplierGima.reference}, :#{#supplierGima.modifiedDate}) "+
            "ON CONFLICT(product_code, country, pos, supplier_id) DO UPDATE "+
            "SET status = :#{#supplierGima.status}, "+
            "reference = :#{#supplierGima.reference}, "+
            "modified_date = :#{#supplierGima.modifiedDate}", nativeQuery = true)
    void upsert(SupplierGima supplierGima);

    @Query("SELECT sg FROM SupplierGima sg JOIN FETCH sg.id.supplier WHERE sg.id.country = :country AND sg.id.productCode = :productCode AND sg.status NOT IN :INACTIVE_STATUS_LIST AND sg.id.pos = :pos")
    List<SupplierGima> findAllByIdProductCodeAndIdCountryAndIdPosJoinFetch(String productCode, Country country, String pos, List<String> INACTIVE_STATUS_LIST);

    @Query(value = "SELECT product_code AS productCode, supplier_id AS supplierId, array_agg(distinct status) AS supplierGimaStatuses FROM supplier_gima WHERE country = :#{#country.name()} AND product_code IN (:productCodes) GROUP BY product_code, supplier_id", nativeQuery = true)
    List<SupplierGimaStatusesProjection> findAllInProductCodesAndCountryGroupedByProductCodeAndSupplierId(List<String> productCodes, Country country);

    @Query("SELECT s FROM SupplierGima sg JOIN  Supplier s ON sg.id.supplier.id = s.id WHERE sg.id.country = :country AND sg.id.productCode = :productCode AND sg.status NOT IN :INACTIVE_STATUS_LIST GROUP BY s")
    List<Supplier> findSuppliersByProductCodeAndCountryWithActiveStatus(String productCode, Country country,List<String> INACTIVE_STATUS_LIST);

}
