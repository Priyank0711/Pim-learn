package com.maf.pim.repository;

import com.cosium.spring.data.jpa.entity.graph.domain2.DynamicEntityGraph;
import com.cosium.spring.data.jpa.entity.graph.repository.EntityGraphJpaRepository;
import com.maf.pim.entity.ClassificationClass;
import com.maf.pim.enums.Country;

import java.util.Optional;

public interface ClassificationClassGraphRepository extends EntityGraphJpaRepository<ClassificationClass, String> {

    Optional<ClassificationClass> findByCodeAndCountry(String code, Country country, DynamicEntityGraph entityGraph);

}
