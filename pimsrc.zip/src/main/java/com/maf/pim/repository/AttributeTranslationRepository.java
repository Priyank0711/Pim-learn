package com.maf.pim.repository;

import com.maf.pim.entity.translation.AttributeTranslation;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AttributeTranslationRepository extends JpaRepository<AttributeTranslation, Long> {
}
