package com.maf.pim.repository;

import com.maf.pim.entity.Category;
import com.maf.pim.entity.ClassificationClass;

import java.util.List;
import java.util.Set;

public interface ExtendedCategoryRepository {

    List<Object[]> findSuperCategories(Category category, boolean requiredRootCategory);
    Set<ClassificationClass> getClassificationsByCategory(Category category);

    Set<ClassificationClass> getClassificationsWithParentsByCategory(Category category);
}
