package com.maf.pim.repository;

import com.maf.pim.entity.Product;
import com.maf.pim.entity.ProductId;
import com.maf.pim.enums.Country;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.util.List;
import java.util.Optional;
import java.util.Set;

@Repository
public interface ProductRepository extends JpaRepository<Product, ProductId> {

    @Modifying
    @Query(value = "INSERT INTO product\n" +
            "            (\n" +
            "                        code,\n" +
            "                        country,\n" +
            "                        depth,\n" +
            "                        gross_weight,\n" +
            "                        height,\n" +
            "                        nature,\n" +
            "                        nbr_of_month,\n" +
            "                        product_food_type,\n" +
            "                        product_type,\n" +
            "                        unit_item,\n" +
            "                        warranty,\n" +
            "                        width,\n" +
            "                        year_of_warranty,\n" +
            "                        department,\n" +
            "                        section,\n" +
            "                        family,\n" +
            "                        sub_family,\n" +
            "                        ean,\n" +
            "                        gica_vat_cod,\n" +
            "                        gica_vat_per,\n" +
            "                        item_measure,\n" +
            "                        item_status,\n" +
            "                        code_delivery_gica,\n" +
            "                        number_of_unit,\n" +
            "                        modified_date,\n" +
            "                        creation_time,\n" +
            "                        assortments,\n" +
            "                        supplier_id\n" +
            "            )\n" +
            "VALUES (:#{#product.id.code},\n" +
            "       :#{#product.countryNative},\n" +
            "       :#{#product.depth},\n" +
            "       :#{#product.grossWeight},\n" +
            "       :#{#product.height},\n" +
            "       :#{#product.natureNative},\n" +
            "       :#{#product.nbrOfMonth},\n" +
            "       :#{#product.productFoodTypeNative},\n" +
            "       :#{#product.productTypeNative},\n" +
            "       :#{#product.unitItem},\n" +
            "       :#{#product.warranty},\n" +
            "       :#{#product.width},\n" +
            "       :#{#product.yearOfWarranty},\n" +
            "       :#{#product.department},\n" +
            "       :#{#product.section},\n" +
            "       :#{#product.family},\n" +
            "       :#{#product.subFamily},\n" +
            "       :#{#product.ean},\n" +
            "       :#{#product.gicaVatCod},\n" +
            "       :#{#product.gicaVatPer},\n" +
            "       :#{#product.itemMeasure},\n" +
            "       :#{#product.itemStatus},\n" +
            "       :#{#product.codeDeliveryGica},\n" +
            "       :#{#product.numberOfUnit},\n" +
            "       :#{#product.modifiedDate},\n" +
            "       :#{#product.creationTime},\n" +
            "       :#{#product.assortmentsNative},\n" +
            "       :#{#product.supplierIdNative})\n" +
            "on conflict (code, country) do UPDATE\n" +
            "set    depth=:#{#product.depth},\n" +
            "       gross_weight=:#{#product.grossWeight},\n" +
            "       height=:#{#product.height},\n" +
            "       nature= coalesce(:#{#product.natureNative},product.nature),\n" +
            "       nbr_of_month=:#{#product.nbrOfMonth},\n" +
            "       product_food_type=:#{#product.productFoodTypeNative},\n" +
            "       product_type= CASE WHEN product.product_type is null THEN :#{#product.productTypeNative} ELSE product.product_type END,\n" +
            "       unit_item=:#{#product.unitItem},\n" +
            "       warranty=:#{#product.warranty},\n" +
            "       width=:#{#product.width},\n" +
            "       year_of_warranty=:#{#product.yearOfWarranty},\n" +
            "       ean=:#{#product.ean},\n" +
            "       gica_vat_cod=:#{#product.gicaVatCod},\n" +
            "       gica_vat_per=:#{#product.gicaVatPer},\n" +
            "       item_measure=:#{#product.itemMeasure},\n" +
            "       item_status=:#{#product.itemStatus},\n" +
            "       code_delivery_gica=:#{#product.codeDeliveryGica},\n" +
            "       number_of_unit=:#{#product.numberOfUnit},\n" +
            "       assortments=:#{#product.assortmentsNative},\n" +
            "       modified_date=:#{#product.modifiedDate},\n" +
            "       supplier_id= :#{#product.supplierIdNative}"
            , nativeQuery = true)
    void upsert(@Param("product") Product product);

    @Query(value = "select p from Product p where p.id.country = :country and (p.id.code = :code or p.ean = :code)")
    Optional<Product> findByCodeOrEan(String code, Country country);

    @Query( value = "select p.id from Product p where p.id.country=:country and coalesce(p.marketplaceProduct,false)=:marketplaceProduct",
            countQuery = "select count(*) from Product p where p.id.country = :country and coalesce(p.marketplaceProduct,false)=:marketplaceProduct")
    Page<ProductId> findIdsByIdCountry(Country country, boolean marketplaceProduct, Pageable pageable);

    @Query(value = "select p.id from Product p where p.id.country=:country " +
            "and coalesce(p.marketplaceProduct,false)=:marketplaceProduct and ( p.modifiedDate > :modifiedDate " +
            "or Exists (select 1 from p.categories c where c.modifiedDate > :modifiedDate))",
            countQuery = "select count(*) from Product p where p.id.country=:country " +
                    "and coalesce(p.marketplaceProduct,false)=:marketplaceProduct and (p.modifiedDate > :modifiedDate " +
                    "or Exists (select 1 from p.categories c where c.modifiedDate > :modifiedDate))")
    Page<ProductId> findIdsByIdCountryAndMarketplaceProductAndModifiedDateGreaterThan(Country country, boolean marketplaceProduct, Instant modifiedDate, Pageable pageable);

    @Query(value = "SELECT * FROM (SELECT DISTINCT ON (p.code) p.code, p.modified_date FROM product p JOIN supplier_gima sg ON p.code = sg.product_code AND p.country = sg.country WHERE p.country =:#{#country.name()}) AS res",
            countQuery = "SELECT COUNT(DISTINCT p.code) FROM product p JOIN supplier_gima sg ON p.code = sg.product_code AND p.country = sg.country WHERE p.country =:#{#country.name()}", nativeQuery = true)
    Page<Object[]> findIdsWithSupplierGimaByCountry(Country country, Pageable pageable);

    @Query(value = "SELECT * FROM (SELECT DISTINCT ON (p.code) p.code, p.modified_date FROM product p JOIN supplier_gima sg ON p.code = sg.product_code AND p.country = sg.country WHERE p.country =:#{#country.name()} AND (" +
            "sg.modified_date > :modifiedDate OR " +
            "sg.supplier_id IN :supplierIds OR " +
            "p.supplier_id IN :supplierIds" +
            ")) AS res",
    countQuery = "SELECT COUNT(DISTINCT p.code) FROM product p JOIN supplier_gima sg ON p.code = sg.product_code AND p.country = sg.country WHERE p.country =:#{#country.name()} AND (" +
            "sg.modified_date > :modifiedDate OR " +
            "sg.supplier_id IN :supplierIds OR " +
            "p.supplier_id IN :supplierIds" +
            ")", nativeQuery = true)
    Page<Object[]> findIdsWithSupplierOrSupplierGimaInSyncSuppliersByModifiedDataAndCountry(Country country, Instant modifiedDate, Set<String> supplierIds, Pageable pageable);

    @Modifying
    @Transactional
    @Query(value = "Update product set approval_status= :approvalStatus, modified_date=CURRENT_TIMESTAMP at time zone 'UTC', " +
            "status_start_date =:startDate, status_end_date = :endDate " +
            "where country= :country and code= :code ;", nativeQuery = true)
    int updateApprovalStatus(String code, String country, String approvalStatus, Instant startDate, Instant endDate);

    @Modifying
    @Transactional
    @Query(value = "Update product set unpublished_pos= :unpublishedPos, modified_date=CURRENT_TIMESTAMP at time zone 'UTC' " +
            "where country= :country and code= :code ;", nativeQuery = true)
    int updateUnpublishedPos(String code, String country, String[] unpublishedPos);

    @Modifying
    @Transactional
    @Query(value = "UPDATE product SET barcodes = :barcodes, modified_date = current_timestamp AT TIME ZONE 'UTC' WHERE code = :code AND country = :country", nativeQuery = true)
    int updateProductBarcodes(@Param("barcodes") String[] barcodes, @Param("code") String code, @Param("country") String country);

    @Modifying
    @Query(value = "INSERT INTO product_category (category_id, product_code, product_country) " +
            "Select id, :productCode, country from category where country= :country and id IN :categoryIds", nativeQuery = true)
    void insertCategoriesForProduct(List<String> categoryIds, String country, String productCode);

    @Modifying
    @Query(value = "DELETE FROM product_category WHERE product_code= :productCode AND product_country= :country AND category_id IN :categoryIds", nativeQuery = true)
    void deleteCategoriesForProduct(List<String> categoryIds, String country, String productCode);

    @Modifying
    @Query(value = "INSERT INTO public.product_translation (language, product_code, product_country, name) VALUES (:language, :productCode, :country, :name) " +
            "ON CONFLICT (language, product_country, product_code) DO UPDATE SET name = :name, modified_date=current_timestamp at time zone 'UTC'", nativeQuery = true)
    void updateProductTranslations(String productCode, String country, String name, String language);
}
