package com.maf.pim.repository;

import com.maf.pim.entity.ProductAttributeValue;
import com.maf.pim.entity.ProductAttributeValueId;
import com.maf.pim.entity.ProductId;
import com.maf.pim.projections.ProductAttrValueProjection;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;
import java.util.Set;

public interface ProductAttributeValueRepository extends JpaRepository<ProductAttributeValue, ProductAttributeValueId> {

    @Query(value = "select pav from ProductAttributeValue pav join fetch pav.id.assignment aa join fetch pav.id.product where pav.id.product.id in (:productIds) and trim(pav.value) <> '' ")
    List<ProductAttributeValue> findWithAttributeByIdProductIdIn(List<ProductId> productIds);

    @Query(value = "select pav from ProductAttributeValue pav join fetch pav.id.assignment aa join fetch pav.id.product where pav.id.product.id = :productId")
    List<ProductAttributeValue> findAttributesByIdProductId(ProductId productId);

    @Query(value = "select pav from ProductAttributeValue pav where pav.id.product.id = :productId AND pav.id.assignment.id = :assignmentId")
    List<ProductAttributeValue> findByIdProductIdAndAssignmentId(ProductId productId, Long assignmentId);

    @Query(value = "select pav.language, pav.product_country as productCountry, " +
            "pav.product_code as productCode,pav.assignment_id as assignmentId, pav.value " +
            "from product_attribute_value pav where product_country = :country and " +
            "product_code in (:productIds) and assignment_id in (:assignmentIds) and trim(value) <> ''", nativeQuery = true)
    List<ProductAttrValueProjection> findAllByProductIdsAndAssignmentIds(String country, Set<String> productIds, Set<Long> assignmentIds);
}
