package com.maf.pim.repository;

import com.maf.pim.entity.translation.CategoryTranslation;
import com.maf.pim.enums.CategoryType;
import com.maf.pim.enums.Country;
import com.maf.pim.enums.Language;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Set;

public interface CategoryTranslationRepository extends JpaRepository<CategoryTranslation, Long> {

    List<CategoryTranslation> findAllByLanguageAndNameIgnoreCaseInAndCategoryCategoryTypeEqualsAndCategoryCountry(Language language, Set<String> names, CategoryType type, Country country);

}
