package com.maf.pim.repository;

import com.maf.pim.entity.SyncSupplier;
import com.maf.pim.enums.Country;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface SyncSupplierRepository extends JpaRepository<SyncSupplier, Country> {
}
