package com.maf.pim.repository;

import com.maf.pim.entity.CoreAttribute;
import com.maf.pim.enums.Country;
import com.maf.pim.enums.ProductType;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface CoreAttributeRepository extends JpaRepository<CoreAttribute, Long> {
    List<CoreAttribute> findAllByAttrTypeAndActiveAndCountryIn(ProductType type, boolean active, List<Country> countries);
}
