package com.maf.pim.repository;

import com.maf.pim.entity.translation.ClassificationClassTranslation;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ClassificationClassTranslationRepository extends JpaRepository<ClassificationClassTranslation, Long> {
}
