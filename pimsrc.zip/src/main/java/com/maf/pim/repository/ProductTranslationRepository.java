package com.maf.pim.repository;

import com.maf.pim.entity.ProductTranslationId;
import com.maf.pim.entity.translation.ProductTranslation;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProductTranslationRepository extends JpaRepository<ProductTranslation, ProductTranslationId> {
}
