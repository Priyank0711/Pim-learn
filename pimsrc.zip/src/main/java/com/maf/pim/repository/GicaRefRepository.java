package com.maf.pim.repository;

import com.maf.pim.entity.GicaReference;
import com.maf.pim.entity.GicaReferenceId;
import org.springframework.data.jpa.repository.JpaRepository;

public interface GicaRefRepository extends JpaRepository<GicaReference, GicaReferenceId> {
}
