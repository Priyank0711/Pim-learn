package com.maf.pim.repository;

import com.cosium.spring.data.jpa.entity.graph.domain2.DynamicEntityGraph;
import com.cosium.spring.data.jpa.entity.graph.repository.EntityGraphJpaRepository;
import com.maf.pim.entity.AttributeAssignment;
import com.maf.pim.entity.ClassificationClass;

import java.util.List;

public interface AttributeAssignmentGraphRepository extends EntityGraphJpaRepository<AttributeAssignment, String> {
    List<AttributeAssignment> findAllByClassificationClass(ClassificationClass classification, DynamicEntityGraph entityGraph);
}
