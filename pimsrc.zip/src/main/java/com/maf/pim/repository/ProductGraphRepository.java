package com.maf.pim.repository;

import com.cosium.spring.data.jpa.entity.graph.domain2.DynamicEntityGraph;
import com.cosium.spring.data.jpa.entity.graph.repository.EntityGraphJpaRepository;
import com.maf.pim.entity.Product;
import com.maf.pim.entity.ProductId;
import com.maf.pim.enums.Country;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Repository;

import java.time.Instant;
import java.util.List;
import java.util.Optional;

@Repository
public interface ProductGraphRepository extends EntityGraphJpaRepository<Product, ProductId> {

    Page<Product> findAllByIdCountryAndModifiedDateGreaterThan(Country country, Instant time, DynamicEntityGraph entityGraph, Pageable pageable);

    Page<Product> findAllByIdCountry(Country country, DynamicEntityGraph entityGraph, Pageable pageable);

    List<Product> findByIdIn(List<ProductId> productIds, DynamicEntityGraph entityGraph);
    Optional<Product> findByEanAndIdCountry(String ean, Country country, DynamicEntityGraph entityGraph);

}
