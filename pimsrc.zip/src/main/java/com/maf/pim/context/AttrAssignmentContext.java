package com.maf.pim.context;

import com.maf.pim.entity.ProductAttributeValue;
import lombok.Data;

import java.util.List;
import java.util.Map;

@Data
public class AttrAssignmentContext extends SessionContext{
    private Map<Long, List<ProductAttributeValue>> assignmentValueMap;
}
