package com.maf.pim.context;

import com.maf.pim.entity.ProductAttributeValue;
import com.maf.pim.entity.ProductId;
import com.maf.pim.entity.SupplierGimaStatusesProjection;
import com.maf.pim.enums.Country;
import com.maf.pim.enums.Language;
import com.maf.pim.enums.ProductPicker;
import lombok.Data;

import java.util.List;
import java.util.Map;

@Data
public class SessionContext {
    private List<Language> languages;
    private Country country;
    private Map<ProductId,List<ProductAttributeValue>> productAttributeValueMap;
    private Map<ProductId,List<SupplierGimaStatusesProjection>> productSupplierGimaStatusesMap;
    private List<ProductPicker> productPickers;
    private boolean marketplaceProduct;
}
