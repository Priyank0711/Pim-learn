package com.maf.pim.context;

import com.maf.pim.enums.MediaFormat;
import com.maf.pim.enums.MediaType;
import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class MediaContext {
    private MediaFormat format;
    private MediaType type;
}
