package com.maf.pim.context;

import com.maf.pim.enums.Country;
import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class TranslationContext {
    private Country country;
}
