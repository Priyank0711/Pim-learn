package com.maf.pim.populator;

import com.maf.pim.enums.ProductType;

public interface ProductTypePopulator<S, T, C> extends ContextPopulator<S, T, C>  {
    ProductType getProductType();
}
