package com.maf.pim.populator;

import com.maf.pim.enums.ProductPicker;

public interface ProductContextPopulator<S, T, C> extends ContextPopulator<S, T, C> {
    ProductPicker getProductOption();
}
