package com.maf.pim.populator;

import com.maf.pim.enums.ProductSection;

public interface ReverseProductPopulator<S,T> extends Populator<S,T>{
    ProductSection getProductOption();

}
