package com.maf.pim.populator;

import com.maf.pim.enums.ProductSection;

public interface ProductSectionResponsePopulator<S, T> extends Populator<S, T> {

    ProductSection getProductSection();
}
