package com.maf.pim.populator;

import com.maf.pim.context.SessionContext;
import com.maf.pim.data.ProductData;
import com.maf.pim.entity.Product;
import com.maf.pim.enums.ProductPicker;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;
import org.springframework.util.CollectionUtils;

import java.util.Collection;
import java.util.Map;
import java.util.Set;
import java.util.function.Function;
import java.util.stream.Collectors;

@Service
@Slf4j
public class ProductConfigurablePopulator {
    private final Map<ProductPicker, ProductContextPopulator> productPopulators;

    public ProductConfigurablePopulator(final Set<ProductContextPopulator> productContextPopulators) {
        productPopulators = productContextPopulators.stream()
                .collect(Collectors.toMap(ProductContextPopulator::getProductOption, Function.identity()));
    }

    public void populate(final Product source, final ProductData target, final SessionContext sessionContext, final Collection<ProductPicker> options) {

        Assert.notNull(source, "Parameter [source] must not be null");
        Assert.notNull(target, "Parameter [target] must not be null");
        Assert.notEmpty(options, "Parameter [options] must not be empty");

        if (!CollectionUtils.isEmpty(getProductPopulators()))
        {
            for (final ProductPicker option : options) {
                final ProductContextPopulator<Product, ProductData, SessionContext> populator = getProductPopulators().get(option);
                if (populator == null) {
                    log.debug("No populator configured for option [" + option + "]");
                } else {
                    populator.populate( source,target, sessionContext);
                }
            }
        }

    }
    public Map<ProductPicker, ProductContextPopulator> getProductPopulators() {
        return productPopulators;
    }
}
