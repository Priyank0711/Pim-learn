package com.maf.pim.populator;

public interface ContextPopulator<S, T, C> {
    void populate( S source,T target, C context);
}
