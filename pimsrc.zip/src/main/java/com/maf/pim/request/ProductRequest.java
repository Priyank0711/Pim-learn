package com.maf.pim.request;

import com.maf.pim.entity.ProductId;
import com.maf.pim.enums.Country;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

import java.util.List;

@Data
public class ProductRequest {
    @NotNull @NotEmpty
    private List<String> codes;
    boolean syncToEventHub;
}
