package com.maf.pim.request;

import lombok.Data;

import java.util.Set;

@Data
public class SyncSupplierRequest {

    private Set<String> suppliersIds;
}
