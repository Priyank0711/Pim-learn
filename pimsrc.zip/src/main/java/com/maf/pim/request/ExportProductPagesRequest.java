package com.maf.pim.request;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

import java.time.Instant;

@Data
public class ExportProductPagesRequest {

    private Instant lastModifiedDate;

    @NotNull
    @Min(value = 0)
    private Integer startPage;

    @NotNull
    @Min(value = 1)
    private Integer numberOfPagesToProcess;

    private boolean includeOnlyMarketplaceProducts;
}
