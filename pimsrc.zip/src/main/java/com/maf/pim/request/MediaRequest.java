package com.maf.pim.request;

import com.maf.pim.enums.Country;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class MediaRequest {
    @NotNull @NotEmpty
    String productCode;
    @NotNull @NotEmpty
    String mediaCode;
}
