package com.maf.pim.comparator;

import com.maf.pim.entity.Media;
import org.apache.commons.lang3.StringUtils;

import java.util.Comparator;

public class MediaComparator implements Comparator<Media> {
    @Override
    public int compare(Media m1, Media m2) {
        String name1 = m1.getName();
        String name2 = m2.getName();

        boolean isNumeric1 = StringUtils.isNotBlank(name1) && name1.matches(".*_(\\d+).*");
        boolean isNumeric2 = StringUtils.isNotBlank(name2) && name2.matches(".*_(\\d+).*");

        if (isNumeric1 && isNumeric2) {
            // Both names are numeric, compare their numeric parts
            Integer num1 = Integer.parseInt(name1.replaceAll(".*_(\\d+).*", "$1"));
            Integer num2 = Integer.parseInt(name2.replaceAll(".*_(\\d+).*", "$1"));
            return num1.compareTo(num2);
        } else if (isNumeric1) {
            // Only name1 is numeric, it should come before name2
            return -1;
        } else if (isNumeric2) {
            // Only name2 is numeric, it should come before name1
            return 1;
        } else {
            // Neither name is numeric, consider them equal
            return 0;
        }
    }
}
