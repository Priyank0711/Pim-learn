import com.maf.core.model.BrandCategoryModel
import com.microsoft.azure.storage.CloudStorageAccount
import com.microsoft.azure.storage.blob.CloudBlobClient
import com.microsoft.azure.storage.blob.CloudBlobContainer
import com.microsoft.azure.storage.blob.CloudBlockBlob
import com.opencsv.CSVWriter
import de.hybris.platform.catalog.model.CatalogVersionModel
import de.hybris.platform.category.model.CategoryModel
import de.hybris.platform.core.servicelayer.data.SearchPageData
import de.hybris.platform.cronjob.enums.CronJobResult
import de.hybris.platform.cronjob.enums.CronJobStatus
import de.hybris.platform.servicelayer.cronjob.PerformResult
import de.hybris.platform.servicelayer.search.FlexibleSearchQuery
import de.hybris.platform.servicelayer.search.paginated.PaginatedFlexibleSearchParameter
import de.hybris.platform.servicelayer.search.paginated.util.PaginatedSearchUtils
import com.maf.core.model.BrandCategoryModel
import com.maf.core.model.GicaCategoryModel
import com.maf.core.model.NavigationCategoryModel
import com.maf.core.model.PromotionCategoryModel
import com.maf.marketplace.services.model.MarketplaceCategoryModel
import de.hybris.platform.catalog.model.classification.*;

final String storeId = cronjob.getBaseStore().getUid();
final String country = storeId.replace('maf','').toUpperCase();
final String catalogId = storeId + 'ProductCatalog';
println '';
println 'catalogId ' + catalogId;
final CatalogVersionModel catalogVersion = catalogVersionService.getCatalogVersion(catalogId, 'Online');

int currentPage = Integer.parseInt(cronjob.getLastDocumentNumber());
int pageSize = 40000;
boolean autoIncrement = cronjob.getUseCommissionInvoiceCyclePeriod();

final String categoriesQuery = "select distinct({pk}) from {category} where {catalogversion} = ?catalogVersion and ({code} = 'brands_category' or ({pk}  NOT IN ({{ select {ccr:target} from {categorycategoryrelation as ccr join category as c on {ccr:source} = {c:pk}} }}) and {pk} IN ({{select {pcr:source} from {CategoryProductRelation as pcr join category as c on {pcr:source}={c:pk} join Product as p on {pcr:target}={p:pk}} where {p:catalogversion} = ?catalogVersion}})))";
final FlexibleSearchQuery searchQuery = new FlexibleSearchQuery(categoriesQuery);
searchQuery.addQueryParameter('catalogVersion', catalogVersion);

PaginatedFlexibleSearchParameter parameter = new PaginatedFlexibleSearchParameter();
SearchPageData searchPageData = PaginatedSearchUtils.createSearchPageDataWithPagination(pageSize, currentPage, true);
parameter.setFlexibleSearchQuery(searchQuery);
parameter.setSearchPageData(searchPageData);
SearchPageData<CategoryModel> searchResult = paginatedFlexibleSearchService.search(parameter);

int totalNumberOfPages=searchResult.getPagination().getNumberOfPages();
int totalNumberOfResults=searchResult.getPagination().getTotalNumberOfResults();
int size=searchResult.getResults().size();

println 'currentPage = '+currentPage;
println 'pageSize = '+pageSize;
println 'totalNumberOfPages = '+totalNumberOfPages;
println 'totalNumberOfResults = '+totalNumberOfResults;
println 'resultSize = '+size;

int classificationProducts = 0;

final Collection<CategoryModel> categories = searchResult.getResults();

if(size>0 && currentPage <= totalNumberOfPages){

	List<String> columsHeaders = Arrays.asList('CODE','NAME[en]','NAME[ar]','PARENT_CODE','CATEGORY_TYPE');

	char ch = '|';
	File file = new File('BrandCategories_'+country+'_'+currentPage+'.csv');
	println 'Writing to File ' + file.getName();

	csvWriter = new CSVWriter(new FileWriter(file), ch, CSVWriter.DEFAULT_QUOTE_CHARACTER, CSVWriter.DEFAULT_ESCAPE_CHARACTER);

	List<String[]> lines = new ArrayList<String[]>();
	lines.add(columsHeaders.toArray(new String[columsHeaders.size()]));

	for(final CategoryModel category:categories){
		lookupExportableCategories(category, lines, null)

	}

	csvWriter.writeAll(lines);
	try {
		csvWriter.close();
	} catch (IOException e) {
		e.printStackTrace();
	}

	//Upload to Dev
	String devConnectionString='DefaultEndpointsProtocol=https;AccountName=pimcoreservicedevelop;AccountKey=qYHP2r84KzSMRm++0NRERac5OHURRQW93RM9qMCTND03/m6eeu77WJvbHDybFydAmMkcFtZ/z93x+AStG/xIBg==;EndpointSuffix=core.windows.net';
	uploadFileToAzure(file, country, devConnectionString);
	uploadFileToOriginalAzure(file, country, devConnectionString);

	//Upload to Test
	String testConnectionString='DefaultEndpointsProtocol=https;AccountName=pimcoreservicetest;AccountKey=VTLUQMC8EBvtD2X46uZuBmqQDAxSwoFM+aa/qeNXjWg4HkAu7V1PMypFfDATQ1nQ9V16tU4hiwAR+ASt7vG2JA==;EndpointSuffix=core.windows.net';
	uploadFileToAzure(file, country, testConnectionString);
	uploadFileToOriginalAzure(file, country, testConnectionString);

	//Upload to Prod
	if(org.apache.commons.lang3.BooleanUtils.isTrue(cronjob.getIncludeConsignmentsNotSentToJde())){
		String prodConnectionString='DefaultEndpointsProtocol=https;AccountName=pimcoreservicemaster;AccountKey=/lw/Lum/lLmOuILNJIh+HiScvg+QzKvFCrCacSNlaseN9uyuXCr8HvGF0CqEmIR31hrrRA+owl4m+ASthtlxAw==;EndpointSuffix=core.windows.net';
		uploadFileToAzure(file, country, prodConnectionString);
		uploadFileToOriginalAzure(file, country, prodConnectionString);
	}
	file.delete();

}else{
	println '**********LIMIT REACHED*********'
	cronjob.setActive(false);
	modelService.save(cronjob)
	new PerformResult(CronJobResult.UNKNOWN, CronJobStatus.PAUSED)
}


private void lookupExportableCategories(CategoryModel currentCategory, List<String[]> lines, CategoryModel parentCategory) {

	if(!(currentCategory instanceof PromotionCategoryModel || currentCategory instanceof ClassificationClassModel)){
		List<String> line = new ArrayList<String>();
		line.add(currentCategory.getCode().replaceAll(",","_"));
		line.add(currentCategory.getName(Locale.forLanguageTag("en")));
		line.add(currentCategory.getName(Locale.forLanguageTag("ar")));
		line.add(parentCategory != null ? parentCategory.getCode() : currentCategory instanceof BrandCategoryModel ? "brands_category" : getParentCode(currentCategory));

		if(currentCategory instanceof BrandCategoryModel){
			line.add("BRAND");
		}else if(currentCategory instanceof GicaCategoryModel){
			line.add("GICA");

		}else if(currentCategory instanceof MarketplaceCategoryModel){
			line.add("MARKETPLACE");

		}else if(currentCategory instanceof NavigationCategoryModel){
			line.add("NAVIGATION");

		}else if(currentCategory instanceof PromotionCategoryModel){
			line.add("PROMOTION");

		}else{
			if(CategoryModel._TYPECODE.equals(currentCategory.getItemtype())
					&& org.apache.commons.collections4.CollectionUtils.isNotEmpty(currentCategory.getSupercategories())
					&& containsClassificationSuperCat(currentCategory)){
				line.add("CLASSIFICATION");
			}else{
				line.add("CATEGORY");
			}

		}
		lines.add(line.toArray(new String[line.size()]));

		for (CategoryModel subCategory : currentCategory.getCategories()) {

			lookupExportableCategories(subCategory, lines, currentCategory);
		}
	}
}

private boolean containsClassificationSuperCat(CategoryModel currentCategory){
	for(CategoryModel category : currentCategory.getSupercategories()){
		if(category.getCode().contains("nonfood_icecat_category") || ClassificationClassModel._TYPECODE.equals(category.getItemtype())){
			return true;
		}
	}
	return false;
}

private String getParentCode(CategoryModel category){
	if("brands_category".equals(category.getCode())){
		return "maf_category";
	}
	return "orphan_category"
}

private void uploadFileToAzure(File file, String country, String connectionString) {
	String containerName='integrations';
	String blobPath= 'data-migration/' + country+'/input/'+file.getName();
	println 'FileUploading='+file.getName();

	CloudStorageAccount storageAccount;
	try {
		storageAccount = CloudStorageAccount.parse(connectionString);
		CloudBlobClient blobClient = storageAccount.createCloudBlobClient();
		CloudBlobContainer container = blobClient.getContainerReference(containerName);

		final CloudBlockBlob blob = container.getBlockBlobReference(blobPath);
		blob.getProperties().setContentType('text/csv');
		blob.uploadFromFile(file.getPath());
	} catch (Exception e) {
		e.printStackTrace();
	}
}

private void uploadFileToOriginalAzure(File file, String country, String connectionString) {
	String containerName='integrations';
	String blobPath= 'data-migration/' + country+'/Original/Categories/'+file.getName();
	println 'FileUploading='+file.getName();

	CloudStorageAccount storageAccount;
	try {
		storageAccount = CloudStorageAccount.parse(connectionString);
		CloudBlobClient blobClient = storageAccount.createCloudBlobClient();
		CloudBlobContainer container = blobClient.getContainerReference(containerName);

		final CloudBlockBlob blob = container.getBlockBlobReference(blobPath);
		blob.getProperties().setContentType('text/csv');
		blob.uploadFromFile(file.getPath());
	} catch (Exception e) {
		e.printStackTrace();
	}
}




if(autoIncrement){
	cronjob.setLastDocumentNumber((currentPage+1).toString());
}
modelService.save(cronjob);