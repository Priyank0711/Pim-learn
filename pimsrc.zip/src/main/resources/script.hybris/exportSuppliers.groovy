import com.maf.core.model.SupplierModel
import com.microsoft.azure.storage.CloudStorageAccount
import com.microsoft.azure.storage.blob.CloudBlobClient
import com.microsoft.azure.storage.blob.CloudBlobContainer
import com.microsoft.azure.storage.blob.CloudBlockBlob
import com.opencsv.CSVWriter
import de.hybris.platform.core.servicelayer.data.SearchPageData
import de.hybris.platform.cronjob.enums.CronJobResult
import de.hybris.platform.cronjob.enums.CronJobStatus
import de.hybris.platform.servicelayer.cronjob.PerformResult
import de.hybris.platform.servicelayer.search.FlexibleSearchQuery
import de.hybris.platform.servicelayer.search.paginated.PaginatedFlexibleSearchParameter
import de.hybris.platform.servicelayer.search.paginated.util.PaginatedSearchUtils

final String storeId = cronjob.getBaseStore().getUid();
final String country = storeId.replace('maf', '').toUpperCase();

int currentPage = Integer.parseInt(cronjob.getLastDocumentNumber());
int pageSize = 40000;
boolean autoIncrement = cronjob.getUseCommissionInvoiceCyclePeriod();

final String categoriesQuery = "select distinct({pk}) from {Supplier} where {baseStore} = ?storeId";
final FlexibleSearchQuery searchQuery = new FlexibleSearchQuery(categoriesQuery);
searchQuery.addQueryParameter('storeId', storeId);

PaginatedFlexibleSearchParameter parameter = new PaginatedFlexibleSearchParameter();
SearchPageData searchPageData = PaginatedSearchUtils.createSearchPageDataWithPagination(pageSize, currentPage, true);
parameter.setFlexibleSearchQuery(searchQuery);
parameter.setSearchPageData(searchPageData);
SearchPageData<SupplierModel> searchResult = paginatedFlexibleSearchService.search(parameter);

int totalNumberOfPages = searchResult.getPagination().getNumberOfPages();
int totalNumberOfResults = searchResult.getPagination().getTotalNumberOfResults();
int size = searchResult.getResults().size();

println 'currentPage = ' + currentPage;
println 'pageSize = ' + pageSize;
println 'totalNumberOfPages = ' + totalNumberOfPages;
println 'totalNumberOfResults = ' + totalNumberOfResults;
println 'resultSize = ' + size;

final Collection<SupplierModel> suppliers = searchResult.getResults();

if (size > 0 && currentPage <= totalNumberOfPages) {

    List<String> columsHeaders = Arrays.asList('supplierNumber','supplierDescription','contactName','streetName','address1','address2','ADR2FO','city','regionCode',
            'countryCode','telephone','telephonePoste','faxNumber1','currencyCode','email','codeCountry');

    char ch = '|';
    File file = new File('GICASUPPLIER_' + country + '_' + currentPage + '.csv');
    println 'Writing to File ' + file.getName();

    csvWriter = new CSVWriter(new FileWriter(file), ch, CSVWriter.NO_QUOTE_CHARACTER, CSVWriter.NO_ESCAPE_CHARACTER);

    List<String[]> lines = new ArrayList<String[]>();
    lines.add(columsHeaders.toArray(new String[columsHeaders.size()]));

    for (final SupplierModel supplier : suppliers) {
        List<String> line = new ArrayList<String>();
        line.add(supplier.getCode());
        line.add(supplier.getDescription());
        line.add(supplier.getContactName());
        line.add(supplier.getStreetName());
        line.add(supplier.getFirstAddress());
        line.add(supplier.getSecondAddress());
        line.add(supplier.getPoBox());
        line.add(supplier.getCity());
        line.add(supplier.getRegionCode());
        line.add(supplier.getCountryCode());
        line.add(supplier.getTelephone());
        line.add(supplier.getTelephoniquePoste());
        line.add(supplier.getFaxNumber());
        line.add(supplier.getCurrency());
        line.add(supplier.getEmail());
        line.add(supplier.getCodeCountry());
        lines.add(line.toArray(new String[line.size()]));

    }

    csvWriter.writeAll(lines);
    try {
        csvWriter.close();
    } catch (IOException e) {
        e.printStackTrace();
    }

    //Upload to Dev
    String devConnectionString='DefaultEndpointsProtocol=https;AccountName=pimcoreservicedevelop;AccountKey=qYHP2r84KzSMRm++0NRERac5OHURRQW93RM9qMCTND03/m6eeu77WJvbHDybFydAmMkcFtZ/z93x+AStG/xIBg==;EndpointSuffix=core.windows.net';
    uploadFileToAzure(file, country, devConnectionString);
    uploadFileToOriginalAzure(file, country, devConnectionString);

    //Upload to Test
    String testConnectionString='DefaultEndpointsProtocol=https;AccountName=pimcoreservicetest;AccountKey=VTLUQMC8EBvtD2X46uZuBmqQDAxSwoFM+aa/qeNXjWg4HkAu7V1PMypFfDATQ1nQ9V16tU4hiwAR+ASt7vG2JA==;EndpointSuffix=core.windows.net';
    uploadFileToAzure(file, country, testConnectionString);
    uploadFileToOriginalAzure(file, country, testConnectionString);

    //Upload to Prod
    if(org.apache.commons.lang3.BooleanUtils.isTrue(cronjob.getIncludeConsignmentsNotSentToJde())) {
        String prodConnectionString='DefaultEndpointsProtocol=https;AccountName=pimcoreservicemaster;AccountKey=/lw/Lum/lLmOuILNJIh+HiScvg+QzKvFCrCacSNlaseN9uyuXCr8HvGF0CqEmIR31hrrRA+owl4m+ASthtlxAw==;EndpointSuffix=core.windows.net';
        uploadFileToAzure(file, country, prodConnectionString);
        uploadFileToOriginalAzure(file, country, prodConnectionString);
    }
    file.delete();

} else {
    println '**********LIMIT REACHED*********'
    cronjob.setActive(false);
    modelService.save(cronjob)
    new PerformResult(CronJobResult.UNKNOWN, CronJobStatus.PAUSED)
}


private void uploadFileToAzure(File file, String country, String connectionString) {
    String containerName = 'integrations';
    String blobPath= 'gica/' + country+'/input/'+file.getName();
    println 'FileUploading=' + file.getName();

    CloudStorageAccount storageAccount;
    try {
        storageAccount = CloudStorageAccount.parse(connectionString);
        CloudBlobClient blobClient = storageAccount.createCloudBlobClient();
        CloudBlobContainer container = blobClient.getContainerReference(containerName);

        final CloudBlockBlob blob = container.getBlockBlobReference(blobPath);
        blob.getProperties().setContentType('text/csv');
        blob.uploadFromFile(file.getPath());
    } catch (Exception e) {
        e.printStackTrace();
    }
}

private void uploadFileToOriginalAzure(File file, String country, String connectionString) {
    String containerName = 'integrations';
    String blobPath = 'data-migration/' + country + '/Original/Supplier/' + file.getName();
    println 'FileUploading=' + file.getName();

    CloudStorageAccount storageAccount;
    try {
        storageAccount = CloudStorageAccount.parse(connectionString);
        CloudBlobClient blobClient = storageAccount.createCloudBlobClient();
        CloudBlobContainer container = blobClient.getContainerReference(containerName);

        final CloudBlockBlob blob = container.getBlockBlobReference(blobPath);
        blob.getProperties().setContentType('text/csv');
        blob.uploadFromFile(file.getPath());
    } catch (Exception e) {
        e.printStackTrace();
    }
}


if (autoIncrement) {
    cronjob.setLastDocumentNumber((currentPage + 1).toString());
}
modelService.save(cronjob);