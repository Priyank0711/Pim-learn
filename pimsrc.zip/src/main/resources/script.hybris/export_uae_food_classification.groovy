import com.maf.core.model.cronjob.*
import com.maf.core.model.cronjob.*
import com.maf.facades.azure.data.*
import com.microsoft.azure.storage.CloudStorageAccount
import com.microsoft.azure.storage.blob.CloudBlobClient
import com.microsoft.azure.storage.blob.CloudBlobContainer
import com.microsoft.azure.storage.blob.CloudBlockBlob
import com.opencsv.CSVWriter
import de.hybris.platform.catalog.enums.*
import de.hybris.platform.catalog.model.classification.*
import de.hybris.platform.catalog.model.classification.ClassAttributeAssignmentModel
import de.hybris.platform.catalog.model.classification.ClassificationClassModel
import de.hybris.platform.core.*
import de.hybris.platform.core.model.product.ProductModel
import de.hybris.platform.core.servicelayer.data.SearchPageData
import de.hybris.platform.cronjob.enums.CronJobResult
import de.hybris.platform.cronjob.enums.CronJobStatus
import de.hybris.platform.servicelayer.cronjob.PerformResult
import de.hybris.platform.servicelayer.search.FlexibleSearchQuery
import de.hybris.platform.servicelayer.search.paginated.PaginatedFlexibleSearchParameter
import de.hybris.platform.servicelayer.search.paginated.util.PaginatedSearchUtils
import org.apache.commons.lang3.StringUtils
import org.apache.commons.collections4.*

final String storeId = cronjob.getBaseStore().getUid();
final String country = storeId.replace('maf', '').toUpperCase();
final String catalogId = storeId + 'Classification';


int currentPage = Integer.parseInt(cronjob.getLastDocumentNumber());
int pageSize = 40000;
boolean autoIncrement = cronjob.getUseCommissionInvoiceCyclePeriod();

final String PRODUCTS_QUERY = "SELECT {cc.pk} FROM {ClassificationClass AS cc join ClassificationSystemVersion as version on {cc:catalogVersion}={version:pk} join ClassificationSystem as cs on {version:catalog}={cs:pk}} WHERE {cs:id}=?id and {cc:code} IN ('consumable','F-Non-consumable','nc-cleaning-household','nc-textile','nc-baby','nc-beauty-personal-care','c-fresh-frozen','c-suppliment & Vitamin','c-beverages','c-food-cupboard','nc-flowers-plants','c-tobacco','nc-pets') ORDER BY {pk}";
final FlexibleSearchQuery searchQuery = new FlexibleSearchQuery(PRODUCTS_QUERY);
searchQuery.addQueryParameter('id', catalogId);


PaginatedFlexibleSearchParameter parameter = new PaginatedFlexibleSearchParameter();
SearchPageData searchPageData = PaginatedSearchUtils.createSearchPageDataWithPagination(pageSize, currentPage, true);
parameter.setFlexibleSearchQuery(searchQuery);
parameter.setSearchPageData(searchPageData);
SearchPageData<ProductModel> searchResult = paginatedFlexibleSearchService.search(parameter);

int totalNumberOfPages = searchResult.getPagination().getNumberOfPages();
int totalNumberOfResults = searchResult.getPagination().getTotalNumberOfResults();
int size = searchResult.getResults().size();

println 'currentPage = ' + currentPage;
println 'pageSize = ' + pageSize;
println 'totalNumberOfPages = ' + totalNumberOfPages;
println 'totalNumberOfResults = ' + totalNumberOfResults;
println 'resultSize = ' + size;

final Collection<ClassificationClassModel> products = searchResult.getResults();

if (size > 0 && currentPage <= totalNumberOfPages) {

	List<String> columsHeaders = Arrays.asList('group','groupName','parentCategoryId','categoryId','categoryName','categoryNameAr','classificationClassId','classificationClassName','classificationClassNameAr','attributeId','attributeName','attributeNameAr','type','position'
	);

	char ch = '|';
	File file = new File('Food_Classifications_' + country + '_' + currentPage + '.csv');


	csvWriter = new CSVWriter(new FileWriter(file), ch, CSVWriter.DEFAULT_QUOTE_CHARACTER, CSVWriter.DEFAULT_ESCAPE_CHARACTER);

	List<String[]> lines = new ArrayList<String[]>();
	lines.add(columsHeaders.toArray(new String[columsHeaders.size()]));


	for (final ClassificationClassModel classificationClass : products) {

		List<ClassAttributeAssignmentModel> assignmentModelList = classificationClass.getDeclaredClassificationAttributeAssignments();
		
		for(ClassAttributeAssignmentModel classAttributeAssignmentModel : assignmentModelList){
			ClassificationAttributeModel feature= classAttributeAssignmentModel.getClassificationAttribute();
			List<String> line = new ArrayList<String>();
		line.add("food");
		line.add("food");
		line.add(classificationClass.getCode() + "_class_category");

			if(CollectionUtils.isEmpty(classificationClass.getSupercategories())){
				line.add(classificationClass.getCode());
				line.add(StringUtils.isNotBlank(classificationClass.getName(Locale.forLanguageTag("en"))) ? classificationClass.getName(Locale.forLanguageTag("en")) : classificationClass.getCode());
				line.add(classificationClass.getName(Locale.forLanguageTag("ar")));
			}else {
				line.add(classificationClass.getSupercategories().get(0).getCode());
				line.add(StringUtils.isNotBlank(classificationClass.getSupercategories().get(0).getName(Locale.forLanguageTag("en"))) ? classificationClass.getSupercategories().get(0).getName(Locale.forLanguageTag("en")) : classificationClass.getSupercategories().get(0).getCode());
				line.add(classificationClass.getSupercategories().get(0).getName(Locale.forLanguageTag("ar")));
			}


		line.add(classificationClass.getCode());
		line.add(StringUtils.isNotBlank(classificationClass.getName(Locale.forLanguageTag("en"))) ? classificationClass.getName(Locale.forLanguageTag("en")) : classificationClass.getCode());
		line.add(classificationClass.getName(Locale.forLanguageTag("ar")));

			line.add(feature.getCode());
			line.add(StringUtils.isNotEmpty(feature.getName(Locale.forLanguageTag("en"))) ? feature.getName(Locale.forLanguageTag("en")) :feature.getCode());
		    line.add(feature.getName(Locale.forLanguageTag("ar")));
			ClassificationAttributeTypeEnum classificationAttributeType = classAttributeAssignmentModel.getAttributeType();

			if(classificationAttributeType != null){
				if (classificationAttributeType.getCode() == 'number'){
					line.add("numerical");
				}else if (classificationAttributeType.getCode() == 'boolean'){
					line.add("y_n");
				}else{
					line.add(classAttributeAssignmentModel.getAttributeType().getCode());
				}
			}else{
				line.add("");
			}
			line.add(classAttributeAssignmentModel.getPosition() != null ? classAttributeAssignmentModel.getPosition().toString():"")
			lines.add(line.toArray(new String[line.size()]));
			
		}
		

		


	}

	csvWriter.writeAll(lines);
	try {
		csvWriter.close();
	} catch (IOException e) {
		e.printStackTrace();
	}


	//Upload to Dev
	String devConnectionString='DefaultEndpointsProtocol=https;AccountName=pimcoreservicedevelop;AccountKey=qYHP2r84KzSMRm++0NRERac5OHURRQW93RM9qMCTND03/m6eeu77WJvbHDybFydAmMkcFtZ/z93x+AStG/xIBg==;EndpointSuffix=core.windows.net';
	uploadFileToAzure(file, country, devConnectionString);

	//Upload to Test
	String testConnectionString='DefaultEndpointsProtocol=https;AccountName=pimcoreservicetest;AccountKey=VTLUQMC8EBvtD2X46uZuBmqQDAxSwoFM+aa/qeNXjWg4HkAu7V1PMypFfDATQ1nQ9V16tU4hiwAR+ASt7vG2JA==;EndpointSuffix=core.windows.net';
	uploadFileToAzure(file, country, testConnectionString);

	//Upload to Prod
	if(org.apache.commons.lang3.BooleanUtils.isTrue(cronjob.getIncludeConsignmentsNotSentToJde())){
		String prodConnectionString='DefaultEndpointsProtocol=https;AccountName=pimcoreservicemaster;AccountKey=/lw/Lum/lLmOuILNJIh+HiScvg+QzKvFCrCacSNlaseN9uyuXCr8HvGF0CqEmIR31hrrRA+owl4m+ASthtlxAw==;EndpointSuffix=core.windows.net';
		uploadFileToAzure(file, country, prodConnectionString);
	}
	file.delete();
	

} else {
	println '**********LIMIT REACHED*********'
	cronjob.setActive(false);
	modelService.save(cronjob)
	new PerformResult(CronJobResult.UNKNOWN, CronJobStatus.PAUSED)
}


private void uploadFileToAzure(File file, String country, String connectionString) {
	String containerName='integrations';
	String blobPath= 'data-migration/' + country+'/Original/Categories/'+file.getName();
	println 'FileUploading=' + file.getName();

	CloudStorageAccount storageAccount;
	try {
		storageAccount = CloudStorageAccount.parse(connectionString);
		CloudBlobClient blobClient = storageAccount.createCloudBlobClient();
		CloudBlobContainer container = blobClient.getContainerReference(containerName);

		final CloudBlockBlob blob = container.getBlockBlobReference(blobPath);
		blob.getProperties().setContentType('text/csv');
		blob.uploadFromFile(file.getPath());
	} catch (Exception e) {
		e.printStackTrace();
	}
}

private String getNotNullValue(Object value) {
	return value != null ? value.toString() : StringUtils.EMPTY;
}

if(autoIncrement){
	cronjob.setLastDocumentNumber((currentPage+1).toString());
}
modelService.save(cronjob);