import de.hybris.platform.servicelayer.search.FlexibleSearchQuery;
import de.hybris.platform.core.servicelayer.data.SearchPageData;
import de.hybris.platform.servicelayer.search.SearchResult;
import de.hybris.platform.servicelayer.search.paginated.PaginatedFlexibleSearchParameter;
import de.hybris.platform.servicelayer.search.paginated.PaginatedFlexibleSearchService;
import de.hybris.platform.servicelayer.search.paginated.util.PaginatedSearchUtils;

import de.hybris.platform.core.model.product.ProductModel;
import de.hybris.platform.catalog.model.CatalogVersionModel;
import de.hybris.platform.core.model.media.MediaContainerModel;
import com.maf.marketplace.services.model.MarketplaceCategoryModel;
import de.hybris.platform.category.model.CategoryModel;
import com.maf.core.model.BrandCategoryModel;
import de.hybris.platform.catalog.model.classification.ClassificationClassModel;
import com.maf.core.model.NavigationCategoryModel;
import com.maf.core.model.GicaCategoryModel;
import com.maf.core.model.LeaFletModel;
import com.maf.core.model.PromotionCategoryModel;
import de.hybris.platform.catalog.model.classification.ClassificationAttributeValueModel;
import de.hybris.platform.core.model.media.MediaModel;

import de.hybris.platform.commercefacades.product.data.ProductData;
import de.hybris.platform.commercefacades.product.data.ClassificationData;
import de.hybris.platform.classification.features.FeatureList;
import de.hybris.platform.classification.features.Feature;
import de.hybris.platform.commercefacades.product.data.ClassificationData;
import de.hybris.platform.commercefacades.product.data.FeatureData;
import de.hybris.platform.commercefacades.product.data.FeatureValueData;
import de.hybris.platform.classification.features.FeatureValue;
import de.hybris.platform.classification.features.LocalizedFeature;

import de.hybris.platform.commerceservices.util.ConverterFactory;
import de.hybris.platform.servicelayer.dto.converter.Converter;
import de.hybris.platform.converters.Populator;
import de.hybris.platform.commercefacades.product.converters.populator.ProductFeatureListPopulator;
import de.hybris.platform.commercefacades.product.converters.populator.ClassificationPopulator;
import com.maf.facades.product.converters.populator.MafFeaturePopulator

import de.hybris.platform.servicelayer.cronjob.PerformResult
import de.hybris.platform.cronjob.enums.CronJobStatus
import de.hybris.platform.cronjob.enums.CronJobResult
import static org.apache.commons.collections.CollectionUtils.isNotEmpty;

import com.opencsv.CSVWriter;
import java.io.File;
import java.io.FileWriter;
import org.apache.commons.collections.CollectionUtils;
import com.microsoft.azure.storage.CloudStorageAccount;
import com.microsoft.azure.storage.blob.CloudBlobClient;
import com.microsoft.azure.storage.blob.CloudBlobContainer;
import com.microsoft.azure.storage.blob.CloudBlockBlob;
import java.io.FileInputStream;
import java.util.Set;
import java.util.Collection;
import java.util.*
import java.util.Collection;
import java.util.ArrayList;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.collections4.ListUtils;
import com.google.gson.Gson;
import org.apache.commons.lang.math.NumberUtils;


	final String storeId = cronjob.getBaseStore().getUid();
	final String country = storeId.replace('maf','').toUpperCase();
	final String catalogId = storeId + 'ProductCatalog';
	println '';
	println 'catalogId ' + catalogId;
	final CatalogVersionModel catalogVersion = catalogVersionService.getCatalogVersion(catalogId, 'Online');
    
   	int currentPage = Integer.parseInt(cronjob.getLastDocumentNumber());
	int pageSize = 1000;
	boolean autoIncrement = cronjob.getUseCommissionInvoiceCyclePeriod();
	
	final String categoriesQuery = "select distinct({pk}) from {category} where {catalogversion} = ?catalogVersion  and {pk} NOT IN ({{ select {ccr:target} from {categorycategoryrelation as ccr join category as c on {ccr:source} = {c:pk}} where {c:catalogversion} = ?catalogVersion }}) and ({pk} IN ({{ select {ccr:source} from {categorycategoryrelation as ccr join category as c on {ccr:source} = {c:pk}} where {c:catalogversion} = ?catalogVersion }}) or {pk} IN ({{select {pcr:source} from {CategoryProductRelation as pcr join category as c on {pcr:source}={c:pk} join Product as p on {pcr:target}={p:pk}} where {p:catalogversion} = ?catalogVersion}}))";
	final FlexibleSearchQuery searchQuery = new FlexibleSearchQuery(categoriesQuery);
	searchQuery.addQueryParameter('catalogVersion', catalogVersion);
		   
    PaginatedFlexibleSearchParameter parameter = new PaginatedFlexibleSearchParameter();
    SearchPageData searchPageData = PaginatedSearchUtils.createSearchPageDataWithPagination(pageSize, currentPage, true);
	parameter.setFlexibleSearchQuery(searchQuery);
    parameter.setSearchPageData(searchPageData);
    SearchPageData<CategoryModel> searchResult = paginatedFlexibleSearchService.search(parameter);
	
	int totalNumberOfPages=searchResult.getPagination().getNumberOfPages();
	int totalNumberOfResults=searchResult.getPagination().getTotalNumberOfResults();
	int size=searchResult.getResults().size();
	
	println 'currentPage = '+currentPage;
	println 'pageSize = '+pageSize;
	println 'totalNumberOfPages = '+totalNumberOfPages;
	println 'totalNumberOfResults = '+totalNumberOfResults;
	println 'resultSize = '+size;
	
	int classificationProducts = 0;
	
	final Collection<CategoryModel> categories = searchResult.getResults();

	if(size>0 && currentPage <= totalNumberOfPages){
	
		List<String> columsHeaders = Arrays.asList('CODE','NAME[en]','NAME[ar]','PARENT_CODE','CATEGORY_TYPE');
		
		char ch = '|';
		File file = new File('Categories_'+country+'_'+currentPage+'.csv');
		println 'Writing to File ' + file.getName();
		
		csvWriter = new CSVWriter(new FileWriter(file), ch, CSVWriter.DEFAULT_QUOTE_CHARACTER, CSVWriter.DEFAULT_ESCAPE_CHARACTER);

		List<String[]> lines = new ArrayList<String[]>();
		lines.add(columsHeaders.toArray(new String[columsHeaders.size()]));

		for(final CategoryModel category:categories){
			lookupExportableCategories(category, lines, null)
	    			
	    }

		csvWriter.writeAll(lines);
	    try {
			csvWriter.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		uploadFileToAzure(file, country);	
		file.delete();
	
	}else{
		println '**********LIMIT REACHED*********'
		cronjob.setActive(false);
		modelService.save(cronjob)
		new PerformResult(CronJobResult.UNKNOWN, CronJobStatus.PAUSED)
	}
	

	  private void lookupExportableCategories(CategoryModel currentCategory, List<String[]> lines, CategoryModel parentCategory) {

	  	if(!(currentCategory instanceof PromotionCategoryModel)){
List<String> line = new ArrayList<String>();
			line.add(currentCategory.getCode());
			line.add(currentCategory.getName(Locale.forLanguageTag("en")));
			line.add(currentCategory.getName(Locale.forLanguageTag("ar")));
			line.add(parentCategory != null ? parentCategory.getCode() : "");
			
			if(currentCategory instanceof BrandCategoryModel){
				line.add("BRAND");
			}else if(currentCategory instanceof GicaCategoryModel){
				line.add("GICA");

			}else if(currentCategory instanceof MarketplaceCategoryModel){
				line.add("MARKETPLACE");
				
			}else if(currentCategory instanceof NavigationCategoryModel){
				line.add("NAVIGATION");
				
			}else if(currentCategory instanceof PromotionCategoryModel){
				line.add("PROMOTION");
				
			}else{
				line.add("");

			}
			lines.add(line.toArray(new String[line.size()]));
      
      for (CategoryModel subCategory : currentCategory.getCategories()) {
        
        lookupExportableCategories(subCategory, lines, currentCategory);
      }
	  	}
  }

private void uploadFileToAzure(File file, String country) {
	String connectionString='DefaultEndpointsProtocol=https;AccountName=datafeedmaster;AccountKey=iHmRGq0Vf4BLKx+Bl6UbNAOqKaUhdAmeI3SkK1iYGFtr7o0wSRhMCD8DmOwTPRtxZ6SnlJnoYpBAk3R3c2DFBw==;EndpointSuffix=core.windows.net';
    String containerName='pim-core';
    String blobPath=country+'/'+file.getName();
    println 'FileUploading='+file.getName();
     
    CloudStorageAccount storageAccount;
	try {
		storageAccount = CloudStorageAccount.parse(connectionString);
		CloudBlobClient blobClient = storageAccount.createCloudBlobClient();
	    CloudBlobContainer container = blobClient.getContainerReference(containerName);
	    
	    final CloudBlockBlob blob = container.getBlockBlobReference(blobPath);
	    blob.getProperties().setContentType('text/csv');
		blob.uploadFromFile(file.getPath());
	} catch (Exception e) {
		e.printStackTrace();
	}
}

private boolean isValid(final CategoryModel category){


	return false;
}


if(autoIncrement){
	cronjob.setLastDocumentNumber((currentPage+1).toString());
}
modelService.save(cronjob);