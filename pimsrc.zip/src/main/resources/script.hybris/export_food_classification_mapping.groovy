import com.microsoft.azure.storage.CloudStorageAccount
import com.microsoft.azure.storage.blob.CloudBlobClient
import com.microsoft.azure.storage.blob.CloudBlobContainer
import com.microsoft.azure.storage.blob.CloudBlockBlob
import com.opencsv.CSVWriter
import de.hybris.platform.catalog.model.classification.*
import de.hybris.platform.catalog.model.classification.ClassificationClassModel
import de.hybris.platform.category.model.CategoryModel
import de.hybris.platform.core.servicelayer.data.SearchPageData
import de.hybris.platform.cronjob.enums.CronJobResult
import de.hybris.platform.cronjob.enums.CronJobStatus
import de.hybris.platform.servicelayer.cronjob.PerformResult
import de.hybris.platform.servicelayer.search.FlexibleSearchQuery
import de.hybris.platform.servicelayer.search.paginated.PaginatedFlexibleSearchParameter
import de.hybris.platform.servicelayer.search.paginated.util.PaginatedSearchUtils
import org.apache.commons.collections4.CollectionUtils

final String storeId = cronjob.getBaseStore().getUid();
	final String country = storeId.replace('maf','').toUpperCase();
	final String catalogId = storeId + 'Classification';
	println '';
	println 'catalogId ' + catalogId;
	final ClassificationSystemVersionModel catalogVersion = classificationSystemService.getSystemVersion(catalogId, '1.0');
	println 'catalogIdPk ' + catalogVersion.getPk();

int currentPage = Integer.parseInt(cronjob.getLastDocumentNumber());
int pageSize = 40000;
boolean autoIncrement = cronjob.getUseCommissionInvoiceCyclePeriod();
	
	final String categoriesQuery = "select {pk} from {classificationclass} where {catalogversion} = ?catalogVersion  and {pk} NOT IN ({{ select {ccr:target} from {categorycategoryrelation as ccr join classificationclass as c on {ccr:source} = {c:pk}} where {c:catalogversion} = ?catalogVersion }}) and ({pk} IN ({{ select {ccr:source} from {categorycategoryrelation as ccr join classificationclass as c on {ccr:source} = {c:pk}} where {c:catalogversion} = ?catalogVersion }}) or {pk} IN ({{select {pcr:source} from {CategoryProductRelation as pcr join classificationclass as c on {pcr:source}={c:pk} join Product as p on {pcr:target}={p:pk}} where {p:catalogversion} = ?catalogVersion }}))";
	final FlexibleSearchQuery searchQuery = new FlexibleSearchQuery(categoriesQuery);
	searchQuery.addQueryParameter('catalogVersion', catalogVersion);
		   
    PaginatedFlexibleSearchParameter parameter = new PaginatedFlexibleSearchParameter();
    SearchPageData searchPageData = PaginatedSearchUtils.createSearchPageDataWithPagination(pageSize, currentPage, true);
	parameter.setFlexibleSearchQuery(searchQuery);
    parameter.setSearchPageData(searchPageData);
    SearchPageData<ClassificationClassModel> searchResult = paginatedFlexibleSearchService.search(parameter);
	
	int totalNumberOfPages=searchResult.getPagination().getNumberOfPages();
	int totalNumberOfResults=searchResult.getPagination().getTotalNumberOfResults();
	int size=searchResult.getResults().size();
	
	println 'currentPage = '+currentPage;
	println 'pageSize = '+pageSize;
	println 'totalNumberOfPages = '+totalNumberOfPages;
	println 'totalNumberOfResults = '+totalNumberOfResults;
	println 'resultSize = '+size;
	
	int classificationProducts = 0;
	
	final Collection<ClassificationClassModel> categories = searchResult.getResults();

	if(size>0 && currentPage <= totalNumberOfPages){
	

		char ch = '|';
		File file = new File('Food_Classification_Nav_Category_'+country+'_'+currentPage+'.csv');
		println 'Writing to File ' + file.getName();
		
		csvWriter = new CSVWriter(new FileWriter(file), ch, CSVWriter.DEFAULT_QUOTE_CHARACTER, CSVWriter.DEFAULT_ESCAPE_CHARACTER);

		List<String> classHeaders = Arrays.asList('code','classificationClass');

		List<String[]> categoryList = new ArrayList<String[]>();
		categoryList.add(classHeaders.toArray(new String[classHeaders.size()]));


		for(final ClassificationClassModel category:categories){
			lookupExportableCategories(category, categoryList, null);
	    			
	    }


		csvWriter.writeAll(categoryList);
	    try {
			csvWriter.close();
		} catch (IOException e) {
			e.printStackTrace();
		}

		//Upload to Dev
		String devConnectionString='DefaultEndpointsProtocol=https;AccountName=pimcoreservicedevelop;AccountKey=qYHP2r84KzSMRm++0NRERac5OHURRQW93RM9qMCTND03/m6eeu77WJvbHDybFydAmMkcFtZ/z93x+AStG/xIBg==;EndpointSuffix=core.windows.net';
		uploadFileToAzure(file, country, devConnectionString);

		//Upload to Test
		String testConnectionString='DefaultEndpointsProtocol=https;AccountName=pimcoreservicetest;AccountKey=VTLUQMC8EBvtD2X46uZuBmqQDAxSwoFM+aa/qeNXjWg4HkAu7V1PMypFfDATQ1nQ9V16tU4hiwAR+ASt7vG2JA==;EndpointSuffix=core.windows.net';
		uploadFileToAzure(file, country, testConnectionString);

		//Upload to Prod
		if(org.apache.commons.lang3.BooleanUtils.isTrue(cronjob.getIncludeConsignmentsNotSentToJde())){
			String prodConnectionString='DefaultEndpointsProtocol=https;AccountName=pimcoreservicemaster;AccountKey=/lw/Lum/lLmOuILNJIh+HiScvg+QzKvFCrCacSNlaseN9uyuXCr8HvGF0CqEmIR31hrrRA+owl4m+ASthtlxAw==;EndpointSuffix=core.windows.net';
			uploadFileToAzure(file, country, prodConnectionString);
		}
		file.delete();
		
	
	}else{
		println '**********LIMIT REACHED*********'
		cronjob.setActive(false);
		modelService.save(cronjob)
		new PerformResult(CronJobResult.UNKNOWN, CronJobStatus.PAUSED)
	}
	

	  private void lookupExportableCategories(ClassificationClassModel currentCategory , List<String[]> categories, CategoryModel parentCategory) {

      
      for (CategoryModel subCategory : currentCategory.getCategories()) {
      	if(subCategory instanceof ClassificationClassModel){
      		
           lookupExportableCategories(subCategory, categories, currentCategory);

      	}else if(subCategory instanceof CategoryModel && subCategory.getCatalogVersion().getVersion() == 'Online'){
			if(!isOrphanCategory(subCategory)){
				List<String> categoryLine = new ArrayList<String>();
				categoryLine.add(subCategory.getCode());
				categoryLine.add(currentCategory.getCode());
				categories.add(categoryLine.toArray(new String[categoryLine.size()]));
			}else{
				println 'Orphan Category' + subCategory.getCode();
			}
      	}
      }
  }

private boolean isOrphanCategory(CategoryModel categoryModel){
	return CollectionUtils.isEmpty(getAllSuperCategories(categoryModel))
			&& CollectionUtils.isEmpty(getAllSubCategories(categoryModel))
	        && CollectionUtils.isEmpty(categoryModel.getProducts())
}

private List<CategoryModel> getAllSuperCategories(CategoryModel categoryModel){
	List<CategoryModel> allSuperCategories = new ArrayList<>();
	for (CategoryModel subCategory : categoryModel.getSupercategories()) {
		if(subCategory instanceof ClassificationClassModel){

		}else if(subCategory instanceof CategoryModel){
			allSuperCategories.add(subCategory);
		}
	}
	return allSuperCategories;
}

private List<CategoryModel> getAllSubCategories(CategoryModel categoryModel){
	List<CategoryModel> allSubCategories = new ArrayList<>();
	for (CategoryModel subCategory : categoryModel.getAllSubcategories()) {
		if(subCategory instanceof ClassificationClassModel){

		}else if(subCategory instanceof CategoryModel){
			allSubCategories.add(subCategory);
		}
	}
	return allSubCategories;
}

private void uploadFileToAzure(File file, String country, String connectionString) {
	String containerName='integrations';
	String blobPath= 'data-migration/' + country+'/Original/Categories/'+file.getName();
    println 'FileUploading='+file.getName();
     
    CloudStorageAccount storageAccount;
	try {
		storageAccount = CloudStorageAccount.parse(connectionString);
		CloudBlobClient blobClient = storageAccount.createCloudBlobClient();
	    CloudBlobContainer container = blobClient.getContainerReference(containerName);
	    
	    final CloudBlockBlob blob = container.getBlockBlobReference(blobPath);
	    blob.getProperties().setContentType('text/csv');
		blob.uploadFromFile(file.getPath());
	} catch (Exception e) {
		e.printStackTrace();
	}
}

if(autoIncrement){
	cronjob.setLastDocumentNumber((currentPage+1).toString());
}
modelService.save(cronjob);

