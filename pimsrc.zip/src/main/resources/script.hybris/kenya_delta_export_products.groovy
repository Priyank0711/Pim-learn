import com.maf.core.model.*
import com.maf.core.model.cronjob.*
import com.maf.core.model.cronjob.*
import com.maf.facades.azure.data.*
import com.microsoft.azure.storage.CloudStorageAccount
import com.microsoft.azure.storage.blob.CloudBlobClient
import com.microsoft.azure.storage.blob.CloudBlobContainer
import com.microsoft.azure.storage.blob.CloudBlockBlob
import com.opencsv.CSVWriter
import de.hybris.platform.catalog.model.CatalogVersionModel
import de.hybris.platform.catalog.model.classification.ClassAttributeAssignmentModel
import de.hybris.platform.catalog.model.classification.ClassificationAttributeModel
import de.hybris.platform.catalog.model.classification.ClassificationClassModel
import de.hybris.platform.category.model.CategoryModel
import de.hybris.platform.classification.features.Feature
import de.hybris.platform.classification.features.FeatureList
import de.hybris.platform.commercefacades.product.data.ClassificationData
import de.hybris.platform.commercefacades.product.data.FeatureData
import de.hybris.platform.commercefacades.product.data.FeatureValueData
import de.hybris.platform.commercefacades.product.data.ProductData
import de.hybris.platform.core.*
import de.hybris.platform.core.model.media.MediaContainerModel
import de.hybris.platform.core.model.media.MediaModel
import de.hybris.platform.core.model.product.ProductModel
import de.hybris.platform.core.servicelayer.data.SearchPageData
import de.hybris.platform.cronjob.enums.CronJobResult
import de.hybris.platform.cronjob.enums.CronJobStatus
import de.hybris.platform.servicelayer.cronjob.PerformResult
import de.hybris.platform.servicelayer.search.FlexibleSearchQuery
import de.hybris.platform.servicelayer.search.paginated.PaginatedFlexibleSearchParameter
import de.hybris.platform.servicelayer.search.paginated.util.PaginatedSearchUtils
import org.apache.commons.collections.CollectionUtils
import org.apache.commons.lang3.StringUtils

import java.text.DateFormat
import java.text.SimpleDateFormat
import java.util.stream.Collectors

final String storeId = cronjob.getBaseStore().getUid();
	final String country = storeId.replace('maf','').toUpperCase();
	final String catalogId = storeId + 'ProductCatalog';
	println '';
	println 'catalogId ' + catalogId;
	final CatalogVersionModel catalogVersion = catalogVersionService.getCatalogVersion(catalogId, 'Online');
	
    int currentPage = Integer.parseInt(cronjob.getLastDocumentNumber());
	int pageSize = 40000;
	boolean autoIncrement = cronjob.getUseCommissionInvoiceCyclePeriod();
	
	//final String PRODUCTS_QUERY = "SELECT {p.pk} FROM {Product AS p} WHERE {catalogVersion}=?catalogVersion ORDER BY {pk}";
    final String PRODUCTS_QUERY = "SELECT {p.pk} FROM {Product AS p} WHERE {catalogVersion}=?catalogVersion and {modifiedtime} >= ?lastExecution ORDER BY {pk}";
	final FlexibleSearchQuery searchQuery = new FlexibleSearchQuery(PRODUCTS_QUERY);
	searchQuery.addQueryParameter('catalogVersion', catalogVersion);
    searchQuery.addQueryParameter('lastExecution', cronjob.getEndDate());
		   
    PaginatedFlexibleSearchParameter parameter = new PaginatedFlexibleSearchParameter();
    SearchPageData searchPageData = PaginatedSearchUtils.createSearchPageDataWithPagination(pageSize, currentPage, true);
	parameter.setFlexibleSearchQuery(searchQuery);
    parameter.setSearchPageData(searchPageData);
    SearchPageData<ProductModel> searchResult = paginatedFlexibleSearchService.search(parameter);
	
	int totalNumberOfPages=searchResult.getPagination().getNumberOfPages();
	int totalNumberOfResults=searchResult.getPagination().getTotalNumberOfResults();
	int size=searchResult.getResults().size();
	
	println 'currentPage = '+currentPage;
	println 'pageSize = '+pageSize;
	println 'totalNumberOfPages = '+totalNumberOfPages;
	println 'totalNumberOfResults = '+totalNumberOfResults;
	println 'resultSize = '+size;
	
	int classificationProducts = 0;
	
	final Collection<ProductModel> products = searchResult.getResults();

	if(size>0 && currentPage <= totalNumberOfPages){



		List<String> columsHeaders = Arrays.asList('code', 'country', 'ean', 'expressProduct', 'storeId', 'approvalStatus'
				, 'department', 'section', 'family', 'subFamily', 'itemStatus', 'grossWeight', 'minOrderQuantity', 'width', 'weight', 'height'
				, 'depth', 'maxToOrder', 'unitItem', 'barcodes', 'assortments', 'marketplaceProduct', 'itemMeasure', 'loyaltyPoint', 'deliveryTime', 'nature'
				, 'media', 'gallery', 'gicaVatCod', 'gicaVatPer','minimumWeightToOrder'
				,'substituted','maxOrderQuantity','loyaltyPointsStartDate','loyaltyPointsEndDate','nonReplenishable','numberOfUnit','categories'

				//Localized Attributes
				,'name[en]', 'name[ar]', 'onlineName[en]', 'onlineName[ar]', 'description[en]', 'description[ar]', 'bulkMessage[en]', 'bulkMessage[ar]', 'marketingText[en]', 'marketingText[ar]'
				, 'metaTitle[en]', 'metaTitle[ar]', 'metaDescription[en]', 'metaDescription[ar]', 'metaKeywords[en]', 'metaKeywords[ar]'
				,'tipsAndVideos[en]','tipsAndVideos[ar]','productColor[en]','productColor[ar]'


				//Food Attributes
				,'ingredients[en]', 'ingredients[ar]', 'brandMarketingMessage[en]', 'brandMarketingMessage[ar]'
				,'storageConditions[en]', 'storageConditions[ar]', 'allergyAdvice[en]', 'allergyAdvice[ar]', 'preparationAndUsage[en]', 'preparationAndUsage[ar]', 'size[en]', 'size[ar]'
				, 'countryOrigin[en]', 'countryOrigin[ar]','safetyWarnings[en]','safetyWarnings[ar]','weightIncrement','averageWeightByPiece','weightVariation','averagePieceByKg','productFoodType'

				//Non Food Attributes
				,'nbrOfMonth', 'freeDelivery', 'freeInstallation', 'genuineStock', 'onDemand', 'preorder', 'preOrderDeliveryTime', 'codeDeliveryGica',
				'preorderDescription[en]','preorderDescription[ar]','warranty'


				//Service Attributes
				, 'warrantyType', 'yearOfWarranty','productType','creationTime','unpublishedPos','supplier'
		);

		char ch = '|';
		File file = new File('Delta_Products_' + country + '_' + cronjob.getNumberOfRetries() + '.csv');
		println 'Writing to File ' + file.getName();
		println columsHeaders.size()

		csvWriter = new CSVWriter(new FileWriter(file), ch, CSVWriter.DEFAULT_QUOTE_CHARACTER, CSVWriter.DEFAULT_ESCAPE_CHARACTER);

		List<String[]> lines = new ArrayList<String[]>();
		lines.add(columsHeaders.toArray(new String[columsHeaders.size()]));

		List<String> mediaColumsHeaders = Arrays.asList('code', 'name', 'format','masterUrl','url','relativePath','country');

		File mediaFile = new File('Delta_Media_' + country + '_' + cronjob.getNumberOfRetries() + '.csv');
		mediaCsvWriter = new CSVWriter(new FileWriter(mediaFile), ch, CSVWriter.DEFAULT_QUOTE_CHARACTER, CSVWriter.DEFAULT_ESCAPE_CHARACTER);

		List<String[]> mediaLines = new ArrayList<String[]>();
		mediaLines.add(mediaColumsHeaders.toArray(new String[mediaColumsHeaders.size()]));

		List<String> classifHeaders = Arrays.asList('code','classification_category', 'classification_class','classification_class_name[en]','classification_class_name[ar]','attribute_id','attribute_name[en]', 'attribute_name[ar]','value[en]','value[ar]','country');

		File classifFile = new File('Delta_Product_Classif' + country + '_' + cronjob.getNumberOfRetries() + '.csv');
		classIfCsvWriter = new CSVWriter(new FileWriter(classifFile), ch, CSVWriter.DEFAULT_QUOTE_CHARACTER, CSVWriter.DEFAULT_ESCAPE_CHARACTER);

		List<String[]> classifLines = new ArrayList<String[]>();
		classifLines.add(classifHeaders.toArray(new String[classifHeaders.size()]));


		MafExportCronjobModel job = (MafExportCronjobModel) modelService.get(PK.fromLong(11552409059829))
		MafAzureProductData data = mafExportProductService.feedSetUpData(job.getCode(),job.getLastExportTime());


		String pattern = "MM/dd/yyyy HH:mm:ss";
		DateFormat df = new SimpleDateFormat(pattern);

		final Map<String, String> definedAttributes = getPredefinedAttribute();

		for (final ProductModel product : products) {
			List<String> line = new ArrayList<String>();
			line.add(product.getCode());
			line.add(country);
			line.add(product.getEan());
			line.add(String.valueOf(product.isIsExpressProduct()));
			line.add(storeId);
			line.add(product.getApprovalStatus() != null ? product.getApprovalStatus().toString() : "");//Clear in Order
			line.add(product.getDepartment());
			line.add(product.getSection());
			line.add(product.getFamily());
			line.add(product.getSubFamily());
			line.add(product.getItemStatus());
			line.add(product.getGrossWeight() != null ? Double.toString(product.getGrossWeight()) : "");
			line.add(product.getMinOrderQuantity() ? Integer.toString(product.getMinOrderQuantity()) : "");
			line.add(product.getWidth() != null ? Double.toString(product.getWidth()) : "");
			line.add(product.getWeight() != null ? Double.toString(product.getWeight()) : "");
			line.add(product.getHeight() != null ? Double.toString(product.getHeight()) : "");
			line.add(product.getDepth() != null ? Double.toString(product.getDepth()) : "");
			line.add(product.getMaxToOrder() != null ? Integer.toString(product.getMaxToOrder()) : "");
			line.add(product.getUnitItem() != null ? Integer.toString(product.getUnitItem()) : "");
			if (CollectionUtils.isNotEmpty(product.getMafBarCodes())) {
				Set<String> codes = product.getMafBarCodes().stream().map(barcode -> barcode.getCode()).collect(Collectors.toSet());
				line.add(String.join(",", codes));
			}else{
				line.add("");
			}
			if (CollectionUtils.isNotEmpty(product.getAssortments())) {
				Set<String> assortments = product.getAssortments().stream().map(assortment -> assortment.getCode()).collect(Collectors.toSet());
				line.add(String.join(",", assortments));
			}else{
				line.add("");
			}
			line.add(product.getMarketplaceProduct() != null ? String.valueOf(product.getMarketplaceProduct()) : "");
			line.add(product.getItemMeasure());
			line.add(product.getNumberOfPoints() != null ? Integer.toString(product.getNumberOfPoints()) : "");
			line.add(product.getDeliveryTime() != null ? String.valueOf(product.getDeliveryTime()) : "");
			line.add(product.getProductNature() != null ? product.getProductNature().getCode() : "");//Clear Order
			final List<MediaContainerModel> containers = product.getGalleryImages();
			String mediaCode = ""
			StringJoiner joiner = new StringJoiner(",");
			if (CollectionUtils.isNotEmpty(containers)){
				for(MediaContainerModel container : containers){
					if(container.getMaster() != null){
						MediaModel media = container.getMaster();
						if (StringUtils.isBlank(mediaCode) && media.getCode().contains("main")){
							mediaCode = media.getCode();
						}else{
							joiner.add(media.getCode());
						}
						List<String> mediaLine = new ArrayList<String>();
						mediaLine.add(media.getCode());
						mediaLine.add(media.getRealFileName());
						mediaLine.add(media.getMime());
						mediaLine.add(container.getMasterUrl());
						mediaLine.add(media.getURL());
						mediaLine.add("sys-master-root/"+media.getLocation());
						mediaLine.add(country);
						mediaLines.add(mediaLine.toArray(new String[mediaLine.size()]));
					}
				}
			}
			line.add(mediaCode)//Media
			line.add(joiner.toString())//Gallery
			line.add(product.getGicaVatCod());
			line.add(product.getGicaVatPer());//Clear the Order
			line.add(product.getMinimumWeightToOrder() != null ? Double.toString(product.getMinimumWeightToOrder()): "");

			line.add(product.getIsSubstituted() != null ? String.valueOf(product.getIsSubstituted()) : "");
			line.add(product.getMaxOrderQuantity() != null? Integer.toString(product.getMaxOrderQuantity()) : "");
			line.add(product.getStartDate() != null ? df.format(product.getStartDate()) : "");
			line.add(product.getEndDate() != null ? df.format(product.getEndDate()) : "");
			line.add(product.getNonReplenishable() != null ? String.valueOf(product.getNonReplenishable()) : "");
			line.add(product.getNumberOfUnit() != null ? Double.toString(product.getNumberOfUnit()): "")

			StringJoiner categories = new StringJoiner(",");
			List<CategoryModel> classifCategories = new ArrayList<>();

			final List<CategoryModel> allCategoryModelList = product.getSupercategories();
			Set<CategoryModel> categoryModelList = new HashSet<CategoryModel>(allCategoryModelList);

			if(CollectionUtils.isNotEmpty(categoryModelList)){

				for(CategoryModel category : categoryModelList){
					if (!(category instanceof PromotionCategoryModel)){
						if(CategoryModel._TYPECODE.equals(category.getItemtype())){
							classifCategories.add(category);
						}
						if (category instanceof NavigationCategoryModel){
							List<CategoryModel> navigationSuperCat = category.getSupercategories();
							if(CollectionUtils.isNotEmpty(navigationSuperCat)){
								for(CategoryModel navigationCategory : navigationSuperCat){
									if(navigationCategory instanceof ClassificationClassModel){
										classifCategories.add(navigationCategory);
									}

								}

							}
						}
						categories.add(category.getCode());
					}
				}

			}

			line.add(categories.toString()); //categories

			//Localized Attributes
			line.add(product.getName(Locale.forLanguageTag("en")) !=null ? product.getName(Locale.forLanguageTag("en")).replaceAll("\\n", "\\\\n").replaceAll("\u0000", "") :"");
			line.add(product.getName(Locale.forLanguageTag("ar")) !=null ? product.getName(Locale.forLanguageTag("ar")).replaceAll("\\n", "\\\\n").replaceAll("\u0000", "") :"");
			line.add(product.getOnlineName(Locale.forLanguageTag("en")) !=null ? product.getOnlineName(Locale.forLanguageTag("en")).replaceAll("\\n", "\\\\n").replaceAll("\u0000", "") :"");
			line.add(product.getOnlineName(Locale.forLanguageTag("ar")) !=null ? product.getOnlineName(Locale.forLanguageTag("ar")).replaceAll("\\n", "\\\\n").replaceAll("\u0000", "") :"");
			line.add(product.getDescription(Locale.forLanguageTag("en")) !=null ? product.getDescription(Locale.forLanguageTag("en")).replaceAll("\\n", "\\\\n").replaceAll("\u0000", "") :"");
			line.add(product.getDescription(Locale.forLanguageTag("ar")) !=null ? product.getDescription(Locale.forLanguageTag("ar")).replaceAll("\\n", "\\\\n").replaceAll("\u0000", "") :"");
			line.add(product.getBulkMessage(Locale.forLanguageTag("en")) !=null ? product.getBulkMessage(Locale.forLanguageTag("en")).replaceAll("\\n", "\\\\n").replaceAll("\u0000", "") :"");
			line.add(product.getBulkMessage(Locale.forLanguageTag("ar")) !=null ? product.getBulkMessage(Locale.forLanguageTag("ar")).replaceAll("\\n", "\\\\n").replaceAll("\u0000", "") :"");
			line.add(product.getMarketingText(Locale.forLanguageTag("en")) !=null ? product.getMarketingText(Locale.forLanguageTag("en")).replaceAll("\\n", "\\\\n").replaceAll("\u0000", "") :"");
			line.add(product.getMarketingText(Locale.forLanguageTag("ar")) !=null ? product.getMarketingText(Locale.forLanguageTag("ar")).replaceAll("\\n", "\\\\n").replaceAll("\u0000", "") :"");

			line.add(product.getMetaTitle() != null ? product.getMetaTitle().replaceAll("\\n", "\\\\n").replaceAll("\u0000", "") :"");
			line.add("");

			line.add(product.getMetaDescription() != null ? product.getMetaDescription().replaceAll("\\n", "\\\\n").replaceAll("\u0000", "") :"");
			line.add("");

			line.add(product.getMetaKeywords() != null ? product.getMetaKeywords().replaceAll("\\n", "\\\\n").replaceAll("\u0000", "") :"");
			line.add("");

			line.add(product.getTipsAndVideos() != null ? product.getTipsAndVideos().replaceAll("\\n", "\\\\n").replaceAll("\u0000", "") : "");
			line.add("");

			line.add(product.getProductColor(Locale.forLanguageTag("en")) != null ? product.getProductColor(Locale.forLanguageTag("en")).replaceAll("\\n", "\\\\n").replaceAll("\u0000", "") : "");
			line.add(product.getProductColor(Locale.forLanguageTag("ar")) != null ? product.getProductColor(Locale.forLanguageTag("ar")).replaceAll("\\n", "\\\\n").replaceAll("\u0000", "") : "");//Clear the order


			String productType = "";

			if (product instanceof FoodProductModel){
				productType = "FOOD";
				final FoodProductModel foodProduct = (FoodProductModel) product;

				line.add(foodProduct.getIngredients(Locale.forLanguageTag("en")) !=null ? product.getIngredients(Locale.forLanguageTag("en")).replaceAll("\\n", "\\\\n").replaceAll("\u0000", "") :"");
				line.add(foodProduct.getIngredients(Locale.forLanguageTag("ar")) !=null ? product.getIngredients(Locale.forLanguageTag("ar")).replaceAll("\\n", "\\\\n").replaceAll("\u0000", "") :"");

				line.add(foodProduct.getBrandMarketingMessage(Locale.forLanguageTag("en")) !=null ? product.getBrandMarketingMessage(Locale.forLanguageTag("en")).replaceAll("\\n", "\\\\n").replaceAll("\u0000", "") :"");
				line.add(foodProduct.getBrandMarketingMessage(Locale.forLanguageTag("ar")) !=null ? product.getBrandMarketingMessage(Locale.forLanguageTag("ar")).replaceAll("\\n", "\\\\n").replaceAll("\u0000", "") :"");

				line.add(foodProduct.getStorageConditions(Locale.forLanguageTag("en")) !=null ? product.getStorageConditions(Locale.forLanguageTag("en")).replaceAll("\\n", "\\\\n").replaceAll("\u0000", "") :"");
				line.add(foodProduct.getStorageConditions(Locale.forLanguageTag("ar")) !=null ? product.getStorageConditions(Locale.forLanguageTag("ar")).replaceAll("\\n", "\\\\n").replaceAll("\u0000", "") :"");

				line.add(foodProduct.getAllergyAdvice(Locale.forLanguageTag("en")) !=null ? product.getAllergyAdvice(Locale.forLanguageTag("en")).replaceAll("\\n", "\\\\n").replaceAll("\u0000", "") :"");
				line.add(foodProduct.getAllergyAdvice(Locale.forLanguageTag("ar")) !=null ? product.getAllergyAdvice(Locale.forLanguageTag("ar")).replaceAll("\\n", "\\\\n").replaceAll("\u0000", "") :"");

				line.add(foodProduct.getPreparationAndUSage(Locale.forLanguageTag("en")) !=null ? product.getPreparationAndUSage(Locale.forLanguageTag("en")).replaceAll("\\n", "\\\\n").replaceAll("\u0000", "") :"");
				line.add(foodProduct.getPreparationAndUSage(Locale.forLanguageTag("ar")) !=null ? product.getPreparationAndUSage(Locale.forLanguageTag("ar")).replaceAll("\\n", "\\\\n").replaceAll("\u0000", "") :"");

				line.add(foodProduct.getSize(Locale.forLanguageTag("en")) !=null ? product.getSize(Locale.forLanguageTag("en")).replaceAll("\\n", "\\\\n").replaceAll("\u0000", "") :"");
				line.add(foodProduct.getSize(Locale.forLanguageTag("ar")) !=null ? product.getSize(Locale.forLanguageTag("ar")).replaceAll("\\n", "\\\\n").replaceAll("\u0000", "") :"");

				line.add(foodProduct.getCountryOrigin(Locale.forLanguageTag("en")) !=null ? product.getCountryOrigin(Locale.forLanguageTag("en")).replaceAll("\\n", "\\\\n").replaceAll("\u0000", "") :"");
				line.add(foodProduct.getCountryOrigin(Locale.forLanguageTag("ar")) !=null ? product.getCountryOrigin(Locale.forLanguageTag("ar")).replaceAll("\\n", "\\\\n").replaceAll("\u0000", "") :"");

				line.add(foodProduct.getSafetyWarnings(Locale.forLanguageTag("en")) !=null ? product.getSafetyWarnings(Locale.forLanguageTag("en")).replaceAll("\\n", "\\\\n").replaceAll("\u0000", "") :"");
				line.add(foodProduct.getSafetyWarnings(Locale.forLanguageTag("ar")) !=null ? product.getSafetyWarnings(Locale.forLanguageTag("ar")).replaceAll("\\n", "\\\\n").replaceAll("\u0000", "") :"");

				line.add(foodProduct.getWeightIncrement() != null ? Double.toString(foodProduct.getWeightIncrement()) : "");
				line.add(foodProduct.getAverageWeightByPiece()!= null? Double.toString(foodProduct.getAverageWeightByPiece()) : "");
				line.add(foodProduct.getWeightVariation()!= null? Double.toString(foodProduct.getWeightVariation()) : "");
				line.add(foodProduct.getAveragePieceByKg()!= null? Integer.toString(foodProduct.getAveragePieceByKg()) : "");
				line.add(foodProduct.getProductFoodType() != null ? foodProduct.getProductFoodType().getCode() : "");//Clear the order
			}else{
				line.add("");
				line.add("");
				line.add("");
				line.add("");
				line.add("");
				line.add("");
				line.add("");
				line.add("");
				line.add("");
				line.add("");
				line.add("");
				line.add("");
				line.add("");
				line.add("");
				line.add("");
				line.add("");
				line.add("");
				line.add("");
				line.add("");
				line.add("");
				line.add("");
			}


			if (product instanceof NonFoodProductModel){
				productType = "NONFOOD";
				final NonFoodProductModel nonFoodProduct = (NonFoodProductModel) product;
				line.add(nonFoodProduct.getNbrOfMonth() != null ? Integer.toString(nonFoodProduct.getNbrOfMonth()) : "");
				line.add(String.valueOf(nonFoodProduct.isFreeDelivery()));
				line.add(String.valueOf(nonFoodProduct.isFreeInstallation()));
				line.add(String.valueOf(nonFoodProduct.isGenuineStock()));
				line.add(String.valueOf(nonFoodProduct.isOnDemand()));
				line.add(String.valueOf(nonFoodProduct.isPreorder()));
				line.add(nonFoodProduct.getPreOrderDeliveryTime() != null ? df.format(nonFoodProduct.getPreOrderDeliveryTime()) : "");
				line.add(nonFoodProduct.getCodeDeliveryGica());
				line.add(nonFoodProduct.getPreorderDescription() !=null ? nonFoodProduct.getPreorderDescription().replaceAll("\\n", "\\\\n") :"");
				line.add("");
				line.add(String.valueOf(nonFoodProduct.isWarranty()))
			}else{
				line.add("");
				line.add("");
				line.add("");
				line.add("");
				line.add("");
				line.add("");
				line.add("");
				line.add("");
				line.add("");
				line.add("");
				line.add("");
			}

			if (product instanceof ServiceProductModel){
				productType = "SERVICE_PRODUCT";
				final ServiceProductModel serviceProduct = (ServiceProductModel) product;
				line.add(serviceProduct.getWarrantyType() != null ? serviceProduct.getWarrantyType().getCode() : "");
				line.add(serviceProduct.getYearOfWarranty() != null ? Integer.toString(serviceProduct.getYearOfWarranty()) : "");
			}else{
				line.add("");
				line.add("");
			}
			line.add(StringUtils.isNoneBlank(productType) ? productType : "PRODUCT");
			line.add(product.getCreationtime() != null ? df.format(product.getCreationtime()) : "");
			if (CollectionUtils.isNotEmpty(product.getListOfUnpublishedPos())) {
				Set<String> codes = product.getListOfUnpublishedPos().stream().map(pos -> pos.getName()).collect(Collectors.toSet());
				line.add(String.join(",", codes));
			}else{
				line.add("");
			}
			line.add(product.getSupplier() != null ? product.getSupplier().getCode() : "")
			lines.add(line.toArray(new String[line.size()]));

			final ProductData productData = new ProductData();
			mafExportProductService.populateClassificationData(product, productData, data);
			if (CollectionUtils.isNotEmpty(productData.getClassifications())) {
				FeatureList featureList = classificationService.getFeatures(product);
				Map<String, String> featureDataMap = new HashMap<>();
				if (featureList != null && !featureList.getFeatures().isEmpty()) {

					Iterator var4 = featureList.getFeatures().iterator();
					while(var4.hasNext()) {
						Feature feature = (Feature) var4.next();
						ClassAttributeAssignmentModel classAttributeAssignmentModel = feature.getClassAttributeAssignment();
						ClassificationAttributeModel classificationAttributeModel = classAttributeAssignmentModel.getClassificationAttribute();

						featureDataMap.put(classificationAttributeModel.getCode().toLowerCase(), classificationAttributeModel.getCode());
					}
				}



				for (ClassificationData classificationData : productData.getClassifications()) {
					if (CollectionUtils.isNotEmpty(classificationData.getFeatures())) {
						for (FeatureData featureData : classificationData.getFeatures()) {
							if (CollectionUtils.isNotEmpty(featureData.getFeatureValues())) {
								for (FeatureValueData valueData : featureData.getFeatureValues()) {
									List<String> classifLine = new ArrayList<String>();
									classifLine.add(product.getCode());
									String classifCategoryCode = "";

									if (classifCategories.size() == 1){
										classifCategoryCode = classifCategories.get(0).getCode();
									}else{
										classifCategoryCode = getApplicableClassificationCode(classifCategories, classificationData)
									}

									classifLine.add(classifCategoryCode);
									classifLine.add(classificationData.getCode());
									classifLine.add(classificationData.getName());
									classifLine.add(classificationData.getName_ar());
									final String featureNameExisting = StringUtils.isNotEmpty(featureData.getName()) ? featureData.getName() : featureDataMap.get(getLastIndex(featureData.getCode()));
									final String featureName = StringUtils.isNotEmpty(featureNameExisting) ? featureNameExisting : getLastIndexAndCamelCase(featureData.getCode());
									if(StringUtils.isNotEmpty(featureName)){
										classifLine.add(predefinedAttribute.getOrDefault(featureName, ""));
									}else{
										classifLine.add("");
									}
									classifLine.add(featureName);
									classifLine.add(featureData.getName_ar());
									classifLine.add(valueData.getValue() !=null ? valueData.getValue().replaceAll("\\n", "\\\\n").replaceAll("\u0000", "") :"");
									classifLine.add(valueData.getValue_ar() !=null ? valueData.getValue_ar().replaceAll("\\n", "\\\\n").replaceAll("\u0000", "") :"");
									classifLine.add(country);
									classifLines.add(classifLine.toArray(new String[classifLine.size()]));
								}
							}
						}
					}
				}
			}

		}

		mediaCsvWriter.writeAll(mediaLines);
		try {
			mediaCsvWriter.close();
		} catch (IOException e) {
			e.printStackTrace();
		}

		csvWriter.writeAll(lines);
		try {
			csvWriter.close();
		} catch (IOException e) {
			e.printStackTrace();
		}

		classIfCsvWriter.writeAll(classifLines);
		try {
			classIfCsvWriter.close();
		} catch (IOException e) {
			e.printStackTrace();
		}


		uploadFileToAzure(mediaFile, country);
		uploadFileToAzure(file, country);
		uploadFileToAzure(classifFile, country);

		uploadFileToOriginalAzure(mediaFile, country);
		mediaFile.delete();
		uploadFileToOriginalAzure(file, country);
		file.delete();
		uploadFileToOriginalAzure(classifFile, country);
		classifFile.delete();

		if (totalNumberOfPages == 1){
			cronjob.setEndDate(cronjob.getStartTime())
			cronjob.setLastDocumentNumber("0");
			modelService.save(cronjob);
		}


	}else{
		println '**********LIMIT REACHED*********'
		cronjob.setEndDate(cronjob.getStartTime())
		cronjob.setLastDocumentNumber("0");
		modelService.save(cronjob)
		new PerformResult(CronJobResult.UNKNOWN, CronJobStatus.PAUSED)
	}

private String getLastIndexAndCamelCase(String input) {
	String[] parts = input.split("\\.");
	String lastPart = parts[parts.length - 1];

	// Remove non-alphabetic characters and capitalize the first letter
	String[] words = lastPart.split("\\W+");

	StringJoiner joiner = new StringJoiner(" ");

	for (String word : words) {
		StringBuilder camelCase = new StringBuilder();
		camelCase.append(Character.toUpperCase(word.charAt(0)))
				.append(word.substring(1).toLowerCase());
		joiner.add(camelCase);
	}

	return joiner.toString();
}

private String getLastIndex(String input) {
	String[] parts = input.split("\\.");
	return parts[parts.length - 1];
}

private void uploadFileToAzure(File file, String country) {
	String connectionString='DefaultEndpointsProtocol=https;AccountName=pimcoreservicemaster;AccountKey=/lw/Lum/lLmOuILNJIh+HiScvg+QzKvFCrCacSNlaseN9uyuXCr8HvGF0CqEmIR31hrrRA+owl4m+ASthtlxAw==;EndpointSuffix=core.windows.net';
	String containerName='integrations';
	String blobPath= 'data-migration/' + country+'/input/'+file.getName();
	println 'FileUploading='+file.getName();

	CloudStorageAccount storageAccount;
	try {
		storageAccount = CloudStorageAccount.parse(connectionString);
		CloudBlobClient blobClient = storageAccount.createCloudBlobClient();
		CloudBlobContainer container = blobClient.getContainerReference(containerName);

		final CloudBlockBlob blob = container.getBlockBlobReference(blobPath);
		blob.getProperties().setContentType('text/csv');
		blob.uploadFromFile(file.getPath());
	} catch (Exception e) {
		e.printStackTrace();
	}
}

private void uploadFileToOriginalAzure(File file, String country) {
	String connectionString='DefaultEndpointsProtocol=https;AccountName=pimcoreservicemaster;AccountKey=/lw/Lum/lLmOuILNJIh+HiScvg+QzKvFCrCacSNlaseN9uyuXCr8HvGF0CqEmIR31hrrRA+owl4m+ASthtlxAw==;EndpointSuffix=core.windows.net';
	String containerName='integrations';
	String blobPath= 'data-migration/' + country+'/Original/Products/'+file.getName();
	println 'FileUploading='+file.getName();

	CloudStorageAccount storageAccount;
	try {
		storageAccount = CloudStorageAccount.parse(connectionString);
		CloudBlobClient blobClient = storageAccount.createCloudBlobClient();
		CloudBlobContainer container = blobClient.getContainerReference(containerName);

		final CloudBlockBlob blob = container.getBlockBlobReference(blobPath);
		blob.getProperties().setContentType('text/csv');
		blob.uploadFromFile(file.getPath());
	} catch (Exception e) {
		e.printStackTrace();
	}
}

private String getNotNullValue(Object value) {
    return value != null ? value.toString() : StringUtils.EMPTY;
}


private String getApplicableClassificationCode( List<CategoryModel> classifCategories, ClassificationData classificationData){

	for(CategoryModel classificationModel:classifCategories){
		if(classificationModel.getCode().equals(classificationData.getCode())){
			return classificationModel.getCode();
		}
		Collection<CategoryModel> superCategories = categoryService.getAllSupercategoriesForCategory(classificationModel);
		for(CategoryModel superClassificationModel:superCategories){
			if(superClassificationModel.getCode().equals(classificationData.getCode())){
				return classificationModel.getCode();
			}

		}

	}
	return "";
}

private Map<String,String> getPredefinedAttribute(){

	final Map<String, String> attr = new HashMap<>();

	attr.put("Capacity in Liters","Capacity_in_Liters_ken");
	attr.put("Type","Type_ken");
	attr.put("Case design","Case_design_ken");
	attr.put("Top surface type","Top_surface_type_ken");
	attr.put("Number of burners/cooking zones","Number_of_burners/cooking_zones_ken");
	attr.put("Hob type","Hob_type_ken");
	attr.put("Built-in display","Built-in_display_ken");
	attr.put("Number of gas burners","Number_of_gas_burners_ken");
	attr.put("Number of electric cooking zones","Number_of_electric_cooking_zones_ken");
	attr.put("Dimensions WxDxH","Dimensions_WxDxH_ken");
	attr.put("Number of slots","Number_of_slots_ken");
	attr.put("Warming rack","Warming_rack_ken");
	attr.put("Number of slices","Number_of_slices_ken");
	attr.put("Long slot","Long_slot_ken");
	attr.put("Overheat protection","Overheat_protection_ken");
	attr.put("Water level indicator","Water_level_indicator_ken");
	attr.put("Water tank capacity","Water_tank_capacity_ken");
	attr.put("Cordless","Cordless_ken");
	attr.put("Adjustable thermostat","Adjustable_thermostat_ken");
	attr.put("Power","Power_ken");
	attr.put("Housing material","Housing_material_ken");
	attr.put("Reservoir for brewed coffee","Reservoir_for_brewed_coffee_ken");
	attr.put("Capacity in cups","Capacity_in_cups_ken");
	attr.put("Built-in grinder","Built-in_grinder_ken");
	attr.put("Coffee input type","Coffee_input_type_ken");
	attr.put("Types of drink","Types_of_drink_ken");
	attr.put("Coffee maker type","Coffee_maker_type_ken");
	attr.put("Sandwich rack","Sandwich_rack_ken");
	attr.put("Number of sandwiches","Number_of_sandwiches_ken");
	attr.put("Grilling","Grilling_ken");
	attr.put("Waffle making","Waffle_making_ken");
	attr.put("Number of speeds","Number_of_speeds_ken");
	attr.put("Built-in pulp container","Built-in_pulp_container_ken");
	attr.put("Juice container","Juice_container_ken");
	attr.put("Bowl material","Bowl_material_ken");
	attr.put("Pulse function","Pulse_function_ken");
	attr.put("Bowl capacity","Bowl_capacity_ken");
	attr.put("Variable speed","Variable_speed_ken");
	attr.put("Ice crushing","Ice_crushing_ken");
	attr.put("Removable bowl","Removable_bowl_ken");
	attr.put("Dishwasher-proof parts","Dishwasher-proof_parts_ken");
	attr.put("Turbo","Turbo_ken");
	attr.put("Material","Material_ken");
	attr.put("Interior capacity","Interior_capacity_ken");
	attr.put("Microwave power","Microwave_power_ken");
	attr.put("Control type","Control_type_ken");
	attr.put("Cooking types","Cooking_types_ken");
	attr.put("Turntable","Turntable_ken");
	attr.put("Connected load","Connected_load_ken");
	attr.put("Energy efficiency class","Energy_efficiency_class_ken");
	attr.put("Total oven power","Total_oven_power_ken");
	attr.put("Energy consumption - forced convection","Energy_consumption_-_forced_convection_ken");
	attr.put("Energy consumption - conventional","Energy_consumption_-_conventional_ken");
	attr.put("Oven type","Oven_type_ken");
	attr.put("Cooking types - 1st oven","Cooking_types_-_1st_oven_ken");
	attr.put("Total oven interior capacity","Total_oven_interior_capacity_ken");
	attr.put("Oven size","Oven_size_ken");
	attr.put("Variable steam","Variable_steam_ken");
	attr.put("Automatic anti-calc","Automatic_anti-calc_ken");
	attr.put("Continuous steam","Continuous_steam_ken");
	attr.put("Cord length","Cord_length_ken");
	attr.put("Steam boost performance","Steam_boost_performance_ken");
	attr.put("Steam boost function","Steam_boost_function_ken");
	attr.put("Soleplate type","Soleplate_type_ken");
	attr.put("Designed for travel","Designed_for_travel_ken");
	attr.put("Non-twisting cord","Non-twisting_cord_ken");
	attr.put("Power supply type","Power_supply_type_ken");
	attr.put("Number of programs","Number_of_programs_ken");
	attr.put("Buttonhole type","Buttonhole_type_ken");
	attr.put("Free arm","Free_arm_ken");
	attr.put("Number of stitches","Number_of_stitches_ken");
	attr.put("Sewing machine functions","Sewing_machine_functions_ken");
	attr.put("Maximum steam pressure","Maximum_steam_pressure_ken");
	attr.put("Iron power","Iron_power_ken");
	attr.put("Cool shot function","Cool_shot_function_ken");
	attr.put("Number of heating levels","Number_of_heating_levels_ken");
	attr.put("Ionic function","Ionic_function_ken");
	attr.put("Concentrator nozzle","Concentrator_nozzle_ken");
	attr.put("Diffuser nozzle","Diffuser_nozzle_ken");
	attr.put("Device type","Device_type_ken");
	attr.put("Auto power off","Auto_power_off_ken");
	attr.put("Ion conditioning","Ion_conditioning_ken");
	attr.put("Ceramic heating system","Ceramic_heating_system_ken");
	attr.put("Adjustable temperature","Adjustable_temperature_ken");
	attr.put("Swivel cord","Swivel_cord_ken");
	attr.put("Battery type","Battery_type_ken");
	attr.put("Power source","Power_source_ken");
	attr.put("Timer","Timer_ken");
	attr.put("Purpose","Purpose_ken");
	attr.put("Toothbrush frequency - oscillations","Toothbrush_frequency_-_oscillations_ken");
	attr.put("Adjustable speed","Adjustable_speed_ken");
	attr.put("Teeth brushing modes","Teeth_brushing_modes_ken");
	attr.put("Toothbrush frequency - pulsations","Toothbrush_frequency_-_pulsations_ken");
	attr.put("Toothbrush frequency - rotations","Toothbrush_frequency_-_rotations_ken");
	attr.put("Number of teeth brushing modes","Number_of_teeth_brushing_modes_ken");
	attr.put("Number of brush heads included","Number_of_brush_heads_included_ken");
	attr.put("Number of handles included","Number_of_handles_included_ken");
	attr.put("Flosser included","Flosser_included_ken");
	attr.put("Irrigator","Irrigator_ken");
	attr.put("Massage function","Massage_function_ken");
	attr.put("Placement supported","Placement_supported_ken");
	attr.put("Mean arterial pressure","Mean_arterial_pressure_ken");
	attr.put("Pulse rate measuring","Pulse_rate_measuring_ken");
	attr.put("Diastolic blood pressure","Diastolic_blood_pressure_ken");
	attr.put("Systolic blood pressure","Systolic_blood_pressure_ken");
	attr.put("Speaking function","Speaking_function_ken");
	attr.put("Display type","Display_type_ken");
	attr.put("Shaver system","Shaver_system_ken");
	attr.put("Trimmer","Trimmer_ken");
	attr.put("Number of shaver heads/blades","Number_of_shaver_heads/blades_ken");
	attr.put("Washable","Washable_ken");
	attr.put("Cutter width","Cutter_width_ken");
	attr.put("Number of length steps","Number_of_length_steps_ken");
	attr.put("Minimum hair length","Minimum_hair_length_ken");
	attr.put("Maximum hair length","Maximum_hair_length_ken");
	attr.put("Wet & Dry","Wet_&_Dry_ken");
	attr.put("8988","8988_ken");
	attr.put("Backlight","Backlight_ken");
	attr.put("Cooling","Cooling_ken");
	attr.put("Shaver","Shaver_ken");
	attr.put("Number of tweezers","Number_of_tweezers_ken");
	attr.put("Floating head","Floating_head_ken");
	attr.put("Suitable for short hair","Suitable_for_short_hair_ken");
	attr.put("Rechargeable","Rechargeable_ken");
	attr.put("Charging time","Charging_time_ken");
	attr.put("Operating time","Operating_time_ken");
	attr.put("Suitable for entire body","Suitable_for_entire_body_ken");
	attr.put("Noise level","Noise_level_ken");
	attr.put("Cleaning type","Cleaning_type_ken");
	attr.put("Proper use","Proper_use_ken");
	attr.put("Vacuum cleaner air filtering","Vacuum_cleaner_air_filtering_ken");
	attr.put("Cleaning surfaces","Cleaning_surfaces_ken");
	attr.put("Dust re-emission class","Dust_re-emission_class_ken");
	attr.put("Carpet cleaning performance class","Carpet_cleaning_performance_class_ken");
	attr.put("Hard floor cleaning performance class","Hard_floor_cleaning_performance_class_ken");
	attr.put("Dust container type","Dust_container_type_ken");
	attr.put("Dust capacity","Dust_capacity_ken");
	attr.put("Dirt capacity dry","Dirt_capacity_dry_ken");
	attr.put("Maximum input power","Maximum_input_power_ken");
	attr.put("Annual energy consumption","Annual_energy_consumption_ken");
	attr.put("Runtime","Runtime_ken");
	attr.put("Battery voltage","Battery_voltage_ken");
	attr.put("Power consumption - typical","Power_consumption_-_typical_ken");
	attr.put("Energy Star certified","Energy_Star_certified_ken");
	attr.put("Height adjustment","Height_adjustment_ken");
	attr.put("Diameter","Diameter_ken");
	attr.put("Placement","Placement_ken");
	attr.put("Suitable for rooms up to","Suitable_for_rooms_up_to_ken");
	attr.put("Air purify rate","Air_purify_rate_ken");
	attr.put("Heating power","Heating_power_ken");
	attr.put("Heating power - min","Heating_power_-_min_ken");
	attr.put("Heat source","Heat_source_ken");
	attr.put("Recommended usage","Recommended_usage_ken");
	attr.put("Number of spouts","Number_of_spouts_ken");
	attr.put("Capacity","Capacity_ken");
	attr.put("Suitable for vacuum cleaner type","Suitable_for_vacuum_cleaner_type_ken");
	attr.put("Rice bowl","Rice_bowl_ken");
	attr.put("Automatic programs","Automatic_programs_ken");
	attr.put("Easy-to-clean non stick inner pot","Easy-to-clean_non_stick_inner_pot_ken");
	attr.put("AC input frequency","AC_input_frequency_ken");
	attr.put("AC input voltage","AC_input_voltage_ken");
	attr.put("Power supply input frequency","Power_supply_input_frequency_ken");
	attr.put("Input voltage","Input_voltage_ken");
	attr.put("Number of layers","Number_of_layers_ken");
	attr.put("Dishwasher proof","Dishwasher_proof_ken");
	attr.put("Non-stick inner bowl","Non-stick_inner_bowl_ken");
	attr.put("Collapsible basket","Collapsible_basket_ken");
	attr.put("Accessories included","Accessories_included_ken");
	attr.put("Suitable for","Suitable_for_ken");
	attr.put("Number of power levels","Number_of_power_levels_ken");
	attr.put("Certification","Certification_ken");
	attr.put("RoHS compliance","RoHS_compliance_ken");
	attr.put("Number of knobs","Number_of_knobs_ken");
	attr.put("Knobs colour","Knobs_colour_ken");
	attr.put("Digital zoom","Digital_zoom_ken");
	attr.put("Optical zoom","Optical_zoom_ken");
	attr.put("Megapixel","Megapixel_ken");
	attr.put("Sensor type","Sensor_type_ken");
	attr.put("Image stabilizer","Image_stabilizer_ken");
	attr.put("Still image resolution","Still_image_resolution_ken");
	attr.put("Image formats supported","Image_formats_supported_ken");
	attr.put("Maximum image resolution","Maximum_image_resolution_ken");
	attr.put("Camera type","Camera_type_ken");
	attr.put("Image sensor size","Image_sensor_size_ken");
	attr.put("Display","Display_ken");
	attr.put("Display diagonal","Display_diagonal_ken");
	attr.put("Touchscreen","Touchscreen_ken");
	attr.put("Vari-angle LCD display","Vari-angle_LCD_display_ken");
	attr.put("Battery technology","Battery_technology_ken");
	attr.put("Power source type","Power_source_type_ken");
	attr.put("Light exposure correction","Light_exposure_correction_ken");
	attr.put("ISO sensitivity","ISO_sensitivity_ken");
	attr.put("Light exposure modes","Light_exposure_modes_ken");
	attr.put("Light metering","Light_metering_ken");
	attr.put("ISO sensitivity - min","ISO_sensitivity_-_min_ken");
	attr.put("ISO sensitivity - max","ISO_sensitivity_-_max_ken");
	attr.put("White balance","White_balance_ken");
	attr.put("Self-timer","Self-timer_ken");
	attr.put("Shooting modes","Shooting_modes_ken");
	attr.put("GPS - satellite","GPS_-_satellite_ken");
	attr.put("Photo effects","Photo_effects_ken");
	attr.put("Scene modes","Scene_modes_ken");
	attr.put("Compatible memory cards","Compatible_memory_cards_ken");
	attr.put("Built-in microphone","Built-in_microphone_ken");
	attr.put("Focus adjustment","Focus_adjustment_ken");
	attr.put("Auto focusing modes","Auto_focusing_modes_ken");
	attr.put("Normal focusing range - tele","Normal_focusing_range_-_tele_ken");
	attr.put("Normal focusing range - wide","Normal_focusing_range_-_wide_ken");
	attr.put("Bluetooth","Bluetooth_ken");
	attr.put("Wi-Fi","Wi-Fi_ken");
	attr.put("Near Field Communication","Near_Field_Communication_ken");
	attr.put("Flash range - wide","Flash_range_-_wide_ken");
	attr.put("Flash range - tele","Flash_range_-_tele_ken");
	attr.put("Flash modes","Flash_modes_ken");
	attr.put("PictBridge","PictBridge_ken");
	attr.put("HDMI","HDMI_ken");
	attr.put("USB version","USB_version_ken");
	attr.put("Fastest camera shutter speed","Fastest_camera_shutter_speed_ken");
	attr.put("Slowest camera shutter speed","Slowest_camera_shutter_speed_ken");
	attr.put("Maximum video resolution","Maximum_video_resolution_ken");
	attr.put("Video recording","Video_recording_ken");
	attr.put("HD type","HD_type_ken");
	attr.put("Battery life - max","Battery_life_-_max_ken");
	attr.put("Storage media","Storage_media_ken");
	attr.put("Total megapixels","Total_megapixels_ken");
	attr.put("Photo mode","Photo_mode_ken");
	attr.put("Full HD","Full_HD_ken");
	attr.put("Maximum frame rate","Maximum_frame_rate_ken");
	attr.put("Maximum weight - capacity","Maximum_weight_-_capacity_ken");
	attr.put("Height - max","Height_-_max_ken");
	attr.put("Number of legs","Number_of_legs_ken");
	attr.put("Brand compatibility","Brand_compatibility_ken");
	attr.put("Approximate recycling time","Approximate_recycling_time_ken");
	attr.put("Camera brands compatibility","Camera_brands_compatibility_ken");
	attr.put("Lens structure - elements/groups","Lens_structure_-_elements/groups_ken");
	attr.put("Closest focusing distance","Closest_focusing_distance_ken");
	attr.put("Minimum aperture number","Minimum_aperture_number_ken");
	attr.put("Maximum aperture number","Maximum_aperture_number_ken");
	attr.put("Lens type","Lens_type_ken");
	attr.put("Component for","Component_for_ken");
	attr.put("Lens mount interface","Lens_mount_interface_ken");
	attr.put("Filter size","Filter_size_ken");
	attr.put("Length","Length_ken");
	attr.put("Quantity per pack","Quantity_per_pack_ken");
	attr.put("Interface","Interface_ken");
	attr.put("Ethernet LAN","Ethernet_LAN_ken");
	attr.put("Headphone connectivity","Headphone_connectivity_ken");
	attr.put("Filter type","Filter_type_ken");
	attr.put("Display resolution","Display_resolution_ken");
	attr.put("LED backlight","LED_backlight_ken");
	attr.put("3D","3D_ken");
	attr.put("Built-in speaker","Built-in_speaker_ken");
	attr.put("Card reader integrated","Card_reader_integrated_ken");
	attr.put("Video playback","Video_playback_ken");
	attr.put("Battery capacity","Battery_capacity_ken");
	attr.put("Disc types supported","Disc_types_supported_ken");
	attr.put("Camcorder tape type","Camcorder_tape_type_ken");
	attr.put("Camcorder media type","Camcorder_media_type_ken");
	attr.put("Internal storage capacity","Internal_storage_capacity_ken");
	attr.put("Interchangeable lens","Interchangeable_lens_ken");
	attr.put("Viewfinder type","Viewfinder_type_ken");
	attr.put("Built-in flash","Built-in_flash_ken");
	attr.put("Built-in light","Built-in_light_ken");
	attr.put("USB 2.0 ports quantity","USB_2.0_ports_quantity_ken");
	attr.put("2308","2308_ken");
	attr.put("Headphone outputs","Headphone_outputs_ken");
	attr.put("Component video - YPbPr/YCbCr out","Component_video_-_YPbPr/YCbCr_out_ken");
	attr.put("S-Video out","S-Video_out_ken");
	attr.put("USB 3.0 - 3.1 Gen 1 Type-A ports quantity","USB_3.0_-_3.1_Gen_1_Type-A_ports_quantity_ken");
	attr.put("22701","22701_ken");
	attr.put("Camcorder type","Camcorder_type_ken");
	attr.put("Brightness","Brightness_ken");
	attr.put("Magnification","Magnification_ken");
	attr.put("Objective diameter","Objective_diameter_ken");
	attr.put("Exit pupil","Exit_pupil_ken");
	attr.put("Eye relief","Eye_relief_ken");
	attr.put("Prism type","Prism_type_ken");
	attr.put("Foldable","Foldable_ken");
	attr.put("Waterproof","Waterproof_ken");
	attr.put("Field of view at 1000 m","Field_of_view_at_1000_m_ken");
	attr.put("Flash card type","Flash_card_type_ken");
	attr.put("Flash memory class","Flash_memory_class_ken");
	attr.put("Internal memory","Internal_memory_ken");
	attr.put("Colour","Colour_ken");
	attr.put("Maximum resolution","Maximum_resolution_ken");
	attr.put("Number of print cartridges","Number_of_print_cartridges_ken");
	attr.put("Maximum duty cycle","Maximum_duty_cycle_ken");
	attr.put("Print speed - black, normal quality, A4/US Letter","Print_speed_-_black,_normal_quality,_A4/US_Letter_ken");
	attr.put("Standard input capacity","Standard_input_capacity_ken");
	attr.put("Standard output capacity","Standard_output_capacity_ken");
	attr.put("Standard interfaces","Standard_interfaces_ken");
	attr.put("ISO A-series sizes - A0...A9","ISO_A-series_sizes_-_A0...A9_ken");
	attr.put("3628","3628_ken");
	attr.put("Standard tray media types","Standard_tray_media_types_ken");
	attr.put("Maximum ISO A-series paper size","Maximum_ISO_A-series_paper_size_ken");
	attr.put("Maximum internal memory","Maximum_internal_memory_ken");
	attr.put("Print technology","Print_technology_ken");
	attr.put("Duplex printing","Duplex_printing_ken");
	attr.put("Network ready","Network_ready_ken");
	attr.put("Mobile printing technologies","Mobile_printing_technologies_ken");
	attr.put("Maximum scan size","Maximum_scan_size_ken");
	attr.put("Optical scanning resolution","Optical_scanning_resolution_ken");
	attr.put("Colour scanning","Colour_scanning_ken");
	attr.put("Duplex scanning","Duplex_scanning_ken");
	attr.put("Film scanning","Film_scanning_ken");
	attr.put("Scanner type","Scanner_type_ken");
	attr.put("Quantity","Quantity_ken");
	attr.put("Printing colours","Printing_colours_ken");
	attr.put("Compatible products","Compatible_products_ken");
	attr.put("Type finish","Type_finish_ken");
	attr.put("Media weight","Media_weight_ken");
	attr.put("Paper size","Paper_size_ken");
	attr.put("Sheets per pack","Sheets_per_pack_ken");
	attr.put("Modem speed","Modem_speed_ken");
	attr.put("Colour faxing","Colour_faxing_ken");
	attr.put("Answering machine","Answering_machine_ken");
	attr.put("Copying","Copying_ken");
	attr.put("Maximum standard media size","Maximum_standard_media_size_ken");
	attr.put("Platform","Platform_ken");
	attr.put("Built-in optical drive","Built-in_optical_drive_ken");
	attr.put("Digital audio optical out","Digital_audio_optical_out_ken");
	attr.put("HDMI ports quantity","HDMI_ports_quantity_ken");
	attr.put("Video game included","Video_game_included_ken");
	attr.put("Number of gamepads included","Number_of_gamepads_included_ken");
	attr.put("Compatibility","Compatibility_ken");
	attr.put("Language version","Language_version_ken");
	attr.put("Genre","Genre_ken");
	attr.put("Developer","Developer_ken");
	attr.put("ESRB rating","ESRB_rating_ken");
	attr.put("Release date","Release_date_ken");
	attr.put("Game edition","Game_edition_ken");
	attr.put("PEGI rating","PEGI_rating_ken");
	attr.put("Multiplayer mode","Multiplayer_mode_ken");
	attr.put("Processor model","Processor_model_ken");
	attr.put("Number of processors installed","Number_of_processors_installed_ken");
	attr.put("Processor family","Processor_family_ken");
	attr.put("Processor cores","Processor_cores_ken");
	attr.put("Processor frequency","Processor_frequency_ken");
	attr.put("Internal memory type","Internal_memory_type_ken");
	attr.put("Chassis type","Chassis_type_ken");
	attr.put("Optical drive type","Optical_drive_type_ken");
	attr.put("Power supply","Power_supply_ken");
	attr.put("Display included","Display_included_ken");
	attr.put("Ethernet LAN - RJ-45 ports","Ethernet_LAN_-_RJ-45_ports_ken");
	attr.put("Microphone in","Microphone_in_ken");
	attr.put("DVI port","DVI_port_ken");
	attr.put("VGA D-Sub ports quantity","VGA_D-Sub_ports_quantity_ken");
	attr.put("USB 3.0 - 3.1 Gen 1 Type-C ports quantity","USB_3.0_-_3.1_Gen_1_Type-C_ports_quantity_ken");
	attr.put("22702","22702_ken");
	attr.put("Thunderbolt 3 ports quantity","Thunderbolt_3_ports_quantity_ken");
	attr.put("On-board graphics adapter model","On-board_graphics_adapter_model_ken");
	attr.put("Discrete graphics adapter model","Discrete_graphics_adapter_model_ken");
	attr.put("Total storage capacity","Total_storage_capacity_ken");
	attr.put("Operating system installed","Operating_system_installed_ken");
	attr.put("Wi-Fi standards","Wi-Fi_standards_ken");
	attr.put("3G","3G_ken");
	attr.put("4G","4G_ken");
	attr.put("Form factor","Form_factor_ken");
	attr.put("Numeric keypad","Numeric_keypad_ken");
	attr.put("Docking connector","Docking_connector_ken");
	attr.put("DisplayPorts quantity","DisplayPorts_quantity_ken");
	attr.put("Thunderbolt ports quantity","Thunderbolt_ports_quantity_ken");
	attr.put("Front camera","Front_camera_ken");
	attr.put("Contrast ratio - typical","Contrast_ratio_-_typical_ken");
	attr.put("Viewing angle, horizontal","Viewing_angle,_horizontal_ken");
	attr.put("Viewing angle, vertical","Viewing_angle,_vertical_ken");
	attr.put("Display brightness","Display_brightness_ken");
	attr.put("Response time","Response_time_ken");
	attr.put("Supported graphics resolutions","Supported_graphics_resolutions_ken");
	attr.put("Display technology","Display_technology_ken");
	attr.put("Native aspect ratio","Native_aspect_ratio_ken");
	attr.put("Display number of colours","Display_number_of_colours_ken");
	attr.put("EPEAT compliance","EPEAT_compliance_ken");
	attr.put("Power consumption - standby","Power_consumption_-_standby_ken");
	attr.put("VGA - D-Sub ports quantity","VGA_-_D-Sub_ports_quantity_ken");
	attr.put("Cable lock slot","Cable_lock_slot_ken");
	attr.put("On/off switch","On/off_switch_ken");
	attr.put("VESA mounting","VESA_mounting_ken");
	attr.put("TV tuner integrated","TV_tuner_integrated_ken");
	attr.put("Built-in camera","Built-in_camera_ken");
	attr.put("Thin client installed","Thin_client_installed_ken");
	attr.put("Kids tablet","Kids_tablet_ken");
	attr.put("Touch technology","Touch_technology_ken");
	attr.put("Headphone out","Headphone_out_ken");
	attr.put("Keyboard supplied","Keyboard_supplied_ken");
	attr.put("Rear camera","Rear_camera_ken");
	attr.put("Rear camera resolution - numeric","Rear_camera_resolution_-_numeric_ken");
	attr.put("Memory clock speed","Memory_clock_speed_ken");
	attr.put("Screen shape","Screen_shape_ken");
	attr.put("Detachable display","Detachable_display_ken");
	attr.put("Mouse included","Mouse_included_ken");
	attr.put("Autonomy mode","Autonomy_mode_ken");
	attr.put("Fingerprint reader","Fingerprint_reader_ken");
	attr.put("PIN-secured access","PIN-secured_access_ken");
	attr.put("Lightning connector","Lightning_connector_ken");
	attr.put("Password protection","Password_protection_ken");
	attr.put("Micro-USB connector","Micro-USB_connector_ken");
	attr.put("USB connector","USB_connector_ken");
	attr.put("CD write speed","CD_write_speed_ken");
	attr.put("Native capacity","Native_capacity_ken");
	attr.put("Optical disc diameter","Optical_disc_diameter_ken");
	attr.put("Speakerphone","Speakerphone_ken");
	attr.put("Caller ID","Caller_ID_ken");
	attr.put("Phonebook capacity","Phonebook_capacity_ken");
	attr.put("Intercom","Intercom_ken");
	attr.put("Mounting type","Mounting_type_ken");
	attr.put("Elderly phone","Elderly_phone_ken");
	attr.put("Number of handsets included","Number_of_handsets_included_ken");
	attr.put("Connectivity technology","Connectivity_technology_ken");
	attr.put("Data transfer rate","Data_transfer_rate_ken");
	attr.put("Hard drive capacity","Hard_drive_capacity_ken");
	attr.put("Hard drive speed","Hard_drive_speed_ken");
	attr.put("Hard drive interface","Hard_drive_interface_ken");
	attr.put("Hard drive size","Hard_drive_size_ken");
	attr.put("USB powered","USB_powered_ken");
	attr.put("License quantity","License_quantity_ken");
	attr.put("Number of years","Number_of_years_ken");
	attr.put("Windows operating systems supported","Windows_operating_systems_supported_ken");
	attr.put("Mac operating systems supported","Mac_operating_systems_supported_ken");
	attr.put("Talk time - 3G","Talk_time_-_3G_ken");
	attr.put("Standby time - 3G","Standby_time_-_3G_ken");
	attr.put("Curved design","Curved_design_ken");
	attr.put("Internal RAM in GB","Internal_RAM_in_GB_ken");
	attr.put("Orientation sensor","Orientation_sensor_ken");
	attr.put("Auto focus","Auto_focus_ken");
	attr.put("Second camera","Second_camera_ken");
	attr.put("Main camera resolution - numeric","Main_camera_resolution_-_numeric_ken");
	attr.put("SIM card type","SIM_card_type_ken");
	attr.put("3G standards","3G_standards_ken");
	attr.put("2G standards","2G_standards_ken");
	attr.put("SIM card capability","SIM_card_capability_ken");
	attr.put("Operating system version","Operating_system_version_ken");
	attr.put("Subscription type","Subscription_type_ken");
	attr.put("USB port","USB_port_ken");
	attr.put("Talk time - 2G","Talk_time_-_2G_ken");
	attr.put("Standby time - 2G","Standby_time_-_2G_ken");
	attr.put("Video call","Video_call_ken");
	attr.put("Flash card support","Flash_card_support_ken");
	attr.put("Personal info management","Personal_info_management_ken");
	attr.put("External display","External_display_ken");
	attr.put("MMS","MMS_ken");
	attr.put("E-mail","E-mail_ken");
	attr.put("FM radio","FM_radio_ken");
	attr.put("WAP","WAP_ken");
	attr.put("Data network","Data_network_ken");
	attr.put("Charger compatibility","Charger_compatibility_ken");
	attr.put("Charger type","Charger_type_ken");
	attr.put("Quick charge","Quick_charge_ken");
	attr.put("Charging source","Charging_source_ken");
	attr.put("Number of charging cycles","Number_of_charging_cycles_ken");
	attr.put("Number of simultaneously connected devices - max","Number_of_simultaneously_connected_devices_-_max_ken");
	attr.put("Built-in memory","Built-in_memory_ken");
	attr.put("Memory card slot","Memory_card_slot_ken");
	attr.put("Electronic compass","Electronic_compass_ken");
	attr.put("Protection features","Protection_features_ken");
	attr.put("Channels quantity","Channels_quantity_ken");
	attr.put("Sensitivity","Sensitivity_ken");
	attr.put("Cover","Cover_ken");
	attr.put("Backlight display","Backlight_display_ken");
	attr.put("Digits","Digits_ken");
	attr.put("Display number of lines","Display_number_of_lines_ken");
	attr.put("Second display","Second_display_ken");
	attr.put("Display tilting","Display_tilting_ken");
	attr.put("Design","Design_ken");
	attr.put("Band material","Band_material_ken");
	attr.put("Watch glass type","Watch_glass_type_ken");
	attr.put("Housing colour","Housing_colour_ken");
	attr.put("Band colour","Band_colour_ken");
	attr.put("Watch dial colour","Watch_dial_colour_ken");
	attr.put("Suggested gender","Suggested_gender_ken");
	attr.put("Storage media type","Storage_media_type_ken");
	attr.put("Shock proof","Shock_proof_ken");
	attr.put("Mechanism type","Mechanism_type_ken");
	attr.put("Chronograph","Chronograph_ken");
	attr.put("Chronometer","Chronometer_ken");
	attr.put("Battery life","Battery_life_ken");
	attr.put("Auto standby","Auto_standby_ken");
	attr.put("Languages support","Languages_support_ken");
	attr.put("Mobile operating systems supported","Mobile_operating_systems_supported_ken");
	attr.put("Social network services supported","Social_network_services_supported_ken");
	attr.put("Bluetooth version","Bluetooth_version_ken");
	attr.put("Thickness","Thickness_ken");
	attr.put("Shape","Shape_ken");
	attr.put("Band size","Band_size_ken");
	attr.put("Projection distance","Projection_distance_ken");
	attr.put("Projection technology","Projection_technology_ken");
	attr.put("Projector brightness","Projector_brightness_ken");
	attr.put("Screen size compatibility","Screen_size_compatibility_ken");
	attr.put("Projector native resolution","Projector_native_resolution_ken");
	attr.put("Focal length range","Focal_length_range_ken");
	attr.put("Bulb power","Bulb_power_ken");
	attr.put("Service life of lamp","Service_life_of_lamp_ken");
	attr.put("Analog signal format system","Analog_signal_format_system_ken");
	attr.put("Handheld remote control","Handheld_remote_control_ken");
	attr.put("S-Video inputs quantity","S-Video_inputs_quantity_ken");
	attr.put("Composite video in","Composite_video_in_ken");
	attr.put("RS-232 ports","RS-232_ports_ken");
	attr.put("Audio LR in","Audio_LR_in_ken");
	attr.put("Component video - YPbPr/YCbCr in","Component_video_-_YPbPr/YCbCr_in_ken");
	attr.put("Motion interpolation technology","Motion_interpolation_technology_ken");
	attr.put("OLED technology","OLED_technology_ken");
	attr.put("DVI-D ports quantity","DVI-D_ports_quantity_ken");
	attr.put("PC - D-Sub","PC_-_D-Sub_ken");
	attr.put("Common inter","Common_inter_ken");
	attr.put("Common interface","Common_interface_ken");
	attr.put("Common interface Plus","Common_interface_Plus_ken");
	attr.put("Digital signal format system","Digital_signal_format_system_ken");
	attr.put("RMS rated power","RMS_rated_power_ken");
	attr.put("Number of loudspeakers","Number_of_loudspeakers_ken");
	attr.put("Teletext function","Teletext_function_ken");
	attr.put("Internet TV","Internet_TV_ken");
	attr.put("Smart TV","Smart_TV_ken");
	attr.put("Drawers","Drawers_ken");
	attr.put("Frame material","Frame_material_ken");
	attr.put("Frame colour","Frame_colour_ken");
	attr.put("Top material","Top_material_ken");
	attr.put("Shelves","Shelves_ken");
	attr.put("Top colour","Top_colour_ken");
	attr.put("Audio decoders","Audio_decoders_ken");
	attr.put("Audio output channels","Audio_output_channels_ken");
	attr.put("Audio formats supported","Audio_formats_supported_ken");
	attr.put("Video formats supported","Video_formats_supported_ken");
	attr.put("Supported video modes","Supported_video_modes_ken");
	attr.put("Deep colour support","Deep_colour_support_ken");
	attr.put("x.v.Color support","x.v.Color_support_ken");
	attr.put("9789","9789_ken");
	attr.put("Progressive scan","Progressive_scan_ken");
	attr.put("Digital audio coaxial out","Digital_audio_coaxial_out_ken");
	attr.put("Playback disc formats","Playback_disc_formats_ken");
	attr.put("Built-in hard drive","Built-in_hard_drive_ken");
	attr.put("Video upscaling","Video_upscaling_ken");
	attr.put("Apple docking compatibility","Apple_docking_compatibility_ken");
	attr.put("AirPlay","AirPlay_ken");
	attr.put("Receiver type","Receiver_type_ken");
	attr.put("Power output per channel - 20-20KHz@8 Ohm","Power_output_per_channel_-_20-20KHz@8_Ohm_ken");
	attr.put("Supported radio bands","Supported_radio_bands_ken");
	attr.put("Digital audio coaxial in","Digital_audio_coaxial_in_ken");
	attr.put("Digital audio optical in","Digital_audio_optical_in_ken");
	attr.put("HDMI in","HDMI_in_ken");
	attr.put("USB ports quantity","USB_ports_quantity_ken");
	attr.put("Card reader","Card_reader_ken");
	attr.put("HDMI out","HDMI_out_ken");
	attr.put("Speakers connectivity type","Speakers_connectivity_type_ken");
	attr.put("Optical drive included","Optical_drive_included_ken");
	attr.put("CD player","CD_player_ken");
	attr.put("MP3 playback","MP3_playback_ken");
	attr.put("Tuner type","Tuner_type_ken");
	attr.put("Radio type","Radio_type_ken");
	attr.put("Impedance","Impedance_ken");
	attr.put("Peak power","Peak_power_ken");
	attr.put("Rated power","Rated_power_ken");
	attr.put("Speaker type","Speaker_type_ken");
	attr.put("Separate components","Separate_components_ken");
	attr.put("Subwoofer included","Subwoofer_included_ken");
	attr.put("Amplifier included","Amplifier_included_ken");
	attr.put("Mounting depth","Mounting_depth_ken");
	attr.put("Continuous audio playback time","Continuous_audio_playback_time_ken");
	attr.put("Voice recording","Voice_recording_ken");
	attr.put("Player media type","Player_media_type_ken");
	attr.put("Headphones included","Headphones_included_ken");
	attr.put("Wall mountable","Wall_mountable_ken");
	attr.put("Docking connector type","Docking_connector_type_ken");
	attr.put("TV stand usage","TV_stand_usage_ken");
	attr.put("Receiver included","Receiver_included_ken");
	attr.put("Soundbar speaker RMS power","Soundbar_speaker_RMS_power_ken");
	attr.put("Radio tuner integrated","Radio_tuner_integrated_ken");
	attr.put("Karaoke modes","Karaoke_modes_ken");
	attr.put("Microphone connectivity","Microphone_connectivity_ken");
	attr.put("Number of microphones supported - max","Number_of_microphones_supported_-_max_ken");
	attr.put("Number of microphones included","Number_of_microphones_included_ken");
	attr.put("Cable length","Cable_length_ken");
	attr.put("Gender","Gender_ken");
	attr.put("Connector 1","Connector_1_ken");
	attr.put("Connector 2","Connector_2_ken");
	attr.put("Connector contacts plating","Connector_contacts_plating_ken");
	attr.put("Device interface","Device_interface_ken");
	attr.put("Headphone frequency","Headphone_frequency_ken");
	attr.put("Ear coupling","Ear_coupling_ken");
	attr.put("Wearing style","Wearing_style_ken");
	attr.put("Number of drivers","Number_of_drivers_ken");
	attr.put("Number of speakers","Number_of_speakers_ken");
	attr.put("Washing class","Washing_class_ken");
	attr.put("Drying class","Drying_class_ken");
	attr.put("Washing capacity","Washing_capacity_ken");
	attr.put("Drying capacity","Drying_capacity_ken");
	attr.put("AquaStop function","AquaStop_function_ken");
	attr.put("Delayed start timer","Delayed_start_timer_ken");
	attr.put("Anti-Crease function","Anti-Crease_function_ken");
	attr.put("Half-load","Half-load_ken");
	attr.put("Maximum spin speed","Maximum_spin_speed_ken");
	attr.put("Adjustable spin speed","Adjustable_spin_speed_ken");
	attr.put("Noise level - wash","Noise_level_-_wash_ken");
	attr.put("Noise level - drying","Noise_level_-_drying_ken");
	attr.put("Loading type","Loading_type_ken");
	attr.put("Door hinge","Door_hinge_ken");
	attr.put("Energy consumption washing per cycle","Energy_consumption_washing_per_cycle_ken");
	attr.put("Energy consumption washing & drying per cycle","Energy_consumption_washing_&_drying_per_cycle_ken");
	attr.put("3025","3025_ken");
	attr.put("Water consumption washing per cycle","Water_consumption_washing_per_cycle_ken");
	attr.put("Annual energy consumption washing","Annual_energy_consumption_washing_ken");
	attr.put("Annual water consumption washing","Annual_water_consumption_washing_ken");
	attr.put("Water consumption washing & drying per cycle","Water_consumption_washing_&_drying_per_cycle_ken");
	attr.put("8352","8352_ken");
	attr.put("Annual energy consumption washing & drying","Annual_energy_consumption_washing_&_drying_ken");
	attr.put("8354","8354_ken");
	attr.put("Annual water consumption washing & drying","Annual_water_consumption_washing_&_drying_ken");
	attr.put("8355","8355_ken");
	attr.put("Child lock","Child_lock_ken");
	attr.put("Quantity of washing programs","Quantity_of_washing_programs_ken");
	attr.put("Cycle time","Cycle_time_ken");
	attr.put("Number of places","Number_of_places_ken");
	attr.put("Dishwashing programs","Dishwashing_programs_ken");
	attr.put("Water consumption per cycle","Water_consumption_per_cycle_ken");
	attr.put("Annual water consumption","Annual_water_consumption_ken");
	attr.put("Energy consumption per cycle","Energy_consumption_per_cycle_ken");
	attr.put("Climate class","Climate_class_ken");
	attr.put("Total net capacity","Total_net_capacity_ken");
	attr.put("Water dispenser","Water_dispenser_ken");
	attr.put("Icemaker","Icemaker_ken");
	attr.put("Star rating","Star_rating_ken");
	attr.put("Freezer net capacity","Freezer_net_capacity_ken");
	attr.put("Freezing capacity","Freezing_capacity_ken");
	attr.put("Freezer number of shelves/baskets","Freezer_number_of_shelves/baskets_ken");
	attr.put("Freezer position","Freezer_position_ken");
	attr.put("Storage time during power failure","Storage_time_during_power_failure_ken");
	attr.put("No Frost - freezer","No_Frost_-_freezer_ken");
	attr.put("Fridge net capacity","Fridge_net_capacity_ken");
	attr.put("Fridge number of shelves/baskets","Fridge_number_of_shelves/baskets_ken");
	attr.put("Number of vegetable drawers","Number_of_vegetable_drawers_ken");
	attr.put("No Frost - fridge","No_Frost_-_fridge_ken");
	attr.put("Multi-Airflow system - fridge","Multi-Airflow_system_-_fridge_ken");
	attr.put("Fresh zone compartment","Fresh_zone_compartment_ken");
	attr.put("Number of ovens","Number_of_ovens_ken");
	attr.put("1st oven interior capacity","1st_oven_interior_capacity_ken");
	attr.put("Cooling capacity","Cooling_capacity_ken");
	attr.put("Cooling capacity in watts","Cooling_capacity_in_watts_ken");
	attr.put("Cooling energy efficiency - EER, W/W","Cooling_energy_efficiency_-_EER,_W/W_ken");
	attr.put("Air conditioner functions","Air_conditioner_functions_ken");
	attr.put("Connected load - electric","Connected_load_-_electric_ken");
	attr.put("Connected load - gas","Connected_load_-_gas_ken");
	attr.put("Handle length","Handle_length_ken");
	attr.put("Castor wheels","Castor_wheels_ken");
	attr.put("Colour temperature","Colour_temperature_ken");
	attr.put("Luminous flux","Luminous_flux_ken");
	attr.put("Fitting/cap type","Fitting/cap_type_ken");
	attr.put("Light colour","Light_colour_ken");
	attr.put("Bulb shape","Bulb_shape_ken");
	attr.put("Bulb lifetime","Bulb_lifetime_ken");
	attr.put("Voltage","Voltage_ken");
	attr.put("Input power","Input_power_ken");
	attr.put("Multi-tool applications","Multi-tool_applications_ken");
	attr.put("Motor type","Motor_type_ken");
	attr.put("Hose length","Hose_length_ken");
	attr.put("Special nozzle","Special_nozzle_ken");
	attr.put("Surface cleaner","Surface_cleaner_ken");
	attr.put("Rotating nozzle","Rotating_nozzle_ken");
	attr.put("Wash brush","Wash_brush_ken");
	attr.put("Battery form factor","Battery_form_factor_ken");
	attr.put("Number of batteries included","Number_of_batteries_included_ken");
	attr.put("Maximum input water temperature","Maximum_input_water_temperature_ken");
	attr.put("Flow rate - max","Flow_rate_-_max_ken");
	attr.put("Working pressure - max","Working_pressure_-_max_ken");
	attr.put("Lamps quantity","Lamps_quantity_ken");
	attr.put("Non-stick coating","Non-stick_coating_ken");
	attr.put("Lid included","Lid_included_ken");
	attr.put("Internal coating","Internal_coating_ken");
	attr.put("Number of Pieces","Number_of_Pieces_ken");
	attr.put("Size in cm","Size_in_cm_ken");
	attr.put("Other specifications","Other_specifications_ken");
	attr.put("Flashlight type","Flashlight_type_ken");
	attr.put("Carrying handle","Carrying_handle_ken");
	attr.put("School age","School_age_ken");
	attr.put("Number of compartments","Number_of_compartments_ken");
	attr.put("Recommended gender","Recommended_gender_ken");
	attr.put("Age range","Age_range_ken");
	attr.put("Built-in reflector","Built-in_reflector_ken");
	attr.put("Character","Character_ken");
	attr.put("Size in inches","Size_in_inches_ken");
	attr.put("Other features","Other_features_ken");
	attr.put("Number of sheets","Number_of_sheets_ken");
	attr.put("Cover and paper type","Cover_and_paper_type_ken");
	attr.put("Capacity in liters","Capacity_in_liters_ken");
	attr.put("Number of wheels","Number_of_wheels_ken");
	attr.put("Number of pieces inside","Number_of_pieces_inside_ken");
	attr.put("Dimensions WXDXH","Dimensions_WXDXH_ken");
	attr.put("Number of pieces","Number_of_pieces_ken");
	attr.put("Country of origin","Country_of_origin_ken");
	attr.put("USB charging port","USB_charging_port_ken");
	attr.put("Carrying case","Carrying_case_ken");
	attr.put("Interior material","Interior_material_ken");
	attr.put("Exterior finish material","Exterior_finish_material_ken");
	attr.put("Ground cloth","Ground_cloth_ken");
	attr.put("Side window","Side_window_ken");
	attr.put("Ground cloth material","Ground_cloth_material_ken");
	attr.put("Coloration","Coloration_ken");
	attr.put("Zipper type","Zipper_type_ken");
	attr.put("Portable","Portable_ken");
	attr.put("Easy to clean","Easy_to_clean_ken");
	attr.put("Number of seats","Number_of_seats_ken");
	attr.put("Table included","Table_included_ken");
	attr.put("Weatherproof","Weatherproof_ken");
	attr.put("Wicker width","Wicker_width_ken");
	attr.put("Ultraviolet resistant","Ultraviolet_resistant_ken");
	attr.put("Foldable chair","Foldable_chair_ken");
	attr.put("Foldable table","Foldable_table_ken");
	attr.put("Wicker shape","Wicker_shape_ken");
	attr.put("Sofa included","Sofa_included_ken");
	attr.put("Number of chairs included","Number_of_chairs_included_ken");
	attr.put("Built-in capability","Built-in_capability_ken");
	attr.put("Cooking surface shape","Cooking_surface_shape_ken");
	attr.put("Table width","Table_width_ken");
	attr.put("Table length","Table_length_ken");
	attr.put("Table height","Table_height_ken");
	attr.put("Chair width","Chair_width_ken");
	attr.put("Chair depth","Chair_depth_ken");
	attr.put("Chair height","Chair_height_ken");
	attr.put("Sofa width","Sofa_width_ken");
	attr.put("Sofa depth","Sofa_depth_ken");
	attr.put("Sofa height","Sofa_height_ken");
	attr.put("Smoke function","Smoke_function_ken");
	attr.put("Lid","Lid_ken");
	attr.put("Legs","Legs_ken");
	attr.put("Seat upholstery material","Seat_upholstery_material_ken");
	attr.put("Backrest upholstery material","Backrest_upholstery_material_ken");
	attr.put("Built-in air compressor","Built-in_air_compressor_ken");
	attr.put("Cables included","Cables_included_ken");
	attr.put("Beat effects","Beat_effects_ken");
	attr.put("Audio LR out","Audio_LR_out_ken");
	attr.put("External power adapter","External_power_adapter_ken");
	attr.put("Batteries included","Batteries_included_ken");
	attr.put("Minimum age","Minimum_age_ken");
	attr.put("Weight in kilo","Weight_in_kilo_ken");
	attr.put("Batteries Required","Batteries_Required_ken");
	attr.put("Scale Size","Scale_Size_ken");
	attr.put("Number of persons","Number_of_persons_ken");
	attr.put("Pool type","Pool_type_ken");
	attr.put("Inflate type","Inflate_type_ken");
	attr.put("Cover type","Cover_type_ken");
	attr.put("Set up time","Set_up_time_ken");
	attr.put("Number of persons required for set up","Number_of_persons_required_for_set_up_ken");
	attr.put("Maximum water level","Maximum_water_level_ken");
	attr.put("Inner height","Inner_height_ken");
	attr.put("Inner width","Inner_width_ken");
	attr.put("Inner diameter","Inner_diameter_ken");
	attr.put("Inner depth","Inner_depth_ken");
	attr.put("Inflatable","Inflatable_ken");
	attr.put("Filtration capacity","Filtration_capacity_ken");
	attr.put("Number of inflatable toys","Number_of_inflatable_toys_ken");
	attr.put("Frame design","Frame_design_ken");
	attr.put("Frame size","Frame_size_ken");
	attr.put("Wheel size","Wheel_size_ken");
	attr.put("Gearing type","Gearing_type_ken");
	attr.put("Chain gear type","Chain_gear_type_ken");
	attr.put("Bicycle brake control","Bicycle_brake_control_ken");
	attr.put("Brake system","Brake_system_ken");
	attr.put("Luggage rack","Luggage_rack_ken");
	attr.put("Ventilation fan","Ventilation_fan_ken");
	attr.put("Handrails","Handrails_ken");
	attr.put("Tread width","Tread_width_ken");
	attr.put("Emergency Power Off","Emergency_Power_Off_ken");
	attr.put("Bottle holder","Bottle_holder_ken");
	attr.put("Transport wheels","Transport_wheels_ken");
	attr.put("Maximum user weight","Maximum_user_weight_ken");
	attr.put("Optional heart rate measurement","Optional_heart_rate_measurement_ken");
	attr.put("Standard heart rate measurement","Standard_heart_rate_measurement_ken");
	attr.put("Number of angle positions","Number_of_angle_positions_ken");
	attr.put("Damping system","Damping_system_ken");
	attr.put("Training displayed parameters","Training_displayed_parameters_ken");
	attr.put("Training programs","Training_programs_ken");
	attr.put("Quick start","Quick_start_ken");
	attr.put("Manual settings","Manual_settings_ken");
	attr.put("Cooldown function","Cooldown_function_ken");
	attr.put("Maximum speed","Maximum_speed_ken");
	attr.put("Tread length","Tread_length_ken");
	attr.put("BMI measuring","BMI_measuring_ken");
	attr.put("Dimensions - WxDxH","Dimensions_-_WxDxH_ken");
	attr.put("Number of pages","Number_of_pages_ken");
	attr.put("Written by","Written_by_ken");
	attr.put("Publisher","Publisher_ken");
	attr.put("Dust jacket","Dust_jacket_ken");
	attr.put("Graphic display included","Graphic_display_included_ken");
	attr.put("Bundled software","Bundled_software_ken");
	attr.put("Non-slip surface","Non-slip_surface_ken");
	attr.put("Ergometer","Ergometer_ken");
	attr.put("Number of resistors","Number_of_resistors_ken");
	attr.put("Drive system","Drive_system_ken");
	attr.put("Saddle adjustment","Saddle_adjustment_ken");
	attr.put("Compatible wheel size - max","Compatible_wheel_size_-_max_ken");
	attr.put("Compatible wheel size - min","Compatible_wheel_size_-_min_ken");
	attr.put("Realistic slope","Realistic_slope_ken");
	attr.put("Flywheel weight","Flywheel_weight_ken");
	attr.put("Sprint power - 1 minute","Sprint_power_-_1_minute_ken");
	attr.put("Shoulder strap","Shoulder_strap_ken");
	attr.put("Volume","Volume_ken");
	attr.put("Pockets quantity","Pockets_quantity_ken");
	attr.put("Pen loop","Pen_loop_ken");
	attr.put("Adjustable strap","Adjustable_strap_ken");
	attr.put("Interior dimensions - W x D x H","Interior_dimensions_-_W_x_D_x_H_ken");
	attr.put("Maximum strap length","Maximum_strap_length_ken");
	attr.put("Minimum strap length","Minimum_strap_length_ken");
	attr.put("Size","Size_ken");
	attr.put("No of items in 1 pack","No_of_items_in_1_pack_ken");
	attr.put("Sole Material","Sole_Material_ken");
	attr.put("Outsole material","Outsole_material_ken");
	attr.put("Lining material","Lining_material_ken");
	attr.put("Fabric Weight g-m2","Fabric_Weight_g-m2_ken");
	attr.put("Grade","Grade_ken");
	attr.put("Mattress size","Mattress_size_ken");
	attr.put("Density","Density_ken");
	attr.put("Standart Unit Size","Standart_Unit_Size_ken");
	attr.put("Comfort Level","Comfort_Level_ken");
	attr.put("Primary Material","Primary_Material_ken");
	attr.put("Filling Material","Filling_Material_ken");
	attr.put("Care Instruction","Care_Instruction_ken");
	attr.put("Package Msm and Weight","Package_Msm_and_Weight_ken");
	attr.put("Dimensions LxWxT","Dimensions_LxWxT_ken");
	attr.put("Weight","Weight_ken");
	attr.put("Rotary wheel","Rotary_wheel_ken");
	attr.put("Number of bags","Number_of_bags_ken");
	attr.put("Locking","Locking_ken");
	attr.put("Exterior pockets","Exterior_pockets_ken");
	attr.put("Bag size","Bag_size_ken");
	attr.put("Standard Unit Size","Standard_Unit_Size_ken");
	attr.put("Dimensions - LxWxT","Dimensions_-_LxWxT_ken");
	attr.put("Filler material","Filler_material_ken");
	attr.put("Recommended age  - min","Recommended_age__-_min_ken");
	attr.put("Size - European","Size_-_European_ken");
	attr.put("Age - min","Age_-_min_ken");
	attr.put("Age - max","Age_-_max_ken");
	attr.put("Canopy","Canopy_ken");
	attr.put("Belt fastening type","Belt_fastening_type_ken");
	attr.put("Car seat group","Car_seat_group_ken");
	attr.put("Adjustable tray","Adjustable_tray_ken");
	attr.put("Footrest","Footrest_ken");
	attr.put("Adjustable backrest","Adjustable_backrest_ken");
	attr.put("Age Group","Age_Group_ken");
	attr.put("Canopy/Seat/Fabric Material","Canopy/Seat/Fabric_Material_ken");
	attr.put("Safety Harness Point","Safety_Harness_Point_ken");
	attr.put("Frame Material","Frame_Material_ken");
	attr.put("Wheel Lock","Wheel_Lock_ken");
	attr.put("Swivel Mechanism","Swivel_Mechanism_ken");
	attr.put("Maximum Weight Child","Maximum_Weight_Child_ken");
	attr.put("Safety compliance","Safety_compliance_ken");
	attr.put("Guarantee","Guarantee_ken");
	attr.put("Battery required","Battery_required_ken");
	attr.put("Type of Battery","Type_of_Battery_ken");
	attr.put("Additional Information and Benefits","Additional_Information_and_Benefits_ken");
	attr.put("Product Dimensions LxWxT","Product_Dimensions_LxWxT_ken");
	attr.put("Product Weight","Product_Weight_ken");
	attr.put("Packaging Dimensions LxWxT","Packaging_Dimensions_LxWxT_ken");
	attr.put("Packaging Weight","Packaging_Weight_ken");
	attr.put("Surface coloration","Surface_coloration_ken");
	attr.put("Zipper closure","Zipper_closure_ken");
	attr.put("Zipper length","Zipper_length_ken");
	attr.put("Fabric Weight g/m2","Fabric_Weight_g/m2_ken");
	attr.put("Best uses","Best_uses_ken");
	attr.put("Target audience","Target_audience_ken");
	attr.put("Belt material","Belt_material_ken");
	attr.put("Removable buckle","Removable_buckle_ken");
	attr.put("Hidden pocket","Hidden_pocket_ken");
	attr.put("Belt colour","Belt_colour_ken");
	attr.put("Table top material","Table_top_material_ken");
	attr.put("Seat type","Seat_type_ken");
	attr.put("Armrest","Armrest_ken");
	attr.put("Seat material","Seat_material_ken");
	attr.put("Maximum seat load","Maximum_seat_load_ken");
	attr.put("Maximum table load","Maximum_table_load_ken");
	attr.put("Seat width","Seat_width_ken");
	attr.put("Seat depth","Seat_depth_ken");
	attr.put("Seat height","Seat_height_ken");
	attr.put("Backrest height","Backrest_height_ken");
	attr.put("Seating furniture width","Seating_furniture_width_ken");
	attr.put("Seating furniture depth","Seating_furniture_depth_ken");
	attr.put("Seating furniture height","Seating_furniture_height_ken");
	attr.put("Seating furniture weight","Seating_furniture_weight_ken");
	attr.put("Antenna type","Antenna_type_ken");
	attr.put("Networking standards","Networking_standards_ken");
	attr.put("Ethernet LAN interface type","Ethernet_LAN_interface_type_ken");
	attr.put("DSL WAN","DSL_WAN_ken");
	attr.put("Ethernet WAN","Ethernet_WAN_ken");
	attr.put("SIM card slot","SIM_card_slot_ken");
	attr.put("3G/4G USB modem compatibility","3G/4G_USB_modem_compatibility_ken");
	attr.put("WLAN data transfer rate - max","WLAN_data_transfer_rate_-_max_ken");
	attr.put("Wi-Fi standard","Wi-Fi_standard_ken");
	attr.put("Keyboard layout","Keyboard_layout_ken");
	attr.put("Keyboard language","Keyboard_language_ken");
	attr.put("Keyboard form factor","Keyboard_form_factor_ken");
	attr.put("Keyboard integrated devices","Keyboard_integrated_devices_ken");
	attr.put("Keyboard style","Keyboard_style_ken");
	attr.put("Scroll type","Scroll_type_ken");
	attr.put("Buttons type","Buttons_type_ken");
	attr.put("Satellite speaker type","Satellite_speaker_type_ken");
	attr.put("Amplification device included","Amplification_device_included_ken");
	attr.put("Headset type","Headset_type_ken");
	attr.put("Smell of","Smell_of_ken");
	attr.put("Form","Form_ken");
	attr.put("Diapers Size","Diapers_Size_ken");
	attr.put("Sub Type","Sub_Type_ken");
	attr.put("For Swimming","For_Swimming_ken");
	attr.put("Number of Tissues","Number_of_Tissues_ken");
	attr.put("Tissues Type","Tissues_Type_ken");
	attr.put("Skin Type","Skin_Type_ken");
	attr.put("Roll","Roll_ken");
	attr.put("Number of Tissues Layer","Number_of_Tissues_Layer_ken");
	attr.put("Daily Pads","Daily_Pads_ken");
	attr.put("Monthly Pad","Monthly_Pad_ken");
	attr.put("Cleaner Type","Cleaner_Type_ken");
	attr.put("Length Of Roll","Length_Of_Roll_ken");
	attr.put("Color","Color_ken");
	attr.put("Detergent Type","Detergent_Type_ken");
	attr.put("Washing Cycle Type","Washing_Cycle_Type_ken");
	attr.put("Number Of Pieces","Number_Of_Pieces_ken");
	attr.put("Smell Of","Smell_Of_ken");
	attr.put("Type Of Product","Type_Of_Product_ken");
	attr.put("Size in KG","Size_in_KG_ken");
	attr.put("Culotte","Culotte_ken");
	attr.put("Wipe Usage","Wipe_Usage_ken");
	attr.put("Product Material","Product_Material_ken");
	attr.put("Flavour","Flavour_ken");
	attr.put("Pack of","Pack_of_ken");
	attr.put("Per100PortionType","Per100PortionType_ken");
	attr.put("Per100Energyinkcal","Per100Energyinkcal_ken");
	attr.put("Per100EnergyinkJ","Per100EnergyinkJ_ken");
	attr.put("Per100Protein","Per100Protein_ken");
	attr.put("Per100Carbohydrates","Per100Carbohydrates_ken");
	attr.put("Per100Sugar","Per100Sugar_ken");
	attr.put("Per100Fat","Per100Fat_ken");
	attr.put("Per100Fibre","Per100Fibre_ken");
	attr.put("Per100Sodium","Per100Sodium_ken");
	attr.put("Salt","Salt_ken");
	attr.put("Nutrition","Nutrition_ken");
	attr.put("cooking Guidelines","cooking_Guidelines_ken");
	attr.put("Additives","Additives_ken");
	attr.put("Category","Category_ken");

	return attr;

}


if(autoIncrement && totalNumberOfPages > 1){
	cronjob.setLastDocumentNumber((currentPage+1).toString());
}
cronjob.setNumberOfRetries((cronjob.getNumberOfRetries()+1));
modelService.save(cronjob);