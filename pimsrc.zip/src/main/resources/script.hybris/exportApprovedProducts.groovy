import com.maf.core.model.cronjob.*
import com.maf.core.model.cronjob.*
import com.maf.facades.azure.data.*
import de.hybris.platform.catalog.model.CatalogVersionModel
import de.hybris.platform.commercefacades.product.data.ProductData
import de.hybris.platform.core.*
import de.hybris.platform.core.model.product.ProductModel
import de.hybris.platform.core.servicelayer.data.SearchPageData
import de.hybris.platform.cronjob.enums.CronJobResult
import de.hybris.platform.cronjob.enums.CronJobStatus
import de.hybris.platform.servicelayer.cronjob.PerformResult
import de.hybris.platform.servicelayer.search.FlexibleSearchQuery
import de.hybris.platform.servicelayer.search.paginated.PaginatedFlexibleSearchParameter
import de.hybris.platform.servicelayer.search.paginated.util.PaginatedSearchUtils

final String storeId = cronjob.getBaseStore().getUid();
final String catalogId = storeId + 'ProductCatalog';
println '';
println 'catalogId ' + catalogId;
final CatalogVersionModel catalogVersion = catalogVersionService.getCatalogVersion(catalogId, 'Online');

int currentPage = Integer.parseInt(cronjob.getLastDocumentNumber());
int pageSize = 10000;
boolean autoIncrement = cronjob.getUseCommissionInvoiceCyclePeriod();

final String PRODUCTS_QUERY = "SELECT distinct({p.pk}) FROM {Product AS p} WHERE {catalogVersion}=8796093153881 and {approvalStatus} = 8796099674203 and ({marketplaceproduct} = 0 or {marketplaceproduct} is null) ORDER BY {pk}";
final FlexibleSearchQuery searchQuery = new FlexibleSearchQuery(PRODUCTS_QUERY);
searchQuery.addQueryParameter('catalogVersion', catalogVersion);

PaginatedFlexibleSearchParameter parameter = new PaginatedFlexibleSearchParameter();
SearchPageData searchPageData = PaginatedSearchUtils.createSearchPageDataWithPagination(pageSize, currentPage, true);
parameter.setFlexibleSearchQuery(searchQuery);
parameter.setSearchPageData(searchPageData);
SearchPageData<ProductModel> searchResult = paginatedFlexibleSearchService.search(parameter);

int totalNumberOfPages = searchResult.getPagination().getNumberOfPages();
int totalNumberOfResults = searchResult.getPagination().getTotalNumberOfResults();
int size = searchResult.getResults().size();

println 'currentPage = ' + currentPage;
println 'pageSize = ' + pageSize;
println 'totalNumberOfPages = ' + totalNumberOfPages;
println 'totalNumberOfResults = ' + totalNumberOfResults;
println 'resultSize = ' + size;

final Collection<ProductModel> products = searchResult.getResults();

if (size > 0 && currentPage <= totalNumberOfPages) {

    MafExportCronjobModel job = (MafExportCronjobModel) modelService.get(PK.fromLong(11414977151477))
    MafAzureProductData data = mafExportProductService.feedSetUpData(job.getCode(), job.getLastExportTime());

    List<ProductData> results = new ArrayList<>();
    for (final ProductModel product : products) {
        ProductData productData = mafExportProductService.getProductData(data, "mafuae-mafFullExportProductServiceCronjob", product)
        results.add(productData);
    }
    mafExportProductService.syncProducts(results, data);
} else {
    println '**********LIMIT REACHED*********'
    cronjob.setActive(false);
    modelService.save(cronjob)
    new PerformResult(CronJobResult.UNKNOWN, CronJobStatus.PAUSED)
}


if (autoIncrement) {
    cronjob.setLastDocumentNumber((currentPage + 1).toString());
}
modelService.save(cronjob);