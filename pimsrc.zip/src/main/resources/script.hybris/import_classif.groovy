import com.maf.core.model.*
import com.microsoft.azure.storage.CloudStorageAccount
import com.microsoft.azure.storage.blob.*
import com.microsoft.azure.storage.blob.CloudBlobClient
import com.microsoft.azure.storage.blob.CloudBlobContainer
import com.mirakl.hybris.beans.ProductImportFileContextData
import de.hybris.platform.catalog.model.CatalogVersionModel
import de.hybris.platform.catalog.model.classification.*
import de.hybris.platform.core.model.product.ProductModel
import org.apache.commons.csv.CSVFormat
import org.apache.commons.csv.CSVParser
import org.apache.commons.csv.CSVRecord
import org.apache.commons.lang3.StringUtils
import org.apache.commons.lang3.tuple.Triple

import java.time.LocalDate
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.time.format.DateTimeParseException

final String storeId = cronjob.getBaseStore().getUid();;
final String country = storeId.replace('maf', '').toUpperCase();
final String catalogId = storeId + 'ProductCatalog';
final String headerCode = storeId.replace('maf', '');
println '';
println 'catalogId ' + catalogId;
final CatalogVersionModel catalogVersion = catalogVersionService.getCatalogVersion(catalogId, 'Staged');


Map<CloudBlob, File> files = downloadFiles(country);

for (Map.Entry<CloudBlob, File> inputFile : files.entrySet()) {


    try (BufferedReader reader = new BufferedReader(new FileReader(inputFile.getValue()))) {

        // Populating file context
        ProductImportFileContextData context = new ProductImportFileContextData();
        context.setDelimiter("|");
        context.setShopId("2249");
        reader.readLine();

        // Fetching file headers
        String headerLine = reader.readLine();
        String[] header = headerLine.split("\\|");
        String headerCodeLine = reader.readLine();
        String[] headerCodes = headerCodeLine.split("\\|");

        // Replace the constant with a space in each string
        for (int i = 0; i < headerCodes.length; i++) {
            headerCodes[i] = headerCodes[i].replace("_", " ").replace(headerCode, "");
        }


        char delimiter = '|';
        char quote = '"';
        CSVFormat format = CSVFormat.DEFAULT.withDelimiter(delimiter).withQuote(quote);

        String line;
        while ((line = reader.readLine()) != null) {
            // Reading input file
            CSVParser csvParser = CSVParser.parse(line, format);
            for (CSVRecord record : csvParser) {
                String[] values = new String[record.size()];
                for (int i = 0; i < record.size(); i++) {
                    values[i] = record.get(i);
                }
                Map<String, String> productValues = convertToMap(header, values);
                Map<String, String> productCodeValues = convertToMap(headerCodes, values);

                ProductModel productModel = productService.getProductForCode(catalogVersion, productValues.get("Code"));
                if (productModel != null){
                    Triple<ProductImportFileContextData, Boolean, Map<String, String>> source = Triple.of(context, Boolean.TRUE, productCodeValues);

                    try{
                        mktClassificationAttributesPopulator.populate(source, productModel);
                    }catch (Exception ex){
                        println "Failed to load classification " + ex.printStackTrace();
                    }
                    //update fixed column values
                    updateFixedAttributes(productValues, productModel);

                    modelService.save(productModel)
                }
            }
        }
        deleteBlob(inputFile.getKey());
    } catch (Exception e) {
        println e.printStackTrace();
    }
    inputFile.getValue().deleteOnExit();

}

private void deleteBlob(CloudBlob blob) {
    try {
        println "Deleting ${blob.getName()}"
        blob.deleteIfExists()
    } catch (Exception e) {
        println "Error deleting blob: ${e.message}"
    }
}


public String parseString(String attributeValue) {
    return "DELETE".equalsIgnoreCase(attributeValue) ? null : attributeValue;
}

private void updateFixedAttributes(HashMap<String, String> attributesRowValues, ProductModel product) {

    //EN Online name
    String attributeValue = attributesRowValues.remove("Online Name [en]");
    if (StringUtils.isNotBlank(attributeValue)) {
        String s = parseString(attributeValue);
        if(s==null) {
            product.setOnlineName(null);
        }else {
            product.setOnlineName(attributeValue, Locale.forLanguageTag("en"));
        }
    }

    //AR Online name
    attributeValue = attributesRowValues.remove("Online Name [ar]");
    if (StringUtils.isNotBlank(attributeValue)) {
        String s = parseString(attributeValue);
        if(s==null) {
            product.setOnlineName(null, Locale.forLanguageTag("ar"));
        }else {
            product.setOnlineName(attributeValue, Locale.forLanguageTag("ar"));
        }
    }

    //En Description
    attributeValue = attributesRowValues.remove("Description [en]");
    if (StringUtils.isNotBlank(attributeValue)) {
        String s = parseString(attributeValue);
        if(s==null) {
            product.setDescription(null);
        }else {
            product.setDescription(attributeValue, Locale.forLanguageTag("en"));
        }
    }

    //Ar Description
    attributeValue = attributesRowValues.remove("Description [ar]");
    if (StringUtils.isNotBlank(attributeValue)) {
        String s = parseString(attributeValue);
        if(s==null) {
            product.setDescription(null, Locale.forLanguageTag("ar"));
        }else {
            product.setDescription(attributeValue, Locale.forLanguageTag("ar"));
        }
    }

    //En Marketing Text
    attributeValue = attributesRowValues.remove("Marketing Text [en]");
    if (StringUtils.isNotBlank(attributeValue)) {
        String s = parseString(attributeValue);
        if(s==null) {
            product.setMarketingText(null);
        }else {
            product.setMarketingText(attributeValue, Locale.forLanguageTag("en"));
        }
    }

    //Ar Marketing Text
    attributeValue = attributesRowValues.remove("Marketing Text [ar]");
    if (StringUtils.isNotBlank(attributeValue)) {
        String s = parseString(attributeValue);
        if(s==null) {
            product.setMarketingText(null, Locale.forLanguageTag("ar"));
        }else {
            product.setMarketingText(attributeValue, Locale.forLanguageTag("ar"));
        }
    }

    //Tips And Videos
    attributeValue = attributesRowValues.remove("Tips And Videos");
    if (StringUtils.isNotBlank(attributeValue)) {
        String s = parseString(attributeValue);
        if(s==null) {
            product.setTipsAndVideos(null);
        }else {
            product.setTipsAndVideos(attributeValue);
        }
    }

    //En Product Color
    attributeValue = attributesRowValues.remove("Product Color [en]");
    if (StringUtils.isNotBlank(attributeValue)) {
        String s = parseString(attributeValue);
        if(s==null) {
            product.setProductColor(null);
        }else {
            product.setProductColor(attributeValue, Locale.forLanguageTag("en"));
        }
    }

    //Ar Product Color
    attributeValue = attributesRowValues.remove("Product Color [ar]");
    if (StringUtils.isNotBlank(attributeValue)) {
        String s = parseString(attributeValue);
        if(s==null) {
            product.setProductColor(null, Locale.forLanguageTag("ar"));
        }else {
            product.setProductColor(attributeValue, Locale.forLanguageTag("ar"));
        }
    }

    //En Size
    attributeValue = attributesRowValues.remove("Product Size [en]");
    if (StringUtils.isNotBlank(attributeValue) && product instanceof FoodProductModel) {
        FoodProductModel foodProductModel = (FoodProductModel) product;
        String s = parseString(attributeValue);
        if(s==null) {
            foodProductModel.setSize(null);
        }else {
            foodProductModel.setSize(attributeValue, Locale.forLanguageTag("en"));
        }
    }

    //Ar Size
    attributeValue = attributesRowValues.remove("Product Size [ar]");
    if (StringUtils.isNotBlank(attributeValue) && product instanceof FoodProductModel) {
        FoodProductModel foodProductModel = (FoodProductModel) product;
        String s = parseString(attributeValue);
        if(s==null) {
            foodProductModel.setSize(null, Locale.forLanguageTag("ar"));
        }else {
            foodProductModel.setSize(attributeValue, Locale.forLanguageTag("ar"));
        }
    }

    //En preorderDescription
    attributeValue = attributesRowValues.remove("Pre Order Description [en]");
    if (StringUtils.isNotBlank(attributeValue) && product instanceof NonFoodProductModel) {
        NonFoodProductModel nonFoodProductModel = (NonFoodProductModel) product;
        String s = parseString(attributeValue);
        if(s==null) {
            nonFoodProductModel.setPreorderDescription(null);
        }else {
            nonFoodProductModel.setPreorderDescription(attributeValue);
        }
    }

    //En Country Origin
    attributeValue = attributesRowValues.remove("Country Origin [en]");
    if (StringUtils.isNotBlank(attributeValue) && product instanceof FoodProductModel) {
        FoodProductModel foodProductModel = (FoodProductModel) product;
        String s = parseString(attributeValue);
        if(s==null) {
            foodProductModel.setCountryOrigin(null);
        }else {
            foodProductModel.setCountryOrigin(attributeValue, Locale.forLanguageTag("en"));
        }
    }


    //Ar Country Origin
    attributeValue = attributesRowValues.remove("Country Origin [ar]");
    if (StringUtils.isNotBlank(attributeValue) && product instanceof FoodProductModel) {
        FoodProductModel foodProductModel = (FoodProductModel) product;
        String s = parseString(attributeValue);
        if(s==null) {
            foodProductModel.setCountryOrigin(null, Locale.forLanguageTag("ar"));
        }else {
            foodProductModel.setCountryOrigin(attributeValue, Locale.forLanguageTag("ar"));
        }
    }

    //Bulk Message [en]
    attributeValue = attributesRowValues.remove("Bulk Message [en]");
    if (StringUtils.isNotBlank(attributeValue)) {
        String s = parseString(attributeValue);
        if(s==null) {
            product.setBulkMessage(null);
        }else {
            product.setBulkMessage(s, Locale.forLanguageTag("en"));
        }
    }

    //Bulk Message [ar]
    attributeValue = attributesRowValues.remove("Bulk Message [ar]");
    if (StringUtils.isNotBlank(attributeValue)) {
        String s = parseString(attributeValue);
        if(s==null) {
            product.setBulkMessage(null, Locale.forLanguageTag("ar"));
        }else {
            product.setBulkMessage(s, Locale.forLanguageTag("ar"));
        }
    }

    //Minimum Weight To Order
    attributeValue = attributesRowValues.remove("Minimum Weight To Order");
    if (StringUtils.isNotBlank(attributeValue) && product instanceof FoodProductModel) {
        FoodProductModel foodProductModel = (FoodProductModel) product;
        String s = parseString(attributeValue);
        if(s==null) {
            foodProductModel.setMinimumWeightToOrder(null);
        }else if (parseDouble(s) != null){
            foodProductModel.setMinimumWeightToOrder(parseDouble(s));
        }
    }

    //Minimum Weight To Order
    attributeValue = attributesRowValues.remove("Max To Order");
    if (StringUtils.isNotBlank(attributeValue)) {
        String s = parseString(attributeValue);
        if(s==null) {
            product.setMaxToOrder(null);
        }else if (parseInteger(s) != null){
            product.setMaxToOrder(parseInteger(s));
        }
    }

    //Minimum Weight To Order
    attributeValue = attributesRowValues.remove("Weight Increment");
    if (StringUtils.isNotBlank(attributeValue) && product instanceof FoodProductModel) {
        FoodProductModel foodProductModel = (FoodProductModel) product;
        String s = parseString(attributeValue);
        if(s==null) {
            foodProductModel.setWeightIncrement(null);
        }else if (parseDouble(s) != null){
            foodProductModel.setWeightIncrement(parseDouble(s));
        }
    }

    //Minimum Weight To Order
    attributeValue = attributesRowValues.remove("Average Weight By Piece");
    if (StringUtils.isNotBlank(attributeValue) && product instanceof FoodProductModel) {
        FoodProductModel foodProductModel = (FoodProductModel) product;
        String s = parseString(attributeValue);
        if(s==null) {
            foodProductModel.setAverageWeightByPiece(null);
        }else if (parseDouble(s) != null){
            foodProductModel.setAverageWeightByPiece(parseDouble(s));
        }
    }

    //Weight Variation
    attributeValue = attributesRowValues.remove("Weight Variation");
    if (StringUtils.isNotBlank(attributeValue) && product instanceof FoodProductModel) {
        FoodProductModel foodProductModel = (FoodProductModel) product;
        String s = parseString(attributeValue);
        if(s==null) {
            foodProductModel.setWeightVariation(null);
        }else if (parseDouble(s) != null){
            foodProductModel.setWeightVariation(parseDouble(s));
        }
    }

    //Min Order Quantity
    attributeValue = attributesRowValues.remove("Min Order Quantity");
    if (StringUtils.isNotBlank(attributeValue)) {
        String s = parseString(attributeValue);
        if(s==null) {
            product.setMinOrderQuantity(null);
        }else if (parseInteger(s) != null){
            product.setMinOrderQuantity(parseInteger(s));
        }
    }

    //Express
    attributeValue = attributesRowValues.remove("Express");
    if (StringUtils.isNotBlank(attributeValue)) {
        String s = parseString(attributeValue);
        if(s==null) {
            product.setIsExpressProduct(false);
        }else if (parseBoolean(s) != null){
            product.setIsExpressProduct(parseBoolean(s));
        }
    }

    //Pre Order
    attributeValue = attributesRowValues.remove("Pre Order");
    if (StringUtils.isNotBlank(attributeValue) && product instanceof NonFoodProductModel) {
        NonFoodProductModel nonFoodProductModel = (NonFoodProductModel) product;
        String s = parseString(attributeValue);
        if(s==null) {
            nonFoodProductModel.setPreorder(false);
        }else if (parseBoolean(s) != null){
            nonFoodProductModel.setPreorder(parseBoolean(s));
        }
    }

    //Pre Order
    attributeValue = attributesRowValues.remove("Pre Order Date");
    if (StringUtils.isNotBlank(attributeValue) && product instanceof NonFoodProductModel) {
        NonFoodProductModel nonFoodProductModel = (NonFoodProductModel) product;
        String s = parseString(attributeValue);
        if(s==null) {
            nonFoodProductModel.setPreOrderDeliveryTime(null);
        }else if (parseDate(s) != null){
            nonFoodProductModel.setPreOrderDeliveryTime(parseDate(s));
        }
    }

    //Pre Order Delivery Time
    attributeValue = attributesRowValues.remove("Pre Order Delivery Time");
    if (StringUtils.isNotBlank(attributeValue)) {
        String s = parseString(attributeValue);
        if(s==null) {
            product.setDeliveryTime(null);
        }else if (parseDouble(s) != null){
            product.setDeliveryTime(parseDouble(s));
        }
    }

    //Minimum Weight To Order
    attributeValue = attributesRowValues.remove("Num of Points");
    if (StringUtils.isNotBlank(attributeValue)) {
        String s = parseString(attributeValue);
        if(s==null) {
            product.setNumberOfPoints(null);
        }else if (parseInteger(s) != null){
            product.setNumberOfPoints(parseInteger(s));
        }
    }

    //Loyalty Point Start Date
    attributeValue = attributesRowValues.remove("Loyalty Point Start Date");
    if (StringUtils.isNotBlank(attributeValue)) {
        String s = parseString(attributeValue);
        if(s==null) {
            product.setStartDate(null);
        }else if (parseDate(s) != null){
            product.setStartDate(parseDate(s));
        }
    }

    //Loyalty Point End Date
    attributeValue = attributesRowValues.remove("Loyalty Point End Date");
    if (StringUtils.isNotBlank(attributeValue)) {
        String s = parseString(attributeValue);
        if(s==null) {
            product.setEndDate(null);
        }else if (parseDate(s) != null){
            product.setEndDate(parseDate(s));
        }
    }

    //Free Installation
    attributeValue = attributesRowValues.remove("Free Installation");
    if (StringUtils.isNotBlank(attributeValue) && product instanceof NonFoodProductModel) {
        NonFoodProductModel nonFoodProductModel = (NonFoodProductModel) product;
        String s = parseString(attributeValue);
        if(s==null) {
            nonFoodProductModel.setFreeInstallation(false);
        }else if (parseBoolean(s) != null){
            nonFoodProductModel.setFreeInstallation(parseBoolean(s));
        }
    }

    //Allergy Advice [en]
    attributeValue = attributesRowValues.remove("Allergy Advice [en]");
    if (StringUtils.isNotBlank(attributeValue) && product instanceof FoodProductModel) {
        FoodProductModel foodProductModel = (FoodProductModel) product;
        String s = parseString(attributeValue);
        if(s==null) {
            foodProductModel.setAllergyAdvice(null);
        }else {
            foodProductModel.setAllergyAdvice(attributeValue, Locale.forLanguageTag("en"));
        }
    }

    //Allergy Advice [ar]
    attributeValue = attributesRowValues.remove("Allergy Advice [ar]");
    if (StringUtils.isNotBlank(attributeValue) && product instanceof FoodProductModel) {
        FoodProductModel foodProductModel = (FoodProductModel) product;
        String s = parseString(attributeValue);
        if(s==null) {
            foodProductModel.setAllergyAdvice(null, Locale.forLanguageTag("ar"));
        }else {
            foodProductModel.setAllergyAdvice(attributeValue, Locale.forLanguageTag("ar"));
        }
    }

    //Ingredients [en]
    attributeValue = attributesRowValues.remove("Ingredients [en]");
    if (StringUtils.isNotBlank(attributeValue) && product instanceof FoodProductModel) {
        FoodProductModel foodProductModel = (FoodProductModel) product;
        String s = parseString(attributeValue);
        if(s==null) {
            foodProductModel.setIngredients(null);
        }else {
            foodProductModel.setIngredients(attributeValue, Locale.forLanguageTag("en"));
        }
    }

    //Ingredients [ar]
    attributeValue = attributesRowValues.remove("Ingredients [ar]");
    if (StringUtils.isNotBlank(attributeValue) && product instanceof FoodProductModel) {
        FoodProductModel foodProductModel = (FoodProductModel) product;
        String s = parseString(attributeValue);
        if(s==null) {
            foodProductModel.setIngredients(null, Locale.forLanguageTag("ar"));
        }else {
            foodProductModel.setIngredients(attributeValue, Locale.forLanguageTag("ar"));
        }
    }


    //Preparation and Usage [en]
    attributeValue = attributesRowValues.remove("Preparation and Usage [en]");
    if (StringUtils.isNotBlank(attributeValue) && product instanceof FoodProductModel) {
        FoodProductModel foodProductModel = (FoodProductModel) product;
        String s = parseString(attributeValue);
        if(s==null) {
            foodProductModel.setPreparationAndUSage(null);
        }else {
            foodProductModel.setPreparationAndUSage(attributeValue, Locale.forLanguageTag("en"));
        }
    }

    //Preparation and Usage [ar]
    attributeValue = attributesRowValues.remove("Preparation and Usage [ar]");
    if (StringUtils.isNotBlank(attributeValue) && product instanceof FoodProductModel) {
        FoodProductModel foodProductModel = (FoodProductModel) product;
        String s = parseString(attributeValue);
        if(s==null) {
            foodProductModel.setPreparationAndUSage(null, Locale.forLanguageTag("ar"));
        }else {
            foodProductModel.setPreparationAndUSage(attributeValue, Locale.forLanguageTag("ar"));
        }
    }

    //Storage Condition [en]
    attributeValue = attributesRowValues.remove("Storage Condition [en]");
    if (StringUtils.isNotBlank(attributeValue) && product instanceof FoodProductModel) {
        FoodProductModel foodProductModel = (FoodProductModel) product;
        String s = parseString(attributeValue);
        if(s==null) {
            foodProductModel.setStorageConditions(null);
        }else {
            foodProductModel.setStorageConditions(attributeValue, Locale.forLanguageTag("en"));
        }
    }

    //Storage Condition [ar]
    attributeValue = attributesRowValues.remove("Storage Condition [ar]");
    if (StringUtils.isNotBlank(attributeValue) && product instanceof FoodProductModel) {
        FoodProductModel foodProductModel = (FoodProductModel) product;
        String s = parseString(attributeValue);
        if(s==null) {
            foodProductModel.setStorageConditions(null, Locale.forLanguageTag("ar"));
        }else {
            foodProductModel.setStorageConditions(attributeValue, Locale.forLanguageTag("ar"));
        }
    }

    //Brand Marketing Message [en]
    attributeValue = attributesRowValues.remove("Brand Marketing Message [en]");
    if (StringUtils.isNotBlank(attributeValue) && product instanceof FoodProductModel) {
        FoodProductModel foodProductModel = (FoodProductModel) product;
        String s = parseString(attributeValue);
        if(s==null) {
            foodProductModel.setBrandMarketingMessage(null);
        }else {
            foodProductModel.setBrandMarketingMessage(attributeValue, Locale.forLanguageTag("en"));
        }
    }

    //Brand Marketing Message [ar]
    attributeValue = attributesRowValues.remove("Brand Marketing Message [ar]");
    if (StringUtils.isNotBlank(attributeValue) && product instanceof FoodProductModel) {
        FoodProductModel foodProductModel = (FoodProductModel) product;
        String s = parseString(attributeValue);
        if(s==null) {
            foodProductModel.setBrandMarketingMessage(null, Locale.forLanguageTag("ar"));
        }else {
            foodProductModel.setBrandMarketingMessage(attributeValue, Locale.forLanguageTag("ar"));
        }
    }

    //Safety Warnings [en]
    attributeValue = attributesRowValues.remove("Safety Warnings [en]");
    if (StringUtils.isNotBlank(attributeValue) && product instanceof FoodProductModel) {
        FoodProductModel foodProductModel = (FoodProductModel) product;
        String s = parseString(attributeValue);
        if(s==null) {
            foodProductModel.setSafetyWarnings(null);
        }else {
            foodProductModel.setSafetyWarnings(attributeValue, Locale.forLanguageTag("en"));
        }
    }

    //Safety Warnings [ar]
    attributeValue = attributesRowValues.remove("Safety Warnings [ar]");
    if (StringUtils.isNotBlank(attributeValue) && product instanceof FoodProductModel) {
        FoodProductModel foodProductModel = (FoodProductModel) product;
        String s = parseString(attributeValue);
        if(s==null) {
            foodProductModel.setSafetyWarnings(null, Locale.forLanguageTag("ar"));
        }else {
            foodProductModel.setSafetyWarnings(attributeValue, Locale.forLanguageTag("ar"));
        }
    }

}

Date parseDate(String value) {
    if (StringUtils.isNotBlank(value)) {
        try {
            return Date.from(LocalDate.parse(
                    value, DateTimeFormatter.ofPattern("MM-dd-yyyy")
            ).atStartOfDay(ZoneId.of("UTC")).toInstant());
        } catch (DateTimeParseException e){
            println e;
        }
    }
    return null;
}

 Boolean parseBoolean(String value) {
    Boolean result = null;
    if (StringUtils.isNotBlank(value)) {
        if (List.of("YES","TRUE","true", "yes", "Y","y", "1").contains(value)) {
            return Boolean.TRUE;
        } else if (List.of("FALSE","false","NO", "no", "N","n", "0").contains(value)) {
            return Boolean.FALSE;
        }
    }
    return result;
}

public Integer parseInteger(String value) {
    if (StringUtils.isNotBlank(value)) {
        try {
            return Integer.parseInt(value);
        } catch (NumberFormatException e) {
          println e;
        }
    }
    return null;
}

public Double parseDouble(String value) {
    if (StringUtils.isNotBlank(value)) {
        try {
            return Double.parseDouble(value);
        } catch (NumberFormatException e) {
            println e;
        }
    }
    return null;
}

// Utility method to convert array of headers and values to a Map
private static Map<String, String> convertToMap(String[] header, String[] values) {
    Map<String, String> result = new HashMap<>();
    for (int i = 0; i < header.length && i < values.length; i++) {
        if (StringUtils.isNotBlank(values[i])) {
            result.put(header[i], StringUtils.equalsIgnoreCase(values[i], "REMOVE")  ? "DELETE" : values[i]);
        }
    }
    return result;
}

private Map<CloudBlob, File> downloadFiles(String country) {
    Map<CloudBlob, File> files = new HashMap<>();
    String connectionString='DefaultEndpointsProtocol=https;AccountName=pimcoreservicemaster;AccountKey=/lw/Lum/lLmOuILNJIh+HiScvg+QzKvFCrCacSNlaseN9uyuXCr8HvGF0CqEmIR31hrrRA+owl4m+ASthtlxAw==;EndpointSuffix=core.windows.net';
    String containerName='integrations';
    String blobPath = 'gica/' + country + '/hybris/';

    CloudStorageAccount storageAccount;
    try {
        storageAccount = CloudStorageAccount.parse(connectionString);
        CloudBlobClient blobClient = storageAccount.createCloudBlobClient();
        CloudBlobContainer container = blobClient.getContainerReference(containerName);
        // List all blobs in the container and download them
        container.listBlobs(blobPath).each { blobItem ->
            if (blobItem instanceof CloudBlob) {
                def blob = blobItem as CloudBlob
                String name = blob.getName().replace("/", "_")
                def localFile = new File(name)
                println "Downloading ${name}"
                // Download the blob
                blob.downloadToFile(localFile.toPath().toString());
                files.put(blob, localFile);
            }
        }

    } catch (Exception e) {
        println e.printStackTrace();
    }

    return files;
}



