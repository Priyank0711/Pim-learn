exports = async function(changeEvent) {
  // A Database Trigger will always call a function with a changeEvent.
  // Documentation on ChangeEvents: https://www.mongodb.com/docs/manual/reference/change-events

  // This sample function will listen for events and replicate them to a collection in a different Database

  // Access the _id of the changed document:
  //const docId = changeEvent.documentKey._id;

  // Get the MongoDB service you want to use (see "Linked Data Sources" tab)
  const collection_inaccurate_results = context.services.get("pstieracatalogtemp").db("ps-catalog-temp").collection('DiffProduct');
  const collection_product_service = context.services.get("ps-catalog-tier-a-prod").db("ps-catalog").collection('Product');


  // Get the "FullDocument" present in the Insert/Replace/Update ChangeEvents
  try {
    // If this is a "delete" event, delete the document in the other collection
    if (changeEvent.operationType === "delete") {
      // await collection.deleteOne({"_id": docId});
    }

    // If this is an "insert" event, insert the document into the other collection
    else if (changeEvent.operationType === "insert" || changeEvent.operationType === "update" || changeEvent.operationType === "replace") {
      // await collection.insertOne(changeEvent.fullDocument);
      pimProduct = changeEvent.fullDocument

      productServiceProduct = await collection_product_service.findOne({"_id": pimProduct._id})

      polishPimObject(pimProduct);

      polishSourceObject(productServiceProduct);

      if (!compareObjects(productServiceProduct, pimProduct)) {
        pimProduct.psProduct = productServiceProduct;
        collection_inaccurate_results.insertOne(pimProduct)
      }

    }
  } catch(err) {
    console.log("error performing mongodb write: ", err.message);
  }
};


function polishPimObject(object) {
//    delete object.modifiedTime;
//    delete object.marketplaceProduct;

//    deletePropertyInList(object.categoriesHierarchy, 'code');
//    deletePropertyInList(object.images, 'url');

    if (object.classifications !== null && object.classifications instanceof Array) {
        object.classifications.forEach(classification => {
            //delete classification.localizedName;

            classification.features.forEach(feature => {
                feature.code = feature.code.toLowerCase();
            });
        });
    }

    sortAssortments(object.assortments);
    sortList(object.barCodes);
    sortList(object.listofUnpublishedPOS);
    sortClassifications(object.classifications);

    convertToLowerCase(object, 'brandName');

}

function polishSourceObject(object) {
    delete object.modifiedTime;
    delete object.refurbishedOffers;
    delete object.purchasable;
    delete object.numberOfReviews;
    delete object.newOffers;
    delete object.lifeStyle;
    delete object.incremental;
    delete object.eligibleForGiftWrapping;
    delete object.displayOfferAsMainPrice;
    delete object.deliveryTimeDescription;
    delete object.creationTime;
    delete object.metaDescription;
    delete object.metaTitle;
    delete object.salesUnit;
    delete object.averageRating;
    delete object.legalDisclaimer;
    delete object.currencyLocalize;
    delete object.warranty;
    delete object.url;
    delete object.manufacturer;
    delete object.areaOfDelivery;
    delete object.gicaVatPer;
    delete object.gicaVatCod;
    delete object.reviews;
    delete object.serviceProducts;
    delete object.supplier;
    delete object.supplierDescription;
    delete object.productTypeDM51;
    delete object.numberOfOffers;

    deletePropertyInList(object.assortments, 'description');
    deletePropertyInList(object.images, 'url');

    if (object.classifications !== null && object.classifications instanceof Array) {
        object.classifications.forEach(classification => {

                if (classification.features !== null && classification.features instanceof Array) {
                    classification.features.forEach(feature => {
                        delete feature.comparable;
                        delete feature.key;
                        delete feature.positionKey;
                        delete feature.range;


                        feature.code = feature.code.substring(feature.code.lastIndexOf('.')+ 1).toLowerCase();
                    });
                }
        });
    }

    sortAssortments(object.assortments);
    sortList(object.barCodes);
    sortTrimAndDeleteIfListEmpty(object, 'listofUnpublishedPOS');
    sortClassifications(object.classifications);
    removeFieldIfBlank(object, 'nature');
    removeFieldIfOnlyNewLines(object, 'preorderDescription')
    removeFieldIfOnlyNewLines(object, 'tipsAndVideos')
    convertToLowerCase(object, 'brandName');

}

function convertToLowerCase(object, key) {
    if (object[key] !== null && typeof object[key] == 'string') {
        object[key] = object[key].toLowerCase();
    }
}

function sortClassifications(classifications) {
    sortObjectList(classifications, 'code');
    if (classifications !== null && classifications instanceof Array) {
        classifications.forEach(classification => {
            sortObjectList(classification.features, 'code');
       });
    }
}

function sortObjectList(list, key) {
    if (list !== null && list instanceof Array) {
        list.sort((a, b) => a[key].localeCompare(b[key]));
    }
}

function deletePropertyInList(list, property) {
    if (list !== null && list instanceof Array) {
        list.forEach(item => {
            delete item[property];
        });
    }
}

function sortAssortments(assortments) {
    if (assortments !== null && assortments instanceof Array) {
        assortments.sort((a, b) => a.code.localeCompare(b.code));
    }
}

function sortList(list) {
    if (list !== null && list instanceof Array) {
        list.sort();
    }
}

function sortTrimAndDeleteIfListEmpty(object, key) {
    if (object[key] !== null && object[key] instanceof Array) {
        var list = object[key].filter(str => str.trim() !== "");
        if (list.length == 0) {
            delete object[key];
        } else {
            object[key] = list.sort();
        }
    }
}

function containsOnlyNewlines(str) {
  // Use a regular expression to check if the string contains only "\n" characters
  const regex = /^(\n)+$/;
  return regex.test(str);
}

function removeFieldIfOnlyNewLines(object, field) {
    if (object[field] !== null && containsOnlyNewlines(object[field])) {
        delete object[field];
    }
}

function removeFieldIfBlank(object, field) {
    if (object[field] !== null && object[field] == '') {
        delete object[field];
    }
}

function removeSpecialCharsAndTrim(object, field) {
    if (object[field] !== null && typeof object[field] == 'string') {
        object[field] = object[field].replace(/\x00/g, '').trim();
    }
}

function compareObjects(obj1, obj2) {
    if (typeof obj1 !== 'object' || typeof obj2 !== 'object') {
        obj2.result = "Type of objects different";
        console.log("Type of objects different")
        return false;
    }

    const keys1 = Object.keys(obj1);
    const keys2 = Object.keys(obj2);
//    if (keys1.length !== keys2.length) {
//        console.log("length diff. "+ keys1.length +" for obj " + JSON.stringify(obj1) +"\n and  \n" + keys2.length +" for obj " + JSON.stringify(obj2));
//        return false;
//    }

    for (let key of keys1) {
        if (!obj2.hasOwnProperty(key)) {
            console.log("obj2 does not have property - "+ key)
            obj2.result = "obj2 does not have property - "+ key;
            return false;
        }

        if (typeof obj1[key] === 'object' && typeof obj2[key] === 'object') {
            if (!compareObjects(obj1[key], obj2[key])) {
                return false;
            }
        } else {
            if (obj1[key] !== obj2[key]) {
                // check again after removing  special chars
                removeSpecialCharsAndTrim(obj1, key);
                if (obj1[key] !== obj2[key]) {
                    obj2.result = "value mismatch - "+ obj1[key] +" not equal to " + obj2[key] +" for key "+ key;
                    console.log("value mismatch - "+ obj1[key] +" not equal to " + obj2[key] +" for key "+ key);
                    return false;
                }
            }
        }
    }
    return true;
}
