ALTER TABLE public.product_gallery DROP CONSTRAINT product_gallery_pkey;
ALTER TABLE public.product_gallery DROP CONSTRAINT fk_product_media_gallery;
ALTER TABLE public.product_gallery DROP CONSTRAINT fk_product_media_product;

ALTER TABLE product_gallery rename to product_gallery_old;
ALTER TABLE product_gallery_lbn rename to product_gallery_old_lbn;
ALTER TABLE product_gallery_ken rename to product_gallery_old_ken;
ALTER TABLE product_gallery_pak rename to product_gallery_old_pak;

CREATE TABLE IF NOT EXISTS public.product_gallery
(
    media_code character varying(255) NOT NULL,
    media_country character varying(30) NOT NULL,
    product_code character varying(255) NOT NULL,
    product_country character varying(30) NOT NULL,
    CONSTRAINT product_gallery_pkey PRIMARY KEY (media_code, media_country, product_code, product_country),
    CONSTRAINT fk_product_media_gallery FOREIGN KEY (media_code, media_country)
        REFERENCES public.media (code, country) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION,
    CONSTRAINT fk_product_media_product FOREIGN KEY (product_code, product_country)
        REFERENCES public.product (code, country) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
) PARTITION BY LIST (product_country);

CREATE TABLE public.product_gallery_lbn PARTITION OF public.product_gallery FOR VALUES IN ('LBN');
CREATE TABLE public.product_gallery_ken PARTITION OF public.product_gallery FOR VALUES IN ('KEN');
CREATE TABLE public.product_gallery_pak PARTITION OF public.product_gallery FOR VALUES IN ('PAK');

INSERT INTO product_gallery_lbn (media_code, media_country, product_code, product_country)
SELECT media_code, media_country, product_code, product_country FROM product_gallery_old WHERE product_country = 'LBN';

INSERT INTO product_gallery_ken (media_code, media_country, product_code, product_country)
SELECT media_code, media_country, product_code, product_country FROM product_gallery_old WHERE product_country = 'KEN';

INSERT INTO product_gallery_pak (media_code, media_country, product_code, product_country)
SELECT media_code, media_country, product_code, product_country FROM product_gallery_old WHERE product_country = 'PAK';

Drop Table public.product_gallery_old;