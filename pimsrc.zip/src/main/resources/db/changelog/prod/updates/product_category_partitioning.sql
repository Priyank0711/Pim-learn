ALTER TABLE public.product_category DROP CONSTRAINT fk_product_category_product;
ALTER TABLE public.product_category DROP CONSTRAINT fk_product_category_category;
ALTER TABLE public.product_category DROP CONSTRAINT product_category_pkey;

ALTER TABLE product_category rename to product_category_old;

CREATE TABLE IF NOT EXISTS public.product_category
(
    category_id character varying(255) NOT NULL,
    product_code character varying(255) NOT NULL,
    product_country character varying(30) NOT NULL,
    CONSTRAINT product_category_pkey PRIMARY KEY (product_code, product_country, category_id),
    CONSTRAINT fk_product_category_product FOREIGN KEY (product_code, product_country)
        REFERENCES public.product (code, country) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION,
    CONSTRAINT fk_product_category_category FOREIGN KEY (category_id)
        REFERENCES public.category (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
) PARTITION BY LIST (product_country);

CREATE TABLE public.product_category_lbn PARTITION OF public.product_category FOR VALUES IN ('LBN');
CREATE TABLE public.product_category_ken PARTITION OF public.product_category FOR VALUES IN ('KEN');
CREATE TABLE public.product_category_pak PARTITION OF public.product_category FOR VALUES IN ('PAK');

INSERT INTO public.product_category_lbn (category_id, product_code, product_country)
SELECT category_id, product_code, product_country FROM public.product_category_old WHERE product_country = 'LBN';

INSERT INTO public.product_category_ken (category_id, product_code, product_country)
SELECT category_id, product_code, product_country FROM public.product_category_old WHERE product_country = 'KEN';

INSERT INTO public.product_category_pak (category_id, product_code, product_country)
SELECT category_id, product_code, product_country FROM public.product_category_old WHERE product_country = 'PAK';

Drop Table public.product_category_old;