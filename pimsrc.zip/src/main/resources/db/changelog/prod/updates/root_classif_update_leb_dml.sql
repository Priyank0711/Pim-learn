Delete from public.parent_classification where child_id = 'maf_classification_leb' or parent_id = 'maf_classification_leb';

Delete from public.classification_class where id = 'maf_classification_leb';

INSERT INTO public.classification_class(id,country,code) VALUES
('maf_classification_lbn','LBN','maf_classification');

INSERT INTO public.parent_classification(child_id,parent_id) VALUES
('maf_classification_lbn',NULL),
('group1_lbn','maf_classification_lbn'),
('group2_lbn','maf_classification_lbn'),
('group4_lbn','maf_classification_lbn'),
('group3_lbn','maf_classification_lbn'),
('group5_lbn','maf_classification_lbn'),
('group6_lbn','maf_classification_lbn'),
('group7_lbn','maf_classification_lbn'),
('group8_lbn','maf_classification_lbn'),
('group9_lbn','maf_classification_lbn'),
('group10_lbn','maf_classification_lbn'),
('group11_lbn','maf_classification_lbn'),
('group12_lbn','maf_classification_lbn'),
('group13_lbn','maf_classification_lbn'),
('group14_lbn','maf_classification_lbn'),
('group15_lbn','maf_classification_lbn'),
('group16_lbn','maf_classification_lbn'),
('group17_lbn','maf_classification_lbn'),
('group18_lbn','maf_classification_lbn'),
('group19_lbn','maf_classification_lbn');