CREATE EXTENSION IF NOT EXISTS ltree;

CREATE OR REPLACE FUNCTION ltree_default_func()
RETURNS TRIGGER AS $function$
DECLARE
    f_schema_name text;
    f_table_name text;
    f_parent_path text;
	select_query text;
BEGIN
    f_schema_name := quote_ident(TG_TABLE_SCHEMA);
    f_table_name := quote_ident(TG_TABLE_NAME);
    IF NEW.parent_id IS NULL or TRIM(NEW.parent_id)='' THEN
        NEW.path := NEW.id::text::ltree;
    ELSE
        select_query := 'SELECT path::text from '||f_schema_name||'.'||f_table_name||' where id = ($1.parent_id)';
        EXECUTE select_query into f_parent_path USING NEW;
		NEW.path := (f_parent_path||'.'||NEW.id::text)::ltree;
    END IF;
    RETURN NEW;
END;
$function$ LANGUAGE plpgsql;

CREATE TABLE IF NOT EXISTS public.media
(
    code character varying(255) NOT NULL,
    country character varying(30) NOT NULL,
    name character varying(255),
    format character varying(255),
    master_url character varying(255),
    url character varying(255),
    relative_path character varying(255),
    modified_date timestamp(6) without time zone DEFAULT (now() AT time zone 'UTC'),
    CONSTRAINT media_pkey PRIMARY KEY (code, country)
) PARTITION BY LIST(country);

CREATE TABLE IF NOT EXISTS public.media_uae PARTITION OF media FOR VALUES IN ('UAE');
CREATE TABLE IF NOT EXISTS public.media_sau PARTITION OF media FOR VALUES IN ('SAU');
CREATE TABLE IF NOT EXISTS public.media_egy PARTITION OF media FOR VALUES IN ('EGY');
CREATE TABLE IF NOT EXISTS public.media_lbn PARTITION OF media FOR VALUES IN ('LBN');

CREATE TABLE IF NOT EXISTS public.product
(
    code character varying(255) NOT NULL,
    country character varying(30) NOT NULL,
    approval_status character varying(30),
    average_piece_by_kg integer,
    average_weight_by_piece double precision,
    delivery_time integer,
    depth double precision,
    express_product boolean,
    free_delivery boolean,
    free_installation boolean,
    genuine_stock boolean,
    gross_weight double precision,
    height double precision,
    loyalty_point integer,
    marketplace_product boolean,
    max_to_order integer,
    min_order_quantity integer,
    nature character varying(30),
    nbr_of_month integer,
    on_demand boolean,
    preorder boolean,
    product_food_type character varying(30),
    product_type character varying(30),
    unit_item integer,
    warranty boolean,
    weight double precision,
    weight_increment double precision,
    weight_variation double precision,
    width double precision,
    year_of_warranty integer,
    warranty_type character varying(30),
    media_code character varying(255),
    media_country character varying(30),
    pre_order_delivery_time timestamp(6) without time zone,
    department character varying(255),
    section character varying(255),
    family character varying(255),
    sub_family character varying(255),
    ean character varying(255),
    gica_vat_cod character varying(255),
    gica_vat_per character varying(255),
    item_measure character varying(255),
    item_status character varying(255),
    store_id character varying(255),
    code_delivery_gica character varying(255),
    assortments character varying(255)[],
    barcodes character varying(255)[],
    max_order_quantity integer,
    substituted boolean,
    loyalty_points_start_date timestamp(6) without time zone,
    loyalty_points_end_date timestamp(6) without time zone,
    minimum_weight_to_order double precision,
    non_replenishable boolean,
    number_of_unit double precision,
    modified_date timestamp(6) without time zone DEFAULT (now() AT time zone 'UTC'),
    CONSTRAINT product_code_country_pkey PRIMARY KEY (code, country),
    CONSTRAINT product_media_fk FOREIGN KEY (media_code, media_country)
            REFERENCES public.media (code, country) MATCH SIMPLE
            ON UPDATE NO ACTION
            ON DELETE NO ACTION
) PARTITION BY LIST(country);

CREATE TABLE IF NOT EXISTS public.product_uae PARTITION OF product FOR VALUES IN ('UAE');
CREATE TABLE IF NOT EXISTS public.product_sau PARTITION OF product FOR VALUES IN ('SAU');
CREATE TABLE IF NOT EXISTS public.product_egy PARTITION OF product FOR VALUES IN ('EGY');
CREATE TABLE IF NOT EXISTS public.product_lbn PARTITION OF product FOR VALUES IN ('LBN');


CREATE TABLE IF NOT EXISTS public.product_translation
(
    language character varying(30) NOT NULL,
    product_code character varying(255) NOT NULL,
    product_country character varying(30) NOT NULL,
    allergy_advice text,
    brand_marketing_message text,
    bulk_message text,
    country_origin character varying(255),
    description text,
    ingredients text,
    marketing_text text,
    meta_description text,
    meta_keywords text,
    meta_title text,
    name text,
    online_name text,
    preparation_and_usage text,
    safety_warnings text,
    preorder_description text,
    tips_and_videos text,
    product_color text,
    size character varying(255),
    storage_conditions text,
    modified_date timestamp(6) without time zone DEFAULT (now() AT time zone 'UTC'),
    CONSTRAINT product_translation_pkey PRIMARY KEY (language, product_country, product_code),
    CONSTRAINT fk_product_translation FOREIGN KEY (product_code, product_country)
        REFERENCES public.product (code, country) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
) PARTITION BY LIST(product_country);

CREATE TABLE IF NOT EXISTS public.product_translation_uae PARTITION OF product_translation FOR VALUES IN ('UAE');
CREATE TABLE IF NOT EXISTS public.product_translation_sau PARTITION OF product_translation FOR VALUES IN ('SAU');
CREATE TABLE IF NOT EXISTS public.product_translation_egy PARTITION OF product_translation FOR VALUES IN ('EGY');
CREATE TABLE IF NOT EXISTS public.product_translation_lbn PARTITION OF product_translation FOR VALUES IN ('LBN');


CREATE TABLE IF NOT EXISTS public.product_gallery
(
    media_code character varying(255) NOT NULL,
    media_country character varying(30) NOT NULL,
    product_code character varying(255) NOT NULL,
    product_country character varying(30) NOT NULL,
    CONSTRAINT product_gallery_pkey PRIMARY KEY (media_code, media_country, product_code, product_country),
    CONSTRAINT fk_product_media_gallery FOREIGN KEY (media_code, media_country)
        REFERENCES public.media (code, country) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION,
    CONSTRAINT fk_product_media_product FOREIGN KEY (product_code, product_country)
        REFERENCES public.product (code, country) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
);

CREATE TABLE IF NOT EXISTS public.gica_reference
(
    department character varying(255),
    family character varying(255),
    section character varying(255),
    sub_family character varying(255),
    country character varying(30) NOT NULL,
    nature character varying(30),
    type character varying(30),
    category character varying(255),
    classification character varying(255),
    modified_date timestamp(6) without time zone DEFAULT (now() AT time zone 'UTC'),
    CONSTRAINT gica_reference_pk PRIMARY KEY (department, section, family, sub_family, country)
);

CREATE TABLE IF NOT EXISTS public.category
(
    id character varying(255) primary key,
    code character varying(255),
    country character varying(30) NOT NULL,
    parent_id character varying(255) references public.category (id),
    path ltree NOT NULL,
    category_type character varying(30),
    modified_date timestamp(6) without time zone DEFAULT (now() AT time zone 'UTC'),
    CONSTRAINT category_uk UNIQUE (code, country)
);

CREATE TRIGGER ltree_default_trigger
BEFORE INSERT OR UPDATE ON public.category
FOR EACH ROW
EXECUTE PROCEDURE ltree_default_func();

CREATE TABLE IF NOT EXISTS public.category_translation
(
    id serial primary key,
    language character varying(30) NOT NULL,
    category_id character varying(255),
    name text,
    modified_date timestamp(6) without time zone DEFAULT (now() AT time zone 'UTC'),
    CONSTRAINT category_translation_uk UNIQUE (category_id, language),
    CONSTRAINT fk_category_translation FOREIGN KEY (category_id)
        REFERENCES public.category (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
);

CREATE TABLE IF NOT EXISTS public.product_category
(
    category_id character varying(255) NOT NULL,
    product_code character varying(255) NOT NULL,
    product_country character varying(30) NOT NULL,
    CONSTRAINT product_category_pkey PRIMARY KEY (product_code, product_country, category_id),
    CONSTRAINT fk_product_category_product FOREIGN KEY (product_code, product_country)
        REFERENCES public.product (code, country) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION,
    CONSTRAINT fk_product_category_category FOREIGN KEY (category_id)
        REFERENCES public.category (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
);

CREATE TABLE IF NOT EXISTS public.classification_class
(
    id character varying(255) primary key,
    country character varying(30) NOT NULL,
    code character varying(255),
    modified_date timestamp(6) without time zone DEFAULT (now() AT time zone 'UTC'),
    CONSTRAINT classification_class_uk UNIQUE (code, country)
);

CREATE TABLE IF NOT EXISTS public.parent_classification
(
    id serial primary key,
    child_id character varying(255) references public.classification_class (id),
    parent_id character varying(255) references public.classification_class (id),
    modified_date timestamp(6) without time zone DEFAULT (now() AT time zone 'UTC'),
    CONSTRAINT parent_classification_class_uk UNIQUE (child_id, parent_id)
);

CREATE TABLE IF NOT EXISTS public.classification_class_translation
(
    id serial primary key,
    language character varying(30) NOT NULL,
    classification_id character varying(255),
    name text,
    modified_date timestamp(6) without time zone DEFAULT (now() AT time zone 'UTC'),
    CONSTRAINT classification_class_translation_uk UNIQUE (classification_id, language),
    CONSTRAINT fk_class_translation FOREIGN KEY (classification_id)
        REFERENCES public.classification_class (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
);

CREATE TABLE IF NOT EXISTS public.category_classification
(
    category_id character varying(255) NOT NULL,
    classification_id character varying(255) NOT NULL,
    CONSTRAINT category_classification_pkey PRIMARY KEY (category_id, classification_id),
    CONSTRAINT fk_category_class_category FOREIGN KEY (category_id)
        REFERENCES public.category (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION,
    CONSTRAINT fk_category_class_class FOREIGN KEY (classification_id)
        REFERENCES public.classification_class (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
);


CREATE TABLE IF NOT EXISTS public.attribute
(
    id character varying(255) primary key,
    code character varying(255),
    country character varying(30),
    modified_date timestamp(6) without time zone DEFAULT (now() AT time zone 'UTC'),
    CONSTRAINT attribute_uk UNIQUE (code, country)
);

CREATE TABLE IF NOT EXISTS public.attribute_translation
(
    id serial primary key,
    language character varying(30) NOT NULL,
    attribute_id character varying(255),
    name text,
    modified_date timestamp(6) without time zone DEFAULT (now() AT time zone 'UTC'),
    CONSTRAINT attribute_translation_uk UNIQUE (attribute_id, language),
    CONSTRAINT attribute_translation_fk FOREIGN KEY (attribute_id)
        REFERENCES public.attribute (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
);

CREATE TABLE IF NOT EXISTS public.attribute_assignment
(
    id serial primary key,
    multi_lang boolean,
    attribute_id character varying(255),
    classification_id character varying(255),
    feature_type character varying(255),
    modified_date timestamp(6) without time zone DEFAULT (now() AT time zone 'UTC'),
    CONSTRAINT attribute_assignment_uk UNIQUE (attribute_id, classification_id),
    CONSTRAINT attribute_classification_fk FOREIGN KEY (classification_id)
        REFERENCES public.classification_class (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION,
    CONSTRAINT attribute_assignment_fk FOREIGN KEY (attribute_id)
        REFERENCES public.attribute (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
);


CREATE TABLE IF NOT EXISTS public.product_attribute_value
(
    language character varying(30) NOT NULL,
    product_country character varying(30) NOT NULL,
    product_code character varying(255) NOT NULL,
    assignment_id bigint NOT  NULL,
    value text,
    modified_date timestamp(6) without time zone DEFAULT (now() AT time zone 'UTC'),
    CONSTRAINT product_attribute_value_pkey PRIMARY KEY (language, product_country, product_code, assignment_id),
    CONSTRAINT fk_attribute_value_assignment FOREIGN KEY (assignment_id)
        REFERENCES public.attribute_assignment (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION,
    CONSTRAINT fk_attribute_value_product FOREIGN KEY (product_code, product_country)
        REFERENCES public.product (code, country) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
)PARTITION BY LIST(product_country);

 CREATE TABLE IF NOT EXISTS public.product_attribute_value_uae PARTITION OF product_attribute_value FOR VALUES IN ('UAE');
 CREATE TABLE IF NOT EXISTS public.product_attribute_value_sau PARTITION OF product_attribute_value FOR VALUES IN ('SAU');
 CREATE TABLE IF NOT EXISTS public.product_attribute_value_egy PARTITION OF product_attribute_value FOR VALUES IN ('EGY');
 CREATE TABLE IF NOT EXISTS public.product_attribute_value_lbn PARTITION OF product_attribute_value FOR VALUES IN ('LBN');



