package com.maf.pim.azure;

import com.azure.messaging.eventhubs.EventDataBatch;
import com.azure.messaging.eventhubs.EventHubProducerClient;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.maf.pim.azure.config.VariantEventHubClientConfiguration;
import com.maf.pim.data.VariantData;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.context.TestPropertySource;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.Field;
import java.util.List;
import java.util.stream.IntStream;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;


@ExtendWith(MockitoExtension.class)
@TestPropertySource(locations = "classpath:application-test.properties")
class VariantsEventSenderTest {
    @InjectMocks
    private VariantsEventSender variantsEventSender;

    @Mock
    private EventHubProducerClient eventHubProducerClient;

    @InjectMocks
    private VariantEventHubClientConfiguration variantEventHubClientConfiguration;

    private final ObjectMapper objectMapper = new ObjectMapper();

    @Test
    void eventHubClientConfiguration(){
        variantEventHubClientConfiguration.pimVariantEventhubTaskExecutor();
    }

    @Test
    void shouldSplitListToMultipleSubListsIfSizeGreaterThanMaxSize() throws NoSuchFieldException, IllegalAccessException, IOException {
        Field batchSizeField = VariantsEventSender.class.getDeclaredField("batchSize");
        batchSizeField.setAccessible(true);
        batchSizeField.set(variantsEventSender, 500);
        Field enabledField = VariantsEventSender.class.getDeclaredField("enabled");
        enabledField.setAccessible(true);
        enabledField.set(variantsEventSender, true);
        List<VariantData> list = IntStream.range(0, 1000).mapToObj(i -> {
            try {
                return getVariantData();
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }).toList();
        EventDataBatch eventDataBatch = mock(EventDataBatch.class);
        Mockito.when(eventHubProducerClient.createBatch()).thenReturn(eventDataBatch);

        variantsEventSender.sendData(list);

        verify(eventHubProducerClient, times(2)).send(any(EventDataBatch.class));
    }

    @Test
    void exceptionTest() throws NoSuchFieldException, IllegalAccessException, IOException {
        Field batchSizeField = VariantsEventSender.class.getDeclaredField("batchSize");
        batchSizeField.setAccessible(true);
        batchSizeField.set(variantsEventSender, 500);
        Field enabledField = VariantsEventSender.class.getDeclaredField("enabled");
        enabledField.setAccessible(true);
        enabledField.set(variantsEventSender, true);
        VariantData variantData = getVariantData();
        StringBuilder sb = new StringBuilder();
        IntStream.range(0, 1024000).forEach(sb::append);
        variantData.setId(sb.toString());
        EventDataBatch eventDataBatch = mock(EventDataBatch.class);
        Mockito.when(eventHubProducerClient.createBatch()).thenReturn(eventDataBatch);
        Mockito.when(eventDataBatch.tryAdd(any())).thenThrow(new RuntimeException(""));


        variantsEventSender.sendData(List.of(variantData));

        verify(eventHubProducerClient, times(0)).send(any(EventDataBatch.class));
    }

    private VariantData getVariantData() throws IOException {
        return objectMapper.readValue(new File("src/test/resources/variantData1.json"), VariantData.class);
    }


}