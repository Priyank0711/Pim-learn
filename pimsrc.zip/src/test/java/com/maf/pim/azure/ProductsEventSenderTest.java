package com.maf.pim.azure;

import com.azure.messaging.eventhubs.EventDataBatch;
import com.azure.messaging.eventhubs.EventHubProducerClient;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.maf.pim.azure.config.EventHubClientConfiguration;
import com.maf.pim.data.ProductData;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.context.TestPropertySource;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.Field;
import java.util.List;
import java.util.stream.IntStream;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;


@ExtendWith(MockitoExtension.class)
@TestPropertySource(locations = "classpath:application-test.properties")
class ProductsEventSenderTest {
    @InjectMocks
    private ProductsEventSender productsEventSender;

    @Mock
    private EventHubProducerClient eventHubProducerClient;

    @InjectMocks
    private EventHubClientConfiguration eventHubClientConfiguration;

    private final ObjectMapper objectMapper = new ObjectMapper();

    @Test
    void eventHubClientConfiguration(){
        eventHubClientConfiguration.pimEventhubTaskExecutor();
    }

    @Test
    void shouldSplitListToMultipleSubListsIfSizeGreaterThanMaxSize() throws NoSuchFieldException, IllegalAccessException, IOException {
        Field batchSizeField = ProductsEventSender.class.getDeclaredField("batchSize");
        batchSizeField.setAccessible(true);
        batchSizeField.set(productsEventSender, 500);
        Field enabledField = ProductsEventSender.class.getDeclaredField("enabled");
        enabledField.setAccessible(true);
        enabledField.set(productsEventSender, true);
        List<ProductData> list = IntStream.range(0, 1000).mapToObj(i -> {
            try {
                return getProductData();
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }).toList();
        EventDataBatch eventDataBatch = mock(EventDataBatch.class);
        Mockito.when(eventHubProducerClient.createBatch()).thenReturn(eventDataBatch);

        productsEventSender.sendData(list);

        verify(eventHubProducerClient, times(4)).send(any(EventDataBatch.class));
    }

    @Test
    void shouldCallSendIfSingleProductHasSizeMoreThanMax() throws NoSuchFieldException, IllegalAccessException, IOException {
        Field batchSizeField = ProductsEventSender.class.getDeclaredField("batchSize");
        batchSizeField.setAccessible(true);
        batchSizeField.set(productsEventSender, 500);
        Field enabledField = ProductsEventSender.class.getDeclaredField("enabled");
        enabledField.setAccessible(true);
        enabledField.set(productsEventSender, true);
        ProductData productData = getProductData();
        StringBuilder sb = new StringBuilder();
        IntStream.range(0, 1024000).forEach(i -> sb.append(i));
        productData.setProductType(sb.toString());
        EventDataBatch eventDataBatch = mock(EventDataBatch.class);
        Mockito.when(eventHubProducerClient.createBatch()).thenReturn(eventDataBatch);

        productsEventSender.sendData(List.of(productData));

        // This verification is just for code coverage. In actual, batch add should fail because of larger size.
        verify(eventHubProducerClient, times(1)).send(any(EventDataBatch.class));
    }

    @Test
    void exceptionTest() throws NoSuchFieldException, IllegalAccessException, IOException {
        Field batchSizeField = ProductsEventSender.class.getDeclaredField("batchSize");
        batchSizeField.setAccessible(true);
        batchSizeField.set(productsEventSender, 500);
        Field enabledField = ProductsEventSender.class.getDeclaredField("enabled");
        enabledField.setAccessible(true);
        enabledField.set(productsEventSender, true);
        ProductData productData = getProductData();
        StringBuilder sb = new StringBuilder();
        IntStream.range(0, 1024000).forEach(i -> sb.append(i));
        productData.setProductType(sb.toString());
        EventDataBatch eventDataBatch = mock(EventDataBatch.class);
        Mockito.when(eventHubProducerClient.createBatch()).thenReturn(eventDataBatch);
        Mockito.when(eventDataBatch.tryAdd(any())).thenThrow(new RuntimeException(""));


        productsEventSender.sendData(List.of(productData));

        verify(eventHubProducerClient, times(0)).send(any(EventDataBatch.class));
    }

    private ProductData getProductData() throws IOException {
        return objectMapper.readValue(new File("src/test/resources/productData1.json"), ProductData.class);
    }


}