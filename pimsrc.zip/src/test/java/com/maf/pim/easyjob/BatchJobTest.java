package com.maf.pim.easyjob;

import com.maf.pim.easyjob.fileprocessor.ApprovalStatusFileProcessor;
import com.maf.pim.easyjob.record.BasicRecord;
import com.maf.pim.easyjob.record.GicaBarCodeRecord;
import com.maf.pim.easyjob.record.processor.ApprovalStatusRecordProcessor;
import com.maf.pim.easyjob.record.validator.ApprovalStatusValidator;
import com.maf.pim.enums.Country;
import com.maf.pim.enums.FileResultTpe;
import org.jeasy.batch.core.job.*;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.io.File;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collection;
import java.util.concurrent.CompletableFuture;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;

@ExtendWith(MockitoExtension.class)
class BatchJobTest {

    @InjectMocks
    private BatchJob batchJob;

    @InjectMocks
    private ApprovalStatusFileProcessor approvalStatusFileProcessor;

    @Mock
    private ApprovalStatusValidator recordValidator;

    @Mock
    private ApprovalStatusRecordProcessor approvalStatusRecordProcessor;


    @Test
    void testProcessFile(){
        File file = new File("GICABARCODE_UAE.csv");
        BatchJobResult result = batchJob.processFile(file.toPath(), approvalStatusFileProcessor , Country.LBN);
        assertEquals(FileResultTpe.PROCESSED, result.getStatus());
    }

    @Test
    void testProcessFileException(){
        File file = new File("GICABARCODE_UAE.csv");
        BatchJobResult result = batchJob.processFile(file.toPath(), null , Country.LBN);
        assertEquals(FileResultTpe.FAILED, result.getStatus());
    }

    @Test
    void testCreateResult(){
        File file = new File("GICABARCODE_UAE.csv");
        Collection<BasicRecord> collections =  new ArrayList<>();

        GicaBarCodeRecord successRecord = new GicaBarCodeRecord();
        successRecord.setProcessed(true);
        collections.add(successRecord);
        GicaBarCodeRecord failureRecord = new GicaBarCodeRecord();
        failureRecord.setProcessed(false);
        collections.add(failureRecord);

        JobReport jobReport = new JobReport();
        JobParameters jobParameters = new JobParameters();
        jobReport.setParameters(jobParameters);

        JobMetrics jobMetrics = new JobMetrics();
        jobMetrics.setStartTime(LocalDateTime.now().minusMinutes(5));
        jobMetrics.setEndTime(LocalDateTime.now().plusMinutes(5));

        jobReport.setMetrics(jobMetrics);
        jobReport.toString();

        JobExecutor jobExecutor = Mockito.mock(JobExecutor.class);
        Mockito.when(jobExecutor.submit(any(Job.class))).thenReturn(CompletableFuture.completedFuture(jobReport));

        BatchJobResult result = batchJob.createResult(jobExecutor, file.toPath(), approvalStatusFileProcessor , collections);
        assertEquals(FileResultTpe.PARTIALLY_PROCESSED, result.getStatus());
    }

    @Test
    void testCreateResultException(){
        File file = new File("GICABARCODE_UAE.csv");
        Collection<BasicRecord> collections =  new ArrayList<>();

        GicaBarCodeRecord successRecord = new GicaBarCodeRecord();
        successRecord.setProcessed(true);
        collections.add(successRecord);
        GicaBarCodeRecord failureRecord = new GicaBarCodeRecord();
        failureRecord.setProcessed(false);
        collections.add(failureRecord);

        JobReport jobReport = new JobReport();
        JobParameters jobParameters = new JobParameters();
        jobReport.setParameters(jobParameters);

        JobMetrics jobMetrics = new JobMetrics();
        jobMetrics.setStartTime(LocalDateTime.now().minusMinutes(5));
        jobMetrics.setEndTime(LocalDateTime.now().plusMinutes(5));

        jobReport.setMetrics(jobMetrics);
        jobReport.toString();

        JobExecutor jobExecutor = Mockito.mock(JobExecutor.class);
        Mockito.when(jobExecutor.submit(any(Job.class))).thenThrow(new RuntimeException(""));

        BatchJobResult result = batchJob.createResult(jobExecutor, file.toPath(), approvalStatusFileProcessor , collections);
        assertEquals(FileResultTpe.FAILED, result.getStatus());
    }

}
