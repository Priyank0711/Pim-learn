package com.maf.pim.easyjob;

import com.maf.pim.easyjob.fileprocessor.ClassificationFileProcessor;
import com.maf.pim.easyjob.record.BasicRecord;
import com.maf.pim.easyjob.record.DynamicRecord;
import com.maf.pim.easyjob.record.processor.ClassificationRecordProcessor;
import com.maf.pim.easyjob.record.validator.ClassificationRecordValidator;
import com.maf.pim.enums.Country;
import com.maf.pim.enums.FileResultTpe;
import org.jeasy.batch.core.job.*;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.io.File;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collection;
import java.util.concurrent.CompletableFuture;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;

@ExtendWith(MockitoExtension.class)
public class DynamicBatchJobTest {

    @InjectMocks
    private DynamicBatchJob dynamicBatchJob;

    @InjectMocks
    private ClassificationFileProcessor classificationFileProcessor;

    @Mock
    private ClassificationRecordValidator classificationRecordValidator;

    @Mock
    private ClassificationRecordProcessor classificationRecordProcessor;

    private static Collection<BasicRecord> getCollection() {
        Collection<BasicRecord> collections = new ArrayList<>();
        DynamicRecord successRecord = new DynamicRecord();
        successRecord.setProcessed(true);
        collections.add(successRecord);
        DynamicRecord failureRecord = new DynamicRecord();
        failureRecord.setProcessed(false);
        collections.add(failureRecord);
        return collections;
    }

    private static JobReport getJobReport() {
        JobReport jobReport = new JobReport();
        JobParameters jobParameters = new JobParameters();
        jobReport.setParameters(jobParameters);

        JobMetrics jobMetrics = new JobMetrics();
        jobMetrics.setStartTime(LocalDateTime.now().minusMinutes(5));
        jobMetrics.setEndTime(LocalDateTime.now().plusMinutes(5));

        jobReport.setMetrics(jobMetrics);
        return jobReport;
    }

    @Test
    void testProcessFile() {
        File file = new File("src/test/resources/data/input_carrefour-carrefour_3-LBN-CLASSIFICATION 1#_success.csv");
        BatchJobResult result = dynamicBatchJob.processFile(file.toPath(), classificationFileProcessor, Country.LBN);
        assertEquals(FileResultTpe.PROCESSED, result.getStatus());
    }

    @Test
    void testCreateResult() {
        File file = new File("src/test/resources/data/test.csv");
        Collection<BasicRecord> collections = getCollection();
        JobReport jobReport = getJobReport();

        JobExecutor jobExecutor = Mockito.mock(JobExecutor.class);
        Mockito.when(jobExecutor.submit(any(Job.class))).thenReturn(CompletableFuture.completedFuture(jobReport));

        BatchJobResult result = dynamicBatchJob.createResult(jobExecutor, file.toPath(), classificationFileProcessor, collections);
        assertEquals(FileResultTpe.PARTIALLY_PROCESSED, result.getStatus());
    }

    @Test
    void testCreateResultException() {
        File file = new File("test.csv");
        Collection<BasicRecord> collections = getCollection();

        JobExecutor jobExecutor = Mockito.mock(JobExecutor.class);

        BatchJobResult result = dynamicBatchJob.createResult(jobExecutor, file.toPath(), classificationFileProcessor, collections);
        assertEquals(FileResultTpe.FAILED, result.getStatus());
    }
}
