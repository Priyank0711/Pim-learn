package com.maf.pim;

class PimCoreServiceApplicationTests {

	void contextLoads() {
	}

}
