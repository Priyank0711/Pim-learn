package com.maf.pim.comparator;


import com.maf.pim.entity.Media;
import com.maf.pim.entity.MediaId;
import com.maf.pim.enums.Country;
import org.junit.jupiter.api.Test;

import java.util.*;
import java.util.stream.Collectors;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

public class MediaComparatorTest {

    @Test
    public void testSortedOrder() {

        List<Media> gallery = Arrays.asList(
                new Media(new MediaId("user_11", Country.UAE), "user_11", "", "", "", ""),
                new Media(new MediaId("test_10", Country.UAE), "test_10", "", "", "", ""),
                new Media(new MediaId("sample_1", Country.UAE), "sample_1", "", "", "", ""),
                new Media(new MediaId("example_2", Country.UAE), "example_2", "", "", "", ""),
                new Media(new MediaId("2169971_9", Country.UAE), "2169971_9.jpg", "", "", "", ""),
                new Media(new MediaId("2169971_5", Country.UAE), "2169971_5.jpg", "", "", "", ""),
                new Media(new MediaId("random_main", Country.UAE), "random_main", "", "", "", ""),
                new Media(new MediaId("another_extra", Country.UAE), "another_extra", "", "", "", ""),
                new Media(new MediaId("empty1", Country.UAE), null, "", "", "", "")

        );

        Set<Media> sortedSet = gallery.stream()
                .sorted(Comparator.nullsLast(new MediaComparator()))
                .collect(Collectors.toCollection(LinkedHashSet::new));

        Iterator<Media> iterator = sortedSet.iterator();
        assertEquals("sample_1", iterator.next().getName());
        assertEquals("example_2", iterator.next().getName());
        assertEquals("2169971_5.jpg", iterator.next().getName());
        assertEquals("2169971_9.jpg", iterator.next().getName());
        assertEquals("test_10", iterator.next().getName());
        assertEquals("user_11", iterator.next().getName());
        assertEquals("random_main", iterator.next().getName());
        assertEquals("another_extra", iterator.next().getName());
        assertNull(iterator.next().getName());
    }

    @Test
    public void testNullHandling() {
        List<Media> galleryWithNulls = Arrays.asList(

                new Media(new MediaId("empty1", Country.UAE), null, "", "", "", ""),
                new Media(new MediaId("empty", Country.UAE), null, "", "", "", ""),
                new Media(new MediaId("2169971_5", Country.UAE), "2169971_5.jpg", "", "", "", ""),
                new Media(new MediaId("sample_1", Country.UAE), "sample_1", "", "", "", "")
        );

        Set<Media> sortedSetWithNulls = galleryWithNulls.stream()
                .sorted(Comparator.nullsLast(new MediaComparator()))
                .collect(Collectors.toCollection(LinkedHashSet::new));

        Iterator<Media> iterator = sortedSetWithNulls.iterator();
        assertEquals("sample_1", iterator.next().getName());
        assertEquals("2169971_5.jpg", iterator.next().getName());
        assertNull(iterator.next().getName());
        assertNull(iterator.next().getName());

    }

    @Test
    public void testNonNumericHandling() {
        List<Media> galleryNonNumeric = Arrays.asList(

                new Media(new MediaId("file_alpha", Country.UAE), "file_alpha", "", "", "", ""),
                new Media(new MediaId("file_beta", Country.UAE), "file_beta", "", "", "", ""),
                new Media(new MediaId("2169971_5", Country.UAE), "2169971_5.jpg", "", "", "", ""),
                new Media(new MediaId("2169971_9", Country.UAE), "2169971_9.jpg", "", "", "", "")
        );

        Set<Media> sortedSetNonNumeric = galleryNonNumeric.stream()
                .sorted(new MediaComparator())
                .collect(Collectors.toCollection(LinkedHashSet::new));

        Iterator<Media> iterator = sortedSetNonNumeric.iterator();
        assertEquals("2169971_5.jpg", iterator.next().getName());
        assertEquals("2169971_9.jpg", iterator.next().getName());
        assertEquals("file_alpha", iterator.next().getName());
        assertEquals("file_beta", iterator.next().getName());
    }
}

