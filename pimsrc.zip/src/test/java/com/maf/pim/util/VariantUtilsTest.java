package com.maf.pim.util;

import com.maf.pim.context.SessionContext;
import com.maf.pim.data.VariantAttributeValue;
import com.maf.pim.data.VariantData;
import com.maf.pim.entity.Category;
import com.maf.pim.entity.Product;
import com.maf.pim.entity.ProductId;
import com.maf.pim.projections.ProductAttrValueProjection;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.*;

import static com.maf.pim.testUtils.VariantTestUtil.*;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class VariantUtilsTest {

    @Test
    void buildVariantTreeCreatesCorrectStructure() {
        Category category = createCategory();
        SessionContext context = createContext();
        List<VariantTreeLevel> treeLevels = createTreeLevels();
        Map<String, List<ProductAttrValueProjection>> groupedPAVs = createGroupedPAVs();
        Map<Long, String> attributeAssignmentMap = createAttributeAssignmentMap();
        Map<ProductId, Product> productMap = createProductMap();
        VariantData result = VariantUtils.buildVariantTree(groupedPAVs, productMap, attributeAssignmentMap, category, treeLevels, context);

        assertNotNull(result);
        assertEquals("categoryCode", result.getId());
        assertEquals(1, result.getProductIds().size());
        assertNotNull(result.getData());
        assertEquals("test1", result.getData().getCode());
        assertEquals(1, result.getData().getVariants().size());
        assertEquals("value1", result.getData().getVariants().getFirst().getValue());

    }

    @Test
    void buildVariantTreeHandlesEmptyGroupedPAVs() {
        Category category = createCategory();
        SessionContext context = createContext();
        List<VariantTreeLevel> treeLevels = createTreeLevels();
        Map<Long, String> attributeAssignmentMap = createAttributeAssignmentMap();
        Map<ProductId, Product> productMap = createProductMap();

        VariantData result = VariantUtils.buildVariantTree(Collections.emptyMap(), productMap, attributeAssignmentMap, category, treeLevels, context);

        assertNotNull(result);
        assertTrue(result.getProductIds().isEmpty());
        assertEquals("categoryCode", result.getId());
        assertNotNull(result.getData());
        assertEquals("test1", result.getData().getCode());
        assertTrue(result.getData().getVariants().isEmpty());
    }

    @Test
    void buildVariantTreeHandlesGroupedPAVsWithoutRequiredAttributes() {
        Category category = createCategory();
        SessionContext context = createContext();
        List<VariantTreeLevel> treeLevels = createTreeLevels();

        Map<String, List<ProductAttrValueProjection>> groupedPAVs = new HashMap<>();
        List<ProductAttrValueProjection> pavs = new ArrayList<>();
        ProductAttrValueProjection pav = mock(ProductAttrValueProjection.class);
        when(pav.getAssignmentId()).thenReturn(1L);
        pavs.add(pav);
        groupedPAVs.put("productId", pavs);

        Map<Long, String> attributeAssignmentMap = createAttributeAssignmentMap();
        attributeAssignmentMap.put(1L, "test4");
        Map<ProductId, Product> productMap = createProductMap();
        VariantData result = VariantUtils.buildVariantTree(groupedPAVs, productMap, attributeAssignmentMap, category, treeLevels, context);

        assertNotNull(result);
        assertTrue(result.getProductIds().isEmpty());
        assertEquals("categoryCode", result.getId());
        assertNotNull(result.getData());
        assertEquals("test1", result.getData().getCode());
        assertTrue(result.getData().getVariants().isEmpty());
    }

    @Test
    void createVariantDetailCreatesCorrectDetail() {
        Map<String, String> localizedValue = new HashMap<>();
        localizedValue.put("en", "value");

        VariantAttributeValue detail = VariantUtils.createVariantDetail("value", localizedValue);

        assertNotNull(detail);
        assertEquals("value", detail.getValue());
        assertEquals(localizedValue, detail.getLocalizedValue());
    }
}