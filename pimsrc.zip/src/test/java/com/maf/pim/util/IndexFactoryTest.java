package com.maf.pim.util;

import com.maf.pim.properties.ElasticSearchIndexes;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;

@ExtendWith(MockitoExtension.class)
class IndexFactoryTest {

    @InjectMocks
    IndexFactory indexFactory;
    @Mock
    ElasticSearchIndexes indexes;

    @Test
    void getProductIndexName() {

        Mockito.when(indexes.getIndexes()).thenReturn(Map.of("country", "index"));
        assertEquals("index", indexFactory.getProductIndexName("country"));
    }
}