package com.maf.pim.util;

import org.junit.jupiter.api.Test;

import java.util.Objects;

import static org.junit.jupiter.api.Assertions.*;

class
ValueParserTest {

    @Test
    void testParseBooleanTrueValues() {
        assertTrue(ValueParser.parseBoolean("true"));
        assertTrue(ValueParser.parseBoolean("True"));
        assertTrue(ValueParser.parseBoolean("TRUE"));
        assertTrue(ValueParser.parseBoolean("YES"));
        assertTrue(ValueParser.parseBoolean("Yes"));
        assertTrue(ValueParser.parseBoolean("yes"));
        assertTrue(ValueParser.parseBoolean("y"));
        assertTrue(ValueParser.parseBoolean("Y"));
        assertTrue(ValueParser.parseBoolean("1"));
    }
    @Test
    void testParseBooleanFalseValues() {
        assertFalse(ValueParser.parseBoolean("false"));
        assertFalse(ValueParser.parseBoolean("FALSE"));
        assertFalse(ValueParser.parseBoolean("FAlse"));
        assertFalse(ValueParser.parseBoolean("No"));
        assertFalse(ValueParser.parseBoolean("no"));
        assertFalse(ValueParser.parseBoolean("NO"));
        assertFalse(ValueParser.parseBoolean("n"));
        assertFalse(ValueParser.parseBoolean("N"));
        assertFalse(ValueParser.parseBoolean("0"));
    }
    @Test
    void testParseBooleanNullValue() {
        assertNull(ValueParser.parseBoolean(""));
        assertNull(ValueParser.parseBoolean("test"));
        assertNull(ValueParser.parseBoolean("abcsd"));
        assertNull(ValueParser.parseBoolean("trues"));
        assertNull(ValueParser.parseBoolean("falses"));
        assertNull(ValueParser.parseBoolean(null));
    }

    @Test
    void testParseIntegerNullValue() {
        assertNull(ValueParser.parseInteger(""));
        assertNull(ValueParser.parseInteger(null));
    }

    @Test
    void testParseDateNullValue() {
        assertNull(ValueParser.parseDate(""));
        assertNull(ValueParser.parseDate(null));
        assertNull(ValueParser.parseDate("23"));
        assertNull(ValueParser.parseDate("2024-03-31'T'13:00:00"));

    }

    @Test
    void testParseDoubleNullValue() {
        assertNull(ValueParser.parseDouble(""));
        assertNull(ValueParser.parseDouble(null));
    }
    @Test
    void testParseInteger() {
        assertEquals(1, ValueParser.parseInteger("1"));
        assertEquals(100, ValueParser.parseInteger("100"));
    }
    @Test
    void testParseDouble() {
        assertEquals(1.0, ValueParser.parseDouble("1.0"));
        assertEquals(100.0, ValueParser.parseDouble("100.0"));
    }

    @Test
    void testParseDate() {
        assertEquals("2024-03-18T00:00:00Z", Objects.requireNonNull(ValueParser.parseDate("03-18-2024")).toString());
        assertEquals("2024-03-31T00:00:00Z", Objects.requireNonNull(ValueParser.parseDate("03-31-2024")).toString());
    }

}