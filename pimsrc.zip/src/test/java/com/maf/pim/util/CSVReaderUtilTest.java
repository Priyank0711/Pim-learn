package com.maf.pim.util;

import org.junit.jupiter.api.Test;

import java.io.File;
import java.io.IOException;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertTrue;

public class CSVReaderUtilTest {

    @Test
    void testReadColumn() throws IOException {
        File file = new File("src/test/resources/data/2024-MARKETPLACE-KWT.csv");
        Map<String, String> brandCodes = CSVReaderUtil.readColumn(file.getPath(), "BRAND", 2);
        assertTrue(brandCodes.containsKey("AuraVisual"));
    }
}
