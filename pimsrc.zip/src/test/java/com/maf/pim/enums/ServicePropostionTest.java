package com.maf.pim.enums;

import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class ServicePropostionTest {

    @Test
    void getPropositionByValueList() {
        List<ServicePropostion> servicePropostionList = ServicePropostion.getPropositionByValueList("QCOMM, BULK, STANDARD");
        assertEquals(3, servicePropostionList.size());
    }

    @Test
    void getPropositionByValueListWithEmptyValue() {
        List<ServicePropostion> servicePropostionList = ServicePropostion.getPropositionByValueList("");
        assertEquals(0, servicePropostionList.size());
    }

    @Test
    void getPropositionByValueListInvalidValue() {
        List<ServicePropostion> servicePropostionList = ServicePropostion.getPropositionByValueList("QCOMMERCE, STANDARD");
        assertEquals(1, servicePropostionList.size());
    }

}
