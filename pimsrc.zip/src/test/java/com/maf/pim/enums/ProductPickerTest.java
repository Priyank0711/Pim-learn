package com.maf.pim.enums;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class ProductPickerTest {

    @Test
    void toList() {
        assertEquals(9, ProductPicker.toList().size());
    }
}