package com.maf.pim.enums;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class ProductSectionTest {

    @Test
    void when_Valid_shouldReturnTrue() {
        assertTrue(ProductSection.isValid("MULTIMEDIA"));
    }

    @Test
    void when_Invalid_shouldReturnFalse() {
        assertFalse(ProductSection.isValid("INVALID_MULTIMEDIA"));
    }

    @Test
    void when_ToSet_shouldReturnGivenLengthSet() {
        assertEquals(4, ProductSection.toSet().size());
    }
}