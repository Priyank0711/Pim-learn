package com.maf.pim.enums;

import org.junit.jupiter.api.Test;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;


class BlobFileTypeTest {

    @Test
    void shouldReturnTrueForSupplierFiles() {
        assertTrue(BlobFileType.SUPPLIERGIMA.isSupplierFile());
        assertTrue(BlobFileType.GICASUPPLIER.isSupplierFile());
    }

    @Test
    void shouldReturnFalseForNonSupplierFiles() {
        assertFalse(BlobFileType.GICAREFERENCE.isSupplierFile());
        assertFalse(BlobFileType.GICANEWBARCODE.isSupplierFile());
        assertFalse(BlobFileType.GICAITEM.isSupplierFile());
        assertFalse(BlobFileType.PRODUCTAPPROVAL.isSupplierFile());
        assertFalse(BlobFileType.UNPUBLISHEDITEMS.isSupplierFile());
        assertFalse(BlobFileType.CLASSIFICATION.isSupplierFile());
        assertFalse(BlobFileType.CATEGORY.isSupplierFile());
        assertFalse(BlobFileType.MARKETPLACE_CATEGORY_MAPPING.isSupplierFile());
        assertFalse(BlobFileType.OTHER.isSupplierFile());
    }

    @Test
    void shouldReturnMarketPlaceCategoryMapping() {
        Optional<BlobFileType> fileType = BlobFileType.getFileType("MKP_CAT_MAPPINGEGY_0.csv");

        assertEquals(BlobFileType.MARKETPLACE_CATEGORY_MAPPING, fileType.get());
    }
}