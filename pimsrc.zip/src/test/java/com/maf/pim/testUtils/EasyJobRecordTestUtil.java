package com.maf.pim.testUtils;

import com.maf.pim.easyjob.record.DynamicRecord;
import com.maf.pim.enums.Country;

import java.util.HashMap;

public class EasyJobRecordTestUtil {

    public static DynamicRecord mockDynamicRecord() {
        HashMap<String,String> attributesRowValues = new HashMap<>();
        attributesRowValues.put("code", "117349");
        attributesRowValues.put("description[en]", "abcd classification product");
        attributesRowValues.put("onlineName[en]", "onlineName[en]");
        attributesRowValues.put("marketingText[en]", "marketingText[en]");
        attributesRowValues.put("tipsAndVideos[en]", "tipsAndVideos[en]");
        attributesRowValues.put("productColor[en]", "productColor[en]");
        attributesRowValues.put("size[en]", "4");
        attributesRowValues.put("minimumWeightToOrder", "36");
        attributesRowValues.put("maxToOrder", "2");
        attributesRowValues.put("weightIncrement", "32");
        attributesRowValues.put("averageWeightByPiece", "45");
        attributesRowValues.put("preorder", "true");
        attributesRowValues.put("preorderDate", "03-18-2024");
        attributesRowValues.put("preorderDescription", "Test");
        attributesRowValues.put("bulkMessage", "Test\nTest");
        attributesRowValues.put("freeInstallation", "false");
        attributesRowValues.put("numberOfPoints", "4");
        attributesRowValues.put("loyaltyPointStartDate", "03-10-2024");
        attributesRowValues.put("loyaltyPointEndDate", "03-18-2024");


        attributesRowValues.put("Number_of_slots_lbn[en]", "4");
        attributesRowValues.put("bluetooth_lbn", "yes");
        DynamicRecord dynamicRecord = new DynamicRecord(attributesRowValues);
        dynamicRecord.setCountry(Country.LBN);
        return dynamicRecord;
    }

    public static DynamicRecord mockDynamicRecord2() {
        HashMap<String,String> attributesRowValues = new HashMap<>();
        attributesRowValues.put("Number_of_slots_lbn[en]", "");
        attributesRowValues.put("Number_of_slots_lbn[ar]", null);
        attributesRowValues.put("bluetooth_lbn", "REMOVE");
        DynamicRecord dynamicRecord = new DynamicRecord(attributesRowValues);
        dynamicRecord.setCountry(Country.LBN);
        return dynamicRecord;
    }
}
