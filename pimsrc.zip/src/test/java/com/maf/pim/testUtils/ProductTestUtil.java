package com.maf.pim.testUtils;

import com.maf.pim.entity.Attribute;
import com.maf.pim.entity.AttributeAssignment;
import com.maf.pim.entity.Product;
import com.maf.pim.entity.translation.ProductTranslation;
import com.maf.pim.enums.Country;
import com.maf.pim.enums.FeatureType;
import com.maf.pim.enums.Language;

import java.util.*;

public class ProductTestUtil {

    public static Product getProductData() {
        Product product = Product.from("117349", Country.LBN);
        Set<ProductTranslation> productTranslationSet = new HashSet<>();
        productTranslationSet.add(ProductTranslation.from(product, Language.EN));
        product.setProductTranslations(productTranslationSet);
        return product;
    }

    public static Map<String, List<AttributeAssignment>> mockAttributeAssignmentMap() {
        HashMap<String,List<AttributeAssignment>> attributeAssignmentHashMap = new HashMap<>();
        Attribute attribute = new Attribute();
        attribute.setId("Number_of_slots_lbn");
        attribute.setCountry(Country.LBN);
        AttributeAssignment attributeAssignment = new AttributeAssignment();
        attributeAssignment.setAttribute(attribute);
        attributeAssignment.setFeatureType(FeatureType.NUMBER);

        Attribute attribute1 = new Attribute();
        attribute.setId("bluetooth_lbn");
        attribute.setCountry(Country.LBN);
        AttributeAssignment attributeAssignment1 = new AttributeAssignment();
        attributeAssignment1.setAttribute(attribute1);
        attributeAssignment1.setFeatureType(FeatureType.BOOLEAN);

        attributeAssignmentHashMap.put("Number_of_slots_lbn", List.of(attributeAssignment));
        attributeAssignmentHashMap.put("bluetooth_lbn", List.of(attributeAssignment1));
        return attributeAssignmentHashMap;
    }
}
