package com.maf.pim.testUtils;

import com.maf.pim.entity.Category;
import com.maf.pim.entity.translation.CategoryTranslation;
import com.maf.pim.enums.CategoryType;
import com.maf.pim.enums.Country;
import com.maf.pim.enums.Language;

import java.util.HashSet;

public class CategoryTestUtil {

    public static Category getCategoryData(int id){
        CategoryTranslation ct = new CategoryTranslation();
        ct.setId((long) id);
        ct.setName("Test");
        ct.setLanguage(Language.EN);
        Category category = new Category();
        category.setId("id");
        category.setCode("code");
        category.setCountry(Country.LBN);
        category.setCategoryTranslations(new HashSet<>());
        category.getCategoryTranslations().add(ct);
        category.setParentId("test");
        category.setPath("test.test");
        category.setCategoryType(CategoryType.NAVIGATION);
        ct.setCategory(category);
        return category;

    }
}
