package com.maf.pim.testUtils;

import com.maf.pim.context.SessionContext;
import com.maf.pim.entity.*;
import com.maf.pim.entity.translation.AttributeTranslation;
import com.maf.pim.enums.Country;
import com.maf.pim.util.VariantTreeLevel;
import com.maf.pim.entity.translation.CategoryTranslation;
import com.maf.pim.enums.Language;
import com.maf.pim.projections.ProductAttrValueProjection;

import java.util.*;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class VariantTestUtil {

    public static Category createCategory() {
        Category category = new Category();
        category.setCode("categoryCode");
        category.setL1AttrCode("test1");
        category.setL2AttrCode("test2");
        category.setL3AttrCode("test3");

        CategoryTranslation translation = new CategoryTranslation();
        translation.setLanguage(Language.EN);
        translation.setL1AttrName("L1 Attribute Name");
        translation.setL2AttrName("L2 Attribute Name");
        translation.setL3AttrName("L3 Attribute Name");


        Set<CategoryTranslation> translations = new HashSet<>();
        translations.add(translation);

        category.setCategoryTranslations(translations);

        return category;
    }

    public static SessionContext createContext() {
        SessionContext context = mock(SessionContext.class);
        when(context.getCountry()).thenReturn(Country.LBN);
        when(context.getLanguages()).thenReturn(Collections.singletonList(Language.EN));
        return context;
    }

    public static List<VariantTreeLevel> createTreeLevels() {
        List<VariantTreeLevel> treeLevels = new ArrayList<>();
        treeLevels.add(new VariantTreeLevel("test1", CategoryTranslation::getL1AttrName, true));
        treeLevels.add(new VariantTreeLevel("test2", CategoryTranslation::getL2AttrName, false));
        treeLevels.add(new VariantTreeLevel("test3", CategoryTranslation::getL3AttrName, false));
        return treeLevels;
    }

    public static Map<String, List<ProductAttrValueProjection>> createGroupedPAVs() {
        Map<String, List<ProductAttrValueProjection>> groupedPAVs = new HashMap<>();
        List<ProductAttrValueProjection> pavs = new ArrayList<>();

        ProductAttrValueProjection pav = mock(ProductAttrValueProjection.class);
        when(pav.getLang()).thenReturn(Language.EN);
        when(pav.getValue()).thenReturn("value1");
        when(pav.getAssignmentId()).thenReturn(1L);

        ProductAttrValueProjection pav2 = mock(ProductAttrValueProjection.class);
        when(pav2.getLang()).thenReturn(Language.EN);
        when(pav2.getValue()).thenReturn("value2");
        when(pav2.getAssignmentId()).thenReturn(2L);

        ProductAttrValueProjection pav3 = mock(ProductAttrValueProjection.class);
        when(pav3.getLang()).thenReturn(Language.EN);
        when(pav3.getValue()).thenReturn("value3");
        when(pav3.getAssignmentId()).thenReturn(3L);

        pavs.add(pav);pavs.add(pav2);pavs.add(pav3);
        groupedPAVs.put("productId", pavs);

        return groupedPAVs;
    }

    public static Map<Long, String> createAttributeAssignmentMap() {
        Map<Long, String> attributeAssignmentMap = new HashMap<>();
        attributeAssignmentMap.put(1L, "test1");
        attributeAssignmentMap.put(2L, "test2");
        attributeAssignmentMap.put(3L, "test3");

        return attributeAssignmentMap;
    }

    public static Map<String, List<AttributeAssignment>> getAttrAssignmentMap(){
        Map<String, List<AttributeAssignment>> map = new HashMap<>();
        map.put("test2", List.of(getMockAttributeAssignment(2L)));
        map.put("test3", List.of(getMockAttributeAssignment(3L)));
        map.put("test1", List.of(getMockAttributeAssignment(1L)));
        return map;
    }

    public static AttributeAssignment getMockAttributeAssignment(Long id){
        AttributeAssignment aa = new AttributeAssignment();
        Attribute a = new Attribute();
        AttributeTranslation at = new AttributeTranslation();
        at.setLanguage(Language.EN);
        at.setName("test"+id);
        a.setId("test"+id);
        a.setCode("test"+id);
        a.setAttributeTranslations(Set.of(at));
        aa.setAttribute(a);
        aa.setId(id);
        return aa;
    }

    public static Map<ProductId, Product> createProductMap(){
        Map<ProductId, Product> productMap = new HashMap<>();
        ProductId productId = ProductId.from("productId", Country.LBN);
        Product p = new Product();
        p.setId(productId);
        Media m = Media.from("testMedia", Country.LBN);
        m.setUrl("TEST_MEDIA_URL");
        p.setMedia(m);
        productMap.put(productId, p);
        return productMap;
    }
}