package com.maf.pim.testUtils;

import com.maf.pim.entity.AttributeAssignment;
import com.maf.pim.entity.Product;
import com.maf.pim.entity.ProductAttributeValue;
import com.maf.pim.entity.ProductAttributeValueId;
import com.maf.pim.enums.Country;
import com.maf.pim.enums.Language;

public class ProductAttributeValueTestUtil {

    public static ProductAttributeValue mockProductAttributeValue(Language l, Long assignmentId, String val){
        AttributeAssignment aa = new AttributeAssignment();
        aa.setId(assignmentId);
        ProductAttributeValue pav = new ProductAttributeValue();
        ProductAttributeValueId pavId = new ProductAttributeValueId();
        pavId.setLanguage(l);
        pavId.setProduct(Product.from("1234", Country.LBN));
        pavId.setAssignment(aa);
        pav.setId(pavId);
        pav.setValue(val);
        return pav;
    }
}
