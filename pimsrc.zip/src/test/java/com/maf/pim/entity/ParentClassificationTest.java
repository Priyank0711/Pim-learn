package com.maf.pim.entity;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;

class ParentClassificationTest {

    @Test
    void testEqualsHashCode() {
        ParentClassification at1 = new ParentClassification();
        at1.setId(2L);
        ParentClassification at2 = new ParentClassification();
        at2.setId(2L);
        ParentClassification at3 = new ParentClassification();
        at3.setId(3L);
        ParentClassification at4 = new ParentClassification();
        assertEquals(at1, at2);
        assertNotEquals(at1, at3);
        assertNotEquals(at1, at4);
        assertNotEquals(at4, at3);
        assertEquals(at1.hashCode(), at2.hashCode());
        assertNotEquals(at1.hashCode(), at3.hashCode());
        assertNotEquals(at3.hashCode(), at4.hashCode());
    }
}