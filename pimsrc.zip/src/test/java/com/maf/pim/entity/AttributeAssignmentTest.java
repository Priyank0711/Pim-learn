package com.maf.pim.entity;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;

class AttributeAssignmentTest {

    @Test
    void testEqualsHashCode() {
        AttributeAssignment at1 = new AttributeAssignment();
        at1.setId(2L);
        AttributeAssignment at2 = new AttributeAssignment();
        at2.setId(2L);
        AttributeAssignment at3 = new AttributeAssignment();
        at3.setId(3L);
        AttributeAssignment at4 = new AttributeAssignment();
        assertEquals(at1, at2);
        assertNotEquals(at1, at3);
        assertNotEquals(at1, at4);
        assertNotEquals(at4, at3);
        assertEquals(at1.hashCode(), at2.hashCode());
        assertNotEquals(at1.hashCode(), at3.hashCode());
        assertNotEquals(at3.hashCode(), at4.hashCode());
    }
}