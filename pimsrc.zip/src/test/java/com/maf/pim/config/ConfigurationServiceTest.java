package com.maf.pim.config;

import com.maf.pim.enums.Country;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import java.lang.reflect.Field;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

@ExtendWith(MockitoExtension.class)
class ConfigurationServiceTest {

    @InjectMocks
    private ConfigurationService configurationService;

    @BeforeEach
    void init() throws IllegalAccessException, NoSuchFieldException {
        Field enabledCountriesField = ConfigurationService.class.getDeclaredField("enabledCountries");
        enabledCountriesField.setAccessible(true);
        enabledCountriesField.set(configurationService, List.of(Country.UAE));
    }

    @Test
    void gicaSchedulerCronForCountryShouldReturnValidCronForEnabledCountry() {
        String cronExpression = configurationService.gicaSchedulerCronForCountry(Country.UAE);

        assertEquals("0 0/10 * * * *", cronExpression);
    }

    @Test
    void gicaSchedulerCronForCountryShouldReturnDisabledCronForDisabledCountry() {
        String cronExpression = configurationService.gicaSchedulerCronForCountry(Country.LBN);

        assertEquals("-", cronExpression);
    }

    @Test
    void exportProductsSchedulerCronForCountryShouldReturnValidCronForEnabledCountry() {
        String cronExpression = configurationService.exportProductsSchedulerCronForCountry(Country.UAE);

        assertEquals("0 0/10 * * * *", cronExpression);
    }

    @Test
    void exportProductsSchedulerCronForCountryShouldReturnDisabledCronForDisabledCountry() {
        String cronExpression = configurationService.exportProductsSchedulerCronForCountry(Country.LBN);

        assertEquals("-", cronExpression);
    }

    @Test
    void supplierSchedulerCronForCountryShouldReturnValidCronForEnabledCountry() {
        String cronExpression = configurationService.supplierSchedulerCronForCountry(Country.UAE);

        assertEquals("@midnight", cronExpression);
    }

    @Test
    void supplierSchedulerCronForCountryShouldReturnDisabledCronForDisabledCountry() {
        String cronExpression = configurationService.supplierSchedulerCronForCountry(Country.LBN);

        assertEquals("-", cronExpression);
    }

    @Test
    void approveMarketplaceProductsSchedulerCronForCountryShouldReturnValidCronForEnabledCountry() {
        String cronExpression = configurationService.approveMarketplaceProductsSchedulerCronForCountry(Country.UAE);

        assertEquals("0 15 */6 * * *", cronExpression);
    }

    @Test
    void approveMarketplaceProductsSchedulerCronForCountryShouldReturnDisabledCronForDisabledCountry() {
        String cronExpression = configurationService.approveMarketplaceProductsSchedulerCronForCountry(Country.LBN);

        assertEquals("-", cronExpression);
    }

    @Test
    void offHoursGicaSchedulerCronForCountryShouldReturnValidCronForEnabledCountry() {
        String cronExpression = configurationService.offHoursGicaSchedulerCronForCountry(Country.UAE);

        assertEquals("0 0 19 * * *", cronExpression);
    }

    @Test
    void offHoursGicaSchedulerCronForCountryShouldReturnDisabledCronForDisabledCountry() {
        String cronExpression = configurationService.offHoursGicaSchedulerCronForCountry(Country.LBN);

        assertEquals("-", cronExpression);
    }

}