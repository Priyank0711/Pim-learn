package com.maf.pim.populator;

import com.maf.pim.dto.ProductPatchRequest;
import com.maf.pim.entity.Product;
import com.maf.pim.enums.ProductSection;
import com.maf.pim.populator.impl.ReverseConfigurablePopulator;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.*;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class ReverseConfigurablePopulatorTest {

    @InjectMocks
    ReverseConfigurablePopulator reverseConfigurablePopulator;

    @Mock
    ReverseProductPopulator<ProductPatchRequest,Product> reverseProductPopulators;

    @Mock
    Set<ReverseProductPopulator> reverseProductPopulatorSet;
    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        Set<ReverseProductPopulator> reversePopulators = new HashSet<>();
        reversePopulators.add(reverseProductPopulators);

        when(reverseProductPopulators.getProductOption()).thenReturn(ProductSection.PROPERTIES);
        reverseConfigurablePopulator = new ReverseConfigurablePopulator(reversePopulators);
    }
    @Test
    void testPopulateWithValidInputAndOptions() {
        ProductPatchRequest source = new ProductPatchRequest();
        Product target = new Product();
        Set<ProductSection> options = Set.of(ProductSection.PROPERTIES);
        reverseConfigurablePopulator.populate(source,target,options);

        verify(reverseProductPopulators).populate(any(), any());

    }
    @Test
    void testPopulateWithNullSource() {
        Product target = new Product();
        Set<ProductSection> options = Set.of(ProductSection.PROPERTIES);

        assertThrows(IllegalArgumentException.class,
                () -> reverseConfigurablePopulator.populate(null, target, options));
        verify(reverseProductPopulators, never()).populate(any(), any());
    }

    @Test
    void testPopulateWithNullTarget() {
        ProductPatchRequest source = new ProductPatchRequest();
        Set<ProductSection> options = Set.of(ProductSection.PROPERTIES);

        assertThrows(IllegalArgumentException.class,
                () -> reverseConfigurablePopulator.populate(source, null, options));
        verify(reverseProductPopulators, never()).populate(any(), any());
    }

    @Test
    void testPopulateWithNullOptions() {

        ProductPatchRequest source = new ProductPatchRequest();
        Product target = new Product();

        assertThrows(IllegalArgumentException.class,
                () -> reverseConfigurablePopulator.populate(source, target, null));
        verify(reverseProductPopulators, never()).populate(any(), any());
    }


}
