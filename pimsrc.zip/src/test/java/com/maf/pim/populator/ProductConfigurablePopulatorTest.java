package com.maf.pim.populator;

import com.maf.pim.context.SessionContext;
import com.maf.pim.data.ProductData;
import com.maf.pim.entity.Product;
import com.maf.pim.enums.ProductPicker;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class ProductConfigurablePopulatorTest {
    @Mock
    ProductContextPopulator<Product, ProductData, SessionContext> populator1;

    @Mock
    ProductContextPopulator<Product, ProductData, SessionContext> populator2;

    @InjectMocks
    ProductConfigurablePopulator configurablePopulator;

    @Mock
    Set<ProductContextPopulator> productContextPopulators;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    void testPopulateWithValidInputAndOptions() {
        Product source = new Product();
        ProductData target = new ProductData();
        SessionContext sessionContext =new SessionContext();
        Collection<ProductPicker> options = Arrays.asList(ProductPicker.CATEGORY, ProductPicker.GALLERY);

        configurablePopulator.populate(source, target, sessionContext, options);
    }

    @Test
    void testPopulateWithNullSource() {
        ProductData target = new ProductData();
        SessionContext sessionContext =new SessionContext();
        Collection<ProductPicker> options = Arrays.asList(ProductPicker.CATEGORY, ProductPicker.GALLERY);

        assertThrows(IllegalArgumentException.class,
                () -> configurablePopulator.populate(null, target, sessionContext, options));
        verifyNoInteractions(populator1, populator2);
    }

    @Test
    void testPopulateWithNullTarget() {
        Product source = new Product();
        SessionContext sessionContext =new SessionContext();
        Collection<ProductPicker> options = Arrays.asList(ProductPicker.CATEGORY, ProductPicker.GALLERY);

        assertThrows(IllegalArgumentException.class,
                () -> configurablePopulator.populate(source, null, sessionContext, options));
        verifyNoInteractions(populator1, populator2);
    }

    @Test
    void testPopulateWithEmptyOptions() {
        Product source = new Product();
        ProductData target = new ProductData();
        SessionContext sessionContext =new SessionContext();

        assertThrows(IllegalArgumentException.class,
                () -> configurablePopulator.populate(source, target, sessionContext, Collections.emptyList()));
        verifyNoInteractions(populator1, populator2);
    }


}