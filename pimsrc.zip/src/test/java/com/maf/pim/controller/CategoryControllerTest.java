package com.maf.pim.controller;

import com.maf.pim.dto.CategoryResponsePageDto;
import com.maf.pim.enums.CategoryType;
import com.maf.pim.enums.Country;
import com.maf.pim.exceptions.ApiErrors;
import com.maf.pim.exceptions.ApiException;
import com.maf.pim.exceptions.ErrorCodes;
import com.maf.pim.exceptions.PimExceptionHandler;
import com.maf.pim.service.CategoryService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.data.domain.Pageable;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import java.util.ArrayList;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.any;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;



@ExtendWith(SpringExtension.class)
class CategoryControllerTest{

    @InjectMocks
    CategoryController controller;
    @InjectMocks
    PimExceptionHandler exceptionHandler;
    @Mock
    CategoryService service;

    private MockMvc mvc;
    @BeforeEach
    public void setUp()
    {
       mvc = MockMvcBuilders.standaloneSetup(controller).setControllerAdvice(exceptionHandler).build();
    }

    @Test
    void getCategories_throw_exception_bad_request() throws Exception {
        mvc.perform(MockMvcRequestBuilders
                        .get("/test/category")
                        .contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isBadRequest());

        mvc.perform(MockMvcRequestBuilders
                        .get("/LBN/category").param("type", "test")
                        .contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isBadRequest());


        Mockito.verify(service,Mockito.times(0)).getTopLevelCategories(any(), any(), any());
        Mockito.verify(service,Mockito.times(0)).getChildCategoryById(any(), any(), any());
    }

    @Test
    void getCategories_throw_exception_service() throws Exception {
        Mockito.doThrow(new ApiException(new ApiErrors(ErrorCodes.CATEGORY_NOT_FOUND))).when(service).getTopLevelCategories(any(), any(), any());
        mvc.perform(MockMvcRequestBuilders
                .get("/LBN/category")
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isNotFound());

        Mockito.doThrow(new RuntimeException()).when(service).getTopLevelCategories(any(), any(), any());
        mvc.perform(MockMvcRequestBuilders
                        .get("/LBN/category")
                        .contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().is5xxServerError());

        Mockito.doThrow(new ApiException(new ApiErrors(ErrorCodes.CATEGORY_NOT_FOUND))).when(service)
                .getChildCategoryById(any(), any(), any());
        mvc.perform(MockMvcRequestBuilders
                        .get("/LBN/category").param("id", "test")
                        .contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isNotFound());

        Mockito.verify(service,Mockito.times(2)).getTopLevelCategories(any(), any(), any());
        Mockito.verify(service,Mockito.times(1)).getChildCategoryById(any(), any(), any());

    }

    @Test
    void getCategories_should_not_throw_exception() throws Exception{
        ArgumentCaptor<Country> countryCaptor = ArgumentCaptor.forClass(Country.class);
        ArgumentCaptor<Pageable> pageCaptor = ArgumentCaptor.forClass(Pageable.class);
        ArgumentCaptor<CategoryType> typeCaptor = ArgumentCaptor.forClass(CategoryType.class);
        CategoryResponsePageDto responsePageDto = CategoryResponsePageDto.builder().data(new ArrayList<>()).build();

        Mockito.when(service.getTopLevelCategories(countryCaptor.capture(), typeCaptor.capture(),
                pageCaptor.capture())).thenReturn(responsePageDto);
        mvc.perform(MockMvcRequestBuilders
                .get("/LBN/category")
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());
        assertEquals(CategoryType.CLASSIFICATION, typeCaptor.getValue());
        assertEquals(Country.LBN, countryCaptor.getValue());


        Mockito.when(service.getChildCategoryById(any(), countryCaptor.capture(),
                pageCaptor.capture())).thenReturn(responsePageDto);
        mvc.perform(MockMvcRequestBuilders
                        .get("/LBN/category").param("id", "test")
                        .param("type","CLASSIFICATION")
                        .contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());
        assertEquals(CategoryType.CLASSIFICATION, typeCaptor.getValue());
        assertEquals(Country.LBN, countryCaptor.getValue());
        Mockito.verify(service,Mockito.times(1)).getTopLevelCategories(any(), any(), any());
        Mockito.verify(service,Mockito.times(1)).getChildCategoryById(any(), any(), any());

    }
    @Test
    void searchCategories_throw_exception() throws Exception {
        mvc.perform( MockMvcRequestBuilders
                        .get("/LBN/category/search")
                        .contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isBadRequest());

        mvc.perform( MockMvcRequestBuilders
                        .get("/LBN/category/search")
                        .contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isBadRequest());

        mvc.perform( MockMvcRequestBuilders
                        .get("/LBN/category/search").param("type", "test")
                        .param("search","test")
                        .contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isBadRequest());

        Mockito.doThrow(new ApiException(new ApiErrors(ErrorCodes.CATEGORY_NOT_FOUND))).when(service).getCategoriesBySearchWord(any(), any(), any());
        mvc.perform(MockMvcRequestBuilders
                        .get("/LBN/category/search")
                        .param("search","test")
                        .contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isNotFound());

        Mockito.doThrow(new RuntimeException()).when(service).getCategoriesBySearchWord(any(), any(), any());
        mvc.perform(MockMvcRequestBuilders
                        .get("/LBN/category/search")
                        .param("search","test2")
                        .contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isInternalServerError());

    }

    @Test
    void searchCategories_should_not_throw_exception() throws Exception{
        ArgumentCaptor<Country> countryCaptor = ArgumentCaptor.forClass(Country.class);
        ArgumentCaptor<CategoryType> typeCaptor = ArgumentCaptor.forClass(CategoryType.class);

        Mockito.when(service.getCategoriesBySearchWord(any(), countryCaptor.capture(), typeCaptor.capture())).thenReturn(new ArrayList<>());
        mvc.perform(MockMvcRequestBuilders
                        .get("/LBN/category/search")
                        .param("search","test")
                        .param("type","CLASSIFICATION")
                        .contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());
        assertEquals(CategoryType.CLASSIFICATION, typeCaptor.getValue());
        assertEquals(Country.LBN, countryCaptor.getValue());

    }
}