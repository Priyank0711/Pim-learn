package com.maf.pim.controller;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.maf.pim.data.SupplierGimaData;
import com.maf.pim.dto.ProductSuppliersDto;
import com.maf.pim.dto.ProductSuppliersResponse;
import com.maf.pim.enums.Country;
import com.maf.pim.exceptions.ApiErrors;
import com.maf.pim.exceptions.ApiException;
import com.maf.pim.exceptions.ErrorCodes;
import com.maf.pim.exceptions.PimExceptionHandler;
import com.maf.pim.facade.SupplierFacade;
import com.maf.pim.request.ProductSupplierRequestV1;
import com.maf.pim.request.SyncSupplierRequest;
import com.maf.pim.service.impl.SyncSupplierServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@ExtendWith(MockitoExtension.class)
class SupplierControllerTest {

    @InjectMocks
    private SupplierController supplierController;

    @InjectMocks
    private PimExceptionHandler exceptionHandler;

    @Mock
    private SupplierFacade supplierFacade;

    @Mock
    private SyncSupplierServiceImpl syncSupplierService;

    @InjectMocks
    private ObjectMapper objectMapper;

    private MockMvc mvc;

    @BeforeEach
    void setup() {
        mvc = MockMvcBuilders.standaloneSetup(supplierController).setControllerAdvice(exceptionHandler).build();
    }

    static final String BASE_REQUEST_MAPPING = "/{country}/supplier";

    @Test
    void testGetProductSuppliers_When_ProductNotFound_shouldAddErrorInResponse() throws Exception {
        ProductSuppliersResponse productSuppliersResponse = new ProductSuppliersResponse();
        productSuppliersResponse.setProductCode("test_code");
        productSuppliersResponse.setPos("test_pos");
        productSuppliersResponse.setError(ErrorCodes.PRODUCT_NOT_FOUND.getMessage());
        Mockito.when(supplierFacade.getProductSuppliersList(any(), anyList(), anyBoolean())).thenReturn(List.of(productSuppliersResponse));

        MockHttpServletResponse response = mvc.perform(MockMvcRequestBuilders
                        .post(BASE_REQUEST_MAPPING+"/", Country.JOR.name())
                        .content(new ObjectMapper().writeValueAsString(List.of()))
                        .contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON))
                .andReturn().getResponse();

        List<ProductSuppliersResponse> responses = new ObjectMapper().readValue(response.getContentAsString(), new TypeReference<>() {});
        assertEquals(HttpStatus.OK.value(), response.getStatus());
        assertEquals(responses.getFirst().getError(), ErrorCodes.PRODUCT_NOT_FOUND.getMessage());
    }

    @Test
    void testGetProductSuppliers_When_Success_shouldGiveHTTPStatusOK() throws Exception {
        MockHttpServletResponse response = mvc.perform(MockMvcRequestBuilders
                        .post(BASE_REQUEST_MAPPING+"/", Country.JOR.name())
                        .content(new ObjectMapper().writeValueAsString(List.of()))
                        .contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON))
                .andReturn().getResponse();

        assertEquals(HttpStatus.OK.value(), response.getStatus());
    }

    @Test
    void testGetProductSuppliers_When_InternalError_shouldGiveHTTPStatusINTERNAL_SERVER_ERROR() throws Exception {
        ApiErrors apiErrors = new ApiErrors(ErrorCodes.INTERNAL_SERVER_ERROR);
        Mockito.when(supplierFacade.getProductSuppliersList(Country.LBN, List.of(), true)).thenThrow(new ApiException(apiErrors));

        MockHttpServletResponse response = mvc.perform(MockMvcRequestBuilders
                        .post(BASE_REQUEST_MAPPING+"/", Country.JOR.name())
                        .content(new ObjectMapper().writeValueAsString(List.of()))
                        .contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON))
                .andReturn().getResponse();

        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR.value(), response.getStatus());
    }

    @Test
    void testGetProductSuppliers_When_InputParametersAreInvalid_shouldGiveHTTPStatusBad_Request() throws Exception {
        MockHttpServletResponse response = mvc.perform(MockMvcRequestBuilders
                        .post(BASE_REQUEST_MAPPING+"/", "TEST")
                        .contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON))
                .andReturn().getResponse();

        assertEquals(HttpStatus.BAD_REQUEST.value(), response.getStatus());
    }

    @Test
    void testGetProductSuppliersV1_When_SecondarySuppliersRequired_shouldGiveSecondarySuppliersAlso() throws Exception {
        ProductSuppliersResponse productSuppliersResponse = new ProductSuppliersResponse();
        productSuppliersResponse.setProductCode("test_code");
        productSuppliersResponse.setPos("test_pos");
        productSuppliersResponse.setSecondarySuppliers(List.of(new SupplierGimaData()));
        Mockito.when(supplierFacade.getProductSuppliersList(any(), anyList(), anyBoolean())).thenReturn(List.of(productSuppliersResponse));

        ProductSupplierRequestV1 requestV1 = new ProductSupplierRequestV1();
        List<ProductSuppliersDto> productSuppliersDtoList = List.of(new ProductSuppliersDto("123", "1"));
        requestV1.setProductSuppliersDtoList(productSuppliersDtoList);
        requestV1.setReqSecSuppliers(true);

        MockHttpServletResponse response = mvc.perform(MockMvcRequestBuilders
                        .post(BASE_REQUEST_MAPPING+"/v1", Country.JOR.name())
                        .content(new ObjectMapper().writeValueAsString(requestV1))
                        .contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON))
                .andReturn().getResponse();

        List<ProductSuppliersResponse> responses = new ObjectMapper().readValue(response.getContentAsString(), new TypeReference<>() {});
        assertEquals(HttpStatus.OK.value(), response.getStatus());
        assertEquals(1, responses.getFirst().getSecondarySuppliers().size());
    }

    @Test
    void testGetProductSuppliersV1_When_SecondarySuppliersNotRequired_shouldNotGiveSecondarySuppliersAlso() throws Exception {
        ProductSuppliersResponse productSuppliersResponse = new ProductSuppliersResponse();
        productSuppliersResponse.setProductCode("test_code");
        productSuppliersResponse.setPos("test_pos");
        productSuppliersResponse.setSecondarySuppliers(null);
        Mockito.when(supplierFacade.getProductSuppliersList(any(), anyList(), anyBoolean())).thenReturn(List.of(productSuppliersResponse));

        ProductSupplierRequestV1 requestV1 = new ProductSupplierRequestV1();
        List<ProductSuppliersDto> productSuppliersDtoList = List.of(new ProductSuppliersDto("123", "1"));
        requestV1.setProductSuppliersDtoList(productSuppliersDtoList);
        requestV1.setReqSecSuppliers(false);

        MockHttpServletResponse response = mvc.perform(MockMvcRequestBuilders
                        .post(BASE_REQUEST_MAPPING+"/v1", Country.JOR.name())
                        .content(new ObjectMapper().writeValueAsString(requestV1))
                        .contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON))
                .andReturn().getResponse();

        List<ProductSuppliersResponse> responses = new ObjectMapper().readValue(response.getContentAsString(), new TypeReference<>() {});
        assertEquals(HttpStatus.OK.value(), response.getStatus());
        assertNull(responses.getFirst().getSecondarySuppliers());
    }

    @Test
    void testSaveSupplierIds_When_Success_shouldGiveHTTPStatusOK() throws Exception {
        SyncSupplierRequest syncSupplierRequest = new SyncSupplierRequest();
        mvc.perform(MockMvcRequestBuilders.post(BASE_REQUEST_MAPPING+"/sync", Country.JOR.name())
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(syncSupplierRequest)))
                .andExpect(status().isOk())
                .andReturn();
    }
    @Test
    void testSaveSupplierIds_When_Failure_shouldGiveHTTPStatusINTERNAL_SERVER_ERROR() throws Exception {
        ApiErrors apiErrors = new ApiErrors(ErrorCodes.INTERNAL_SERVER_ERROR);
        SyncSupplierRequest syncSupplierRequest = new SyncSupplierRequest();
        when(syncSupplierService.syncSuppliers(any(), any())).thenThrow(new ApiException(apiErrors));

        MockHttpServletResponse response = mvc.perform(MockMvcRequestBuilders.post(BASE_REQUEST_MAPPING+"/sync", Country.JOR.name())
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(syncSupplierRequest)))
                .andReturn().getResponse();

        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR.value(), response.getStatus());
    }


}