package com.maf.pim.controller;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;

import java.util.Locale;
import java.util.Objects;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

@ExtendWith(MockitoExtension.class)
class HealthCheckControllerTest {
    @InjectMocks
    HealthCheckController healthController;
    @BeforeEach
    void setup() {
        MockitoAnnotations.openMocks(this);
    }
    @Test
    void testHealth()
    {
        assertTrue(Objects.requireNonNull(healthController.home(new Locale("en")).getBody()).contains("Welcome, PIM Core Service is running. The time on the server is: "));
        assertEquals(HttpStatus.OK, healthController.home(new Locale("en")).getStatusCode());

    }
}
