package com.maf.pim.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.maf.pim.dto.ProductPatchRequest;
import com.maf.pim.enums.Country;
import com.maf.pim.enums.ProductSection;
import com.maf.pim.exceptions.ApiErrors;
import com.maf.pim.exceptions.ApiException;
import com.maf.pim.exceptions.ErrorCodes;
import com.maf.pim.exceptions.PimExceptionHandler;
import com.maf.pim.facade.ProductFacade;
import com.maf.pim.request.ExportProductPagesRequest;
import com.maf.pim.request.ProductRequest;
import com.maf.pim.service.ProductService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import java.util.Set;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@ExtendWith(MockitoExtension.class)
class ProductControllerTest {
    @InjectMocks
    ProductController productController;

    @Mock
    ProductFacade productFacade;

    @Mock
    ProductService productService;

    @InjectMocks
    PimExceptionHandler exceptionHandler;

    private MockMvc mvc;

    @BeforeEach
    void setup() {
        mvc = MockMvcBuilders.standaloneSetup(productController).setControllerAdvice(exceptionHandler).build();
    }

    @Test
    void testGetProduct() {
        assertEquals(HttpStatus.OK, productController.getProduct(Country.LBN, new ProductRequest()).getStatusCode());
    }

    @Test
    void shouldReturnBadRequestIfRequestBodyIsMissing() throws Exception {
        mvc.perform(MockMvcRequestBuilders
                        .patch("/LBN/product/ /")
                        .contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isBadRequest());
    }

    @Test
    void shouldReturnBadRequestIfExportProductPagesRequestBodyIsMissing() throws Exception {
        mvc.perform(MockMvcRequestBuilders
                        .post("/LBN/product/export/paged/")
                        .contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isBadRequest());
    }

    @Test
    void testExportPagedProduct() throws Exception {
        Mockito.doNothing().when(productFacade).exportPagedProducts(any(), any());
        mvc.perform(MockMvcRequestBuilders
                        .post("/LBN/product/export/paged/")
                        .content(getExportProductPagesRequest())
                        .contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());
    }

    private static String getExportProductPagesRequest() throws JsonProcessingException {
        ExportProductPagesRequest exportProductPagesRequest = new ExportProductPagesRequest();
        exportProductPagesRequest.setStartPage(0);
        exportProductPagesRequest.setNumberOfPagesToProcess(1);
        return new ObjectMapper().writeValueAsString(exportProductPagesRequest);
    }

    @Test
    void shouldUpdateCodeAndCountryWhenCallingService() throws Exception {
        ProductPatchRequest patchProductRequest = new ProductPatchRequest();
        patchProductRequest.setSections(Set.of(ProductSection.PROPERTIES));
        mvc.perform(MockMvcRequestBuilders
                        .patch("/LBN/product/123")
                        .content(new ObjectMapper().writeValueAsString(patchProductRequest))
                        .contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());

    }

    @Test
    void shouldReturnBadRequestIfRequestBodyIsMissingForRemoveMedia() throws Exception {
        mvc.perform(MockMvcRequestBuilders
                        .post("/LBN/product/removeMedia")
                        .contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isBadRequest());
    }


    @Test
    void shouldReturnBadRequestIfRequestBodyIsInvalidForRemoveMedia() throws Exception {
        mvc.perform(MockMvcRequestBuilders
                        .post("/LBN/product/removeMedia")
                        .content("""
                                {
                                    "productCode" : "",
                                    "mediaCode" : "101862_2.jpg"
                                }""")
                        .contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isBadRequest());
    }

    @Test
    void when_GetProductInformation_InputParametersAreInvalid_shouldGiveHTTPStatusBad_Request() throws Exception {
        mvc.perform(MockMvcRequestBuilders
                        .get("/LBNA/product/  ")
                        .contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isBadRequest());
    }

    @Test
    void when_GetProductInformation_InternalError_shouldGiveHTTPStatusINTERNAL_SERVER_ERROR() throws Exception {
        ApiErrors apiErrors = new ApiErrors(ErrorCodes.INTERNAL_SERVER_ERROR);
        Mockito.when(productFacade.getProductInformation(any(), any(), any())).thenThrow(new ApiException(apiErrors));

        mvc.perform(MockMvcRequestBuilders
                        .get("/LBN/product/123")
                        .contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isInternalServerError());
    }

    @Test
    void when_GetProductInformation_Success_shouldReturnSuccessResponse() throws Exception {
        mvc.perform(MockMvcRequestBuilders
                        .get("/LBN/product/123")
                        .contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());
    }

    @Test
    void when_PatchProductDetails_InputParametersAreInvalid_shouldGiveHTTPStatusBad_Request() throws Exception {
        mvc.perform(MockMvcRequestBuilders
                        .patch("/LBN/product/123")
                        .contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isBadRequest());
    }

    @Test
    void when_PatchProductDetails_InternalError_shouldGiveHTTPStatusINTERNAL_SERVER_ERROR() throws Exception {
        ApiErrors apiErrors = new ApiErrors(ErrorCodes.INTERNAL_SERVER_ERROR);
        Mockito.when(productFacade.updateProduct(any())).thenThrow(new ApiException(apiErrors));

        mvc.perform(MockMvcRequestBuilders
                        .patch("/LBN/product/123")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("""
                                {
                                    "sections": ["ATTRIBUTES"]
                                }""")
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isInternalServerError());
    }

    @Test
    void when_PatchProductDetails_Success_shouldReturnSuccessResponse() throws Exception {
        mvc.perform(MockMvcRequestBuilders
                        .patch("/LBN/product/123")
                        .content("""
                                {
                                    "sections": ["ATTRIBUTES"]
                                }""")
                        .contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());
    }
}
