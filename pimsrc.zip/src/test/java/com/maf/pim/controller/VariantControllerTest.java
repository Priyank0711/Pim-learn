package com.maf.pim.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.maf.pim.enums.Country;
import com.maf.pim.exceptions.PimExceptionHandler;
import com.maf.pim.facade.VariantFacade;
import com.maf.pim.request.VariantRequest;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@ExtendWith(MockitoExtension.class)
class VariantControllerTest {
    @InjectMocks
    VariantController variantController;

    @Mock
    VariantFacade variantFacade;

    @InjectMocks
    PimExceptionHandler exceptionHandler;

    private MockMvc mvc;

    @BeforeEach
    void setup() {
        mvc = MockMvcBuilders.standaloneSetup(variantController).setControllerAdvice(exceptionHandler).build();
    }

    @Test
    void testGetVariant() {
        assertEquals(HttpStatus.OK, variantController.getVariant(Country.UAE, new VariantRequest()).getStatusCode());
    }

    @Test
    void shouldReturnBadRequestIfExportVariantRequestBodyIsMissing() throws Exception {
        mvc.perform(MockMvcRequestBuilders
                        .post("/LBN/variant/export/")
                        .contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isBadRequest());
    }

    @Test
    void testExportVariant() throws Exception {
        Mockito.doReturn(Collections.EMPTY_LIST).when(variantFacade).exportVariants(any(), any(), any());
        mvc.perform(MockMvcRequestBuilders
                        .post("/LBN/variant/export/")
                        .content(getExportVariantRequest())
                        .contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());
    }

    private static String getExportVariantRequest() throws JsonProcessingException {
        VariantRequest variantRequest = new VariantRequest();
        variantRequest.setSyncToEventHub(false);
        variantRequest.setCodes(List.of("V1"));
        return new ObjectMapper().writeValueAsString(variantRequest);
    }
}
