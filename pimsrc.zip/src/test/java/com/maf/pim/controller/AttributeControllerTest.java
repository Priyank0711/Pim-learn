package com.maf.pim.controller;

import com.maf.pim.dto.AttributeMetaData;
import com.maf.pim.dto.AttributeResponse;
import com.maf.pim.dto.TemplateAttributeDetails;
import com.maf.pim.enums.Country;
import com.maf.pim.exceptions.ApiErrors;
import com.maf.pim.exceptions.ApiException;
import com.maf.pim.exceptions.ErrorCodes;
import com.maf.pim.exceptions.PimExceptionHandler;
import com.maf.pim.service.TemplateAttributeService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.any;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@ExtendWith(MockitoExtension.class)
class AttributeControllerTest{
    @InjectMocks
    AttributeController controller;
    @Mock
    TemplateAttributeService service;
    @InjectMocks
    PimExceptionHandler exceptionHandler;
    private MockMvc mvc;

    @BeforeEach
    public void setUp()
    {
        mvc = MockMvcBuilders.standaloneSetup(controller).setControllerAdvice(exceptionHandler).build();
    }

    @Test
    void getAttributes_throw_exception_bad_request() throws Exception {
        //bad request: no country present with provided code
        mvc.perform(MockMvcRequestBuilders
                        .get("/test/attribute/template").param("categoryCode", "test")
                        .contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isBadRequest());

        mvc.perform(MockMvcRequestBuilders
                        .get("/test/attribute/category").param("categoryCode", "test")
                        .contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isBadRequest());

        //bad request: required parameter(categoryCode) not present
        mvc.perform(MockMvcRequestBuilders
                        .get("/LBN/attribute/template")
                        .contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isBadRequest());

        Mockito.verify(service,Mockito.times(0)).getAttributesForTemplate(any(), any());
    }

    @Test
    void getAttributes_throw_exception_service() throws Exception {
        Mockito.doThrow(new ApiException(new ApiErrors(ErrorCodes.CATEGORY_NOT_FOUND))).when(service).getAttributesForTemplate(any(), any());
        mvc.perform(MockMvcRequestBuilders
                .get("/LBN/attribute/template").param("categoryCode", "Test")
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isNotFound());

        Mockito.doThrow(new RuntimeException()).when(service).getAttributesForTemplate(any(), any());
        mvc.perform(MockMvcRequestBuilders
                        .get("/LBN/attribute/template").param("categoryCode", "Test")
                        .contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().is5xxServerError());

        Mockito.doThrow(new ApiException(new ApiErrors(ErrorCodes.TEMPLATE_ATTRIBUTE_NOT_FOUND))).when(service).getAttributesForTemplate(any(), any());
        mvc.perform(MockMvcRequestBuilders
                        .get("/LBN/attribute/template").param("categoryCode", "Test")
                        .contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isNotFound());

        Mockito.verify(service,Mockito.times(3)).getAttributesForTemplate(any(), any());
    }

    @Test
    void getAttributes_should_not_throw_exception() throws Exception{
        ArgumentCaptor<Country> countryCaptor = ArgumentCaptor.forClass(Country.class);
        ArgumentCaptor<String> codeCaptor = ArgumentCaptor.forClass(String.class);

        Mockito.when(service.getAttributesForTemplate(codeCaptor.capture(), countryCaptor.capture())).thenReturn(new AttributeResponse());
        mvc.perform(MockMvcRequestBuilders
                        .get("/LBN/attribute/template").param("categoryCode", "Test")
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());
        assertEquals("Test", codeCaptor.getValue());
        assertEquals(Country.LBN, countryCaptor.getValue());

        Mockito.when(service.getAttributesForTemplate(codeCaptor.capture(), countryCaptor.capture())).thenReturn(new AttributeResponse());
        mvc.perform(MockMvcRequestBuilders
                        .get("/LBN/attribute/category").param("categoryCode", "Test")
                        .contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());
        assertEquals("Test", codeCaptor.getValue());
        assertEquals(Country.LBN, countryCaptor.getValue());

        AttributeResponse response = new AttributeResponse();
        response.setAttributeGroups(List.of(getMockAttributeMetaData()));
        Mockito.when(service.getAttributesForTemplate(codeCaptor.capture(), countryCaptor.capture())).thenReturn(response);
        mvc.perform(MockMvcRequestBuilders
                        .get("/LBN/attribute/template").param("categoryCode", "Test")
                        .param("type","CLASSIFICATION")
                        .contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());
        assertEquals("Test", codeCaptor.getValue());
        assertEquals(Country.LBN, countryCaptor.getValue());
        Mockito.verify(service,Mockito.times(3)).getAttributesForTemplate(any(), any());

    }

    private AttributeMetaData getMockAttributeMetaData(){
        AttributeMetaData metaData = new AttributeMetaData();
        metaData.setGroupCode("code");
        metaData.setGroupName("name");
        metaData.setAttributeDetails(List.of(Mockito.mock(TemplateAttributeDetails.class)));
        return metaData;
    }
}