package com.maf.pim.mapper;

import com.maf.pim.dto.productsection.PropertiesDTO;
import com.maf.pim.entity.Product;
import com.maf.pim.enums.ApprovalStatus;
import com.maf.pim.enums.Country;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class PropertiesDTOMapperTest {

    PropertiesDTOMapper mapper = PropertiesDTOMapper.INSTANCE;

    @Test
    void when_toPropertiesDTO_shouldReturnPropertiesDTO() {
        Product product = Product.from("code", Country.LBN);
        product.setApprovalStatus(ApprovalStatus.NEW);
        product.setEan("123");

        PropertiesDTO propertiesDTO = mapper.toPropertiesDTO(product);

        assertEquals("123", propertiesDTO.getEan());
        assertEquals(ApprovalStatus.NEW, propertiesDTO.getApprovalStatus());
    }
}