package com.maf.pim.mapper;

import com.maf.pim.dto.PatchProductResponse;
import com.maf.pim.entity.Product;
import com.maf.pim.entity.translation.ProductTranslation;
import com.maf.pim.enums.Country;
import com.maf.pim.enums.Language;
import org.junit.jupiter.api.Test;

import java.util.Set;

import static org.junit.jupiter.api.Assertions.*;

class PatchProductResponseMapperTest {

    PatchProductResponseMapper patchProductResponseMapper = PatchProductResponseMapper.INSTANCE;
    @Test
    void testMapper() {
        Product product = Product.from("code", Country.LBN);
        ProductTranslation productTranslation = ProductTranslation.from(product, Language.EN);
        productTranslation.setSafetyWarnings("safety warning");
        product.setProductTranslations(Set.of(productTranslation));

        PatchProductResponse patchProductResponse = patchProductResponseMapper.productToProductResponse(product);

        assertEquals("code", patchProductResponse.getCode());
        assertEquals(Country.LBN, patchProductResponse.getCountry());
        assertEquals(1, patchProductResponse.getProductTranslations().size());
        assertEquals(Language.EN, patchProductResponse.getProductTranslations().stream().findFirst().get().getLanguage());
        assertEquals("safety warning", patchProductResponse.getProductTranslations().stream().findFirst().get().getSafetyWarnings());

    }

}