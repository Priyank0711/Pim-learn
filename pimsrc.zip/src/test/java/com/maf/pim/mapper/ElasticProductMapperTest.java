package com.maf.pim.mapper;

import com.maf.pim.data.CategoryData;
import com.maf.pim.enums.CategoryType;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

@ExtendWith(MockitoExtension.class)
class ElasticProductMapperTest {


    @Test
    void getNavCategoryName_withNonEmptyCategories_returnsName() {
        List<CategoryData> categories = List.of(
                CategoryData.builder().type(CategoryType.NAVIGATION).code("code1").name("name1").level(0).build()
        );
        String result = ElasticProductMapper.INSTANCE.getNavCategoryName(categories, 0);
        assertEquals("name1", result);
    }

    @Test
    void getNavCategoryName_withNullOrEmptyCategories_returnsNull() {
        List<CategoryData> categories = List.of();
        String result = ElasticProductMapper.INSTANCE.getNavCategoryName(categories, 0);
        assertNull(result);

        categories = List.of(
                CategoryData.builder().type(CategoryType.NAVIGATION).code("code1").name("name1").level(0).build()
        );
        result = ElasticProductMapper.INSTANCE.getNavCategoryName(categories, 1);
        assertNull(result);

        result = ElasticProductMapper.INSTANCE.getNavCategoryName(null, 0);
        assertNull(result);
    }

    @Test
    void getClassCategory_withNonEmptyCategories_returnsClassCategory() {
        List<CategoryData> categories = List.of(
                CategoryData.builder().type(CategoryType.CLASSIFICATION).code("code1").categoryName("name1").build()
        );
        String result = ElasticProductMapper.INSTANCE.getClassCategory(categories);
        assertEquals("code1-name1", result);
    }

    @Test
    void getClassCategory_withEmptyCategories_returnsNull() {
        List<CategoryData> categories = Collections.emptyList();
        String result = ElasticProductMapper.INSTANCE.getClassCategory(categories);
        assertNull(result);

        categories = List.of(
                CategoryData.builder().type(CategoryType.NAVIGATION).code("code1").categoryName("name1").build()
        );
        result = ElasticProductMapper.INSTANCE.getClassCategory(categories);
        assertNull(result);
    }
}