package com.maf.pim.mapper;

import com.maf.pim.dto.productsection.CategoryDTO;
import com.maf.pim.entity.Category;
import com.maf.pim.enums.Country;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class CategoryDTOMapperTest {

    CategoryDTOMapper mapper = CategoryDTOMapper.INSTANCE;

    @Test
    void when_toCategoryDTO_shouldReturnCategoryDTO() {
        Category category = new Category();
        category.setCode("Category Code");
        category.setId("Category Id");
        category.setCountry(Country.LBN);

        CategoryDTO categoryDTO = mapper.toCategoryDTO(category);

        assertEquals("Category Code", categoryDTO.getCode());
        assertEquals("Category Id", categoryDTO.getId());
    }
}