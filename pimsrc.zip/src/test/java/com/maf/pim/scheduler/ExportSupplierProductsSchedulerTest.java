package com.maf.pim.scheduler;

import com.maf.pim.service.ExportSupplierProductsService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.mockito.ArgumentMatchers.any;

@ExtendWith(MockitoExtension.class)
class ExportSupplierProductsSchedulerTest {

    @InjectMocks
    private ExportSupplierProductsScheduler exportSupplierProductsScheduler;

    @Mock
    private ExportSupplierProductsService exportSupplierProductsService;

    @Test
    void testExportSchedulerJob() {
        exportSupplierProductsScheduler.exportSchedulerJob();
        Mockito.verify(exportSupplierProductsService, Mockito.times(1)).executeJob(any(), any());
    }
    @Test
    void testExportSchedulerJobKwt() {
        exportSupplierProductsScheduler.exportKwtSchedulerJob();
        Mockito.verify(exportSupplierProductsService, Mockito.times(1)).executeJob(any(), any());
    }
    @Test
    void testExportSchedulerJobBhr() {
        exportSupplierProductsScheduler.exportBhrSchedulerJob();
        Mockito.verify(exportSupplierProductsService, Mockito.times(1)).executeJob(any(), any());
    }
    @Test
    void testExportSchedulerJobUae() {
        exportSupplierProductsScheduler.exportUaeSchedulerJob();
        Mockito.verify(exportSupplierProductsService, Mockito.times(1)).executeJob(any(), any());
    }
    @Test
    void testExportSchedulerJobQat() {
        exportSupplierProductsScheduler.exportQatSchedulerJob();
        Mockito.verify(exportSupplierProductsService, Mockito.times(1)).executeJob(any(), any());
    }

    @Test
    void testExportSchedulerJobOmn() {
        exportSupplierProductsScheduler.exportOmnSchedulerJob();
        Mockito.verify(exportSupplierProductsService, Mockito.times(1)).executeJob(any(), any());
    }

}