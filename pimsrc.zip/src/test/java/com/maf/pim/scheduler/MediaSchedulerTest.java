package com.maf.pim.scheduler;

import com.maf.pim.enums.Country;
import com.maf.pim.service.MediaUploadService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class MediaSchedulerTest {
    @InjectMocks
    MediaScheduler mediaScheduler;

    @Mock
    MediaUploadService mediaUploadService;

    @Test
    void testScheduleJob() {
        mediaScheduler.scheduleJob();
        Mockito.verify(mediaUploadService,Mockito.times(1)).uploadMedia();
    }
}