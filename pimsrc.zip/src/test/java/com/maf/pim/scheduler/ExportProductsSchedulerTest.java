package com.maf.pim.scheduler;

import com.maf.pim.service.ExportProductsService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.mockito.ArgumentMatchers.any;

@ExtendWith(MockitoExtension.class)
class ExportProductsSchedulerTest {
    @InjectMocks
    ExportProductsScheduler exportProductsScheduler;

    @Mock
    ExportProductsService exportProductsService;

    @Test
    void testExportSchedulerJob() {
        exportProductsScheduler.exportSchedulerJob();
        Mockito.verify(exportProductsService,Mockito.times(1)).executeJob(any(), any());
    }

    @Test
    void testExportSchedulerJobKen() {
        exportProductsScheduler.exportSchedulerJobKen();
        Mockito.verify(exportProductsService,Mockito.times(1)).executeJob(any(), any());
    }

    @Test
    void testExportSchedulerJobPak() {
        exportProductsScheduler.exportSchedulerJobPak();
        Mockito.verify(exportProductsService,Mockito.times(1)).executeJob(any(), any());
    }

    @Test
    void testExportSchedulerJobJor() {
        exportProductsScheduler.exportSchedulerJobJor();
        Mockito.verify(exportProductsService,Mockito.times(1)).executeJob(any(), any());
    }

    @Test
    void testExportSchedulerJobKwt() {
        exportProductsScheduler.exportSchedulerJobKwt();
        Mockito.verify(exportProductsService,Mockito.times(1)).executeJob(any(), any());
    }

    @Test
    void testExportSchedulerJobBhr() {
        exportProductsScheduler.exportSchedulerJobBhr();
        Mockito.verify(exportProductsService,Mockito.times(1)).executeJob(any(), any());
    }

    @Test
    void testExportSchedulerJobSau() {
        exportProductsScheduler.exportSchedulerJobSau();
        Mockito.verify(exportProductsService,Mockito.times(1)).executeJob(any(), any());
    }

    @Test
    void testExportSchedulerJobSauMkt() {
        exportProductsScheduler.exportSchedulerJobSauMtK();
        Mockito.verify(exportProductsService,Mockito.times(1)).executeJob(any(), any());
    }

    @Test
    void testExportSchedulerJobUae() {
        exportProductsScheduler.exportSchedulerJobUae();
        Mockito.verify(exportProductsService,Mockito.times(1)).executeJob(any(), any());
    }

    @Test
    void testExportSchedulerJobQat() {
        exportProductsScheduler.exportSchedulerJobQat();
        Mockito.verify(exportProductsService,Mockito.times(1)).executeJob(any(), any());
    }
    @Test
    void testExportSchedulerJobEgy() {
        exportProductsScheduler.exportSchedulerJobEgy();
        Mockito.verify(exportProductsService,Mockito.times(1)).executeJob(any(), any());
    }

    @Test
    void testExportSchedulerJobEgyMkt() {
        exportProductsScheduler.exportSchedulerJobEgyMtK();
        Mockito.verify(exportProductsService,Mockito.times(1)).executeJob(any(), any());
    }

    @Test
    void testExportSchedulerJobOmn() {
        exportProductsScheduler.exportSchedulerJobOmn();
        Mockito.verify(exportProductsService,Mockito.times(1)).executeJob(any(), any());
    }
}