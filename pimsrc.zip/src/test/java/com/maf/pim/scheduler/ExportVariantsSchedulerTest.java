package com.maf.pim.scheduler;

import com.maf.pim.service.ExportVariantsService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.mockito.ArgumentMatchers.any;


@ExtendWith(MockitoExtension.class)
class ExportVariantsSchedulerTest {
    @InjectMocks
    ExportVariantsScheduler variantsScheduler;

    @Mock
    ExportVariantsService exportVariantsService;

    @Test
    void testExportSchedulerJobUae() {
        variantsScheduler.exportSchedulerJobUae();
        Mockito.verify(exportVariantsService,Mockito.times(1)).executeJob(any(), any());
    }
}