package com.maf.pim.scheduler;

import com.maf.pim.enums.Country;
import com.maf.pim.service.BlobFileService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import static com.maf.pim.constants.Constants.OFF_HOURS_INPUT_PATH;

@ExtendWith(MockitoExtension.class)
class GicaJobSchedulerTest {
    @InjectMocks
    GicaJobScheduler gicaJobScheduler;

    @Mock
    BlobFileService blobFileService;

    @Test
    void testGicaIntegrationLbnSchedulerJob() {
        gicaJobScheduler.gicaIntegrationLbnSchedulerJob();
        Mockito.verify(blobFileService,Mockito.times(1)).executeJob(Country.LBN);
    }

    @Test
    void testGicaIntegrationKenSchedulerJob() {
        gicaJobScheduler.gicaIntegrationKenSchedulerJob();
        Mockito.verify(blobFileService,Mockito.times(1)).executeJob(Country.KEN);
    }

    @Test
    void testGicaIntegrationPakSchedulerJob() {
        gicaJobScheduler.gicaIntegrationPakSchedulerJob();
        Mockito.verify(blobFileService,Mockito.times(1)).executeJob(Country.PAK);
    }

    @Test
    void testGicaIntegrationJorSchedulerJob() {
        gicaJobScheduler.gicaIntegrationJorSchedulerJob();
        Mockito.verify(blobFileService,Mockito.times(1)).executeJob(Country.JOR);
    }

    @Test
    void testGicaIntegrationKwtSchedulerJob() {
        gicaJobScheduler.gicaIntegrationKwtSchedulerJob();
        Mockito.verify(blobFileService,Mockito.times(1)).executeJob(Country.KWT);
    }

    @Test
    void testGicaIntegrationBhrSchedulerJob() {
        gicaJobScheduler.gicaIntegrationBhrSchedulerJob();
        Mockito.verify(blobFileService,Mockito.times(1)).executeJob(Country.BHR);
    }

    @Test
    void testGicaIntegrationSauSchedulerJob() {
        gicaJobScheduler.gicaIntegrationSauSchedulerJob();
        Mockito.verify(blobFileService,Mockito.times(1)).executeJob(Country.SAU);
    }

    @Test
    void testGicaIntegrationUaeSchedulerJob() {
        gicaJobScheduler.gicaIntegrationUaeSchedulerJob();
        Mockito.verify(blobFileService,Mockito.times(1)).executeJob(Country.UAE);
    }

    @Test
    void testGicaIntegrationQatSchedulerJob() {
        gicaJobScheduler.gicaIntegrationQatSchedulerJob();
        Mockito.verify(blobFileService,Mockito.times(1)).executeJob(Country.QAT);
    }

    @Test
    void testGicaIntegrationEgySchedulerJob() {
        gicaJobScheduler.gicaIntegrationEgySchedulerJob();
        Mockito.verify(blobFileService,Mockito.times(1)).executeJob(Country.EGY);
    }

    @Test
    void testGicaIntegrationOmnSchedulerJob() {
        gicaJobScheduler.gicaIntegrationOmnSchedulerJob();
        Mockito.verify(blobFileService,Mockito.times(1)).executeJob(Country.OMN);
    }

    @Test
    void testOffHoursGicaIntegrationUAESchedulerJob() {
        gicaJobScheduler.offHoursGicaIntegrationUae();
        Mockito.verify(blobFileService,Mockito.times(1)).executeJob(Country.UAE, OFF_HOURS_INPUT_PATH);
    }
}