package com.maf.pim.scheduler;

import com.maf.pim.service.ExportProductsService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.mockito.ArgumentMatchers.any;

@ExtendWith(MockitoExtension.class)
class SanityExportProductsSchedulerTest {
    @InjectMocks
    SanityExportProductsScheduler sanityExportProductsScheduler;

    @Mock
    ExportProductsService exportProductsService;

    @Test
    void testSanityExportSchedulerJob() {
        sanityExportProductsScheduler.exportSchedulerJob();
        Mockito.verify(exportProductsService,Mockito.times(1)).executeJob(any(), any());
    }
}