package com.maf.pim.constants;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

public class ConstantsTest {

    @Test
    void testConstantsInitialization() {
        assertThrows(IllegalStateException.class, Constants::new);
    }

    @Test
    void testConstantsValues() {
        assertEquals("^\\d+_(main|\\d+)\\.(jpg|jpeg|png|gif)$", Constants.FILE_PATTERN);
        assertEquals(204800, Constants.MAX_FILE_SIZE_KB);
        assertEquals("(\\d+)_([a-zA-Z0-9]+)\\.(jpg|jpeg|png|gif)", Constants.TEMP_FILENAME_PATTERN);
        assertEquals("StrictHostKeyChecking", Constants.HOST_KEY);
        assertEquals("no", Constants.SFTP_CONFIG);
        assertEquals("archive/", Constants.ARCHIVE_PATH);
        assertEquals("error/", Constants.ERROR_PATH);
        assertEquals("input/", Constants.INPUT_PATH);
        assertEquals("main", Constants.MAIN_FILE);
        assertEquals("input_(.+?)#", Constants.GICA_FILE_PATTERN);
        assertEquals(".CSV", Constants.CSV_EXTENSION);
        assertEquals("_SUCCESS", Constants.SUCCESS);
        assertEquals("_ERROR", Constants.ERROR);
        assertEquals("Kilo", Constants.KILO);
        assertEquals("piece", Constants.PIECE);
        assertEquals("express", Constants.EXPRESS);
        assertEquals("bulk", Constants.BULK);
        assertEquals("maflbn-export-products", Constants.LBN_EXPORT_JOB_CODE);
        assertEquals("productId", Constants.PRODUCT_ID);
        assertEquals("version", Constants.VERSION);
        assertEquals("format", Constants.FORMAT);
        assertEquals("fullName", Constants.FULL_NAME);
        assertEquals("https://[^/]+/(.+)$", Constants.REMOTE_PATH_PATTERN);
    }
}
